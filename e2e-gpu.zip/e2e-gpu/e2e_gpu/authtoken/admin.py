from django.contrib import admin
from safedelete.admin import SafeDeleteAdmin

from authtoken.models import ApiToken, CustomAPIToken


class ApiTokenAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "deleted_at",
        "id",
        "token_name",
        "created_by",
        "created_at",
        "updated_at",
        "project",
        "is_active",
    )
    raw_id_fields = ("created_by", "project",)
    search_fields = ("id", "project", "created_by__email",)
    list_filter = (
        "deleted", "deleted_at")
    list_display_links = ("id",)
    list_select_related = ("created_by", "project",)


class CustomAPITokenAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "deleted_at",
        "id",
        "expiry",
        "token_name",
        "created_by",
        "created_at",
        "updated_at",
        "project",
        "is_active",
        "service_name"
    )
    raw_id_fields = ("created_by", "project",)
    search_fields = ("id", "project", "created_by__email",)
    list_filter = (
        "deleted", "deleted_at")
    list_display_links = ("id",)
    list_select_related = ("created_by", "project",)


admin.site.register(CustomAPIToken, CustomAPITokenAdmin)
admin.site.register(ApiToken, ApiTokenAdmin)
