import logging

from rest_framework import status

from authtoken.constants import API_TOKEN_CREATE_EVENT, API_TOKEN_DELETE_EVENT, CUSTOM_API_TOKEN_CREATE_EVENT, \
    CUSTOM_API_TOKEN_DELETE_EVENT
from eventlogs.api.v1.services.eventlog_service import EventLogService
from eventlogs.constants import API_TOKEN_SERVICE_CODE, EVENTLOG_SUCCESS_STATUS, CUSTOM_API_TOKEN_SERVICE_CODE
from rbac.constants import CREATE, DELETE

logger = logging.getLogger(__name__)


def api_token_create_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(API_TOKEN_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=API_TOKEN_CREATE_EVENT,
            resource_name=request.data["token_name"],
            resource_id="",
            detailed_info={"request": request.data, "project_id": kwargs.get('project_id')},
            resource_obj_id=None,
            event_type=CREATE,
        )
        response = func(*args, **kwargs)
        if response.status_code == status.HTTP_201_CREATED:
            event_log.update_log(status=EVENTLOG_SUCCESS_STATUS, resource_id=response.data["data"]["id"],
                                 detailed_info={"response": response.data["data"]},
                                 resource_obj_id=response.data["data"]["id"])
        else:
            event_log.log_event_failure()
        return response

    return wrapper_func


def api_token_delete_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(API_TOKEN_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=API_TOKEN_DELETE_EVENT,
            resource_name=kwargs.get("token").token_name,
            resource_id=kwargs.get("token_id"),
            detailed_info={"project_id": kwargs.get('project_id')},
            resource_obj_id=kwargs.get("token_id"),
            event_type=DELETE,
        )
        response = func(*args, **kwargs)
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else \
            event_log.log_event_failure()
        return response

    return wrapper_func


def custom_api_token_create_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(CUSTOM_API_TOKEN_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=CUSTOM_API_TOKEN_CREATE_EVENT,
            resource_name=request.data["token_name"],
            resource_id="",
            detailed_info={"request": request.data, "project_id": kwargs.get("project_id")},
            resource_obj_id=None,
            event_type=CREATE,
        )
        response = func(*args, **kwargs)
        if response.status_code == status.HTTP_201_CREATED:
            event_log.update_log(status=EVENTLOG_SUCCESS_STATUS, resource_id=response.data["data"]["id"],
                                 detailed_info={"project_id": kwargs.get("project_id"), "auth_token": response.data["data"]["auth_token"], "service_name": response.data["data"]["service_name"]},
                                 resource_obj_id=response.data["data"]["id"])
        else:
            event_log.log_event_failure()
        return response

    return wrapper_func


def custom_api_token_delete_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(CUSTOM_API_TOKEN_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=CUSTOM_API_TOKEN_DELETE_EVENT,
            resource_name=kwargs.get("token").token_name,
            resource_id=kwargs.get("token_id"),
            detailed_info={"project_id": kwargs.get("project_id")},
            resource_obj_id=kwargs.get("token_id"),
            event_type=DELETE,
        )
        response = func(*args, **kwargs)
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else \
            event_log.log_event_failure()
        return response

    return wrapper_func
