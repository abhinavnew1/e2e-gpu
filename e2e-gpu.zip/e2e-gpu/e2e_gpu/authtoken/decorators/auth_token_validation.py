from rest_framework.response import Response

from authtoken.models import ApiToken, CustomAPIToken
from e2e_core.api.v1.services.base import BaseService
from e2e_core.constants import NOT_FOUND_ERROR


def validate_api_token_delete_request(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        token_id = kwargs.get("token_id", "")
        project_id = kwargs.get("project_id")
        token = ApiToken.objects.filter(created_by=request.customer,
                                        deleted_at__isnull=True, id=token_id, project_id=project_id). \
            select_related("project").last()
        if not token:
            response = BaseService.get_404_response(NOT_FOUND_ERROR.format(service="Api-Token"))
            return Response(response, status=response.get("code"))
        kwargs["token"] = token
        return func(*args, **kwargs)

    return wrapper_func


def validate_custom_api_token_delete_request(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        token_id = kwargs.get("token_id")
        project_id = kwargs.get("project_id")
        token = CustomAPIToken.objects.filter(created_by=request.customer,
                                              deleted_at__isnull=True, id=token_id, project_id=project_id).last()
        if not token:
            response = BaseService.get_404_response(NOT_FOUND_ERROR.format(service="Api-Token"))
            return Response(response, status=response.get("code"))
        kwargs["token"] = token
        return func(*args, **kwargs)

    return wrapper_func
