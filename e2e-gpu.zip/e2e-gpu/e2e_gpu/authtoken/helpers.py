import json

import requests
from django.conf import settings
from rest_framework import status

ADD_CONTACT_PERSON_ENDPOINT = settings.MYACCOUNT_LB_URL + \
                              "api/v1/apis/token/"


def create_api_key_in_my_account(auth_header, token_name):
    url = ADD_CONTACT_PERSON_ENDPOINT
    data = {
                "token_name": token_name,
                "access_name": [
                    "read",
                    "write"
                ]
            }
    headers = {"Authorization": auth_header,
               "Content-Type": "application/json"}
    response = requests.request("POST", url, data=json.dumps(data), headers=headers)
    if response.status_code != status.HTTP_200_OK:
        return False, response.json().get('errors')
    return True, response.json()["data"]


def delete_api_key_in_my_account(auth_header, token_name, apikey):
    url = f"{ADD_CONTACT_PERSON_ENDPOINT}?token_name={token_name}&apikey={apikey}"
    headers = {"Authorization": auth_header,
               "Content-Type": "application/json"}
    response = requests.request("DELETE", url, headers=headers)
    if response.status_code != status.HTTP_200_OK:
        return False, response.json().get('errors')
    return True, response.json()["data"]


def format_email(email):
    email = email.replace('@', '-')
    email = email.replace('.', '-')
    email = email.replace('+', '-')
    email = email.replace('_', '-')
    email = f"u-{email}"
    return email
