from datetime import datetime

from django.db import models

from authtoken.constants import (API_KEY_MAXIMUM_LENGTH,
                                 AUTH_TOKEN_MAXIMUM_LENGTH,
                                 TOKEN_NAME_MAXIMUM_LENGTH, SERVICE_NAME_TOKEN_CHOICES)
from customer.models import Customer
from e2e_core.helpers import mark_delete_related_objects
from e2e_core.mixins import BaseMixin, SafeDeleteMixinExtended
from projects.models import Projects


class ApiToken(SafeDeleteMixinExtended, BaseMixin):
    project = models.ForeignKey(Projects, null=True, on_delete=models.CASCADE)
    token_name = models.CharField(max_length=TOKEN_NAME_MAXIMUM_LENGTH, unique=True)
    api_key = models.CharField(max_length=API_KEY_MAXIMUM_LENGTH, null=True)
    auth_token = models.TextField(max_length=AUTH_TOKEN_MAXIMUM_LENGTH)
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    is_active = models.BooleanField(default=False)
    is_default = models.BooleanField(default=False)
    created_by = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True)

    def mark_deleted(self):
        if self.deleted_at is None:
            mark_delete_related_objects(self)
            self.deleted_at = datetime.now()
            self.save(update_fields=['deleted_at', 'updated_at',])


class CustomAPIToken(SafeDeleteMixinExtended, BaseMixin):
    project = models.ForeignKey(Projects, on_delete=models.CASCADE)
    token_name = models.CharField(max_length=TOKEN_NAME_MAXIMUM_LENGTH)
    auth_token = models.TextField(max_length=AUTH_TOKEN_MAXIMUM_LENGTH, blank=True)
    expiry = models.DateTimeField(default=None, null=True, blank=True)
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    is_active = models.BooleanField(default=True, null=True )
    service_name = models.CharField(choices=SERVICE_NAME_TOKEN_CHOICES, max_length=256)
    created_by = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True)

    def mark_deleted(self):
        if self.deleted_at is None:
            mark_delete_related_objects(self)
            self.deleted_at = datetime.now()
            self.is_active = False
            self.save(update_fields=['deleted_at', 'updated_at','is_active',])
