NOTEBOOK_LINE_ITEM_UNIQUE_ID = "notebook_{nb_history_id}"
NB_PVC_LINE_ITEM_UNIQUE_ID = "notebook_pvc_{pvc_history_id}"
DATASET_PVC_LINE_ITEM_UNIQUE_ID = "disk_dataset_{pvc_history_id}"
INFERENCE_LINE_ITEM_UNIQUE_ID = "inference_{inf_history_id}"
MODEL_PLAYGROUND_LINE_ITEM_UNIQUE_ID = "mp_{model_name}_{project_id}"
VECTOR_DB_LINE_ITEM_UNIQUE_ID = "vectordb_{vdb_history_id}"
VECTOR_DB_PVC_LINE_ITEM_UNIQUE_ID = "vectordb_pvc_{pvc_history_id}"

# error msgs
DATETIME_TYPE_ERROR = "cycle_startdate and cycle_enddate should be an instance of datetime.datetime"
INVALID_BILLING_DATETIME_ERROR = "cycle_startdate must be less than cycle_enddate"
INVALID_LOCATION_ERROR = "Invalid Location"
FREE_USAGE_INVALID_DATE = "The start_date and end_date must be of the same month"
ROUND_DIGITS = 2
PIPELINE_RUN_LINE_ITEM_UNIQUE_ID = "pipeline_run_{run_history_id}"
