from django.contrib import admin
from safedelete.admin import SafeDeleteAdmin

from container_registry.models import NamespaceDetail, RobotAccountDetail


class NamespaceDetailAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "namespace",
        "id",
        "created_at",
        "created_by",
        "deleted_at",
        "registry_endpoint",
    )
    raw_id_fields = (
        "created_by",
        "project",
    )
    search_fields = ("id", "namespace", "created_by__email",)
    list_display_links = ("id", "namespace")
    list_select_related = ("created_by", "project",)


class RobotAccountDetailAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "robot_account_id",
        "username",
        "namespace_detail",
    )
    raw_id_fields = ("namespace_detail",)
    search_fields = ("id", "username", "robot_account_id",)
    list_display_links = ("id", "username")
    list_select_related =   ("namespace_detail",)


admin.site.register(NamespaceDetail, NamespaceDetailAdmin)
admin.site.register(RobotAccountDetail, RobotAccountDetailAdmin)
