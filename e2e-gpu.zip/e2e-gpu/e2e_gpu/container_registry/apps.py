from django.apps import AppConfig


class ContainerRegistryConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "container_registry"
