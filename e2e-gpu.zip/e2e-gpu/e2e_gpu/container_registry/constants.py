from django.conf import settings

HARBOR_URL = settings.HARBOR_URL
DOMAIN_NAME = settings.DOMAIN_NAME
BASE_PATH = "/api/v2.0/"
HARBOR_BASIC_AUTH = settings.HARBOR_BASIC_AUTH
HARBOR_BASE_URL = HARBOR_URL + BASE_PATH
# HARBOR PROJECTS URLS
PROJECTS = "projects"
URL_SEPARTOR = "/"
PROJECT_SUMMARY = "/summary"
ROBOT_ACCOUNT = "robots"
REPOSITORIES = "/repositories"
PROJECTS_DETALLS = "projects/"
ARTIFACTS = "/artifacts"
PROJECTS_URL = HARBOR_BASE_URL + PROJECTS
PROJECTS_NAME_URL = HARBOR_BASE_URL + PROJECTS + URL_SEPARTOR
PROJECTS_DELETE_URL = HARBOR_BASE_URL + PROJECTS + URL_SEPARTOR
ROBOT_ACCOUNT_URL = HARBOR_BASE_URL + ROBOT_ACCOUNT
PROJECTS_DETALLS_URL = HARBOR_BASE_URL + PROJECTS_DETALLS
HARBOR_PROJECT_INITIAL_ID = 0
HARBOR_PROJECT_STORAGE_LIMIT = -1  # UNLIMITED
DEFAULT_PEAK_USAGE = 0
CONTAINER_REGISTRY_SETUP_STARTED = "Container Registry Setup InProgress"
CUSTOMER_ATTACHED_WITH_PROJECT = "Customer Attached With Project"
CUSTOMER_DELETED_FROM_HARBOR = "Harbor Customer Deleted Successfully"
PROJECT_DELETED_SUCCESSFULLY = "Project Deleted Successfully"
CONTAINER_REGISTRY_CREATED_SUCCESSFULLY = "Container Registry Created Successfully"
CONTAINER_REGISTRY_DELETED_SUCCESSFULLY = "Container Registry Deleted Successfully"
CUSTOMER_DELETION_ERROR = "Error in customer deletion from Harbor"
PROJECT_DELETION_ERROR = "Error in project deletion from Harbor"
REPOSITORY_DELETED_SUCCESSFULLY = "Repository Deleted Successfully"
ARTIFACTS_DELETED_SUCCESSFULLY = "Artifacts Deleted Successfully"
CONTAINER_REGISTRY = "CONTAINER_REGISTRY"
CONTAINER_REGISTRY_FREE = "CONTAINER_REGISTRY_FREE"
CREATE_HARBOR_CUSTOMER = "CREATE_HARBOR_CUSTOMER"
CREATE_HARBOR_PROJECT = "CREATE_HARBOR_PROJECT"
CRITICAL_RED = "CRITICAL_RED"
CRITICAL_GREEN = "CRITICAL_GREEN"
CRITICAL_YELLOW = "CRITICAL_YELLOW"
ARTIFACTS_SERVICE = "ARTIFACTS_SERVICE"
SCANNER_SERVICE = "SCANNER_SERVICE"
HARBOR_SERVICE = "HARBOR_SERVICE"
HARBOR_PROJECT = "HARBOR_PROJECT"
HARBOR_CUSTOMER_DO_NOT_EXIST = "NO Harbor Customer Found"
DB_RECORD_NOT_FOUND = "No record found in DB"
SCANNING_STARTED = "SCANNING STARTED SUCCESSFULLY"
SCANNING_STOPPED = "SCANNING STOPPED SUCCESSFULLY"
PROJECT_ALREADY_EXIST = "Namespace name already exist. Use different namespace."
USER_NOT_AUTHORIZED = "USER NOT AUTHORIZED"
SCAN_IMAGES_CRON_SUBJECT = "SCAN CONTAINER REGISTRY CRON REPORT"
CONTAINER_REGISTRY_PEAK_USAGE = "CONTAINER REGISTRY PEAK USAGE REPORT"
PROJECT_SIZE_ERROR = "Error in Fetching Usage of Project"
MAXIMUM_CHARACTER_SIZE = 256
URL_RESERVED_CHARACTERS = {
    "$": "%24",
    "&": "%26",
    "+": "%2b",
    ",": "%2c",
    "/": "%252f",
    ":": "%3a",
    ";": "%3b",
    "=": "%3d",
    "?": "%3f",
    "@": "%40",
}
USERS = "users/"
PROJECTS = "projects/"
LOGS = "/logs"
PASSWORD = "/password"
SCANNER = "/scanner"
SCAN = "/scan"
STOP = "/stop"
ADDITIONS = "/additions"
VULNERABILITIES = "/vulnerabilities"
HEADERS = {
    "Content-Type": "application/json;charset=UTF-8",
    "Accept": "application/json",
    "Accept-Charset": "UTF-8",
    "Accept-Encoding": "gzip",
}
GET = "GET"
POST = "POST"
DELETE = "DELETE"
PUT = "PUT"
HEAD = "HEAD"
ADMIN = "admin"
PROJECT_NAME_MISSING = "Project Name is Missing from in the Request"
PROJECT_NAME_OR_ID_MISSING = "Project Name or Project ID is Missing from in the Request"
PROJECT_NAME_OR_REPO_NAME_MISSING = (
    "Project Name or Repository Name is Missing from in the Request"
)
PROJECT_NAME_OR_REPO_NAME_OR_REFERENCE_MISSING = (
    "Project Name or Repository Name or Reference is Missing from "
    "in the Request or Action Type is Not Correct"
)
RETRY_LIMIT = 3
RETRY_DELAY_TIME = 5
SETUP_IN_PROGRESS = "Container Registry Setup In Progress"
DELETION_REQUEST_INITIATED = "Container Registry Deletion Started"
CONTAINER_REGISTRY_SETUP_TASK = "container_registry_setup"
CONTAINER_REGISTRY_DELETION_TASK = "container_registry_deletion"
PASSWORD_RESET_SUCCESSFUL = "PASSWORD RESET DONE SUCCESSFULLY"
PROJECT_NOT_FOUND = "Project Not Found"
DEFAULT_PASSWORD_LENGTH = 15
PROJECT_SIZE_INTO_GB = 1000000000
PROJECT_SIZE_INTO_MB = 1000000
FREE_CONTAINER_REGISTRY_SIZE = 1000000000
ROUND_OF_DIGITS = 2
ROLE_ID = 1
PER_PAGE_COUNT = 100
IS_PUBLIC = False
CEVERITY = "high"
PROJECT = "PROJECT"
CREATE_CONTAINER_REGISTRY = "CREATE"
DELETE_CONTAINER_REGISTRY = "DELETE"
AUDIT_LOG_EVENTS = (
    (CREATE_CONTAINER_REGISTRY, CREATE_CONTAINER_REGISTRY),
    (DELETE_CONTAINER_REGISTRY, DELETE_CONTAINER_REGISTRY),
)
SCANNING_START = "start"
SUCCESS = "Success"
EMAIL = "Email"
PROJECT_NAME = "Project Name"
USAGE = "usage"
ERROR = "Error"
SCANNING_STOP = "stop"
SCANNING_ACTION = [SCANNING_START, SCANNING_STOP]
SEVERITY_LEVEL_CRITICAL = "critical"
SEVERITY_LEVEL_HIGH = "high"
SEVERITY_LEVEL_MEDIUM = "medium"
SEVERITY_LEVEL_LOW = "low"
SEVERITY_LEVEL_NONE = "none"
SEVERITY_LEVEL_CHOICES = (
    (SEVERITY_LEVEL_CRITICAL, SEVERITY_LEVEL_CRITICAL),
    (SEVERITY_LEVEL_HIGH, SEVERITY_LEVEL_HIGH),
    (SEVERITY_LEVEL_MEDIUM, SEVERITY_LEVEL_MEDIUM),
    (SEVERITY_LEVEL_LOW, SEVERITY_LEVEL_LOW),
    (SEVERITY_LEVEL_NONE, SEVERITY_LEVEL_NONE),
)
SCAN_IMAGE_ON_PUSH = "true"
DONT_SCAN_IMAGE_ON_PUSH = "false"
VULNERABILITY_SCANNING_CHOICES = (
    (DONT_SCAN_IMAGE_ON_PUSH, DONT_SCAN_IMAGE_ON_PUSH),
    (SCAN_IMAGE_ON_PUSH, SCAN_IMAGE_ON_PUSH),
)

PROJECT_UPDATED_MESSAGE = "Successfully Updated"

# Error or Success message
PROJECT_NOT_CREATED = "No Project Found For Customer. Please, First Create a Project!!"
REGISTRY_NAME_ALREADY_TAKEN = (
    "{name} name for Registry is already taken. Please Try with other name."
)
RESOURCE_SUCCESSFULLY_CREATED = "{name} Created Successfully"
RESOURCE_NOT_FOUND = "Requested {name} not Found"
RESOURCE_CREATION_FAILED = "{name} Creation Failed"
RESOURCE_UPDATION_FAILED = "{name} Updation Failed"
RESOURCE_SUCCESSFULLY_UPDATED = "{name} Updated Successfully"
REGISTRY_CANNOT_BE_DELETED = (
    "Registry cannot be deleted since it is a part of a replication policy."
)
RESOURCE_DELETION_FAILED = "{name} Deletion Failed"
RESOURCE_SUCCESSFULLY_DELETED = "{name} Deleted Successfully"
POLICY_NAME_ALREADY_TAKEN = (
    "{name} name for Policy is already taken. Please Try with other name."
)
RESOURCE_FETCHED_SUCCESSFULLY = "{name} fetched Successfully"
RESOURCE_FETCHING_FAILED = "{name} Fetching Failed"
RESOURCE_SUCCESSFULLY_EXECUTED = "{name} Executed Successfully"
RESOURCE_EXECUTION_FAILED = "{name} Failed"
RESOURCE_EXECUTION_STOPPED = "{name} Stopped"
RESOURCE_EXECUTION_COMPLETED = "{name} Completed"
NAME_UNAVAILABLE = "Name Not Available"
NAME_AVAILABLE = "Name is Available"
INVALID_NAME_ERROR = "name should be at least 2 characters long with lower case characters, numbers and ._- and must be start with characters or numbers"

# project name regex
NAME_REGEX = r"[a-z0-9]([._-]?[a-z0-9])+"
ROBOT_ACCOUNT_PROJECT_ACCESS_PERMISSION = [
    {"resource": "repository", "action": "list"},
    {"resource": "repository", "action": "pull"},
    {"resource": "repository", "action": "push"},
    {"resource": "repository", "action": "delete"},
    {"resource": "artifact", "action": "read"},
    {"resource": "artifact", "action": "list"},
    {"resource": "artifact", "action": "delete"},
    {"resource": "artifact-label", "action": "create"},
    {"resource": "artifact-label", "action": "delete"},
    {"resource": "tag", "action": "create"},
    {"resource": "tag", "action": "delete"},
    {"resource": "tag", "action": "list"},
    {"resource": "scan", "action": "create"},
    {"resource": "scan", "action": "stop"},
    {"resource": "helm-chart", "action": "read"},
    {"resource": "helm-chart-version", "action": "create"},
    {"resource": "helm-chart-version", "action": "delete"},
    {"resource": "helm-chart-version-label", "action": "create"},
    {"resource": "helm-chart-version-label", "action": "delete"},
]
ROBOT_ACCOUNT_CREATION_DICT = {
    "name": "testing",
    "duration": -1,
    "description": None,
    "disable": False,
    "level": "project",
    "permissions": [
        {
            "namespace": "cr-29715",
            "kind": "project",
            "access": ROBOT_ACCOUNT_PROJECT_ACCESS_PERMISSION,
        }
    ],
}
DEFAULT_ERROR_RESPONSE = "Error while Creating Namespace. Please try later."
PROJECT_DATA = {
    "project_name": "",
    "public": IS_PUBLIC,
    "storage_limit": HARBOR_PROJECT_STORAGE_LIMIT,
    "metadata": {
        "auto_scan": "false",
        "prevent_vul": DONT_SCAN_IMAGE_ON_PUSH,
        "severity": SEVERITY_LEVEL_CRITICAL,
    },
}
DEFAULT_VAULT_PATH_CONTAINER_REGISTRY = "secret/registry/namespace-{registry_id}"
DEFAULT_REGISTRY_SECRET_NAME = "namespace-secret-{registry_id}"
NAMESPACE_CREATION_MESSAGE = "Namespace created successfully."
ZERO_TOTAL_COUNT = 0
NAMESPACE_DOESNT_EXISTS = "Namespace doesn't exists."
