import re

from rest_framework.status import HTTP_200_OK

from container_registry.api.v1.services.harbor_service import HarborService
from container_registry.constants import (INVALID_NAME_ERROR, NAME_REGEX,
                                          NAMESPACE_DOESNT_EXISTS,
                                          PROJECT_ALREADY_EXIST)
from container_registry.models import NamespaceDetail


def is_project_name_valid(func):
    def wrapper_func(*args, **kwargs):
        project_name = args[1].data.get("name")
        if not re.fullmatch(NAME_REGEX, project_name):
            return args[0].get_400_response(errors=INVALID_NAME_ERROR)
        return func(*args, **kwargs)

    return wrapper_func


def is_project_name_already_exists(func):
    def wrapper_func(*args, **kwargs):
        project_name = args[1].data.get("name")
        query_param_data = {"project_name": project_name}
        response = HarborService().check_already_project_exists(query_param_data)
        if response.status_code == HTTP_200_OK:
            return args[0].get_400_response(errors=PROJECT_ALREADY_EXIST)
        return func(*args, **kwargs)

    return wrapper_func


def validate_namespace_id(func):
    def wrapper_func(*args, **kwargs):
        project_id = args[0].project_id
        namespace_id = args[1]
        try:
            namespace_obj = NamespaceDetail.objects.get(
                id=namespace_id, project_id=project_id, deleted_at=None
            )
            kwargs["namespace"] = namespace_obj
        except Exception:
            return args[0].get_400_response(errors=NAMESPACE_DOESNT_EXISTS)
        return func(*args, **kwargs)

    return wrapper_func
