from django.conf import settings
from rest_framework.status import HTTP_200_OK

from container_registry.constants import (
    DEFAULT_ERROR_RESPONSE, DEFAULT_REGISTRY_SECRET_NAME,
    DEFAULT_VAULT_PATH_CONTAINER_REGISTRY, PROJECT_DATA, PROJECT_SIZE_INTO_GB,
    PROJECT_SIZE_INTO_MB, ROUND_OF_DIGITS, URL_RESERVED_CHARACTERS)
from container_registry.models import NamespaceDetail, RobotAccountDetail
from e2e_core.api.v1.services.vault import VaultService
from integration.api.v1.services.integration_groot_service import \
    IntegrationGrootService


def reform_repository_name(url_variable):
    for character in URL_RESERVED_CHARACTERS:
        url_variable = url_variable.replace(
            character, URL_RESERVED_CHARACTERS[character]
        )
    return url_variable


def filter_error_from_harbor_response(response: object) -> str:
    try:
        return response.json().get("error")[0].get("message")
    except Exception:
        return DEFAULT_ERROR_RESPONSE


def create_db_entry(
    create_project_response: dict,
    robot_account_creation_response: dict,
    customer: object,
    project_id: int,
):
    namespace_obj = NamespaceDetail.objects.create(
        namespace=create_project_response.get("name"),
        harbor_project_id=create_project_response.get("project_id"),
        registry_endpoint=settings.E2E_CONTAINER_REGISTRY_ENDPOINT,
        created_by=customer,
        project_id=project_id,
    )
    robot_account_obj = RobotAccountDetail.objects.create(
        namespace_detail=namespace_obj,
        robot_account_id=robot_account_creation_response.get("id"),
        username=robot_account_creation_response.get("name"),
    )
    return namespace_obj, robot_account_obj


def create_project_data(data: dict) -> dict:
    PROJECT_DATA["project_name"] = data.get("name")
    return PROJECT_DATA


def store_secret_on_vault(
    robot_account_creation_response: dict, namespace_obj: object, customer
):
    secret = robot_account_creation_response.get("secret")
    username = robot_account_creation_response.get("name")
    namespace_auth_dict = {"username": username, "password": secret}
    secret_vault_path = DEFAULT_VAULT_PATH_CONTAINER_REGISTRY.format(
        registry_id=namespace_obj.id
    )
    VaultService().create_secret(secret_vault_path, namespace_auth_dict)
    integration_groot_service = IntegrationGrootService(
        namespace_obj.project.namespace, customer
    )
    groot_payload = namespace_auth_dict
    groot_payload["created_by_email"] = customer.email
    groot_payload["endpoint"] = namespace_obj.registry_endpoint
    groot_payload["name"] = DEFAULT_REGISTRY_SECRET_NAME.format(
        registry_id=namespace_obj.id
    )
    integration_groot_service.create_registry_secret_on_groot(groot_payload)


def get_registry_secret_details(secret_path):
    try:
        response = VaultService().get_secret(secret_path)
        return response.get("data", {}).get("value", {})
    except Exception:
        return {}


def delete_harbor_project(namespace_obj):
    from container_registry.api.v1.services.harbor_service import HarborService

    project_id = namespace_obj.harbor_project_id
    HarborService().delete_harbor_project(project_id)


def delete_robot_account(namespace_obj):
    from container_registry.api.v1.services.harbor_service import HarborService

    robot_account_id = namespace_obj.robotaccountdetail_set.last().robot_account_id
    HarborService().delete_robot_account(robot_account_id)


def fetch_project_size(namespace_obj):
    from container_registry.api.v1.services.harbor_service import HarborService

    project_size_details = HarborService().get_harbor_project_size(
        namespace_obj.namespace
    )
    if project_size_details.status_code in [HTTP_200_OK]:
        return round(
            project_size_details.json().get("quota").get("used").get("storage")
            / PROJECT_SIZE_INTO_GB,
            ROUND_OF_DIGITS,
        )


def format_artifact_response(data):
    for item in data:
        item["domain_name"] = settings.DOMAIN_NAME
        tags = item.get("tags")
        tag_name = ""
        if tags and len(tags) >= 1:
            tag_name = tags[-1].get("name")
        item["tag_name"] = tag_name
        item["size"] = round(item.get("size") / PROJECT_SIZE_INTO_MB, ROUND_OF_DIGITS)
    return data


def delete_secret_from_groot(namespace_obj):
    integration_groot_service = IntegrationGrootService(
        namespace_obj.project.namespace, namespace_obj.created_by
    )
    _ = integration_groot_service.delete_registry_secret_from_groot(DEFAULT_REGISTRY_SECRET_NAME.format(registry_id=namespace_obj.id))


def get_namespace_obj(namespace_id, project_id):
    return NamespaceDetail.objects.get(
        project_id=project_id, id=namespace_id, deleted_at=None
    )


def is_registry_namespace_obj_exists(registry_namespace_id, project_id):
    return NamespaceDetail.objects.filter(
        deleted_at__isnull=True, id=registry_namespace_id, project_id=project_id
    ).exists()
