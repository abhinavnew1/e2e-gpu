from django.db import models

from container_registry.constants import (
    DONT_SCAN_IMAGE_ON_PUSH, HARBOR_PROJECT_STORAGE_LIMIT,
    ROBOT_ACCOUNT_PROJECT_ACCESS_PERMISSION, SEVERITY_LEVEL_CHOICES,
    SEVERITY_LEVEL_CRITICAL, VULNERABILITY_SCANNING_CHOICES)
from customer.models import Customer
from e2e_core.jsonfield import JSONField
from e2e_core.mixins import BaseMixin, SafeDeleteMixinExtended
from projects.models import Projects


class NamespaceDetail(SafeDeleteMixinExtended, BaseMixin):
    namespace = models.CharField(max_length=40)
    is_public = models.BooleanField(default=False)
    prevent_vul = models.CharField(
        max_length=40,
        choices=VULNERABILITY_SCANNING_CHOICES,
        default=DONT_SCAN_IMAGE_ON_PUSH,
    )
    severity = models.CharField(
        max_length=40, choices=SEVERITY_LEVEL_CHOICES, default=SEVERITY_LEVEL_CRITICAL
    )
    harbor_project_id = models.IntegerField()
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    storage_limit = models.BigIntegerField(
        null=False, blank=False, default=HARBOR_PROJECT_STORAGE_LIMIT
    )
    project = models.ForeignKey(Projects, on_delete=models.CASCADE)
    created_by = models.ForeignKey(
        Customer,
        on_delete=models.SET_NULL,
        null=True,
    )
    registry_endpoint = models.CharField(max_length=256)

    def __str__(self):
        return f"<NamespaceDetail(ID:{self.id} Namespace:{self.namespace}: ProjectID:{self.harbor_project_id})>"

    @classmethod
    def namespace_name(cls, project_id, namespace_id):
        return cls.objects.get(
            project_id=project_id, id=namespace_id, deleted_at=None
        ).namespace


class RobotAccountDetail(SafeDeleteMixinExtended, BaseMixin):
    username = models.CharField(max_length=256)
    robot_account_id = models.IntegerField()
    permission = JSONField(default=ROBOT_ACCOUNT_PROJECT_ACCESS_PERMISSION)
    namespace_detail = models.ForeignKey(NamespaceDetail, on_delete=models.CASCADE)

    def __str__(self):
        return f"<RobotAccountDetail(ID:{self.id}: username:{self.username}: UserID:{self.robot_account_id})>"
