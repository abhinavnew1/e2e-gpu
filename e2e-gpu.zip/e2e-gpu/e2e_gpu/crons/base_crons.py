import logging
import pprint
import traceback

from django.conf import settings

from crons.constants import (CC_MAIL_LIST_FOR_CRON_REPORT,
                             TO_MAIL_LIST_FOR_CRON_REPORT)
from e2e_core.api.v1.services.mandrill import Mandrill

logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s | %(levelname)s | %(module)s [%(process)d %(thread)d] | [%(filename)s:%(lineno)s - %(funcName)s() ] | \n%(message)s')
logger = logging.getLogger(__name__)

mandrill_manager = Mandrill(
    settings.MANDRILL_API_TOKEN, "", settings.NOTIFY_FROM, settings.NOTIFY_FROM
)


class BaseCrons(object):
    def __init__(self):
        self._errors = []
        self._success = []

    def _send_report(self, errors, report, subject, *args, **kwargs):
        subject = f"[TIR] CRON_REPORT | {subject} | {settings.ENVIRONMENT}"
        body_description = kwargs.get("body_description", "")
        body = f"{body_description}\n\nError:\n{pprint.pformat(errors)}\n\nSuccess:\n{pprint.pformat(report)}"
        try:
            mandrill_manager.send_email(
                attachments=[],
                email_list=TO_MAIL_LIST_FOR_CRON_REPORT,
                body=body,
                subject=subject,
                cc_email_list=CC_MAIL_LIST_FOR_CRON_REPORT
            )
        except Exception as e:
            logger.error(f"BASE_CRONS | CRITICAL_RED | ERROR_WHILE_SENDING_MAIL | DETAILS: {subject}--{settings.ENVIRONMENT} | ERROR: {str(e)}")

    def _error_handler(self, customer, error, extra_context={}):
        logger.error(error)
        error_traceback = traceback.format_exc()
        logger.error(error_traceback)
        error = {
            "customer": customer,
            "error": error,
            "error_traceback": error_traceback,
            "extra_context": extra_context
        }
        self._errors.append(error)
