from django.conf import settings

TO_MAIL_LIST_FOR_CRON_REPORT = ["dev-alerts@e2enetworks.com",]
CC_MAIL_LIST_FOR_CRON_REPORT = ["qa@e2enetworks.com", "shivansh.jain@e2enetworks.com",]

NOTEBOOK_AUTO_SHUTDOWN_MAIL_SUBJECT = "NOTEBOOK_AUTO_SHUTDOWN_CRON"
K8S_RESOURCE_CLEANUP_VARIFICATION_CRON = "K8S RESOURCE CLEANUP VARIFICATION CRON"
NOTEBOOK_AUTO_SHUTDOWN_CRON_INTERVAL = 60  # time in minutes
TERMINATE_FREE_NOTEBOOK_USAGE_MAIL_SUBJECT = "TERMINATE_FREE_NOTEBOOK_USAGE_CRON"
K8S_CLEANUP_VARIFICATION = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/services/{service}/statefulset/{statefulset}"
NOTEBOOK = "notebook"
INFERENCE = "inference"

CPU = 'cpu'
MEMORY = "memory"
POD_MAX_BAD_STATE_DURATION = 600
