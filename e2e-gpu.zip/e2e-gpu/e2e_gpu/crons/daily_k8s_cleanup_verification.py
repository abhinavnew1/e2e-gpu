import base64
import json
import logging
from datetime import timedelta

import pytz
from crons.base_crons import BaseCrons
from crons.constants import (INFERENCE,
                             K8S_RESOURCE_CLEANUP_VARIFICATION_CRON, NOTEBOOK,)
from crons.helpers import verify_clean_up_k8s_resources
from django.conf import settings
from e2e_core import datetime_helper
from e2e_core.api.v1.services.mandrill import Mandrill
from inferenceservice.models import Inference
from notebook.models import Notebook

logger = logging.getLogger(__name__)

mandrill_manager = Mandrill(
    settings.MANDRILL_API_TOKEN, "", settings.NOTIFY_FROM, settings.NOTIFY_FROM
)

BODY_DESCRIPTION = "K8s Resource Cleanup Verification Cron: This Cron fetches deleted notebooks, inferences, pipelines, and fine-tuning resources from the last 24 hours from the database. It then verifies if all associated Kubernetes resources (pods, services, HPAs, PVCs, StatefulSets) have been deleted. Any resources not deleted are included in the report."
TO_MAIL_LIST_FOR_CRON_REPORT = ["vipin.rauthan@e2enetworks.com",]
CC_MAIL_LIST_FOR_CRON_REPORT = ["aman.mishra@e2enetworks.com", "jagmeet.singh@e2enetworks.com", "shivansh.jain@e2enetworks.com", "chhavish.bakoliya@e2enetworks.com"]


class K8sCleanupVerification(BaseCrons):

    def run(self, *args, **kwargs):
        reports = dict()
        notebooks = self.get_notebooks()
        inferences = self.get_inference()
        self.notebook_cleanup_verification(notebooks, reports)
        self.inference_cleanup_verification(inferences, reports)
        self._send_report(
            reports
        )

    def get_notebooks(self):
        end_time = datetime_helper.current_datetime(pytz.UTC)
        start_time = end_time - timedelta(days=1)
        notebooks = Notebook.objects.filter(deleted_at__isnull=False, deleted_at__range=(start_time, end_time)).select_related("project")
        return notebooks

    def get_inference(self):
        end_time = datetime_helper.current_datetime(pytz.UTC)
        start_time = end_time - timedelta(days=1)
        inferences = Inference.objects.filter(deleted_at__isnull=False, deleted_at__range=(start_time, end_time)).select_related("project")
        return inferences

    def notebook_cleanup_verification(self, notebooks, reports, *args, **kwargs):
        for notebook in notebooks:
            namespace = f"p-{notebook.project_id}"
            customer = notebook.created_by
            response = verify_clean_up_k8s_resources(namespace, NOTEBOOK, notebook.slug_name, customer)
            logger.info(f"CRON FOR VERIFY_CLEANUP_RESOURCES | SERVICE:-{NOTEBOOK} | NAMESPACE:- {namespace} | STATEFULSET:- {notebook.slug_name}")
            if response.get('data', {}):
                reports[f"{namespace}-{notebook.slug_name}"] = response.get('data', {})

    def inference_cleanup_verification(self, inferences, reports, *args, **kwargs):
        for inference in inferences:
            namespace = f"p-{inference.project_id}"
            customer = inference.created_by
            inference_name = f"is-{inference.id}"
            response = verify_clean_up_k8s_resources(namespace, INFERENCE, inference_name, customer)
            logger.info(f"CRON FOR VERIFY_CLEANUP_RESOURCES | SERVICE:-{INFERENCE} | NAMESPACE:- {namespace} | STATEFULSET:- {inference_name}")
            if response.get('data', {}):
                reports[f"{namespace}-{inference_name}"] = response.get('data', {})

    def generate_json_report(self, report):
        json_report = json.dumps(report, indent=4)
        return json_report

    def _send_report(self, report, *args, **kwargs):
        subject = f"[TIR] CRON_REPORT | {K8S_RESOURCE_CLEANUP_VARIFICATION_CRON} | {settings.ENVIRONMENT}"
        body = f"{BODY_DESCRIPTION}\n"
        json_report = self.generate_json_report(report)
        json_attachment = base64.b64encode(json_report.encode('utf-8')).decode('utf-8')
        attachments = [
            {
                'name': 'report.json',
                'content': json_attachment,
                'type': 'application/json'
            }
        ]
        try:
            mandrill_manager.send_email(
                attachments=attachments,
                email_list=TO_MAIL_LIST_FOR_CRON_REPORT,
                body=body,
                subject=subject,
                cc_email_list=CC_MAIL_LIST_FOR_CRON_REPORT
            )
        except Exception as e:
            logger.error(f"BASE_CRONS | CRITICAL_RED | ERROR_WHILE_SENDING_MAIL | DETAILS: {subject}--{settings.ENVIRONMENT} | ERROR: {str(e)}")


run = K8sCleanupVerification().run
