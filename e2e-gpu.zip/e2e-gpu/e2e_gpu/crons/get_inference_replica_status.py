import logging
from datetime import datetime

from django.db import transaction

from crons.base_crons import BaseCrons
from inferenceservice.api.v1.services.inference_groot_service import \
    InferenceGrootService
from inferenceservice.constants import PYTORCH, TRITON, READY, RUNNING, RETRYING, WAITING, DEPLOYING
from inferenceservice.models import Inference, InferenceHistory

logger = logging.getLogger(__name__)

class SetInferenceHpaStatusCron(BaseCrons):

    def __init__(self, *args, **kwargs):
        super().__init__()

    def run(self):
        inferences = Inference.objects.filter(deleted_at__isnull=True, framework__in=[PYTORCH, TRITON] , status__in=[READY, RUNNING, RETRYING, WAITING, DEPLOYING])
        for inference in inferences:
            _ = self.update_replicas_status(inference)

        with transaction.atomic():
            Inference.objects.bulk_update(inferences, ["replica", "desired_replica"])

    def update_replicas_status(self, inference):
        groot_service = InferenceGrootService(inference.project.namespace, inference.created_by)
        hpa_details, success = groot_service.get_hpa_details(inference.id)
        if not success:
            logger.info(f"SET_INFERENCE_REPLICA_STATUS_CRON | GET_HPA_DETAILS_FROM_GROOT | CRITICAL_RED | INFERENCE_ID:{inference.id}")
            return success
        current_replica = hpa_details.json().get('hpa', {}).get('status', {}).get('current_replicas', "")
        desired_replica = hpa_details.json().get('hpa', {}).get('status', {}).get('desired_replicas', "")
        if not current_replica:
            logger.info(f"SET_INFERENCE_REPLICA_STATUS_CRON | GET_REPLICA_COUNT_FROM_GROOT | CRITICAL_RED | INFERENCE_ID:{inference.id}")
            return False
        if current_replica != inference.replica:
            current_time = datetime.now()
            inference.update_end_date_in_inference_history(end_date=current_time)
            inference.replica = current_replica
            if inference.is_auto_scale_enabled:
                inference.desired_replica = desired_replica
            inference.create_inference_history(start_date=current_time)
        return True


run = SetInferenceHpaStatusCron().run
