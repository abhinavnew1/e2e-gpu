import requests

from crons.constants import K8S_CLEANUP_VARIFICATION


def verify_clean_up_k8s_resources(namespace, service, statefulset, customer):
    url = K8S_CLEANUP_VARIFICATION.format(namespace=namespace, service=service, statefulset=statefulset)
    response = requests.request("GET", url, headers={"e2e-userid": str(customer.email),
            "Content-Type": "application/json"})
    return response.json()


def convert_cpu_to_millicores(cpu):
    return int(cpu) * 1000
