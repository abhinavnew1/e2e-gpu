import logging
import re
from datetime import datetime


import bitmath
import requests
from django.conf import settings
from django.db import transaction

from crons.base_crons import BaseCrons
from crons.constants import CPU, MEMORY, POD_MAX_BAD_STATE_DURATION
from crons.helpers import convert_cpu_to_millicores
from gpu_service.constants import NOT_READY, READY
from gpu_service.models import K8sNode

# Cron Report
NODE_SUBJECT = "NODES RESOURCE CRON: Update K8sNode Resources"
BODY_DESCRIPTION = "NODES RESOURCE CRON: Update NODES resources based on the node resources."
# Resources
EPHEMERAL_STORAGE = "ephemeral-storage"
GPU = "nvidia.com/gpu"
HUGEPAGES_1GI = "hugepages-1Gi"
HUGEPAGES_2MI = "hugepages-2Mi"
ALLOWED_KEYS = [CPU, MEMORY, GPU]
EXCLUDE_ROLES = ["control-plane"]
# URL
GET_ALL_NODE_RESOURCES = settings.GROOT_BASE_URL + "api/node_resources"
GET_NOT_RUNNING_PODS = settings.GROOT_BASE_URL + "/api/not_running_pods"
GET_NODE_RESOURCES = settings.GROOT_BASE_URL + "api/node_resources/{node_name}"
# Date Time
PODS_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"
PODS_STRING_FORMAT = "%m-%d %H:%M:%S"
# Status
STATUS_READY = {"type": "Ready", "status": "True"}
# REGEX
EXTRACT_RESESOURCES_REGEX = r'^\s*(\S+)\s+(\S+)\s+\((\S+)\)\s+(\S+)\s+\((\S+)\)'
POD_NAMESPACE_REGEX = r'^\s*([^\s]+)\s+([^\s]+)\s+.*$'
# General
BATCH_SIZE = 50

logger = logging.getLogger(__name__)


class UpdateSkuResource(BaseCrons):
    def __init__(self):
        super().__init__()
        self.missing_nodes = []
        self.new_nodes = []
        self.altered_nodes = []
        self.successfully_updated_nodes = []
        self.failed_to_update_nodes = []
        self.faulty_pods = []

    def get_json_response(self, url, params=None, retries=2):
        headers = {"Content-Type": "application/json"}
        attempt = 0

        while attempt <= retries:
            try:
                response = requests.get(url, headers=headers, params=params)
                response.raise_for_status()
                return response.json().get('data')
            except requests.RequestException as e:
                if attempt < retries:
                    attempt += 1
                else:
                    logger.error(f"K8S_RESOURCE_CRON | FAILED_TO_GET_K8S_NODE_DATA_FROM_GROOT | {e}")
                    raise e

    def get_pod_age(self, diff):
        days = diff.days
        seconds = diff.seconds
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        if days > 0:
            return f"{days} days"
        elif hours > 0:
            return f"{hours} hours"
        else:
            return f"{minutes} minutes"

    def get_node_resources(self, node_name=None):
        url = GET_NODE_RESOURCES.format(node_name=node_name) if node_name else GET_ALL_NODE_RESOURCES
        return self.get_json_response(url)

    def get_pods_list(self):
        return self.get_json_response(GET_NOT_RUNNING_PODS)

    def extract_resources(self, text):
        pattern = re.compile(EXTRACT_RESESOURCES_REGEX)
        resources = {}
        for line in text.split('\n'):
            # Matches expression [for cpu and memory] of the format resource_type requests (requests_percent) limits (limits_percent)
            match = pattern.match(line)
            if match and match.group(1) in ALLOWED_KEYS:
                resources[match.group(1)] = {
                    'requests': match.group(2),
                    'requests_percent': match.group(3),
                    'limits': match.group(4),
                    'limits_percent': match.group(5)
                }
            # GPU is of the format nvidia.com/gpu: requests, limits
            elif line.strip().startswith(GPU):
                gpu_info = line.split()
                if len(gpu_info) >= 3:
                    resources[GPU] = {'requests': gpu_info[1], 'limits': gpu_info[2]}
        return resources

    def convert_memory_to_mebibytes(self, k8s_memory_value):
        if k8s_memory_value.endswith('m'):
            return bitmath.Byte(int(k8s_memory_value[:-1])/1000).to_MiB().value
        return bitmath.parse_string_unsafe(k8s_memory_value).to_MiB().value

    def extract_details(self, node_name, node_data, node_info):
        total_memory = self.convert_memory_to_mebibytes(node_data['capacity'][MEMORY])
        allocated_memory_percent = int(node_info[MEMORY]['requests_percent'].split('%')[0])
        allocated_memory = (allocated_memory_percent * total_memory) / 100
        return {
            'name': node_name,
            'status': READY if node_data['status'] == STATUS_READY else NOT_READY,
            'worker_type': node_data['worker_type'],
            'total_cpu':  convert_cpu_to_millicores(int(node_data['capacity'][CPU])),
            'total_gpu': int(node_data['capacity'].get(GPU, 0)),
            'total_memory': total_memory,
            'allocated_cpu': int(node_info[CPU]['requests'].split('m')[0]),
            'allocated_memory': allocated_memory,
            'allocated_gpu': int(node_info.get(GPU, {}).get('requests', 0)),
        }

    def check_if_node_is_altered(self, node, node_details):
        is_altered = node.worker_type != node_details.get('worker_type', 'unknown')
        if is_altered:
            logger.info(f"K8S_RESOURCE_CRON | ALTERED_NODE | NODE_NAME - {node.name}")
        return is_altered

    def parse_node_info(self, node_info):
        name = None
        for line in node_info.split('\n'):
            if line.startswith("Name:"):
                name = line.split(":")[1].strip()
            elif line.startswith("Roles:"):
                role = line.split(":")[1].strip()
                if role in EXCLUDE_ROLES:
                    return None
        return name

    def get_pods_namespace(self, text):
        pattern = re.compile(POD_NAMESPACE_REGEX)
        pods = []
        found_namespace = False
        lines = iter(text.splitlines())

        for line in lines:
            if line.strip().startswith("Namespace"):
                found_namespace = True
                next(lines)
                continue
            if line.strip().startswith("Allocated resources:"):
                break
            if found_namespace and line.strip():
                match = pattern.match(line)
                if match:
                    namespace, pod_name = match.groups()
                    pods.append({'namespace': namespace, 'pod_name': pod_name})
        return pods

    def run(self):
        try:
            self.update_nodes_table()
            self.fetch_not_running_pods()
        except Exception as e:
            logger.error(f"K8S_RESOURCE_CRON | FAILED_TO_UPDATE_NODES | {e}")
            self._errors.append(f"K8S_RESOURCE_CRON | FAILED_TO_UPDATE_NODES | {e}")
        self.prepare_cron_report()

    def update_nodes_table(self):
        all_nodes_details = self.get_node_details()
        self.update_all_nodes_in_db(all_nodes_details)

    def get_node_details(self):
        nodes_data = self.get_node_resources()
        all_nodes_details = {}
        stdout_data = nodes_data.get("stdout", "")
        node_info_list = stdout_data.split("\n\n")
        nodes_info = {self.parse_node_info(info): self.extract_resources(info) for info in node_info_list}

        for node_name, node_data in nodes_data.items():
            if node_name != "stdout":
                node_info = nodes_info.get(node_name, {})
                all_nodes_details[node_name] = self.extract_details(node_name, node_data, node_info)
        return all_nodes_details

    def get_single_node_details(self, node_name):
        node_data = self.get_node_resources(node_name)
        node_info = self.extract_resources(node_data.get("stdout", ""))
        pods = self.get_pods_namespace(node_data.get("stdout", ""))
        return self.extract_details(node_name, node_data, node_info), pods

    def update_single_node_in_db(self, node_details, node_name):
        node = K8sNode.objects.get(name=node_name)
        node_update = []
        self.update_node(node, node_details, node_update)
        try:
            node_update = node_update[0].save()
            logger.info(f"K8S_POD_WATCHER | SUCCESSFULLY_UPDATED_NODE | NODE_NAME - {node.name}")
        except Exception as e:
            logger.error(f"K8S_RESOURCE_CRON | FAILED_TO_UPDATE_NODE | NODE_NAME - {node.name} | {e}")

    def update_all_nodes_in_db(self, all_nodes_details):
        all_nodes = {node.name: node for node in K8sNode.objects.all()}
        all_db_node_names = set(all_nodes.keys())
        all_fetched_node_names = set(all_nodes_details.keys())
        self.missing_nodes = list(all_db_node_names - all_fetched_node_names)
        self.new_nodes = list(all_fetched_node_names - all_db_node_names)
        nodes_to_update = []
        nodes_to_create = []

        for node_name, node_details in all_nodes_details.items():
            node = all_nodes.get(node_name)
            if node:
                self.update_node(node, node_details, nodes_to_update)
            else:
                nodes_to_create.append(self.new_node(node_name, node_details))

        self.bulk_create_nodes(nodes_to_create)
        self.bulk_update_nodes(nodes_to_update)
        self.update_inactive_nodes()

    def new_node(self, node_name, node_details):
        return K8sNode(
            name=node_name,
            total_cpu=node_details['total_cpu'],
            total_gpu=node_details['total_gpu'],
            total_memory=node_details['total_memory'],
            available_cpu=node_details['total_cpu'] - node_details['allocated_cpu'],
            available_gpu=node_details['total_gpu'] - node_details['allocated_gpu'],
            available_memory=node_details['total_memory'] - node_details['allocated_memory'],
            worker_type=node_details['worker_type'],
            status=node_details['status']
        )

    def update_node(self, node, node_details, nodes_to_update):
        if self.check_if_node_is_altered(node, node_details):
            self.altered_nodes.append(node.name)
        node.total_cpu = node_details['total_cpu']
        node.total_gpu = node_details['total_gpu']
        node.total_memory = node_details['total_memory']
        node.available_cpu = node_details['total_cpu'] - node_details['allocated_cpu']
        node.available_gpu = node_details['total_gpu'] - node_details['allocated_gpu']
        node.available_memory = node_details['total_memory'] - node_details['allocated_memory']
        node.worker_type = node_details['worker_type']
        node.status = node_details['status']
        nodes_to_update.append(node)

    def update_node_db(self, node_name):
        node_details, pods = self.get_single_node_details(node_name)
        self.update_single_node_in_db(node_details, node_name)
        return pods

    def bulk_create_nodes(self, nodes_to_create):
        if nodes_to_create:
            try:
                with transaction.atomic():
                    K8sNode.objects.bulk_create(nodes_to_create, batch_size=BATCH_SIZE)
                self.new_nodes.extend(node.name for node in nodes_to_create)
                logger.info(f"K8S_RESOURCE_CRON | SUCCESSFULLY_CREATED_NODES_DB | {self.new_nodes}")
            except Exception as e:
                logger.error(f"K8S_RESOURCE_CRON | FAILED_TO_CREATE_NODES_IN_DB | {e}")
                self.failed_to_update_nodes.extend(node.name for node in nodes_to_create)

    def bulk_update_nodes(self, nodes_to_update):
        if nodes_to_update:
            try:
                with transaction.atomic():
                    K8sNode.objects.bulk_update(
                        nodes_to_update,
                        ['total_cpu', 'total_gpu', 'total_memory', 'available_cpu',
                         'available_gpu', 'available_memory', 'worker_type', 'status'],
                        batch_size=BATCH_SIZE
                    )
                self.successfully_updated_nodes.extend(node.name for node in nodes_to_update)
                logger.info(f"K8S_RESOURCE_CRON | SUCCESSFULLY_UPDATED_NODES_DB | {self.successfully_updated_nodes}")
            except Exception as e:
                logger.error(f"K8S_RESOURCE_CRON | FAILED_TO_UPDATE_NODES_DB {e}")
                self.failed_to_update_nodes.extend(node.name for node in nodes_to_update)

    def update_inactive_nodes(self):
        inactive_nodes = K8sNode.objects.filter(name__in=self.missing_nodes)
        if inactive_nodes:
            try:
                inactive_nodes.update(is_node_visible_in_k8s=False)
                self.successfully_updated_nodes.extend(node.name for node in inactive_nodes)
                logger.info(f"K8S_RESOURCE_CRON | SUCCESSFULLY_UPDATED_INACTIVE_NODES_DB | {list(inactive_nodes.values_list('name', flat=True))}")
            except Exception as e:
                logger.error(f"K8S_RESOURCE_CRON | FAILED_TO_UPDATE_INACTIVE_NODES_DB {e}")
                self.failed_to_update_nodes.extend(node.name for node in inactive_nodes)

    def fetch_not_running_pods(self):
        data = self.get_pods_list()
        current_time = datetime.now()

        for pod in data:
            creation_time = datetime.strptime(pod.get("creation_timestamp"), PODS_DATE_FORMAT)
            diff = current_time - creation_time

            # Check if the pod's state has been bad for more than 600 seconds
            if diff.total_seconds() > POD_MAX_BAD_STATE_DURATION:
                pod["age"] = self.get_pod_age(diff)
                self.faulty_pods.append(pod)

    def prepare_cron_report(self):
        self._errors.append({
            'NODES_MISSING_IN_K8S': self.missing_nodes,
            'FAILED_TO_UPDATE_NODES': self.failed_to_update_nodes,
            'ALTERED_NODES': self.altered_nodes,
            'FAULTY_PODS': self.faulty_pods
        })
        self._success.append({
            'UPDATED_NODES': self.successfully_updated_nodes,
            'NEW_NODES': self.new_nodes
        })
        self._send_report(self._errors, self._success, subject=NODE_SUBJECT, body_description=BODY_DESCRIPTION)


run = UpdateSkuResource().run
