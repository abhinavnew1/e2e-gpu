"""Notebook Auto Shutdown Cron: This Cron schedules the celery task for deleting the free notebooks, whose auto shutdown time occurs before the next cron is run.
This cron should also be run whenever any code is deployed on celery server, otherwise the already pushed tasks will be missed.
"""

import logging
from datetime import timedelta

import pytz
from celery.execute import send_task
from django.db.models import F

from crons.base_crons import BaseCrons
from crons.constants import (NOTEBOOK_AUTO_SHUTDOWN_CRON_INTERVAL,
                             NOTEBOOK_AUTO_SHUTDOWN_MAIL_SUBJECT)
from e2e_core import datetime_helper
from notebook.constants import NOTEBOOK_AUTO_SHUTDOWN_TASK
from notebook.helpers import perform_shutdown_action
from notebook.models import Notebook

logger = logging.getLogger(__name__)

BODY_DESCRIPTION = "Notebook Auto Shutdown Cron: This Cron schedules the celery task for deleting the free notebooks, whose auto shutdown time occurs before the next cron is run"


class NotebookAutoShutdownCron(BaseCrons):

    def run(self, *args, **kwargs):
        notebooks_qs = self.get_all_notebooks()
        free_notebooks = self.filter_free_notebooks(notebooks_qs)

        ## TODO: Currently, not creating any tasks.Instead, the cron is run every 15 mins & it directly shutdowns the notebook
        # notebook_to_shutdown = self.get_notebooks_to_be_shutdown_before_next_cron(free_notebooks)
        # self.create_notebook_shutdown_tasks(notebook_to_shutdown)
        notebook_to_shutdown = self.get_notebooks_to_be_shutdown(free_notebooks)
        self.shutdown_notebooks(notebook_to_shutdown)

        self._send_report(
            self._errors,
            self._success,
            subject = NOTEBOOK_AUTO_SHUTDOWN_MAIL_SUBJECT,
            body_description = BODY_DESCRIPTION,
        )


    def get_all_notebooks(self, *args, **kwargs):
        return Notebook.objects.filter(deleted_at__isnull=True).select_related("project", "sku_item_price", "sku_item_price__sku")


    def filter_free_notebooks(self, notebook_qs, *args, **kwargs):
        return notebook_qs.filter(sku__is_free = True)


    def get_notebooks_to_be_shutdown_before_next_cron(self, notebook_qs, *args, **kwargs):
        end_time = datetime_helper.current_datetime(pytz.UTC) + timedelta(minutes=NOTEBOOK_AUTO_SHUTDOWN_CRON_INTERVAL)
        return notebook_qs.filter(auto_shutdown_timeout__lte = end_time - F('created_at'))#TODO


    def create_notebook_shutdown_tasks(self, notebooks_to_shutdown, *args, **kwargs):
        for notebook in notebooks_to_shutdown:
            nb_shutdown_time = notebook.created_at + timedelta(minutes=notebook.auto_shutdown_timeout)
            countdown_in_sec = datetime_helper.round_to_next_second(
                                    nb_shutdown_time - datetime_helper.current_datetime(pytz.UTC)
                                ).total_seconds()
            if countdown_in_sec < 0:
                countdown_in_sec = 0
            try:
                send_task(
                    NOTEBOOK_AUTO_SHUTDOWN_TASK,
                    kwargs={"notebook_id": notebook.id, "count": 0},
                    countdown=countdown_in_sec,
                )
                self._success.append(notebook.id)
            except Exception as e:
                self._errors.append(notebook.id)
                logger.error(f"NOTEBOOK_AUTO_SHUTDOWN_CRON | CRITICAL_RED | ERROR_WHILE_CREATING_TASK | NOTEBOOK_ID:{notebook.id} | ERROR:{str(e)}")


    def get_notebooks_to_be_shutdown(self, notebook_qs, *args, **kwargs):
        current_time = datetime_helper.current_datetime(pytz.UTC)
        return notebook_qs.filter(auto_shutdown_timeout__lte = current_time - F('created_at'))#TODO

    def shutdown_notebooks(self, notebooks_to_shutdown, *args, **kwargs):
        for notebook in notebooks_to_shutdown:
            is_success = perform_shutdown_action(notebook)
            # TODO: notify user
            self._success.append(notebook.id) if is_success else self._errors.append(notebook.id)



run = NotebookAutoShutdownCron().run
