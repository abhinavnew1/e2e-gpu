"""
Terminate Free Notebook Usage Cron: This Cron executes the action to be taken post consumption of notebook free usage hours.
"""

import logging

import pytz
from django.db import transaction
from django.db.models import Case, DateTimeField, F, Prefetch, Q, Sum, When
from rest_framework import status

from crons.base_crons import BaseCrons
from crons.constants import TERMINATE_FREE_NOTEBOOK_USAGE_MAIL_SUBJECT
from customer.models import Customer, CustomerFreeNotebookHours
from e2e_core.datetime_helper import (current_datetime, end_of_the_previous_month,
                                      get_usage_hours_from_timedelta,
                                      round_to_next_minute, starting_of_the_current_month,
                                      starting_of_the_previous_month, tz_aware)
from gpu_service.constants import CPU_SERIES, GPU_SERIES, HOURLY
from gpu_service.helpers import is_credit_sufficient_for_inventory_launch
from gpu_service.models import StockKeepingUnit, SkuItemPrice
from notebook.api.v1.services.notebook_action_service import NotebookActionService
from notebook.api.v1.services.notebook_service import NotebookService
from notebook.constants import (AUTO_CONVERT_TO_PAID_USAGE,
                                AUTO_SHUTDOWN_FREE_USAGE, READY,
                                STOP_NOTEBOOK_ACTION, WAITING)
from notebook.helpers import (send_notebook_auto_convert_email, send_free_tier_auto_convert_failed_email)
from notebook.models import Notebook, NotebookHistory
from rbac.constants import NOTEBOOK
from teams.helpers import get_team_owner_admin_email_list

logger = logging.getLogger(__name__)

CURRENT_MONTH = "CM"
PREVIOUS_MONTH = "PM"
BODY_DESCRIPTION = "Terminate Free Notebook Usage Cron: This Cron executes the action to be taken post consumption of notebook free usage hours."
INVALID_MONTH_ARG = "Invalid Month Args"


class TerminateFreeNotebookUsageCron(BaseCrons):

    def __init__(self, *args, **kwargs):
        super().__init__()
        self.start = None
        self.end = None
        self.auto_shutdown_success = []
        self.auto_shutdown_failed = []
        self.auto_convert_success = []
        self.auto_convert_failed = []
        self.paid_sku_not_found = []
        self.paid_sku_mapping = self.get_free_sku_paid_sku_mapping()

    def run(self, month, *args, **kwargs):
        if month == CURRENT_MONTH:
            self.start = tz_aware(starting_of_the_current_month())
            self.end = round_to_next_minute(current_datetime(pytz.UTC))
        elif month == PREVIOUS_MONTH:
            self.start = tz_aware(starting_of_the_previous_month())
            self.end = tz_aware(end_of_the_previous_month())
        else:
            self._errors.append(INVALID_MONTH_ARG)
            raise ValueError(INVALID_MONTH_ARG)

        self.check_and_terminate_free_usage()
        self._prepare_cron_report()

    def check_and_terminate_free_usage(self, *args, **kwargs):
        """ Check & update customers' free tier notebooks' consumption.
        If monthly free hours limit is reached, terminate the free tier notebooks as per termination policy chosen."""
        all_customers = self._get_all_primary_customers()
        customers_free_tier_usage = self._get_customers_free_tier_usage()

        free_nb_hours_obj_update_list = []
        for customer in all_customers:
            if not hasattr(customer, "customerfreenotebookhours"):
                CustomerFreeNotebookHours.get_or_create_object(customer)
            cpu_used_hours = customers_free_tier_usage.get(customer.id, {}).get(CPU_SERIES, 0.0)
            gpu_used_hours = customers_free_tier_usage.get(customer.id, {}).get(GPU_SERIES, 0.0)
            # monthly free hours limit is only for GPU Free-Tier machines as of now.
            gpu_monthly_hours_limit = customer.customerfreenotebookhours.gpu_free_hours_per_month
            if gpu_used_hours >= gpu_monthly_hours_limit:
                self.terminate_free_tier_notebooks(customer.running_free_tier_nb_list)
            customer.customerfreenotebookhours.gpu_free_hours_used = round(gpu_used_hours, 2)
            customer.customerfreenotebookhours.cpu_free_hours_used = round(cpu_used_hours, 2)
            free_nb_hours_obj_update_list.append(customer.customerfreenotebookhours)
        with transaction.atomic():
            CustomerFreeNotebookHours.objects.bulk_update(
                free_nb_hours_obj_update_list, ['gpu_free_hours_used', 'cpu_free_hours_used', 'updated_at'], batch_size=1000
            )

    def _get_free_tier_notebooks(self, *args, **kwargs):
        return NotebookHistory.objects.filter(
                    Q(end_date__isnull=True) |
                    Q(end_date__gte=self.start),
                    start_date__lte=self.end,
                    sku_item_price__sku__is_free=True
                ).order_by("created_at").select_related("notebook", "sku_item_price", "sku_item_price__sku", "customer", "customer__currency", "notebook__sku_item_price", "notebook__sku_item_price__currency", "notebook__sku_item_price__sku")

    def _get_all_primary_customers(self, *args, **kwargs):
        free_notebooks_qs = self._get_free_tier_notebooks()
        running_free_tier_nb = free_notebooks_qs.filter(
                                    end_date__isnull=True,
                                    notebook__instance_type__in=[AUTO_SHUTDOWN_FREE_USAGE, AUTO_CONVERT_TO_PAID_USAGE]
                                )
        return (
            Customer.get_all_primary_customers()
            .select_related("customerfreenotebookhours")
            .prefetch_related(
                Prefetch("notebookhistory_set", queryset=running_free_tier_nb, to_attr="running_free_tier_nb_list")
            )
        )

    def terminate_free_tier_notebooks(self, nb_history_list, *args, **kwargs):
        for nb_history in nb_history_list:
            nb = nb_history.notebook
            if nb.instance_type == AUTO_SHUTDOWN_FREE_USAGE and nb.status in [READY, WAITING]:
                self.auto_shutdown_free_notebook(nb)
            elif nb.instance_type == AUTO_CONVERT_TO_PAID_USAGE and not self.are_credits_sufficient(nb):
                self.auto_shutdown_free_notebook(nb)
                paid_sku_item_price = self._get_paid_sku_item_price(nb)
                send_free_tier_auto_convert_failed_email(nb, paid_sku_item_price)
            elif nb.instance_type == AUTO_CONVERT_TO_PAID_USAGE:
                self.auto_convert_notebook_to_paid_usage(nb)
            else:
                logger.error(f"TERMINATE_FREE_USAGE_HOURS | CRITICAL_RED | INVALID_INSTANCE_TYPE_FOR_SKU | NOTEBOOK_ID:{nb.id}")

    def auto_shutdown_free_notebook(self, notebook, *args, **kwargs):
        resp = NotebookActionService(
                    notebook.created_by, notebook.project_id, STOP_NOTEBOOK_ACTION, None
                ).perform_action(notebook.id, notebook=notebook)
        if resp.get("code") == status.HTTP_200_OK:
            self.auto_shutdown_success.append(notebook.id)
        else:
            self.auto_shutdown_failed.append(notebook.id)

    def auto_convert_notebook_to_paid_usage(self, notebook, *args, **kwargs):
        free_sku = notebook.sku
        paid_sku_item_price = self._get_paid_sku_item_price(notebook, free_sku)
        if not paid_sku_item_price:
            self.auto_convert_failed.append(notebook.id)
            return
        # As of now, we only update the sku in db because we upgrade the notebook to the paid version of the free sku
        try:
            NotebookService(notebook.created_by, notebook.project_id)._update_notebook_details_in_database(notebook, paid_sku_item_price)
            self.auto_convert_success.append(notebook.id)
        except Exception:
            self.auto_convert_failed.append(notebook.id)
            return
        # send mail notification
        cc_email_list = get_team_owner_admin_email_list(notebook.project.team_id, [notebook.created_by.email])
        send_notebook_auto_convert_email(notebook.created_by.email, cc_email_list, notebook, free_sku, paid_sku_item_price)

    def _get_customers_free_tier_usage(self, *args, **kwargs):
        free_notebooks_qs = self._get_free_tier_notebooks()
        customer_free_tier_hours_used = list(
            free_notebooks_qs.annotate(
                                    billable_start_date=Case(
                                                            When(start_date__gt=self.start, then=F("start_date")),
                                                            default=self.start,
                                                            output_field=DateTimeField()
                                                        ),
                                    billable_end_date=Case(
                                                            When(Q(end_date__isnull=False) & Q(end_date__lte=self.end), then=F("end_date")),
                                                            default=self.end,
                                                            output_field=DateTimeField()
                                                        )
                                ).annotate(
                                    usage_hours=F("billable_end_date") - F("billable_start_date"),
                                    sku_series=F("sku_item_price__sku__series"),
                                ).values(
                                    "customer_id", "sku_series"
                                ).annotate(
                                    total_usage_hours=Sum("usage_hours")
                                ).order_by()
        )
        mapping_dict = {}  # dict containing customer-wise gpu & cpu free hours usage. e.g.: {customer_id:{"GPU": x, "CPU": y}, ...}
        for item in customer_free_tier_hours_used:
            if not mapping_dict.get(item["customer_id"]):
                mapping_dict[item["customer_id"]] = {}
            mapping_dict[item["customer_id"]][item["sku_series"]] = get_usage_hours_from_timedelta(item["total_usage_hours"])
        return mapping_dict

    def get_free_sku_paid_sku_mapping(self, *args, **kwargs):
        paid_sku_mapping = {}
        free_skus = self.get_sku_with_free_hours_limit()
        for free_sku in free_skus:
            paid_sku_item_price_collection = self.get_paid_version_of_sku(free_sku)
            if paid_sku_item_price_collection:
                paid_sku_mapping[free_sku.id] = paid_sku_item_price_collection
            else:
                logger.error(f"SHUTDOWN_FREE_NOTEBOOKS_CRON | CRITICAL_RED | PAID_VERSION_OF_SKU_NOT_FOUND | FREE_SKU_ID:{free_sku.id}")
                self.paid_sku_not_found.append(free_sku.id)
        return paid_sku_mapping

    def get_sku_with_free_hours_limit(self, *args, **kwargs):
        return StockKeepingUnit.objects.filter(is_free=True, category=NOTEBOOK)

    def get_paid_version_of_sku(self, free_sku, *args, **kwargs):
        paid_sku_name = free_sku.name.split("_Free")[0]
        sku_item_price_collection = SkuItemPrice.objects.filter(
                    is_active=True,
                    sku_type=HOURLY,
                    sku__is_free=False,
                    sku__is_active=True,
                    sku__name=paid_sku_name,
                    sku__series=free_sku.series,
                    sku__category=free_sku.category,
                    sku__cpu=free_sku.cpu,
                    sku__gpu=free_sku.gpu,
                    sku__memory=free_sku.memory,
                ).select_related("currency")
        return list(sku_item_price_collection)

    def _prepare_cron_report(self, *args, **kwargs):
        self._errors.append({
            "PAID_VERSION_OF_SKU_NOT_FOUND_FOR_SKU_ID": self.paid_sku_not_found,
            "AUTO_CONVERT_FAILED_FOR_NOTEBOOK_ID": self.auto_convert_failed,
            "AUTO_SHUTDOWN_FAILED_FOR_NOTEBOOK_ID": self.auto_shutdown_failed,
        })
        self._success.append({
            "AUTO_CONVERT_SUCCESS_FOR_NOTEBOOK_ID": self.auto_convert_success,
            "AUTO_SHUTDOWN_SUCCESS_FOR_NOTEBOOK_ID": self.auto_shutdown_success,
        })
        if self.paid_sku_not_found or self.auto_convert_failed or self.auto_shutdown_failed:
            self._send_report(
                self._errors,
                self._success,
                subject=TERMINATE_FREE_NOTEBOOK_USAGE_MAIL_SUBJECT,
                body_description=BODY_DESCRIPTION,
            )

    def are_credits_sufficient(self, notebook):
        billable_customer = notebook.project.team.owner.get_primary_contact()
        sku_item_price = self._get_paid_sku_item_price(notebook)
        is_credit_sufficient, response_str = is_credit_sufficient_for_inventory_launch(billable_customer, sku_item_price)
        return is_credit_sufficient

    def _get_paid_sku_item_price(self, notebook: Notebook, free_sku=None):
        if not free_sku:
            free_sku = notebook.sku
        free_sku_item_price = notebook.sku_item_price
        paid_sku_item_price_collection = self.paid_sku_mapping.get(free_sku.id, [])
        for paid_sku_item_price in paid_sku_item_price_collection:
            if (paid_sku_item_price.currency == free_sku_item_price.currency and paid_sku_item_price.location == free_sku_item_price.location):
                return paid_sku_item_price
        return None


run = TerminateFreeNotebookUsageCron().run
