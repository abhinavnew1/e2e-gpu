from django import forms
from django.contrib import admin
from django.contrib.admin.widgets import FilteredSelectMultiple
from django.contrib.auth.models import Group, Permission
from django.utils.translation import gettext_lazy as _
from safedelete.admin import SafeDeleteAdmin
from simple_history.admin import SimpleHistoryAdmin

from customer.models import Customer, CustomerConsent, CustomerFreeNotebookHours


class CustomerAdmin(SafeDeleteAdmin, SimpleHistoryAdmin):
    fieldsets = (
        (_("Personal Info"), {"fields": ("email", "first_name", "last_name", "phone", "username", "password",)}),
        (_("Additional Info"), {"fields": ("is_primary_contact", "primary_email", "currency", "is_suspended",)}),
        (_("Designation"), {"fields": ("is_active", "is_staff", "is_superuser",)}),
        (_("Important Dates"), {"fields": ("last_login", "date_joined",)}),
    )
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "email",
        "first_name",
        "last_name",
        "is_primary_contact",
        "primary_email",
        "currency",
        "is_active",
        "is_suspended",
        "date_joined",
        "created_at",
        "updated_at",
    )
    raw_id_fields = ()
    search_fields = ("id", "email", "first_name", "last_name", "phone", "primary_email",)
    list_filter = ("is_active", "is_primary_contact", "currency", "is_staff", "is_superuser", "is_suspended",)
    list_display_links = ("id", "email", "first_name", "last_name",)
    readonly_fields = ()
    list_select_related = ("currency",)


class GroupAdminForm(forms.ModelForm):
    users = forms.ModelMultipleChoiceField(
        queryset=Customer.objects.all(),
        required=False,
        widget=FilteredSelectMultiple(verbose_name=_("Users"), is_stacked=False),
    )

    permissions = forms.ModelMultipleChoiceField(
        queryset=Permission.objects.all(),
        required=False,
        widget=FilteredSelectMultiple(verbose_name=_("Permissions"), is_stacked=False),
    )

    class Meta:
        model = Group
        exclude = ()

    def __init__(self, *args, **kwargs):
        super(GroupAdminForm, self).__init__(*args, **kwargs)
        if self.instance and self.instance.pk:
            customer_ids = [ur[0] for ur in self.instance.user_set.values_list()]
            customers = Customer.objects.filter(id__in=customer_ids)
            self.fields["users"].initial = customers

    def save(self, commit=True):
        group = super(GroupAdminForm, self).save(commit=False)
        group.save()

        for user in group.user_set.all():
            group.user_set.remove(user)

        for customer in self.cleaned_data["users"]:
            group.user_set.add(customer)

        if commit:
            group.save()

        if group.pk:
            self.save_m2m()

        return group


class GroupAdmin(admin.ModelAdmin):
    form = GroupAdminForm


class CustomerFreeNotebookHoursAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "customer",
        "gpu_free_hours_per_month",
        "gpu_free_hours_used",
        "cpu_free_hours_used",
    )
    raw_id_fields = ("customer",)
    search_fields = ("id", "customer__email",)
    list_filter = ("deleted", "gpu_free_hours_per_month",)
    list_display_links = ("id", "customer",)
    list_select_related = ("customer",)


class CustomerConsentAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "customer",
        "model_playground"
    )
    raw_id_fields = ("customer",)
    search_fields = ("id", "customer__email",)
    list_filter = ("deleted", "model_playground")
    list_display_links = ("id", "customer",)
    list_select_related = ("customer",)


admin.site.register(Customer, CustomerAdmin)
admin.site.register(Permission)
admin.site.unregister(Group)
admin.site.register(Group, GroupAdmin)
admin.site.register(CustomerFreeNotebookHours, CustomerFreeNotebookHoursAdmin)
admin.site.register(CustomerConsent, CustomerConsentAdmin)