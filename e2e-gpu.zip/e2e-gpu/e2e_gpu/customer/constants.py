

PRIVATE_WORKSPACE_SUPPORT_MESSAGE = "Unable to create Private Workspace for customer./nerrors: {errors}"
SUSPEND = "SUSPEND"
UNSUSPEND = "UN_SUSPEND"

DEFAULT_GPU_FREE_HOURS_PER_MONTH = 2

NOTIFY_CLOUD_SUPPORT_FOR_NEW_CUSTOMER_MAIL_TEMPLATE = "customer/notify_cloud_support_for_new_customer"

# tasks constants
CHECK_AND_NOTIFY_FOR_NEW_CUSTOMER_TASK = "check_and_notify_for_new_customer_task"
ON_CUSTOMER_SUSPEND_TASK = "on_customer_suspend_task"
ON_CUSTOMER_UNSUSPEND_TASK = "customer_unsuspend_task"
CUSTOMER_SERVICE_SUSPENSION_FAILED_ERROR = "Failed to remove services for suspended customer for following items: {items}"
CUSTOMER_SERVICE_UNSUSPENSION_FAILED_ERROR = "Failed to restart services for unsuspended customer for following items: {items}"
CUSTOMER_SERVICE_SUSPENSION_FAILED_SUBJECT = "Services removal failed for suspended customer: {email_id}"
CUSTOMER_SERVICE_UNSUSPENSION_FAILED_SUBJECT = "Services restart failed for unsuspended customer: {email_id}"

# types of users
PRIMARY = "primary"
CONTACT_PERSON = "contact_person"
