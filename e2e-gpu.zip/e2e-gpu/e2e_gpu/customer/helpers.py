import logging

import requests
from django.conf import settings
from rest_framework import status

from gpu_service.constants import MYACCOUNT_CUSTOMER_DETAILS_API, MYACCOUNT_CUSTOMER_INFO_API
from gpu_service.models import Currency

logger = logging.getLogger(__name__)


def fetch_user_currency(customer_auth_header, email):
    """fetches user currency from MyAccount"""
    resp = get_myaccount_customer_details(
        auth_header = customer_auth_header,
    )
    if resp.status_code != status.HTTP_200_OK:
        logger.error(f"FETCH_USER_CURRENCY_FROM_MYACCOUNT | CRITICAL_RED | STATUS_CODE:{str(resp.status_code)} | CANNOT_UPDATE_CUSTOMER_CURRENCY | CUSTOMER:{email}")
        return None
    resp = resp.json()
    currency = Currency.get_currency_object(currency_name=resp["data"].get("payment_currency"))
    return currency


def get_myaccount_customer_details(auth_header):
    url = MYACCOUNT_CUSTOMER_DETAILS_API
    headers = {"Authorization": auth_header,
               "Content-Type": "application/json",}
    response = requests.request("GET", url, headers=headers)
    return response


def get_customer_my_account_info(email):
    email = email.replace('+', '%2B')
    url = MYACCOUNT_CUSTOMER_INFO_API.format(email, settings.GPU_BILLING_API_TOKEN)
    headers = {"authorization": "",
               "Content-Type": "application/json",}
    response = requests.request("GET", url, headers=headers)
    if response.status_code == status.HTTP_200_OK:
        return response.json()["data"]
    logger.error(f"ERROR_DURING_INFO_FETCH_FROM_MY_ACCOUNT | CRITICAL_RED | STATUS_CODE:{str(response.status_code)} | email={email}")
    return {}


def get_prepaid_credit_balance_via_user_email(email):
    customer_info = get_customer_my_account_info(email)
    is_prepaid, prepaid_user_balance = customer_info.get("is_prepaid", None), customer_info.get("prepaid_user_balance", None)
    prepaid_user_balance = float(prepaid_user_balance) if prepaid_user_balance else prepaid_user_balance
    return is_prepaid, prepaid_user_balance

