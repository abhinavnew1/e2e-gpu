from django.conf import settings
from django.contrib.auth.models import AbstractUser, UserManager
from django.db import models
from django.utils.translation import gettext_lazy as _
from safedelete import safedelete_mixin_factory
from simple_history.models import HistoricalRecords

from customer.constants import DEFAULT_GPU_FREE_HOURS_PER_MONTH
from e2e_core.mixins import BaseMixin, SafeDeleteMixinExtended
from gpu_service.models import Currency

policy = settings.SAFE_DELETE_POLICY_SET[settings.SAFE_DELETE_POLICY]

# the admin requires a special mixin with the manager superclass as the UserManager
safe_delete_admin_mixin = safedelete_mixin_factory(
    policy=policy, manager_superclass=UserManager
)


# mixin should come before AbstractUser while inheriting else the manager won't be applied.
class Customer(safe_delete_admin_mixin, BaseMixin, AbstractUser):
    email = models.EmailField(_('email address'), blank=True, unique=True)
    phone = models.CharField(max_length=64, default=None, null=True, blank=True)  # TODO: set null false once phone is set in jwt token
    currency = models.ForeignKey(Currency, on_delete=models.SET_NULL, null=True)
    is_primary_contact = models.BooleanField(null=True)
    primary_email = models.EmailField(null=True)
    password = models.CharField(_('password'), max_length=128, null=True, blank=True)
    is_suspended = models.BooleanField(default=False)

    history = HistoricalRecords()

    def __str__(self):
        return f"<Customer({self.id}: {self.email})>"

    @property
    def full_name(self):
        return self.get_full_name()

    def get_primary_contact(self):
        """returns the customer object of the primary contact for the contact person"""
        if self.is_primary_contact:
            return self
        primary_customer = Customer.objects.filter(email=self.primary_email).first()
        if not primary_customer:
            primary_customer = self.register_primary_contact_on_gpu()
        return primary_customer

    def register_primary_contact_on_gpu(self):
        """ If the primary contact is not present in the GPU Customer model yet, we create an inactive customer record for billing purposes.
        Primary Contact is set as active when the user visits GPU"""
        customer = Customer.objects.create(
                    is_superuser=False,
                    email=self.primary_email,
                    username=self.primary_email,
                    is_primary_contact=True,
                    primary_email=self.primary_email,
                    is_active=False,
                    currency=self.currency,
                )
        CustomerFreeNotebookHours.get_or_create_object(customer)
        return customer

    @classmethod
    def get_all_primary_customers(cls):
        return cls.objects.filter(is_superuser=False, is_primary_contact=True)

    @classmethod
    def get_customer_from_email(cls, email):
        return cls.objects.filter(email=email).first()

    @classmethod
    def get_all_emails_for_primary_user(cls, primary_email: str) -> list:
        """returns a list of emails of all active users related to the primary_email.
        This will include emails of the primary user and all of its secondary contacts
        """
        return list(
            Customer.objects.filter(
                primary_email=primary_email, is_active=True
            ).values_list("email", flat=True)
        )

    @property
    def gpu_free_hours_remaining(self):
        primary_customer = self.get_primary_contact()
        return primary_customer.customerfreenotebookhours.gpu_free_hours_remaining


class CustomerFreeNotebookHours(SafeDeleteMixinExtended, BaseMixin):
    customer = models.OneToOneField(Customer, on_delete=models.CASCADE)
    gpu_free_hours_per_month = models.FloatField(default=DEFAULT_GPU_FREE_HOURS_PER_MONTH)
    gpu_free_hours_used = models.FloatField(default=0)
    cpu_free_hours_used = models.FloatField(default=0)

    @property
    def gpu_free_hours_remaining(self):
        return self.gpu_free_hours_per_month - self.gpu_free_hours_used

    @classmethod
    def get_or_create_object(cls, customer: Customer):
        primary_customer = customer.get_primary_contact()
        obj, is_created = cls.objects.get_or_create(customer=primary_customer)
        return obj, is_created


# PBAC_TODO: Delete after pbac-deployment
class CustomerConsent(SafeDeleteMixinExtended, BaseMixin):
    customer = models.OneToOneField(Customer, on_delete=models.CASCADE)
    model_playground = models.BooleanField(default=False)
