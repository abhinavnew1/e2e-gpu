import logging

from customer.api.v1.services.new_customer_alert_service import NewCustomerAlertService
from customer.constants import (CHECK_AND_NOTIFY_FOR_NEW_CUSTOMER_TASK, CUSTOMER_SERVICE_SUSPENSION_FAILED_ERROR,
                                CUSTOMER_SERVICE_SUSPENSION_FAILED_SUBJECT, CUSTOMER_SERVICE_UNSUSPENSION_FAILED_ERROR,
                                CUSTOMER_SERVICE_UNSUSPENSION_FAILED_SUBJECT, ON_CUSTOMER_SUSPEND_TASK,
                                ON_CUSTOMER_UNSUSPEND_TASK)
from customer.models import Customer
from e2e_core.helpers import support_ticket_generator
from e2e_gpu.celery import app
from notebook.api.v1.services.notebook_groot_service import NotebookGrootService
from notebook.constants import (DONE as NOTEBOOK_DONE, ERROR as NOTEBOOK_ERROR,
                                STOPPED as NOTEBOOK_STOPPED, TERMINATING as NOTEBOOK_TERMINATING)
from notebook.models import Notebook
from projects.api.v1.services.namespace_service import NamespaceService
from projects.models import ProjectMembers
from vector_db.api.v1.services.vectordb_groot_services import VectorDBGatewayGrootService
from vector_db.constants import (DONE as VECTOR_DB_DONE, ERROR as VECTOR_DB_ERROR)
from vector_db.models import VectorDB

logger = logging.getLogger(__name__)


@app.task(
    name=CHECK_AND_NOTIFY_FOR_NEW_CUSTOMER_TASK,
    bind=True,
    autoretry_for=(Exception,),
)
def check_and_notify_for_new_customer_task(self, *args, **kwargs):
    customer_email = kwargs.get("customer_email")
    primary_customer_email = kwargs.get("primary_customer_email")
    created_at_cutoff = kwargs.get("created_at_timestamp")
    created_service = kwargs.get("created_service")

    NewCustomerAlertService(
        customer_email, primary_customer_email, created_service, created_at_cutoff
    ).check_and_notify_for_new_customer()


@app.task(
    name=ON_CUSTOMER_SUSPEND_TASK,
    bind=True
)
def on_customer_suspend_task(self, *args, **kwargs):
    failed_suspensions = {}
    primary_email = kwargs.get("primary_email")
    customer = Customer.objects.filter(email=primary_email).first()

    project_members = ProjectMembers.objects.filter(
        deleted_at__isnull=True,
        team_member__iam_user__owner=customer,
    ).select_related("team_member__iam_user__added_user", "project")

    notebook_list = list(Notebook.objects.filter(
        deleted_at__isnull=True,
        notebookhistory__customer__email=primary_email,
        ssh_keys__isnull=False,
    ).exclude(status__in=[NOTEBOOK_DONE, NOTEBOOK_ERROR, NOTEBOOK_STOPPED, NOTEBOOK_TERMINATING],).distinct())

    vectordb_host_url_list = list(VectorDB.objects.filter(
        deleted_at__isnull=True,
        vectordbhistory__customer__email=primary_email
    ).exclude(status__in=[VECTOR_DB_DONE, VECTOR_DB_ERROR],).distinct().values_list("endpoint_url", flat=True))

    # permissions removal from namespace
    failed_suspensions["permissions"] = []
    namespace_service = NamespaceService(None, None)
    for prj_member in project_members:
        added_user = prj_member.team_member.iam_user.added_user
        namespace_service.project = prj_member.project
        namespace_service.customer = added_user
        is_success = namespace_service.delete_permissions(added_user.email, prj_member.role)
        if not is_success:
            failed_suspensions["permissions"].append(prj_member.id)
    if not failed_suspensions["permissions"]:
        failed_suspensions.pop("permissions", "")

    # remove notebooks ssh service
    failed_suspensions["notebooks"] = []
    for notebook in notebook_list:
        is_success, _ = NotebookGrootService(notebook.project.namespace, notebook.created_by).delete_ssh_service_on_groot(notebook.slug_name, {})
        if not is_success:
            failed_suspensions["notebooks"].append(notebook.id)
    if not failed_suspensions["notebooks"]:
        failed_suspensions.pop("notebooks")

    # remove vector db host url
    failed_suspensions["vectordb_host_url"] = []
    is_success, _ = VectorDBGatewayGrootService(customer=customer).remove_host_in_vectordb_gateway(vectordb_host_url_list)
    if not is_success:
        failed_suspensions["vectordb_host_url"] = vectordb_host_url_list
    if not failed_suspensions["vectordb_host_url"]:
        failed_suspensions.pop("vectordb_host_url")

    # raise ticket of unsuspended items
    if failed_suspensions:
        support_ticket_generator(
            errors=CUSTOMER_SERVICE_SUSPENSION_FAILED_ERROR.format(items=failed_suspensions),
            subject=CUSTOMER_SERVICE_SUSPENSION_FAILED_SUBJECT.format(email_id=primary_email),
            customer=customer
        )


@app.task(
    name=ON_CUSTOMER_UNSUSPEND_TASK,
    bind=True
)
def on_customer_unsuspend_task(self, *args, **kwargs):
    failed_restart = {}
    primary_email = kwargs.get("primary_email")
    customer = Customer.objects.filter(email=primary_email).first()

    project_members = ProjectMembers.objects.filter(
        deleted_at__isnull=True,
        team_member__iam_user__owner=customer,
    ).select_related("team_member__iam_user__added_user", "project")

    vectordb_host_url_list = list(VectorDB.objects.filter(
        deleted_at__isnull=True,
        vectordbhistory__customer__email=primary_email,
    ).exclude(status__in=[VECTOR_DB_DONE, VECTOR_DB_ERROR],).distinct().values_list("endpoint_url", flat=True))

    notebook_list = list(Notebook.objects.filter(
        deleted_at__isnull=True,
        notebookhistory__customer__email=primary_email,
        ssh_keys__isnull=False,
    ).exclude(status__in=[NOTEBOOK_DONE, NOTEBOOK_ERROR, NOTEBOOK_STOPPED, NOTEBOOK_TERMINATING]).distinct())

    # rolebindings re-creation
    failed_restart["permissions"] = []
    namespace_service = NamespaceService(None, None)
    for prj_member in project_members:
        added_user = prj_member.team_member.iam_user.added_user
        namespace_service.project = prj_member.project
        namespace_service.customer = added_user
        is_success = namespace_service.add_permissions(added_user.email, prj_member.role)
        if not is_success:
            failed_restart["permissions"].append(prj_member.id)
    if not failed_restart["permissions"]:
        failed_restart.pop("permissions")

    # vectordb host_url addition in gateway
    failed_restart["vectordb_host_url"] = []
    is_success, _ = VectorDBGatewayGrootService(customer=customer).add_host_in_vectordb_gateway(vectordb_host_url_list)
    if not is_success:
        failed_restart["vectordb_host_url"] = vectordb_host_url_list
    if not failed_restart["vectordb_host_url"]:
        failed_restart.pop("vectordb_host_url")

    # notebook ssh-service recreation
    failed_restart["notebooks"] = []
    for notebook in notebook_list:
        is_success, _ = NotebookGrootService(notebook.project.namespace, notebook.created_by).create_ssh_service_on_groot(notebook.slug_name, {})
        if not is_success:
            failed_restart["notebooks"].append(notebook.id)
    if not failed_restart["notebooks"]:
        failed_restart.pop("notebooks")

    # raise tickets for failed unsuspensions
    if failed_restart:
        support_ticket_generator(
            errors=CUSTOMER_SERVICE_UNSUSPENSION_FAILED_ERROR.format(items=failed_restart),
            subject=CUSTOMER_SERVICE_UNSUSPENSION_FAILED_SUBJECT.format(email_id=primary_email),
            customer=customer
        )
