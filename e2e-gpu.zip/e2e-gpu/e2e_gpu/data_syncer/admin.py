from django.contrib import admin
from safedelete.admin import SafeDeleteAdmin

from data_syncer.models import Connection, Destination, Source


class SourceAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "deleted_at",
        "id",
        "name",
        "airbyte_id",
        "source_type",
        "project",
        "created_by",
    )
    raw_id_fields = ("project", "created_by")
    search_fields = ("id", "airbyte_id", "name", "created_by__email", "project_id")
    list_filter = ("deleted_at", "deleted", "source_type", "status")
    list_display_links = ("id", "name")
    list_select_related = ("project", "created_by")


class DestinationAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "deleted_at",
        "id",
        "name",
        "dataset",
        "path_prefix",
        "airbyte_id",
        "project",
        "created_by",
        "created_at",
        "updated_at",
    )
    raw_id_fields = ("project", "dataset", "created_by")
    search_fields = ("id", "name", "dataset__name", "path_prefix", "airbyte_id", "project_id", "created_by__email")
    list_filter = ("deleted_at", "deleted", "status")
    list_display_links = ("id", "name")
    list_select_related = ("dataset", "project", "created_by")


class ConnectionAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "deleted_at",
        "id",
        "name",
        "source",
        "destination",
        "airbyte_id",
        "frequency",
        "status",
        "project",
        "sync_mode",
        "schedule_type",
        "last_sync",
        "created_by",
    )
    raw_id_fields = ("project", "source", "destination", "created_by")
    search_fields = ("id", "name", "source_id", "destination_id", "airbyte_id", "project_id", "created_by__email")
    list_filter = ("frequency", "status", "sync_mode", "deleted", "deleted_at", "schedule_type")
    list_display_links = ("id", "name")
    list_select_related = ("source", "destination", "project", "created_by")


admin.site.register(Source, SourceAdmin)
admin.site.register(Destination, DestinationAdmin)
admin.site.register(Connection, ConnectionAdmin)
