from django.conf import settings

# airbyte urls
AIRBYTE_SOURCE_TESTING_URL = settings.AIRBYTE_BASE_URL + "api/v1/scheduler/sources/check_connection"
AIRBYTE_SOURCE_CREATION_URL = settings.AIRBYTE_BASE_URL + "api/v1/sources/create"
AIRBYTE_SOURCE_LISTING_URL = settings.AIRBYTE_BASE_URL + "api/v1/sources/list"
AIRBYTE_SOURCE_DELETION_URL = settings.AIRBYTE_BASE_URL + "api/v1/sources/delete"
AIRBYTE_SOURCE_UPDATE_TESTING_URL = settings.AIRBYTE_BASE_URL + "api/v1/sources/check_connection_for_update"
AIRBYTE_SOURCE_UPDATE_URL = settings.AIRBYTE_BASE_URL + "api/v1/sources/update"

AIRBYTE_DESTINATION_TESTING_URL = settings.AIRBYTE_BASE_URL + "api/v1/scheduler/destinations/check_connection"
AIRBYTE_DESTINATION_CREATION_URL = settings.AIRBYTE_BASE_URL + "api/v1/destinations/create"
AIRBYTE_DESTINATION_LISTING_URL = settings.AIRBYTE_BASE_URL + "api/v1/destinations/list"
AIRBYTE_DESTINATION_DELETION_URL = settings.AIRBYTE_BASE_URL + "api/v1/destinations/delete"
AIRBYTE_DESTINATION_UPDATE_TESTING_URL = settings.AIRBYTE_BASE_URL + "api/v1/destinations/check_connection_for_update"
AIRBYTE_DESTINATION_UPDATE_URL = settings.AIRBYTE_BASE_URL + "api/v1/destinations/update"

AIRBYTE_CONNECTION_CREATION_URL = settings.AIRBYTE_BASE_URL + "api/v1/connections/create"
AIRBYTE_CONNECTION_LISTING_URL = settings.AIRBYTE_BASE_URL + "api/v1/web_backend/connections/list"
AIRBYTE_CONNECTION_DELETION_URL = settings.AIRBYTE_BASE_URL + "api/v1/connections/delete"
AIRBYTE_CONNECTION_UPDATION_URL = settings.AIRBYTE_BASE_URL + "api/v1/web_backend/connections/update"
AIRBYTE_CONNCTION_STATE_UPDATE_URL = settings.AIRBYTE_BASE_URL + "/api/v1/state/create_or_update_safe"

AIRBYTE_JOB_CREATION_URL = settings.AIRBYTE_BASE_URL + "api/v1/connections/sync"
AIRBYTE_JOB_LISTING_URL = settings.AIRBYTE_BASE_URL + "api/v1/jobs/list"
AIRBYTE_JOB_DETAILS_URL = settings.AIRBYTE_BASE_URL + "api/v1/jobs/get_without_logs"
AIRBYTE_JOB_DELETION_URL = settings.AIRBYTE_BASE_URL + "api/v1/jobs/cancel"

ENABLE_ACTION = "enable"
DISABLE_ACTION = "disable"
UPDATE_ACTION = "update"
SOURCE = "SOURCE"
DESTINATION = "DESTINATION"
CONNECTION = "CONNECTION"
JOB = "JOB"
CREATE = "CREATE"
LIST = "LIST"
GET = "GET"
DELETE = "DELETE"
UPDATE = "UPDATE"
TEST = "TEST"
UPDATE_TEST = "UPDATE_TEST"
AIRBYTE_SOURCE_URL_DICT = {
    CREATE: AIRBYTE_SOURCE_CREATION_URL,
    LIST: AIRBYTE_SOURCE_LISTING_URL,
    DELETE: AIRBYTE_SOURCE_DELETION_URL,
    TEST: AIRBYTE_SOURCE_TESTING_URL,
    UPDATE_TEST: AIRBYTE_SOURCE_UPDATE_TESTING_URL,
    UPDATE: AIRBYTE_SOURCE_UPDATE_URL,
}
AIRBYTE_DESTINATION_URL_DICT = {
    CREATE: AIRBYTE_DESTINATION_CREATION_URL,
    LIST: AIRBYTE_DESTINATION_LISTING_URL,
    DELETE: AIRBYTE_DESTINATION_DELETION_URL,
    TEST: AIRBYTE_DESTINATION_TESTING_URL,
    UPDATE_TEST: AIRBYTE_DESTINATION_UPDATE_TESTING_URL,
    UPDATE: AIRBYTE_DESTINATION_UPDATE_URL,
}
AIRBYTE_CONNECTION_URL_DICT = {
    CREATE: AIRBYTE_CONNECTION_CREATION_URL,
    LIST: AIRBYTE_CONNECTION_LISTING_URL,
    DELETE: AIRBYTE_CONNECTION_DELETION_URL,
    UPDATE: AIRBYTE_CONNECTION_UPDATION_URL,
}
AIRBYTE_JOB_URL_DICT = {
    CREATE: AIRBYTE_JOB_CREATION_URL,
    LIST: AIRBYTE_JOB_LISTING_URL,
    GET: AIRBYTE_JOB_DETAILS_URL,
    DELETE: AIRBYTE_JOB_DELETION_URL,
}

PAYLOAD_INCREMENTAL_CONNECTION_DATA_TIME_FORMAT = "%Y-%m-%dT%H:%M:%SZ"
AIRBYTE_INCREMENTAL_CONNECTION_DATE_TIME_FORMAT = "%Y-%m-%d %H-%M-%S"
CRONITER_DATE_TIME_FORMAT = "%Y-%m-%d %H:%M:%S"
CRON_EXPRESSION_LENGTH = 5
DATA_SYNCER_NAME_REGEX = r'[a-z0-9]([-a-z0-9]*[a-z0-9])?'
NAME_INVALID = "Name should contain letters, digits and hyphen only and should start with an alpha-numeric character only."
NAME_ALREADY_EXISTS = "{} with same name already exists in project."

MINIO = "minio"
AWS_S3 = "aws_s3"
GCS = "gcs"
AZURE_BLOB_STORAGE = "azure_blob_storage"
GOOGLE_DRIVE_STORAGE = "google_drive_storage"
AIRBYTE_SOURCE_TYPE_CHOICES = (
    (MINIO, MINIO),
    (AWS_S3, AWS_S3),
    (GCS, GCS),
    (AZURE_BLOB_STORAGE, AZURE_BLOB_STORAGE),
    (GOOGLE_DRIVE_STORAGE, GOOGLE_DRIVE_STORAGE),
)

ACTIVE = "active"
INACTIVE = "inactive"
DEPRECATED = "deprecated"
DONE = "done"
ERROR = "error"
SOURCE_STATUS_CHOICES = (
    (ACTIVE, ACTIVE),
    (INACTIVE, INACTIVE),
    (DONE, DONE),
    (ERROR, ERROR),
)
DESTINATION_STATUS_CHOICES = (
    (ACTIVE, ACTIVE),
    (INACTIVE, INACTIVE),
    (DONE, DONE),
    (ERROR, ERROR),
)
CONNECTION_STATUS_CHOICES = (
    (ACTIVE, ACTIVE),
    (INACTIVE, INACTIVE),
    (DONE, DONE),
    (DEPRECATED, DEPRECATED),
    (ERROR, ERROR),
)

FULL_REFRESH_OVERWRITE = "full_refresh_overwrite"
FULL_REFRESH_APPEND = "full_refresh_append"
INCREMENTAL_APPEND = "incremental_append"
AIRBYTE_SYNC_MODE_CHOICES = (
    (FULL_REFRESH_OVERWRITE, FULL_REFRESH_OVERWRITE),
    (FULL_REFRESH_APPEND, FULL_REFRESH_APPEND),
    (INCREMENTAL_APPEND, INCREMENTAL_APPEND),
)

STAR_PAYLOAD_STRING = "**********"
FREQUENCY = "frequency"
MANUAL = "manual"
BASIC = "basic"
CRON = "cron"
CONNECTION_SCHEDULE_TYPE_CHOICES = (
    (MANUAL, MANUAL),
    (BASIC, BASIC),
    (CRON, CRON),
)

PENDING = "pending"
RUNNING = "running"
INCOMPLETE = "incomplete"
FAILED = "failed"
SUCCEEDED = "succeeded"
CANCELLED = "cancelled"
AIRBYTE_JOB_STATUS_CHOICES = (
    (PENDING, PENDING),
    (RUNNING, RUNNING),
    (INCOMPLETE, INCOMPLETE),
    (FAILED, FAILED),
    (SUCCEEDED, SUCCEEDED),
    (CANCELLED, CANCELLED),
    (DONE, DONE),
    (ERROR, ERROR),
)

DEFINITION_ID_DICT = {
    MINIO: settings.MINIO_DEFINITION_ID,
    AWS_S3: settings.AWS_S3_DEFINITION_ID,
    GCS: settings.GCS_DEFINITION_ID,
    GOOGLE_DRIVE_STORAGE: settings.GOOGLE_DRIVE_STORAGE_DEFINITION_ID,
    AZURE_BLOB_STORAGE: settings.AZURE_BLOB_STORAGE_DEFINITION_ID,
}

S3_STREAM_NAME = "s3_objects"
MINIO_STREAM_NAME = "minio_objects"
GOOGLE_DRIVE_STORAGE_STREAM_NAME = "google_drive_objects"
GCS_STREAM_NAME = "gcs_objects"
AZURE_BLOB_STORAGE_STREAM_NAME = "blob_objects"
AIRBYTE_CONNECTION_STREAM_NAME_DICT = {
    MINIO: MINIO_STREAM_NAME,
    AWS_S3: S3_STREAM_NAME,
    GOOGLE_DRIVE_STORAGE: GOOGLE_DRIVE_STORAGE_STREAM_NAME,
    GCS: GCS_STREAM_NAME,
    AZURE_BLOB_STORAGE: AZURE_BLOB_STORAGE_STREAM_NAME,
}

SOURCE_CATALOG_ID_DICT = {
    MINIO: settings.SOURCE_CATALOG_ID_MINIO,
    AWS_S3: settings.SOURCE_CATALOG_ID_S3,
    GCS: settings.SOURCE_CATALOG_ID_GCS,
    GOOGLE_DRIVE_STORAGE: settings.SOURCE_CATALOG_ID_GOOGLE_DRIVE_STORAGE,
    AZURE_BLOB_STORAGE: settings.SOURCE_CATALOG_ID_AZURE_BLOB_STORAGE,
}

MINIO_STREAM_DICT = {
    "name": MINIO_STREAM_NAME,
    "supportedSyncModes": ["full_refresh", "incremental"],
    "sourceDefinedCursor": True,
    "defaultCursorField": ["date_and_time"],
    "jsonSchema": {
        "properties": {
            "date_and_time": {
                "type": "string"
            },
            "endpoint_url": {
                "type": "string"
            },
            "access_key": {
                "type": "string"
            },
            "secret_key": {
                "type": "string"
            },
            "bucket_name": {
                "type": "string"
            },
            "object_name": {
                "type": "string"
            }
        }
    }
}
AWS_S3_STREAM_DICT = {
    "name": S3_STREAM_NAME,
    "supportedSyncModes": ["full_refresh", "incremental"],
    "sourceDefinedCursor": True,
    "defaultCursorField": ["date_and_time"],
    "jsonSchema": {
        "properties": {
            "date_and_time": {
                "type": "string"
            },
            "access_key": {
                "type": "string"
            },
            "secret_key": {
                "type": "string"
            },
            "bucket_name": {
                "type": "string"
            },
            "object_name": {
                "type": "string"
            },
            "aws_region": {
                "type": "string"
            },
            "arn_role": {
                "type": "string"
            }
        }
    }
}
GOOGLE_DRIVE_STORAGE_STREAM_DICT = {
    "name": GOOGLE_DRIVE_STORAGE_STREAM_NAME,
    "supportedSyncModes": ["full_refresh", "incremental"],
    "sourceDefinedCursor": True,
    "defaultCursorField": ["date_and_time"],
    "jsonSchema": {
        "properties": {
            "date_and_time": {
                "type": "string"
            },
            "refresh_token": {
                "type": "string"
            },
            "client_id": {
                "type": "string"
            },
            "client_secret": {
                "type": "string"
            },
            "object_id": {
                "type": "string"
            },
            "object_name": {
                "type": "string"
            },
            "object_type": {
                "type": "string"
            }
        }
    }
}
GCS_STREAM_DICT = {
    "name": GCS_STREAM_NAME,
    "supportedSyncModes": ["full_refresh", "incremental"],
    "sourceDefinedCursor": True,
    "defaultCursorField": ["date_and_time"],
    "jsonSchema": {
        "properties": {
            "date_and_time": {
                "type": "string"
            },
            "credentials_dict": {
                "type": "string"
            },
            "bucket_name": {
                "type": "string"
            },
            "object_name": {
                "type": "string"
            }
        }
    }
}
AZURE_BLOB_STORAGE_STREAM_DICT = {
    "name": AZURE_BLOB_STORAGE_STREAM_NAME,
    "supportedSyncModes": ["full_refresh", "incremental"],
    "sourceDefinedCursor": True,
    "defaultCursorField": ["date_and_time"],
    "jsonSchema": {
        "properties": {
            "date_and_time": {
                "type": "string"
            },
            "connection_string": {
                "type": "string"
            },
            "container_name": {
                "type": "string"
            },
            "object_name": {
                "type": "string"
            }
        }
    }
}
AIRBYTE_STREAM_DICT = {
    MINIO: MINIO_STREAM_DICT,
    AWS_S3: AWS_S3_STREAM_DICT,
    GCS: GCS_STREAM_DICT,
    GOOGLE_DRIVE_STORAGE: GOOGLE_DRIVE_STORAGE_STREAM_DICT,
    AZURE_BLOB_STORAGE: AZURE_BLOB_STORAGE_STREAM_DICT,
}

AIRBYTE_JOB_CANCELLATION_FAILED = "Data_syncer job cancellation failed"
FAILED_TO_TEST_AIRBYTE_RESOURCE = "Failed to test {}."
AIRBYTE_SOURCE_CREATION_FAILED = "Failed to create Source."
FAILED_TO_CREATE_DESTINATION = "Failed to create Destination."
FAILED_TO_CREATE_AIRBYTE_JOB = "Failed to sync."
JOB_NOT_RUNNING = "Job not in running state."
CONNECTION_INACTIVE = "Connection is not active."
SYNC_ALREADY_IN_PROGRESS = "Sync is already under progress."
CONNECTION_EXISTS = "Cannot delete {resource}. One or more connections exist with this {resource}."
RESOURCE_IN_ERROR_STATE = "Could not perform this action, {resource} in error state."
INVALID_CRON_EXPRESSION = "Cron expression is invalid."
CRON_EXPRESSION_LENGTH_ERROR = "Cron expressions require exactly 5 fields."
CRON_EXPRESSION_LAST_FIELD_ERROR = "Numeric values are not allowed in the last field of the cron expression."
CRON_EXPRESSION_SINGLE_QUESTION_MARK_CONSTRAINT_ERROR = "Invalid cron expression: Either the day_of_month or day_of_week field must contain '?', but not both."

AIRBYTE_WORKSPACE_CREATION_FAILED_MESSAGE = "Airbyte Workspace creation failed. Errors: {}"
AIRBYTE_WORKSPACE_CREATION_FAILED_SUBJECT = "Airbyte Workspace creation failed for customer: {email}"
INCONSISTENT_AIRBYTE_SOURCES_MESSAGE = "Inconsistency found for Airbyte sources. Following items were not found on airbyte server: {}"
INCONSISTENT_AIRBYTE_SOURCES_SUBJECT = "Airbyte sources inconsistency found for customer {email}"
INCONSISTENT_AIRBYTE_DESTINATIONS_MESSAGE = "Inconsistency found for Airbyte destinataions. Following items were not found on airbyte server: {}"
INCONSISTENT_AIRBYTE_DESTINATIONS_SUBJECT = "Airbyte destinations inconsistency found for customer {email}"
INCONSISTENT_AIRBYTE_CONNECTIONS_MESSAGE = "Inconsistency found for Airbyte connections. Following items were not found on airbyte server: {}"
INCONSISTENT_AIRBYTE_CONNECTIONS_SUBJECT = "Airbyte connections inconsistency found for customer {email}"
INCONSISTENT_AIRBYTE_JOBS_MESSAGE = "Inconsistency found for Airbyte jobs. Following items were not found on airbyte server: {}"
INCONSISTENT_AIRBYTE_JOBS_SUBJECT = "Airbyte jobs inconsistency found for customer {email}"
AIRBYTE_CONNECTION_STATE_UPDATION_FAILED_ERROR = "Airbyte Connection state updation failed for hook call with connection_id:{connection_id} and error: {error}"
AIRBYTE_CONNECTION_STATE_UPDATION_FAILED_SUBJECT = "Airbyte Connection state updation failed for customer: {email}"

DATA_SYNCER_SOURCE_CREATE_EVENT = "DATA_SYNCER_SOURCE_CREATE"
DATA_SYNCER_SOURCE_UPDATE_EVENT = "DATA_SYNCER_SOURCE_UPDATE"
DATA_SYNCER_SOURCE_DELETE_EVENT = "DATA_SYNCER_SOURCE_DELETE"
DATA_SYNCER_DESTINATION_CREATE_EVENT = "DATA_SYNCER_DESTINATION_CREATE"
DATA_SYNCER_DESTINATION_UPDATE_EVENT = "DATA_SYNCER_DESTINATION_UPDATE"
DATA_SYNCER_DESTINATION_DELETE_EVENT = "DATA_SYNCER_DESTINATION_DELETE"
DATA_SYNCER_CONNECTION_CREATE_EVENT = "DATA_SYNCER_CONNECTION_CREATE"
DATA_SYNCER_CONNECTION_UPDATE_EVENT = "DATA_SYNCER_CONNECTION_UPDATE"
DATA_SYNCER_CONNECTION_DELETE_EVENT = "DATA_SYNCER_CONNECTION_DELETE"
DATA_SYNCER_JOB_CREATE_EVENT = "DATA_SYNCER_JOB_CREATE"
DATA_SYNCER_JOB_CANCEL_EVENT = "DATA_SYNCER_JOB_CANCEL"
