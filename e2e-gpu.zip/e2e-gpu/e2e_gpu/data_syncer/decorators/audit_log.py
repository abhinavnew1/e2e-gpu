from rest_framework import status

from data_syncer.constants import (DATA_SYNCER_CONNECTION_CREATE_EVENT,
                                   DATA_SYNCER_CONNECTION_DELETE_EVENT,
                                   DATA_SYNCER_CONNECTION_UPDATE_EVENT,
                                   DATA_SYNCER_DESTINATION_CREATE_EVENT,
                                   DATA_SYNCER_DESTINATION_DELETE_EVENT,
                                   DATA_SYNCER_DESTINATION_UPDATE_EVENT,
                                   DATA_SYNCER_JOB_CANCEL_EVENT,
                                   DATA_SYNCER_JOB_CREATE_EVENT,
                                   DATA_SYNCER_SOURCE_CREATE_EVENT,
                                   DATA_SYNCER_SOURCE_DELETE_EVENT,
                                   DATA_SYNCER_SOURCE_UPDATE_EVENT)
from eventlogs.api.v1.services.eventlog_service import EventLogService
from eventlogs.constants import (CREATE, DATA_SYNCER_CONNECTION_SERVICE_CODE,
                                 DATA_SYNCER_DESTINATION_SERVICE_CODE,
                                 DATA_SYNCER_SOURCE_SERVICE_CODE, DELETE,
                                 EVENTLOG_SUCCESS_STATUS, UPDATE)


def source_create_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(DATA_SYNCER_SOURCE_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=DATA_SYNCER_SOURCE_CREATE_EVENT,
            resource_name=request.data.get("name"),
            resource_id="",
            resource_obj_id=None,
            event_type=CREATE,
        )
        response = func(*args, **kwargs)
        if response.status_code == status.HTTP_201_CREATED:
            event_log.update_log(
                status=EVENTLOG_SUCCESS_STATUS,
                resource_id=response.data["data"]["id"],
                detailed_info={
                    "name": response.data["data"].get("name"),
                    "source_type": response.data["data"].get("source_type"),
                    "configuration": response.data["data"].get("configuration"),
                    "project_id": kwargs.get("project_id"),
                },
                resource_obj_id=response.data["data"]["id"]
            )
        else:
            event_log.log_event_failure()
        return response
    return wrapper_func


def source_update_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(DATA_SYNCER_SOURCE_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=DATA_SYNCER_SOURCE_UPDATE_EVENT,
            resource_name=kwargs.get("source").name,
            resource_id=kwargs.get("source_id"),
            resource_obj_id=kwargs.get("source_id"),
            detailed_info={
                "request_data": request.data,
                "project_id": kwargs.get("project_id")
            },
            event_type=UPDATE
        )
        response = func(*args, **kwargs)
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else event_log.log_event_failure()
        return response
    return wrapper_func


def source_delete_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(DATA_SYNCER_SOURCE_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=DATA_SYNCER_SOURCE_DELETE_EVENT,
            resource_name=kwargs.get("source").name,
            resource_id=kwargs.get("source_id"),
            resource_obj_id=kwargs.get("source_id"),
            detailed_info={
                "project_id": kwargs.get("project_id")
            },
            event_type=DELETE
        )
        response = func(*args, **kwargs)
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else event_log.log_event_failure()
        return response
    return wrapper_func


def destination_create_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(DATA_SYNCER_DESTINATION_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=DATA_SYNCER_DESTINATION_CREATE_EVENT,
            resource_name=request.data.get("name"),
            resource_id="",
            resource_obj_id=None,
            event_type=CREATE,
        )
        response = func(*args, **kwargs)
        if response.status_code == status.HTTP_201_CREATED:
            event_log.update_log(
                status=EVENTLOG_SUCCESS_STATUS,
                resource_id=response.data["data"]["id"],
                detailed_info={
                    "name": response.data["data"].get("name"),
                    "dataset": response.data["data"].get("dataset"),
                    "path_prefix": response.data["data"].get("path_prefix"),
                    "project_id": kwargs.get("project_id"),
                },
                resource_obj_id=response.data["data"]["id"]
            )
        else:
            event_log.log_event_failure()
        return response
    return wrapper_func


def destination_update_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(DATA_SYNCER_DESTINATION_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=DATA_SYNCER_DESTINATION_UPDATE_EVENT,
            resource_name=kwargs.get("destination").name,
            resource_id=kwargs.get("destination_id"),
            resource_obj_id=kwargs.get("destination_id"),
            detailed_info={
                "request_data": request.data,
                "project_id": kwargs.get("project_id")
            },
            event_type=UPDATE
        )
        response = func(*args, **kwargs)
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else event_log.log_event_failure()
        return response
    return wrapper_func


def destination_delete_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(DATA_SYNCER_DESTINATION_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=DATA_SYNCER_DESTINATION_DELETE_EVENT,
            resource_name=kwargs.get("destination").name,
            resource_id=kwargs.get("destination_id"),
            resource_obj_id=kwargs.get("destination_id"),
            detailed_info={
                "project_id": kwargs.get("project_id")
            },
            event_type=DELETE
        )
        response = func(*args, **kwargs)
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else event_log.log_event_failure()
        return response
    return wrapper_func


def connection_create_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(DATA_SYNCER_CONNECTION_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=DATA_SYNCER_CONNECTION_CREATE_EVENT,
            resource_name=request.data.get("name"),
            resource_id="",
            resource_obj_id=None,
            event_type=CREATE,
        )
        response = func(*args, **kwargs)
        if response.status_code == status.HTTP_201_CREATED:
            event_log.update_log(
                status=EVENTLOG_SUCCESS_STATUS,
                resource_id=response.data["data"]["id"],
                detailed_info={
                    "name": response.data["data"].get("name"),
                    "status": response.data["data"].get("status"),
                    "frequency": response.data["data"].get("frequency"),
                    "project_id": kwargs.get("project_id"),
                },
                resource_obj_id=response.data["data"]["id"]
            )
        else:
            event_log.log_event_failure()
        return response
    return wrapper_func


def connection_update_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(DATA_SYNCER_CONNECTION_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=DATA_SYNCER_CONNECTION_UPDATE_EVENT,
            resource_name=kwargs.get("connection").name,
            resource_id=kwargs.get("connection_id"),
            resource_obj_id=kwargs.get("source_id"),
            detailed_info={
                "request_data": {"action": request.query_params.dict().get("action"), "body": request.data},
                "project_id": kwargs.get("project_id")
            },
            event_type=UPDATE
        )
        response = func(*args, **kwargs)
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else event_log.log_event_failure()
        return response
    return wrapper_func


def connection_delete_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(DATA_SYNCER_CONNECTION_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=DATA_SYNCER_CONNECTION_DELETE_EVENT,
            resource_name=kwargs.get("connection").name,
            resource_id=kwargs.get("connection_id"),
            resource_obj_id=kwargs.get("connection_id"),
            detailed_info={
                "project_id": kwargs.get("project_id")
            },
            event_type=DELETE
        )
        response = func(*args, **kwargs)
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else event_log.log_event_failure()
        return response
    return wrapper_func


def job_create_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(DATA_SYNCER_CONNECTION_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=DATA_SYNCER_JOB_CREATE_EVENT,
            resource_name=kwargs.get("connection").name,
            resource_id="",
            resource_obj_id=None,
            event_type=CREATE,
        )
        response = func(*args, **kwargs)
        if response.status_code == status.HTTP_201_CREATED:
            event_log.update_log(
                status=EVENTLOG_SUCCESS_STATUS,
                resource_id=response.data["data"]["id"],
                detailed_info={
                    "id": kwargs.get("connection").id,
                    "status": response.data["data"].get("status"),
                    "project_id": kwargs.get("project_id"),
                },
                resource_obj_id=kwargs.get("connection").id
            )
        else:
            event_log.log_event_failure()
        return response
    return wrapper_func


def job_cancel_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(DATA_SYNCER_CONNECTION_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=DATA_SYNCER_JOB_CANCEL_EVENT,
            resource_name=kwargs.get("connection").name,
            resource_id=kwargs.get("connection").id,
            resource_obj_id=kwargs.get("connection").id,
            detailed_info={
                "project_id": kwargs.get("project_id")
            },
            event_type=DELETE
        )
        response = func(*args, **kwargs)
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else event_log.log_event_failure()
        return response
    return wrapper_func
