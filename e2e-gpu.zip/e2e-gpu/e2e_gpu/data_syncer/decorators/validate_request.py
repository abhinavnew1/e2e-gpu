from django.conf import settings
from rest_framework.response import Response

from data_syncer.models import Connection, Destination, Source
from e2e_core.api.v1.services.base import BaseService
from e2e_core.constants import NOT_FOUND_ERROR


def validate_source_request(func):
    def wrapper_func(*args, **kwargs):
        project_id = kwargs.get("project_id")
        source_id = kwargs.get("source_id")
        source = Source.objects.filter(
            deleted_at__isnull=True,
            id=source_id,
            project_id=project_id,
        ).select_related(
            "project", "created_by"
        ).first()
        if not source:
            response = BaseService.get_404_response(NOT_FOUND_ERROR.format(service="Source"))
            return Response(response, status=response.get('code'))
        kwargs["source"] = source
        return func(*args, **kwargs)
    return wrapper_func


def validate_destination_request(func):
    def wrapper_func(*args, **kwargs):
        project_id = kwargs.get("project_id")
        destination_id = kwargs.get("destination_id")
        destination = Destination.objects.filter(
            deleted_at__isnull=True,
            id=destination_id,
            project_id=project_id
        ).select_related(
            "project", "created_by", "dataset"
        ).first()
        if not destination:
            response = BaseService.get_404_response(NOT_FOUND_ERROR.format(service="Destination"))
            return Response(response, status=response.get('code'))
        kwargs["destination"] = destination
        return func(*args, **kwargs)
    return wrapper_func


def validate_connection_request(func):
    def wrapper_func(*args, **kwargs):
        project_id = kwargs.get("project_id")
        connection_id = kwargs.get("connection_id")
        connection = Connection.objects.filter(
            deleted_at__isnull=True,
            id=connection_id,
            project_id=project_id
        ).select_related(
            "created_by", "source", "destination", "project"
        ).first()
        if not connection:
            response = BaseService.get_404_response(NOT_FOUND_ERROR.format(service="Connection"))
            return Response(response, status=response.get('code'))
        kwargs["connection"] = connection
        return func(*args, **kwargs)
    return wrapper_func


def validate_airbyte_hook_call(func):
    def wrapper_func(*args, **kwargs):
        query_params = args[1].query_params.dict()
        if query_params.get("token") != settings.AIRBYTE_WEBHOOK_PAYLOAD_TOKEN:
            response = BaseService.get_baked_400_response({})
            return Response(response, status=response.get('code'))
        return func(*args, **kwargs)
    return wrapper_func
