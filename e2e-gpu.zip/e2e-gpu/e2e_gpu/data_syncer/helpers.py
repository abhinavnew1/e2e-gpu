import json
import re
from copy import deepcopy

from django.conf import settings

from data_syncer import constants
from data_syncer.constants import (AIRBYTE_CONNECTION_STREAM_NAME_DICT,
                                   AIRBYTE_STREAM_DICT, DATA_SYNCER_NAME_REGEX,
                                   DEFINITION_ID_DICT, DONE, ERROR,
                                   INCONSISTENT_AIRBYTE_CONNECTIONS_MESSAGE,
                                   INCONSISTENT_AIRBYTE_CONNECTIONS_SUBJECT,
                                   INCONSISTENT_AIRBYTE_DESTINATIONS_MESSAGE,
                                   INCONSISTENT_AIRBYTE_DESTINATIONS_SUBJECT,
                                   INCONSISTENT_AIRBYTE_SOURCES_MESSAGE,
                                   INCONSISTENT_AIRBYTE_SOURCES_SUBJECT,
                                   NAME_ALREADY_EXISTS, NAME_INVALID,
                                   SOURCE_CATALOG_ID_DICT, STAR_PAYLOAD_STRING)
from data_syncer.models import Connection, Destination, Source
from e2e_core.datetime_helper import timestamp_to_tz
from e2e_core.helpers import support_ticket_generator


def validate_data_syncer_name(model_class, name, project_id, instance_id=None):
    if not re.fullmatch(DATA_SYNCER_NAME_REGEX, name):
        return False, NAME_INVALID
    if model_class.objects.filter(deleted_at__isnull=True, project_id=project_id, name=name).exclude(id=instance_id).exists():
        return False, NAME_ALREADY_EXISTS.format(model_class.__name__)
    return True, ""


def prepare_airbyte_source_payload(validated_data):
    payload = {
        "name": validated_data.get("name"),
        "sourceDefinitionId": DEFINITION_ID_DICT.get(validated_data.get("source_type")),
        "workspaceId": settings.AIRBYTE_WORKSPACE_ID,
        "connectionConfiguration": deepcopy(validated_data.get("configuration")),
    }
    payload["connectionConfiguration"]["credentials_dict"] = json.dumps(payload.get("connectionConfiguration", {}).get("credentials_dict"))
    return payload


def prepare_airbyte_source_updation_payload(validated_data, source: Source):
    payload = {
        "sourceId": source.airbyte_id,
        "name": source.slug_name,
        "connectionConfiguration": deepcopy(source.configuration)
    }
    for key in payload["connectionConfiguration"].keys():
        payload["connectionConfiguration"][key] = validated_data.get("configuration", {}).get(key, payload["connectionConfiguration"][key])

    payload["connectionConfiguration"]["access_key"] = validated_data.get("configuration", {}).get("access_key", STAR_PAYLOAD_STRING)
    payload["connectionConfiguration"]["secret_key"] = validated_data.get("configuration", {}).get("secret_key", STAR_PAYLOAD_STRING)
    payload["connectionConfiguration"]["client_secret"] = validated_data.get("configuration", {}).get("client_secret", STAR_PAYLOAD_STRING)
    payload["connectionConfiguration"]["credentials_dict"] = validated_data.get("configuration", {}).get("credentials_dict", STAR_PAYLOAD_STRING)
    payload["connectionConfiguration"]["connection_string"] = validated_data.get("configuration", {}).get("connection_string", STAR_PAYLOAD_STRING)
    return payload


def prepare_airbyte_destination_updation_payload(validated_data, destination: Destination):
    payload = {
        "name": destination.slug_name,
        "destinationId": destination.airbyte_id,
        "connectionConfiguration": {
            "access_key": STAR_PAYLOAD_STRING,
            "secret_key": STAR_PAYLOAD_STRING,
            "bucket_name": destination.dataset.bucket.bucket_name,
            "endpoint_url": settings.S3_ENDPOINT,
            "prefix": validated_data.get("path_prefix", destination.path_prefix),
        }
    }
    return payload


def prepare_airbyte_connection_payload(connection: Connection):
    airbyte_payload = {
        "sourceId": connection.source.airbyte_id,
        "destinationId": connection.destination.airbyte_id,
        "name": connection.slug_name,
        "namespaceDefinition": "destination",
        "nonBreakingChangesPreference": "propagate_columns",
        "geography": "auto",
        "syncCatalog": {
            "streams": [
                {
                    "config": {
                        "cursorField": ["date_and_time"],
                        "primaryKey": [],
                        "aliasName": AIRBYTE_CONNECTION_STREAM_NAME_DICT[connection.source.source_type],
                        "selected": True,
                        "suggested": True,
                        "selectedFields": [],
                    },
                }
            ]
        },
        "notifySchemaChanges": True,
        "status": "active",
        "backfillPreference": "disabled",
        "sourceCatalogId": SOURCE_CATALOG_ID_DICT[connection.source.source_type],
    }
    match connection.schedule_type:
        case constants.BASIC:
            airbyte_payload["scheduleType"] = "basic"
            airbyte_payload["scheduleData"] = {
                "basicSchedule": {
                    "units": connection.frequency,
                    "timeUnit": "hours"
                }
            }
        case constants.MANUAL:
            airbyte_payload["scheduleType"] = "manual"
        case constants.CRON:
            airbyte_payload["scheduleType"] = "cron"
            airbyte_payload["scheduleData"] = {
                "cron": {
                    "cronTimeZone": settings.IST_TIMEZONE_STR,
                    "cronExpression": f"0 {connection.frequency}"  # appending 0 in cron expression to convert 5 fields expression coming from frontend to airbyte compatible 6 fields
                }
            }
        case _:
            airbyte_payload["scheduleType"] = "manual"
    match connection.sync_mode:
        case constants.FULL_REFRESH_OVERWRITE:
            airbyte_payload["syncCatalog"]["streams"][0]["config"]["syncMode"] = "full_refresh"
            airbyte_payload["syncCatalog"]["streams"][0]["config"]["destinationSyncMode"] = "overwrite"
        case constants.FULL_REFRESH_APPEND:
            airbyte_payload["syncCatalog"]["streams"][0]["config"]["syncMode"] = "full_refresh"
            airbyte_payload["syncCatalog"]["streams"][0]["config"]["destinationSyncMode"] = "append"
        case constants.INCREMENTAL_APPEND:
            airbyte_payload["syncCatalog"]["streams"][0]["config"]["syncMode"] = "incremental"
            airbyte_payload["syncCatalog"]["streams"][0]["config"]["destinationSyncMode"] = "append"
        case _:
            airbyte_payload["syncCatalog"]["streams"][0]["config"]["syncMode"] = "full_refresh"
            airbyte_payload["syncCatalog"]["streams"][0]["config"]["destinationSyncMode"] = "overwrite"
    airbyte_payload["syncCatalog"]["streams"][0]["stream"] = AIRBYTE_STREAM_DICT[connection.source.source_type]
    return airbyte_payload


def prepare_airbyte_connection_updation_payload(validated_data, connection: Connection):
    airbyte_payload = prepare_airbyte_connection_payload(connection)
    airbyte_payload["status"] = connection.status
    airbyte_payload["connectionId"] = connection.airbyte_id
    if validated_data.get("schedule"):
        match validated_data.get("schedule", {}).get("schedule_type"):
            case constants.BASIC:
                airbyte_payload["scheduleType"] = "basic"
                airbyte_payload["scheduleData"] = {
                    "basicSchedule": {
                        "units": validated_data.get("schedule", {}).get("basic_schedule"),
                        "timeUnit": "hours"
                    }
                }
            case constants.MANUAL:
                airbyte_payload["scheduleType"] = "manual"
                airbyte_payload.pop("scheduleData", "")
            case constants.CRON:
                airbyte_payload["scheduleType"] = "cron"
                airbyte_payload["scheduleData"] = {
                    "cron": {
                        "cronTimeZone": settings.IST_TIMEZONE_STR,
                        "cronExpression": f"0 {validated_data.get("schedule", {}).get("cron_expression")}"  # appending 0 in cron expression to convert 5 fields expression coming from frontend to airbyte compatible 6 fields
                    }
                }
            case _:
                airbyte_payload["scheduleType"] = "manual"
    return airbyte_payload


def update_airbyte_source_details(sources, airbyte_sources):
    airbyte_source_mapping = {airbyte_source["sourceId"]: airbyte_source for airbyte_source in airbyte_sources}
    inconsistent_sources = []
    for source in sources:
        if not airbyte_source_mapping.get(source.airbyte_id) and source.status not in [ERROR, DONE]:
            source.status = ERROR
            source.save(update_fields=["status", "updated_at"])
            inconsistent_sources.append(source.id)
    if inconsistent_sources:
        support_ticket_generator(
            errors=INCONSISTENT_AIRBYTE_SOURCES_MESSAGE.format(inconsistent_sources),
            subject=INCONSISTENT_AIRBYTE_SOURCES_SUBJECT.format(email=inconsistent_sources[0].created_by.email),
            customer=inconsistent_sources[0].created_by
        )


def update_airbyte_destination_details(destinations, airbyte_destinations):
    airbyte_destination_mapping = {airbyte_destination["destinationId"]: airbyte_destination for airbyte_destination in airbyte_destinations}
    inconsistent_destinations = []
    for destination in destinations:
        if not airbyte_destination_mapping.get(destination.airbyte_id) and destination.status not in [ERROR, DONE]:
            destination.status = ERROR
            destination.save(update_fields=["status", "updated_at"])
            inconsistent_destinations.append(destination.id)
    if inconsistent_destinations:
        support_ticket_generator(
            errors=INCONSISTENT_AIRBYTE_DESTINATIONS_MESSAGE.format(inconsistent_destinations),
            subject=INCONSISTENT_AIRBYTE_DESTINATIONS_SUBJECT.format(email=inconsistent_destinations[0].created_by.email),
            customer=inconsistent_destinations[0].created_by
        )


def update_airbyte_connection_details(connections, airbyte_connections):
    airbyte_connections_mapping = {airbyte_connection["connectionId"]: airbyte_connection for airbyte_connection in airbyte_connections}
    inconsistent_connections = []
    for connection in connections:
        if connection.status not in [ERROR, DONE]:
            airbyte_connection = airbyte_connections_mapping.get(connection.airbyte_id)
            if not airbyte_connection:
                connection.status = ERROR
                connection.save(update_fields=["status", "updated_at"])
                inconsistent_connections.append(connection.id)
            else:
                connection.last_sync = timestamp_to_tz(airbyte_connection.get("latestSyncJobCreatedAt")) if airbyte_connection.get("latestSyncJobCreatedAt") else None
                connection.status = airbyte_connection.get("status")
                connection.save(update_fields=["last_sync", "status", "updated_at"])
    if inconsistent_connections:
        support_ticket_generator(
            errors=INCONSISTENT_AIRBYTE_CONNECTIONS_MESSAGE.format(inconsistent_connections),
            subject=INCONSISTENT_AIRBYTE_CONNECTIONS_SUBJECT.format(email=inconsistent_connections[0].created_by.email),
            customer=inconsistent_connections[0].created_by
        )


def update_airbyte_job_details(airbyte_jobs):
    return [updated_job_details(job) for job in airbyte_jobs]


def updated_job_details(airbyte_data):
    airbyte_job = airbyte_data.get("job", {})
    return {
        "id": airbyte_job.get("id"),
        "status": airbyte_job.get("status"),
        "created_at": timestamp_to_tz(airbyte_job.get("createdAt")),
        "updated_at": timestamp_to_tz(airbyte_job.get("updatedAt"))
    }
