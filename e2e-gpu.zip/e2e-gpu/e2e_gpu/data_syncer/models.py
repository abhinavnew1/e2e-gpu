from datetime import datetime

from django.db import models

from customer.models import Customer
from data_syncer.constants import (ACTIVE, AIRBYTE_SOURCE_TYPE_CHOICES,
                                   AIRBYTE_SYNC_MODE_CHOICES,
                                   CONNECTION_SCHEDULE_TYPE_CHOICES,
                                   CONNECTION_STATUS_CHOICES,
                                   DESTINATION_STATUS_CHOICES, DONE,
                                   SOURCE_STATUS_CHOICES)
from dataset.models import Dataset
from e2e_core.mixins import BaseMixin, SafeDeleteMixinExtended
from projects.models import Projects


class Source(BaseMixin, SafeDeleteMixinExtended):
    created_by = models.ForeignKey(Customer, on_delete=models.PROTECT, related_name="source_created_by")
    name = models.CharField(max_length=255)
    airbyte_id = models.CharField(max_length=255, null=True)
    project = models.ForeignKey(Projects, on_delete=models.CASCADE)
    source_type = models.CharField(choices=AIRBYTE_SOURCE_TYPE_CHOICES, max_length=32)
    deleted_at = models.DateTimeField(null=True, blank=True)
    status = models.CharField(choices=SOURCE_STATUS_CHOICES, max_length=32, default=ACTIVE)
    configuration = models.JSONField()

    def __str__(self):
        return f"<Source({self.id}: {self.name}: {self.source_type})>"

    @property
    def slug_name(self):
        """Source name in airbyte"""
        return f"{self.project.namespace}-s-{self.id}"

    def mark_deleted(self):
        if not self.deleted_at:
            self.status = DONE
            self.deleted_at = datetime.now()
            self.save(update_fields=["status", "deleted_at", "updated_at"])

    def delete(self):
        self.mark_deleted()
        super().delete()


class Destination(BaseMixin, SafeDeleteMixinExtended):
    created_by = models.ForeignKey(Customer, on_delete=models.PROTECT, related_name="destination_created_by")
    name = models.CharField(max_length=255)
    dataset = models.ForeignKey(Dataset, on_delete=models.PROTECT)
    path_prefix = models.CharField(max_length=255, null=True, blank=True)
    airbyte_id = models.CharField(max_length=255, null=True)
    status = models.CharField(choices=DESTINATION_STATUS_CHOICES, max_length=32, default=ACTIVE)
    project = models.ForeignKey(Projects, on_delete=models.CASCADE)
    deleted_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"<Destination({self.id}: {self.name})>"

    @property
    def slug_name(self):
        """Destination name in airbyte"""
        return f"{self.project.namespace}-d-{self.id}"

    def mark_deleted(self):
        if not self.deleted_at:
            self.status = DONE
            self.deleted_at = datetime.now()
            self.save(update_fields=["status", "deleted_at", "updated_at"])

    def delete(self):
        self.mark_deleted()
        super().delete()


class Connection(BaseMixin, SafeDeleteMixinExtended):
    created_by = models.ForeignKey(Customer, on_delete=models.PROTECT, related_name="connections_created_by")
    name = models.CharField(max_length=255)
    source = models.ForeignKey(Source, on_delete=models.PROTECT)
    destination = models.ForeignKey(Destination, on_delete=models.PROTECT)
    airbyte_id = models.CharField(max_length=255, null=True)
    schedule_type = models.CharField(choices=CONNECTION_SCHEDULE_TYPE_CHOICES, max_length=255)
    frequency = models.CharField(max_length=255)
    project = models.ForeignKey(Projects, on_delete=models.CASCADE)
    status = models.CharField(choices=CONNECTION_STATUS_CHOICES, max_length=32, default=ACTIVE)
    sync_mode = models.CharField(choices=AIRBYTE_SYNC_MODE_CHOICES, max_length=32)
    last_sync = models.DateTimeField(null=True, blank=True)
    deleted_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"<Connection({self.id}: {self.name}: {self.status})>"

    @property
    def slug_name(self):
        """Connection name in airbyte"""
        return f"{self.project.namespace}-c-{self.id}"

    def mark_deleted(self):
        if not self.deleted_at:
            self.status = DONE
            self.deleted_at = datetime.now()
            self.save(update_fields=["status", "deleted_at", "updated_at"])

    def delete(self):
        self.mark_deleted()
        super().delete()
