from django.contrib import admin
from safedelete.admin import SafeDeleteAdmin

from dataset.models import Dataset


class DatasetAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "deleted_at",
        "id",
        "name",
        "project",
        "storage_type",
        "status",
        "created_by",
        "description",
        "pvc",
        "bucket",
        "access_key",
    )
    raw_id_fields = ("project", "pvc", "bucket", "access_key", "created_by",)
    search_fields = ("id", "name", "project__name", "bucket__bucket_name", "created_by__email",)
    list_filter = ("storage_type", "status", "deleted_at", "deleted",)
    list_display_links = ("id", "name",)
    readonly_fields = ()
    list_select_related = ("project", "created_by", "pvc", "bucket", "access_key",)


admin.site.register(Dataset, DatasetAdmin)
