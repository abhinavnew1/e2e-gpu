from django.conf import settings

from e2e_core.constants import MAX_LENGTH_ERROR

# dataset groot urls
CREATE_DATASET_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/datasets"
LIST_DATASETS_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/datasets"
DATASET_DETAILS_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/datasets/{dataset_name}"
DELETE_DATASET_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/datasets/{dataset_name}"


# dataset storage types
MANAGED_STORAGE = "managed"
E2E_OBJECT_STORAGE = "e2e_s3"
PVC = "pvc"
STORAGE_TYPE_CHOICES = (
    (MANAGED_STORAGE, MANAGED_STORAGE),
    (E2E_OBJECT_STORAGE, E2E_OBJECT_STORAGE),
    (PVC, PVC)
)

# Dataset status
PENDING = "Pending"
OK = "OK"
DONE = "Done"
ERROR = "error"
DATASET_STATUS_LIST = [PENDING, OK, DONE, ERROR]
DATASET_STATUS_CHOICES = tuple(
    (status, status) for status in DATASET_STATUS_LIST
)

DATASET_NAME_REGEX = r'[a-z0-9]([-a-z0-9]*[a-z0-9])?'
DATASET_NAME_MAX_LENGTH = 50
DATASET_NAME_MAX_LENGTH_ERROR = MAX_LENGTH_ERROR.format(field_name="Dataset Name", max_length=DATASET_NAME_MAX_LENGTH)

# objects types filter
FILE_TYPE = "file"
DIRECTORY_TYPE = "directory"

# datasets search filter
DATASET_FILTER_KEY_MAPPING = {
    "name": "name__in",
    "created_by": "created_by__email__in",
    "storage_type": "storage_type__in",
}
DATASET_EXCLUDE_KEY_MAPPING = {
    "not_name": "name__in",
    "not_created_by": "created_by__email__in",
    "not_storage_type": "storage_type__in",
}

# audit log constants
DATASET_RESOURCE = "dataset"
MANAGED_DATASET_CREATE_EVENT = "DATASET_CREATE_WITH_NEW_EOS_BUCKET"
S3_DATASET_CREATE_EVENT = "DATASET_CREATE_WITH_EXISTING_EOS_BUCKET"
DATASET_DELETE_EVENT = "DATASET_DELETE"
DATASET_UPDATE_EVENT = "DATASET_UPDATE"
DATASET_OBJECT_DELETE_EVENT = "DATASET_OBJECT_DELETE"
DATASET_OBJECT_UPLOAD_EVENT = "DATASET_OBJECT_UPLOAD"
GENAI_OBJECT_UPLOAD_EVENT =  "GENAI_OBJECT_UPLOAD"
PVC_DATASET_CREATE_EVENT = "DATASET_CREATE_WITH_DISK"
PVC_DATASET_UPGRADE_EVENT = "DATASET_DISK_UPGRADE"

# error/success msgs
NAME_INVALID = "Dataset name should start and end with an alphanumeric character and can contain lowercase letters, digits and hyphen only."
DATASET_NAME_ALREADY_EXISTS = "Dataset with the same name already exists in the Project"
BUCKET_ALREADY_ATTACHED = "The bucket is already attached on another dataset in this project"
ACCESS_KEY_ATTACH_FAILED = "Error while attaching Access Key to Dataset Bucket"
GET_OBJECTS_URL_ERROR = "Error in getting object {action} url"
FETCH_OBJECTS_ERROR = "Error while fetching objects"
NO_OBJECTS_FETCH_FOR_PVC = "No objects fetched for disk dataset"
DATASET_MOUNTED_ERROR = "Cannot delete dataset as it is being used by {service}: {instances}"
DATASET_MOUNTED_FINETUNING_ERROR = "Cannot delete dataset as it is being used by finetunings: {finetunings}"

# support ticket constants
FAILED_TO_DETACH_KEY = "Failed to detach access key from bucket for customer: {email_id}"
FAILED_TO_DELETE_BUCKET = "Failed to delete bucket for customer: {email_id}"
FAILED_TO_DELETE_ACCESS_KEY = "Failed to delete access key for customer: {email_id}"
FAILED_TO_DETACH_ACCESS_KEY_MESSAGE = "Failed to detach access key from bucket: {bucket_name}\
    with permission id: {permission_id} and access key: {access_key} with tag: {access_tag}. \n errors: {errors}"
FAILED_TO_DELETE_BUCKET_MESSAGE = "Failed to delete bucket: {bucket_name}.\n errors: {errors}"
FAILED_TO_DELETE_ACCESS_KEY_MESSAGE = "Failed to delete access key: {access_key}.\n errors: {errors}"
FAILED_TO_DELETE_PERMISSIONS_MESSAGE = "Failed to Delete EOS Bucket permissions for bucket: {bucket_name}\
      and permissions id: {permission_id}.\n errors: {errors}"
FAILED_TO_DELETE_PERMISSIONS_SUBJECT = "Failed to Delete EOS Bucket for customer: {email_id}"
DATASET_INCONSISTENCY_TICKET_SUBJECT = "Dataset does not exist on groot | DATASET_INCONSISTENCY"
DATASET_INCONSISTENCY_TICKET_MESSAGE = "Dataset '{dataset_name}' (ID:{dataset_id}) exists in our DB but does not exist on groot."

# celery task
DELETE_OBJECT_STORAGE_FOR_DATASET_TASK = "delete_object_storage_for_dataset_task"
COUNTDOWN_FOR_DATASET_OBJECT_STORAGE_DELETION = 5
