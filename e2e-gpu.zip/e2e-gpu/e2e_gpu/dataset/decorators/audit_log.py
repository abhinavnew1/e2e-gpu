import logging

from rest_framework import status

from dataset.constants import (DATASET_DELETE_EVENT,
                               GENAI_OBJECT_UPLOAD_EVENT,
                               DATASET_OBJECT_DELETE_EVENT,
                               DATASET_OBJECT_UPLOAD_EVENT,
                               DATASET_UPDATE_EVENT,
                               MANAGED_DATASET_CREATE_EVENT, MANAGED_STORAGE,
                               S3_DATASET_CREATE_EVENT, PVC, PVC_DATASET_CREATE_EVENT, 
                               PVC_DATASET_UPGRADE_EVENT)
from eos.constants import OBJECT_UPLOAD_ACTION
from eventlogs.api.v1.services.eventlog_service import EventLogService
from eventlogs.constants import (CREATE, DELETE, DATASET_SERVICE_CODE, EVENTLOG_FAILED_STATUS,
                                 EVENTLOG_SUCCESS_STATUS, UPDATE)

logger = logging.getLogger(__name__)


def dataset_create_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(DATASET_SERVICE_CODE)
        storage_type = request.data.get("type")
        if storage_type != PVC:
            event_type = MANAGED_DATASET_CREATE_EVENT if storage_type == MANAGED_STORAGE else S3_DATASET_CREATE_EVENT
        else:
            event_type = PVC_DATASET_CREATE_EVENT
        event_log.create_log(
            request = request,
            event = event_type,
            resource_name = request.data["name"],
            resource_id = "",
            detailed_info={"request": request.data, "project_id": kwargs.get('project_id')},
            resource_obj_id = None,
            event_type = CREATE
        )
        response = func(*args, **kwargs)
        if response.status_code == status.HTTP_201_CREATED:
            event_log.update_log(status=EVENTLOG_SUCCESS_STATUS, resource_id=response.data["data"]["id"],
                                 detailed_info={"response": response.data, "project_id": kwargs.get('project_id')},
                                 resource_obj_id=response.data["data"]["id"])
        else:
            event_log.update_log(status=EVENTLOG_FAILED_STATUS, detailed_info={"response": request.data,
                                                                               "project_id": kwargs.get('project_id')})
        return response

    return wrapper_func


def dataset_delete_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(DATASET_SERVICE_CODE)
        event_log.create_log(
            request = request,
            event = DATASET_DELETE_EVENT,
            resource_name = kwargs.get("dataset").name,
            resource_id = kwargs.get("dataset_id"),
            detailed_info={"project_id": kwargs.get('project_id')},
            resource_obj_id=kwargs.get("dataset_id"),
            event_type = DELETE
        )
        response = func(*args, **kwargs)
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else \
            event_log.log_event_failure()
        return response

    return wrapper_func


def dataset_update_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(DATASET_SERVICE_CODE)
        response = func(*args, **kwargs)
        dataset = kwargs.get("dataset")
        log_status = EVENTLOG_SUCCESS_STATUS if response.status_code==status.HTTP_200_OK else EVENTLOG_FAILED_STATUS
        event_log.create_log(
            request = request,
            event = PVC_DATASET_UPGRADE_EVENT if dataset.storage_type == PVC else DATASET_UPDATE_EVENT,
            resource_name = kwargs.get("dataset").name,
            resource_id = kwargs.get("dataset_id"),
            resource_obj_id=kwargs.get("dataset_id"),
            detailed_info = {"update_data": request.data, "project_id": kwargs.get('project_id')},
            status = log_status,
            event_type = UPDATE
        )
        return response

    return wrapper_func


def dataset_object_delete_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(DATASET_SERVICE_CODE)
        response = func(*args, **kwargs)
        log_status = EVENTLOG_SUCCESS_STATUS if response.status_code == status.HTTP_200_OK else EVENTLOG_FAILED_STATUS
        event_log.create_log(
            request=request,
            event=DATASET_OBJECT_DELETE_EVENT,
            resource_name=kwargs.get("dataset").name,
            resource_id=kwargs.get("dataset_id"),
            status=log_status,
            resource_obj_id=kwargs.get("dataset_id"),
            detailed_info={"object_name": request.GET.get("object_name"), "project_id": kwargs.get('project_id')},
            event_type=DELETE
        )
        return response

    return wrapper_func


def dataset_object_upload_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        if request.GET.get("action") == OBJECT_UPLOAD_ACTION:
            event_log = EventLogService(DATASET_SERVICE_CODE)
            response = func(*args, **kwargs)
            log_status = EVENTLOG_SUCCESS_STATUS if response.status_code == status.HTTP_200_OK else EVENTLOG_FAILED_STATUS
            event_log.create_log(
                request=request,
                event=DATASET_OBJECT_UPLOAD_EVENT,
                resource_name=kwargs.get("dataset").name,
                resource_id=kwargs.get("dataset_id"),
                status=log_status,
                resource_obj_id=kwargs.get("dataset_id"),
                detailed_info={"object_name": request.GET.get("file_name"), "project_id": kwargs.get('project_id')},
                event_type=UPDATE
            )
            return response
        return func(*args, **kwargs)

    return wrapper_func

def genai_object_upload_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        if request.GET.get("action") == OBJECT_UPLOAD_ACTION:
            event_log = EventLogService(DATASET_SERVICE_CODE)
            response = func(*args, **kwargs)
            log_status = EVENTLOG_SUCCESS_STATUS if response.status_code == status.HTTP_200_OK else EVENTLOG_FAILED_STATUS
            event_log.create_log(
                request=request,
                event=GENAI_OBJECT_UPLOAD_EVENT,
                resource_name=kwargs.get("dataset").name,
                resource_id=kwargs.get("dataset_id"),
                status=log_status,
                resource_obj_id=kwargs.get("dataset_id"),
                detailed_info={"object_name_from_ui": request.GET.get("file_name"), "customer_project_id": kwargs.get('customer_project_id')},
                event_type=UPDATE
            )
            return response
        return func(*args, **kwargs)

    return wrapper_func