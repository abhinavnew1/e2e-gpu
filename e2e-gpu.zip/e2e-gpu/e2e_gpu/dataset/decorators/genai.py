from django.conf import settings

def use_genai_data_bucket(func):
    def wrapper_func(*args, **kwargs):
        kwargs["dataset_id"]  = settings.GENAI_DATASET_ID
        kwargs["customer_project_id"] = kwargs["project_id"]
        kwargs["project_id"] = settings.GENAI_INFERENCE_PROJECT_ID
        return func(*args, **kwargs)

    return wrapper_func