import logging

from django.db.models import Q
from rest_framework.response import Response

from dataset.constants import DATASET_MOUNTED_ERROR, DATASET_MOUNTED_FINETUNING_ERROR
from dataset.models import Dataset
from e2e_core.api.v1.services.base import BaseService
from e2e_core.constants import (INVALID_ACTION, NOT_FOUND_ERROR,
                                PARAMS_MISSING_OR_INVALID, UNAUTHORIZED_ACCESS)
from e2e_core.helpers import get_pk_or_name_from_value
from eos.constants import OBJECT_DOWNLOAD_ACTION, OBJECT_UPLOAD_ACTION
from pipelines.constants import SUCCEEDED

logger = logging.getLogger(__name__)


def validate_dataset_request(func):
    def wrapper_func(*args, **kwargs):
        dataset_id, dataset_name = get_pk_or_name_from_value(kwargs.get("dataset_id", ""))
        project_id = kwargs.get("project_id", "")
        dataset = Dataset.objects.filter(Q(id=dataset_id) | Q(name=dataset_name), deleted_at__isnull=True, project_id=project_id)\
                  .select_related("project", "access_key", "bucket", "pvc").first()
        if not dataset:
            response = BaseService.get_404_response(NOT_FOUND_ERROR.format(service="Dataset"))
            return Response(response, status=response.get("code"))
        kwargs["dataset"] = dataset
        kwargs["dataset_id"] = dataset.id
        return func(*args, **kwargs)

    return wrapper_func


def validate_object_upload_download_action(func):
    def wrapper_func(*args, **kwargs):
        file_name = args[0].query_params.get("file_name")
        if not file_name:
            return args[0].get_baked_412_response(PARAMS_MISSING_OR_INVALID.format(param="file_name"))
        action = args[0].query_params.get("action")
        if not (action==OBJECT_UPLOAD_ACTION or action==OBJECT_DOWNLOAD_ACTION):
            return args[0].get_baked_400_response(INVALID_ACTION)
        return func(*args, **kwargs)

    return wrapper_func


def check_if_dataset_is_currently_in_use(func):
    def wrapper_func(*args, **kwargs):
        dataset = kwargs.get("dataset")
        notebooks = list(dataset.get_mounted_on_notebooks().values_list("name", flat=True))
        finetunings = list(dataset.mounted_on_finetuning.exclude(Q(run__state=SUCCEEDED) |
                                                                 Q(deleted_at__isnull=False) |
                                                                 Q(run__deleted_at__isnull=False)).values_list("name", flat=True))
        inferences = list(dataset.inference_set.filter(deleted_at__isnull=True).values_list("name", flat=True))
        if notebooks:
            return args[0].get_baked_412_response(DATASET_MOUNTED_ERROR.format(service="notebooks", instances=str(notebooks)[1: -1]))
        if finetunings:
            return args[0].get_baked_412_response(DATASET_MOUNTED_FINETUNING_ERROR.format(finetunings=str(finetunings)[1: -1]))
        if inferences:
            return args[0].get_baked_412_response(DATASET_MOUNTED_ERROR.format(service="model endpoints", instances=str(inferences)[1: -1]))
        return func(*args, **kwargs)

    return wrapper_func
