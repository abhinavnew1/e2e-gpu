import logging

from e2e_core.helpers import advanced_search_filter, process_boolean, support_ticket_generator
from dataset.constants import (DATASET_INCONSISTENCY_TICKET_MESSAGE,
                               DATASET_INCONSISTENCY_TICKET_SUBJECT,
                               DATASET_EXCLUDE_KEY_MAPPING,
                               DATASET_FILTER_KEY_MAPPING,
                               ERROR)
from dataset.models import Dataset

logger = logging.getLogger(__name__)


def datasets_search_filter(dataset_qs, **kwargs):
    # normal search
    if kwargs.get("search_string"):
        search_string = kwargs.get("search_string")
        dataset_qs = dataset_qs.filter(name__icontains=search_string)

    # advanced search
    if process_boolean(kwargs.get("is_advanced_search"), False):
        dataset_qs = advanced_search_filter(
            dataset_qs, DATASET_FILTER_KEY_MAPPING, DATASET_EXCLUDE_KEY_MAPPING, **kwargs
        )

    return dataset_qs


def update_datalist_from_groot(bucket_datasets, groot_datasets_list, *args, **kwargs):
    """func to update datasets' data from groot in DB"""
    dataset_mapping = {data["name"]: data for data in groot_datasets_list}
    for dataset_obj in bucket_datasets:
        if not dataset_mapping.get(dataset_obj.name):
            logger.error(f"DATASET_INCONSISTENCY | CRITICAL_RED | DATASET_DOES_NOT_EXIST_ON_GROOT | DATASET_NAME:{dataset_obj.name}")
            if dataset_obj.status != ERROR:
                dataset_obj.status = ERROR
                generate_dataset_inconsistency_ticket(dataset_obj)
            continue
        dataset_obj.status = dataset_mapping[dataset_obj.name]["status"]
    Dataset.objects.bulk_update(bucket_datasets, ['status', 'updated_at', ])


def update_dataset_details_from_groot(dataset_obj, groot_dataset_dict, *args, **kwargs):
    """func to update a dataset's data from groot in DB"""
    dataset_obj.status = groot_dataset_dict["status"]
    dataset_obj.save(update_fields=['status', 'updated_at', ])


def generate_dataset_inconsistency_ticket(dataset):
    support_ticket_generator(
        errors=DATASET_INCONSISTENCY_TICKET_MESSAGE.format(dataset_name=dataset.name, dataset_id=dataset.id),
        subject=DATASET_INCONSISTENCY_TICKET_SUBJECT,
        customer=dataset.created_by,
    )
