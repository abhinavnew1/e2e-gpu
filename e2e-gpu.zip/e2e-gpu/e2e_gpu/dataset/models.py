from datetime import datetime

from django.db import models
from django.db.models import Q

from customer.models import Customer
from dataset.constants import (DATASET_NAME_MAX_LENGTH, DATASET_STATUS_CHOICES,
                               DONE, PENDING, PVC, STORAGE_TYPE_CHOICES)
from e2e_core.helpers import get_pk_or_name_from_value, mark_delete_related_objects
from e2e_core.mixins import BaseMixin, SafeDeleteMixinExtended
from eos.models import AccessKey, Bucket
from projects.models import Projects
from pvc.models import PVCStorage


class Dataset(SafeDeleteMixinExtended, BaseMixin):
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    name = models.CharField(max_length=DATASET_NAME_MAX_LENGTH)
    project = models.ForeignKey(Projects, on_delete=models.CASCADE)
    description = models.TextField(default=None, null=True, blank=True)
    storage_type = models.CharField(choices=STORAGE_TYPE_CHOICES, max_length=64)
    pvc = models.OneToOneField(PVCStorage, on_delete=models.PROTECT, blank=True, null=True)
    bucket = models.ForeignKey(Bucket, on_delete=models.PROTECT, blank=True, null=True)
    access_key = models.ForeignKey(AccessKey, on_delete=models.PROTECT, blank=True,  null=True)
    status = models.CharField(choices=DATASET_STATUS_CHOICES, max_length=64, default=PENDING)
    created_by = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True)

    class Meta:
        # Define unique-together constraint for sdk api calls
        unique_together = ['name', 'project']

    def __str__(self):
        return f"<Dataset({self.id}: {self.name}: {self.storage_type})>"

    def mark_deleted(self):
        if self.deleted_at is None:
            mark_delete_related_objects(self)
            self.status = DONE
            self.deleted_at = datetime.now()
            self.save(update_fields=['deleted_at', 'status', 'updated_at',])
            self.mounted_on_notebooks.clear()
            if self.storage_type == PVC:
                self.pvc.mark_deleted()
            else:
                self.bucket.mark_deleted()
                self.access_key.mark_deleted()

    def get_mounted_on_notebooks(self):
        # self.mounted_on_notebooks.all() does not filter the soft deleted records in NotebookDatasetMapping Model. Hence this method.
        return self.mounted_on_notebooks.filter(
            notebookdatasetmapping__deleted=False, notebookdatasetmapping__is_mounted=True
        )

    @classmethod
    def get_qs_from_id_or_name(cls, dataset_id, project_id):
        '''dataset_id can be id or name. Both can be used to uniquely identify a dataset instance within the project'''
        dataset_id, dataset_name = get_pk_or_name_from_value(dataset_id)
        return Dataset.objects.filter(Q(id=dataset_id) | Q(name=dataset_name), project_id=project_id)
