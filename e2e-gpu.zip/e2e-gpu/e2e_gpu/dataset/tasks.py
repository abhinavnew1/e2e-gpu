import logging

from dataset.api.v1.services.dataset_service import DatasetService
from dataset.constants import DELETE_OBJECT_STORAGE_FOR_DATASET_TASK
from e2e_gpu.celery import app

logger = logging.getLogger(__name__)

@app.task(
    name=DELETE_OBJECT_STORAGE_FOR_DATASET_TASK,
    bind=True,
)
def delete_object_storage_for_dataset_taks(self, *args, **kwargs):
    dataset = kwargs.get("dataset")
    customer_auth_header = kwargs.get("customer_auth_header")
    customer = kwargs.get("customer")
    project_id = kwargs.get("project_id")
    DatasetService(customer, project_id).delete_object_storage_for_dataset(dataset, customer_auth_header)