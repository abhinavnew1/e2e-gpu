DE_PROVISIONED_SUCCESSFULLY = "De-provisioned Successfully"
ERROR_WHILE_PROJECTS_DELETION = "Error occured during deleting given projects: {projects}"
