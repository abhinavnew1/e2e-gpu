from distributed_jobs.models import (Cluster, ClusterPlan, Job, SfsDetail,
                                     SfsPlan, WorkerNode)
from django.contrib import admin
from safedelete.admin import SafeDeleteAdmin

# Register your models here.


class WorkerNodeAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "node_name",
        "is_active",
        "no_of_gpu_cards",
        "blocked",
        "node_ip",
        "cluster_name",
        "created_by_email"

    )
    raw_id_fields = ("sku", "cluster")
    search_fields = ("id", "node_name")
    list_filter = ("deleted", "is_active", "blocked")
    list_display_links = (
        "id",
        "node_name",
    )

    def cluster_name(self, obj):
        return obj.cluster.name if obj.cluster else "-"

    def created_by_email(self, obj):
        return obj.cluster.created_by.email if obj.cluster else "-"


class JobAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "name",
        "job_type",
        "deleted_at",
        "created_by_email"
    )
    raw_id_fields = ("registry_namespace", "cluster", "project", "sfs")
    search_fields = (
        "id",
        "name",
        "created_by__email"
    )
    list_filter = (
        "deleted",
        "job_type",
        "is_active",
        "deleted_at",
    )
    list_display_links = (
        "id",
        "name",
    )

    def created_by_email(self, obj):
        return obj.created_by.email if obj else ""


class ClusterAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "name",
        "deleted_at",
        "created_by_email"
    )
    raw_id_fields = ("created_by", "project", "cluster_plan", "sku_item_price")
    search_fields = (
        "id",
        "name",
        "created_by__email"
    )
    list_filter = (
        "deleted",
        "is_active",
        "deleted_at"
    )
    list_display_links = (
        "id",
        "name",
    )

    def created_by_email(self, obj):
        return obj.created_by.email


class ClusterPlansAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "name",
        "no_of_node",
    )
    search_fields = (
        "id",
        "name",
    )
    list_filter = (
        "deleted",
        "is_active",
    )
    list_display_links = (
        "id",
        "name",
    )
    raw_id_fields = ("sku",)


class SfsPlanAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "name",
        "is_active",
        "bs_size",
        "iops",
    )
    raw_id_fields = ("sku",)
    search_fields = ("id", "name")
    list_filter = ("deleted", "is_active",)
    list_display_links = (
        "id",
        "name",
    )


class SfsDetailAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "name",
        "is_active",
        "my_account_sfs_id",
        "sfs_ip",
        "sc_name",
        "created_by_email"
    )
    raw_id_fields = ("project", "created_by", "plan")
    search_fields = ("id", "name", "created_by__email")
    list_filter = ("deleted", "is_active", "deleted_at")
    list_display_links = (
        "id",
        "name",
    )
    def created_by_email(self, obj):
        return obj.created_by.email



admin.site.register(WorkerNode, WorkerNodeAdmin)
admin.site.register(Cluster, ClusterAdmin)
admin.site.register(ClusterPlan, ClusterPlansAdmin)
admin.site.register(Job, JobAdmin)
admin.site.register(SfsPlan, SfsPlanAdmin)
admin.site.register(SfsDetail, SfsDetailAdmin)
