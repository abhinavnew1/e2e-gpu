from django.conf import settings

PYTORCH_JOB = "PyTorchJob"
PYTORCH_JOB_LIST = [PYTORCH_JOB]
JOB_TYPE_CHOICES = tuple((job, job) for job in PYTORCH_JOB_LIST)
CLUSTER_DELETION_MESSAGE = "Cluster deleted successfully"
CLUSTER_CREATION_MESSAGE = "Cluster created successfully"
CLUSTER_NOT_FOUND_MESSAGE = "Cluster does not exist"
CLUSTER_PLAN_NOT_FOUND = "Cluster plan not found"
JOB_DELETION_MESSAGE = "Job deleted successfully"
JOB_CREATION_MESSAGE = "Job created successfully"
SFS_CREATION_MESSAGE = "SFS created successfully"
SFS_PLAN_NOT_FOUND = "SFS plan not found"
JOB_NOT_FOUND_MESSAGE = "Job does not exist"
PRIVATE_IMAGE = "private"
PUBLIC_IMAGE = "public"
SET_NODE_LABEL_URL = (
    settings.GROOT_BASE_URL + "api/namespaces/{namespace}/label-node/{node_name}/"
)
CREATE_JOB_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/distributed-job/"
DELETE_JOB_URL = (
    settings.GROOT_BASE_URL + "api/namespaces/{namespace}/distributed-job/{job_name}/"
)
JOB_DETAILS_URL = (
    settings.GROOT_BASE_URL + "api/namespaces/{namespace}/distributed-job/{job_name}/"
)
EVENT_JOB_URL = (
    settings.GROOT_BASE_URL
    + "api/namespaces/{namespace}/distributed-job/events/{job_name}/"
)
JOB_PODS_URL = (
    settings.GROOT_BASE_URL
    + "api/namespaces/{namespace}/distributed-job/pods/{job_name}/"
)
JOB_POD_LOG_URL = (
    settings.GROOT_BASE_URL
    + "api/namespaces/{namespace}/distributed-job/pod/logs/{pod_name}/"
)
MYACCOUNT_CREATE_SFS = f"{settings.MYACCOUNT_PROD_LB_URL}api/v1/efs/create/?apikey={settings.MYACCOUNT_INTERNAL_ACC_API_KEY}&project_id={settings.MYACCOUNT_INTERNAL_ACC_PROJECT_ID}&location={settings.MYACCOUNT_SFS_LOCATION}"
MYACCOUNT_DELETE_SFS = (
    f"{settings.MYACCOUNT_PROD_LB_URL}api/v1/efs/delete/"
    + "{efs_id}"
    + f"/?apikey={settings.MYACCOUNT_INTERNAL_ACC_API_KEY}&project_id={settings.MYACCOUNT_INTERNAL_ACC_PROJECT_ID}&location={settings.MYACCOUNT_SFS_LOCATION}"
)
MYACCOUNT_LIST_SFS = (
    f"{settings.MYACCOUNT_PROD_LB_URL}api/v1/efs/"
    + f"/?apikey={settings.MYACCOUNT_INTERNAL_ACC_API_KEY}&project_id={settings.MYACCOUNT_INTERNAL_ACC_PROJECT_ID}&location={settings.MYACCOUNT_SFS_LOCATION}"
)
JOB_CREATE_SFS = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/sfs/"
CREATE_SFS_PVC = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/sfs-pvc/"
DELETE_SFS_PVC = (
    settings.GROOT_BASE_URL + "api/namespaces/{namespace}/sfs-pvc/{sfs_pvc_name}/"
)

DELETE_SFS = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/sfs/{sfs_name}"
SFS_NOT_FOUND_MESSAGE = "SFS does not exist"
SFS_DELETION_MESSAGE = "SFS deleted successfully"

JOB_CREATE_EVENT = "JOBS_CREATE"
JOB_DELETE_EVENT = "JOBS_DELETE"
JOB_ACTION_EVENT = "JOBS_{}_ACTION"

CLUSTER_CREATE_EVENT = "JOBS_CLUSTER_CREATE"
CLUSTER_DELETE_EVENT = "JOBS_CLUSTER_DELETE"
CLUSTER_ACTION_EVENT = "JOBS_CLUSTER_{}_ACTION"

SFS_CREATE_EVENT = "JOBS_SFS_CREATE"
SFS_DELETE_EVENT = "JOBS_SFS_DELETE"
SFS_ACTION_EVENT = "JOBS_SFS_{}_ACTION"
SFS_SIZE_CONVERSION_FACTOR = 1000

# JOB STATUS
CREATING = "Creating"
RUNNING = "Running"
SUCCEEDED = "Succeeded"
PENDING = "Pending"
FAILED = "Failed"
DONE = "Done"
TERMINATED = 'Terminated'
PYTORCH_JOBS_STATUS_LIST = [CREATING, SUCCEEDED, FAILED, RUNNING, PENDING, TERMINATED]
PYTORCH_JOBS_STATUS_CHOICES = tuple(
    (status, status) for status in PYTORCH_JOBS_STATUS_LIST
)

# job actions
TERMINATE_JOB = 'terminate'

INTERVAL_TO_TIME_FORMAT_MAPPING = {
    "5m": [300, "%I:%M:%S%p", 15],
    "1h": [3600, "%I:%M%p", 180],
    "1d": [86400, "%I:%M:%p", 3600],
    "7d": [604800, "%m/%d/%Y, %I%p", 28800],
    "1mn": [2592000, "%m/%d/%Y", 86400],
}
CLUSTER_MONITORING_DATA_GET_ERROR = "Prometheus server connection error"
CLUSTER_INVALID_REQUEST = "Invalid reqest! Cluster Not Found"
NODE_MEM_TOTAL_BYTES = "node_memory_MemTotal_bytes"
NODE_CPU_TOTAL_SECONDS = "node_cpu_seconds_total"
NODE_DISK_READ_BYTES = "node_disk_read_bytes_total"
NODE_DISK_WRITTEN_BYTES = "node_disk_written_bytes_total"
GPU_TEMPERATURE = "gpu_temperature"
GPU_UTIL = "gpu_util"


CLUSTER_MONITORING_METRIC_LIST = [
    NODE_MEM_TOTAL_BYTES,
    NODE_CPU_TOTAL_SECONDS,
    NODE_DISK_READ_BYTES,
    NODE_DISK_WRITTEN_BYTES,
    GPU_TEMPERATURE,
    GPU_UTIL,
]
PARAMS_MISSING_OR_INVALID = "{param} is either invalid or not provided"
JOB_CREATE_NFS = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/nfs-server"
DELETE_NFS_PVC = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/nfs-server/{nfs_id}"

PRODUCTION_EOS = "objectstore.e2enetworks.net"
PYTORCH_LOGS_PATH = 'projects/{namespace}/logs/pods/{pod_name}/pytorch/'
DISTRIBUTED_JOBS_MONITORING_DATA_GET_ERROR = "Can't get job monitoring data : {reason}"
IST_TIMEZONE_NAME = "Asia/Kolkata"
