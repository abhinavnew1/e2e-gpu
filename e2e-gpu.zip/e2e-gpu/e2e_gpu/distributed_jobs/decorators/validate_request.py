from distributed_jobs.constants import CLUSTER_INVALID_REQUEST
from distributed_jobs.models import Cluster
from e2e_core.api.v1.services.base import BaseService
from rest_framework.response import Response


def validate_cluster_request(func):
    def wrapper_func(*args, **kwargs):
        cluster_id = kwargs.get("cluster_id")
        project_id = kwargs.get("project_id")
        cluster = (
            Cluster.objects.filter(
                deleted_at__isnull=True, id=cluster_id, project_id=project_id
            )
            .select_related("project", "cluster_plan")
            .first()
        )
        if not cluster:
            response = BaseService.get_404_response(CLUSTER_INVALID_REQUEST)
            return Response(response, status=response.get("code"))
        kwargs["cluster"] = cluster
        return func(*args, **kwargs)

    return wrapper_func
