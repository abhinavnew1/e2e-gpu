import requests
from container_registry.constants import DEFAULT_REGISTRY_SECRET_NAME
from distributed_jobs.api.v1.services.job_groot_service import \
    DistributedJobGrootService
from distributed_jobs.constants import (MYACCOUNT_CREATE_SFS,
                                        MYACCOUNT_DELETE_SFS,
                                        MYACCOUNT_LIST_SFS,
                                        SFS_SIZE_CONVERSION_FACTOR)
from django.conf import settings
from e2e_core.helpers import convert_gb_to_gi


def set_node_label_groot(node_names, cluster_obj, namespace):
    for node_name in node_names:
        payload = {
            "label_key": "distributed_jobs",
            "label_value": f"distributed-training-{cluster_obj.id}",
        }
        DistributedJobGrootService(
            namespace, cluster_obj.created_by
        ).set_node_label_request(node_name, payload)


def get_e2e_registry_secret_name(registry_namespace_id):
    if registry_namespace_id:
        return DEFAULT_REGISTRY_SECRET_NAME.format(registry_id=registry_namespace_id)


def create_job_groot_payload(job_obj, request_body):
    cluster_id = request_body.get("cluster_id")
    registry_namespace_id = None
    if job_obj.registry_namespace:
        registry_namespace_id = job_obj.registry_namespace.id
    payload = {}
    payload["id"] = job_obj.id
    payload["master_commands"] = job_obj.master_command
    payload["worker_commands"] = job_obj.worker_command if job_obj.worker_command else []
    payload["image_url"] = request_body.get("image_url", [])
    payload["master_replica"] = 1
    payload["worker_replica"] = job_obj.no_of_workers - 1
    payload["label_value"] = f"distributed-training-{cluster_id}"
    payload["image_pull_secret_name"] = get_e2e_registry_secret_name(
        registry_namespace_id
    )
    payload["image_pull_policy"] = request_body.get("image_pull_policy", "Always")
    if job_obj.sfs:
        payload["pvc_name"] = f"pvc-sfs-{job_obj.sfs.id}"
    if request_body.get("sfs_mount_path"):
        payload["sfs_mount_path"] = request_body.get("sfs_mount_path")
    payload["environmentVariable"] = request_body.get("environmentVariable")
    payload["job_cpu"] = request_body.get("job_cpu", "2")
    payload["job_memory"] = convert_gb_to_gi(request_body.get("job_memory", "2GB"))
    payload["job_gpu"] = request_body.get("job_gpu", "1")

    return payload


def create_sfs_myaccount(auth_header, sfs_obj):
    url = MYACCOUNT_CREATE_SFS
    payload = {
        "efs_name": sfs_obj.get("name"),
        "efs_disk_size": sfs_obj.get("size"),
        "efs_disk_iops": sfs_obj.get("iops"),
        "vpc_id": settings.MYACCOUNT_INTERNAL_ACC_VPC_ID,
        "efs_plan_name": sfs_obj.get("plan_name"),
    }
    headers = {
        "Authorization": settings.MYACCOUNT_INTERNAL_ACC_AUTH_TOKEN,
        "Content-Type": "application/json",
    }
    response = requests.request("POST", url, json=payload, headers=headers)
    return response


def delete_sfs_myaccount(auth_header, efs_id):
    url = MYACCOUNT_DELETE_SFS.format(efs_id=efs_id)
    headers = {
        "Authorization": settings.MYACCOUNT_INTERNAL_ACC_AUTH_TOKEN,
        "Content-Type": "application/json",
    }
    response = requests.request("DELETE", url, headers=headers)
    return response


def get_sfs_status():
    url = MYACCOUNT_LIST_SFS
    headers = {
        "Authorization": settings.MYACCOUNT_INTERNAL_ACC_AUTH_TOKEN,
        "Content-Type": "application/json",
    }
    response = requests.request("GET", url, headers=headers)

    return response


def get_size_and_unit(size: int):
    if size >= SFS_SIZE_CONVERSION_FACTOR:
        return size / SFS_SIZE_CONVERSION_FACTOR, "TB"
    return size, "GB"
