from datetime import datetime
from container_registry.models import NamespaceDetail
from customer.models import Customer
from distributed_jobs.constants import (CREATING, JOB_TYPE_CHOICES,
                                        PYTORCH_JOB,
                                        PYTORCH_JOBS_STATUS_CHOICES, DONE)
from django.db import models
from e2e_core.mixins import BaseMixin, SafeDeleteMixinExtended
from gpu_service.models import SkuItemPrice, StockKeepingUnit
from projects.models import Projects


class ClusterPlan(BaseMixin, SafeDeleteMixinExtended):
    name = models.CharField(max_length=200)
    no_of_node = models.IntegerField(default=3)
    is_active = models.BooleanField(default=True)
    sku = models.ForeignKey(StockKeepingUnit, on_delete=models.SET_NULL, null=True)

    def __str__(self) -> str:
        return f"Cluster_Plan {self.name}"

    @property
    def gpu_switch_type(self):
        return self.sku.gpu_switch_type


class Cluster(BaseMixin, SafeDeleteMixinExtended):
    name = models.CharField(max_length=200)
    created_by = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True)
    cluster_plan = models.ForeignKey(ClusterPlan, on_delete=models.SET_NULL, null=True)
    is_active = models.BooleanField(default=True)
    deleted_at = models.DateTimeField(null=True, blank=True)
    project = models.ForeignKey(Projects, on_delete=models.CASCADE)
    sku_item_price = models.ForeignKey(SkuItemPrice, on_delete=models.PROTECT)

    def __str__(self) -> str:
        return f"Cluster {self.name}"

    @property
    def no_of_node(self):
        return self.cluster_plan.no_of_node

    @property
    def no_of_gpu(self):
        return str(self.cluster_plan.sku.gpu)

    @property
    def no_of_cpu(self):
        return str(self.cluster_plan.sku.cpu)

    @property
    def node_memory(self):
        return self.cluster_plan.sku.display_memory


class WorkerNode(BaseMixin, SafeDeleteMixinExtended):
    node_name = models.CharField(max_length=200)
    no_of_gpu_cards = models.IntegerField(default=0)
    is_active = models.BooleanField(default=True)
    sku = models.ForeignKey(StockKeepingUnit, on_delete=models.SET_NULL, null=True)
    blocked = models.BooleanField(default=False)
    cluster = models.ForeignKey(
        Cluster, on_delete=models.SET_NULL, null=True, blank=True
    )
    node_ip = models.GenericIPAddressField()

    def __str__(self) -> str:
        return f"WorkerNode {self.node_name}"

    @property
    def gpu_switch_type(self):
        return self.sku.gpu_switch_type


class SfsPlan(BaseMixin, SafeDeleteMixinExtended):
    name = models.CharField(max_length=200)
    bs_size = models.FloatField(help_text="Size of the Filesystem")
    sku = models.ForeignKey(StockKeepingUnit, on_delete=models.SET_NULL, null=True)
    is_active = models.BooleanField(default=True)
    iops = models.IntegerField()
    available_inventory_status = models.BooleanField(default=True)

    def __str__(self) -> str:
        return f"Sfs {self.name}"


class SfsDetail(BaseMixin, SafeDeleteMixinExtended):
    name = models.CharField(max_length=200)
    my_account_sfs_id = models.IntegerField()
    sfs_ip = models.GenericIPAddressField()
    is_active = models.BooleanField(default=True)
    sc_name = models.CharField(max_length=200)
    created_by = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True)
    deleted_at = models.DateTimeField(null=True, blank=True)
    plan = models.ForeignKey(SfsPlan, on_delete=models.SET_NULL, null=True)
    project = models.ForeignKey(Projects, on_delete=models.CASCADE)

    def __str__(self):
        return self.name

    @property
    def size(self):
        return self.plan.bs_size


class Job(BaseMixin, SafeDeleteMixinExtended):
    name = models.CharField(max_length=200)
    job_type = models.CharField(
        choices=JOB_TYPE_CHOICES, max_length=64, default=PYTORCH_JOB
    )
    master_args = models.JSONField(blank=True, null=True)
    worker_args = models.JSONField(blank=True, null=True)
    k8s_details = models.JSONField(default=dict)
    pod_dict = models.JSONField(default=dict)
    no_of_workers = models.IntegerField()
    master_command = models.JSONField(blank=True, null=True)
    worker_command = models.JSONField(blank=True, null=True)
    created_by = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True)
    cluster = models.ForeignKey(Cluster, on_delete=models.SET_NULL, null=True)
    is_active = models.BooleanField(default=True)
    deleted_at = models.DateTimeField(null=True, blank=True)
    image_url = models.TextField()
    is_private_image = models.BooleanField(default=False)
    registry_namespace = models.ForeignKey(
        NamespaceDetail, on_delete=models.SET_NULL, null=True, blank=True
    )
    project = models.ForeignKey(Projects, on_delete=models.CASCADE)
    sfs = models.ForeignKey(SfsDetail, on_delete=models.SET_NULL, null=True, blank=True)
    sfs_mount_path = models.CharField(max_length=300)
    status = models.CharField(
        choices=PYTORCH_JOBS_STATUS_CHOICES, max_length=64, default=CREATING
    )
    initial_data = models.JSONField()

    def __str__(self) -> str:
        return f"Job {self.name} {self.job_type}"

    def mark_deleted(self):
        if self.deleted_at is None:
            self.is_active = False
            self.deleted_at = datetime.now()
            self.status = DONE
            self.save(update_fields=['deleted_at', 'status', 'is_active', 'updated_at'])
