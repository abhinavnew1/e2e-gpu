from django.apps import AppConfig


class E2ECoreConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'e2e_core'
