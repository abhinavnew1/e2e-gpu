from django.conf import settings

# common error/success response messages
SUCCESS = "Success"
AUTHENTICATION_FAILED = "Authentication Failed"
UNAUTHORIZED_ACCESS = "Unauthorized Access!"
INVALID_ACTION = "Invalid action"
NOT_FOUND_ERROR = "{service} not found"
CREATION_FAILED_ERROR = "{service} creation failed"
UPDATION_FAILED_ERROR = "{service} updation failed"
FETCHING_ERROR = "Unable to fetch {service} details"
DELETION_FAILED_ERROR = "{service} deletion failed"
DELETION_SUCCESS = "{service} deleted successfully"
PARAMS_MISSING_OR_INVALID = "{param} is either invalid or not provided"
PERMISSION_DENIED = "You don't have the permission to perform this action"
MAX_LENGTH_ERROR = "{field_name} can contain a maximum of {max_length} characters"
INVALID_DATE_FILTER_TYPE = "Invalid type for date_filter"
INVALID_START_OR_END_DATE = "Invalid start_date or end_date"
START_DATE_CANNOT_BE_GREATER_THAN_END_DATE = "start_date cannot be greater than end_date"
FUTURE_DATE_ERROR = "start_date or end_date cannot be in future"

# support tickect common message
SUPPORT_TICKET_MESSAGE = "\n\n{ticket_type} Issue generated on behalf of\n{customer_name}"\
                        "\n{client_phone}\n{client_email}"

TECHNICAL = "technical"

# Date time Constants
LAST_HOUR = "last_hour"
LAST_24_HOURS = "last_24_hours"
LAST_7_DAYS = "last_7_days"
CURRENT_MONTH = "current_month"
PREVIOUS_MONTH = "previous_month"
SEMI_ANNUAL = "semi_annual"
CUSTOM = "custom"
DATE_FILTER_TYPES = [
	LAST_HOUR, LAST_24_HOURS, LAST_7_DAYS, CURRENT_MONTH, PREVIOUS_MONTH, SEMI_ANNUAL, CUSTOM
]
DATE_STRING_REGEX = r'(^0[1-9]|[12][0-9]|3[01])-(0[1-9]|1[0-2])-(\d{4}$)'
ALLOWED_SPECIAL_CHARACTERS = "#@"

# specifically for gpu-sdk or internal uses
GPU_DEFAULT_API_KEY = settings.GPU_DEFAULT_API_KEY
MY_ACCOUNT_API_LB_URL = settings.MY_ACCOUNT_API_LB_URL

E2E_EMAIL_DOMAIN = "@e2enetworks.com"

# name patterns
NAME_REGEX = r'[a-z]([-a-z0-9]*[a-z0-9])?'
NAME_INVALID = "Name should start with an alphabet and end with an alphanumeric character and can contain lowercase letters, digits and hyphen only."
