import re
from datetime import datetime, timedelta

import pytz
from dateutil.relativedelta import relativedelta
from django.conf import settings

from e2e_core.constants import (CURRENT_MONTH, CUSTOM, DATE_FILTER_TYPES,
                                DATE_STRING_REGEX, FUTURE_DATE_ERROR,
                                INVALID_START_OR_END_DATE,
                                LAST_24_HOURS, LAST_7_DAYS, LAST_HOUR,
                                PARAMS_MISSING_OR_INVALID, PREVIOUS_MONTH,
                                SEMI_ANNUAL,
                                START_DATE_CANNOT_BE_GREATER_THAN_END_DATE)


def ist_tz():
    return pytz.timezone(settings.IST_TIMEZONE_STR)


def current_datetime(tz=None):
    """
    :param tzinfo tz: timezone, a tzinfo subclass. defaults to None
    :returns: datetime.datetime: returns tz_aware datetime if tz is provided else returns UTC based tz_unaware datetime
    """
    return datetime.now(tz)


def sod(dt):
    """returns start of the day time component. eg: 01-jan-2023 00:00:00"""
    return datetime.combine(dt, datetime.min.time())


def eod(dt):
    """returns end of the day time component. eg: 01-jan-2023 11:59:59"""
    return datetime.combine(dt, datetime.max.time())


def str_to_dt(s):
    return datetime.strptime(s, '%d-%m-%Y').date()


def previous_day(dt):
    return (dt - timedelta(days=1))


def str_to_tz(dt, is_eod=False):
    """converts a date string to tz aware date time. sample input: '01-01-2023' """
    unaware_date = datetime.strptime(dt, '%d-%m-%Y')
    if is_eod:
        unaware_date = eod(unaware_date)
    return pytz.utc.localize(unaware_date)


def starting_of_the_current_month():
    return sod(current_datetime().replace(day=1))


def starting_of_the_previous_month():
    return starting_of_the_current_month() - relativedelta(months=1)


def end_of_the_previous_month():
    return eod(starting_of_the_current_month() - timedelta(days=1))


def tz_aware(dt_unaware):
    timezone = pytz.timezone(pytz.UTC.zone)
    return timezone.localize(dt_unaware, is_dst=None)


def round_to_previous_minute(datetime_obj):
    return datetime(
        year=datetime_obj.year,
        month=datetime_obj.month,
        day=datetime_obj.day,
        hour=datetime_obj.hour,
        minute=datetime_obj.minute,
        tzinfo=pytz.UTC,
    )


def round_to_next_minute(datetime_obj):
    timedelta_mins = 0 if datetime_obj.second == 0 else 1
    return datetime(
        year=datetime_obj.year,
        month=datetime_obj.month,
        day=datetime_obj.day,
        hour=datetime_obj.hour,
        minute=datetime_obj.minute,
        tzinfo=pytz.UTC,
    ) + timedelta(minutes=timedelta_mins)


def round_to_next_second(datetime_obj):
    timedelta_seconds = 0 if datetime_obj.microsecond == 0 else 1
    return datetime(
        year=datetime_obj.year,
        month=datetime_obj.month,
        day=datetime_obj.day,
        hour=datetime_obj.hour,
        minute=datetime_obj.minute,
        second=datetime_obj.second,
        tzinfo=pytz.UTC,
    ) + timedelta(seconds=timedelta_seconds)


def round_to_previous_second(datetime_obj):
    return datetime(
        year=datetime_obj.year,
        month=datetime_obj.month,
        day=datetime_obj.day,
        hour=datetime_obj.hour,
        minute=datetime_obj.minute,
        second=datetime_obj.second,
        tzinfo=pytz.UTC,
    )


def get_usage_hours(start_dt, end_dt):
    no_of_hours = (
        round_to_next_minute(end_dt) - round_to_next_minute(start_dt)
    ).total_seconds() / 3600.0
    return no_of_hours


def get_usage_hours_from_timedelta(timedelta_obj: timedelta):
    no_of_hours = timedelta_obj.total_seconds() / 3600.0
    return no_of_hours


def timestamp_to_tz(timestamp):
    """converts a timestamp to tz aware datetime; tz=utc"""
    if not isinstance(timestamp, float):
        timestamp = float(timestamp)
    dt_unaware = datetime.utcfromtimestamp(timestamp)
    dt_aware = tz_aware(dt_unaware)
    return dt_aware


def date_filter_validator(*args, **kwargs):
    date_filter = kwargs.get("date_filter")
    start_date_str, end_date_str = kwargs.get("start_date"), kwargs.get("end_date")
    if not date_filter or date_filter not in DATE_FILTER_TYPES:
        return False, PARAMS_MISSING_OR_INVALID.format(param="date_filter")
    if date_filter == CUSTOM:
        if not re.fullmatch(DATE_STRING_REGEX, start_date_str) or not re.fullmatch(DATE_STRING_REGEX, end_date_str):
            return False, INVALID_START_OR_END_DATE
        start_date, end_date = str_to_dt(start_date_str), str_to_dt(end_date_str)
        curr_date = current_datetime().date()
        if start_date > end_date:
            return False, START_DATE_CANNOT_BE_GREATER_THAN_END_DATE
        if start_date > curr_date or end_date > curr_date:
            return False, FUTURE_DATE_ERROR
    return True, ""


def get_start_and_end_datetime(date_filter, *args, **kwargs):
    """ Returns datetime objects for start & end date based on the type of date filter.

    :param str date_filter (required): a string denoting the type of date filter
    :param str start_date: start date in dd-mm-yyyy format. Required if date_filter == custom
    :param str end_date: end date in dd-mm-yyyy format. Required if date_filter == custom

    :returns tz_aware datetime objects for start date and end date
    :rtype: datetime, datetime

    datetime_helper.date_filter_validator() can be used to validate the correctness of params
    """
    curr_datetime = current_datetime()

    if date_filter == LAST_HOUR:
        end_date = round_to_next_minute(curr_datetime)
        start_date = end_date - timedelta(hours=1)

    elif date_filter == LAST_24_HOURS:
        end_date = round_to_next_minute(curr_datetime)
        start_date = end_date - timedelta(hours=24)

    elif date_filter == LAST_7_DAYS:
        end_date = round_to_next_minute(curr_datetime)
        start_date = end_date - timedelta(days=7)

    elif date_filter == CURRENT_MONTH:
        start_date = starting_of_the_current_month()
        end_date = round_to_next_minute(curr_datetime)

    elif date_filter == PREVIOUS_MONTH:
        start_date = starting_of_the_previous_month()
        end_date = end_of_the_previous_month()

    elif date_filter == SEMI_ANNUAL:
        start_date = sod(curr_datetime - relativedelta(months=6))
        end_date = round_to_next_minute(curr_datetime)

    else:  # date_filter == CUSTOM:
        start_date_str, end_date_str = kwargs.get("start_date"), kwargs.get("end_date")
        start_date = sod(str_to_tz(start_date_str))
        end_date = round_to_next_minute(curr_datetime) if str_to_dt(end_date_str) >= curr_datetime.date() else eod(str_to_tz(end_date_str))

    if start_date.tzinfo is None:
        start_date = tz_aware(start_date)
    if end_date.tzinfo is None:
        end_date = tz_aware(end_date)

    return start_date, end_date

def change_timezone(datetime_obj, timezone):
    tz = pytz.timezone(timezone)
    return datetime_obj.astimezone(tz)
