class ObjectNotFoundError(Exception):
    pass


class ObjectCreateError(Exception):
    pass


class ObjectDeleteError(Exception):
    pass


class ObjectUpdateError(Exception):
    pass


class ObjectFetchError(Exception):
    pass


class ObjectAlreadyExistError(Exception):
    pass


class TirPermissionError(Exception):
    pass
