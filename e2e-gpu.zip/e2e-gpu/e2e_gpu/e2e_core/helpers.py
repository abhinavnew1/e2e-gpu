import base64
import csv
import pickle
import re
import secrets
import string

import bitmath
import pytz
from django.db.models import Case, Value, When
from rest_framework import serializers
from safedelete import utils

from e2e_core.api.v1.services.support_ticket_service import \
    SupportTicketService
from e2e_core.constants import (ALLOWED_SPECIAL_CHARACTERS, E2E_EMAIL_DOMAIN,
                                TECHNICAL, NAME_REGEX, NAME_INVALID)
from notebook.constants import STATUS_PRIORITY


def pagination_params(request):
    """ Extracts the pagination params from request's query parameters"""
    return {
        "page_no": request.GET.get("page_no", ""),
        "per_page": request.GET.get("per_page", "")
    }


def mark_delete_related_objects(obj, *args, **kwargs):
    """ marks the deleted_at for the objects related to 'obj' """
    related_objects = utils.related_objects(obj)
    for related_object in related_objects:
        if hasattr(related_object, "mark_deleted"):
            related_object.mark_deleted()


def support_ticket_generator(errors, subject, customer):
    validated_data = {
            "ticket_type": TECHNICAL,
            "message": errors,
            "subject": subject,
    }
    SupportTicketService().create_ticket(customer, validated_data)


def convert_gb_to_gi(size_in_gb: str | int) -> str:
    """
    :param str | int size_in_gb: size in GB either as int or as str in xxGB format
    :returns size in GiB in xxGi format
    :rtype: str
    """
    if isinstance(size_in_gb, str):
        size_in_gb = int(size_in_gb.split("GB")[0].strip())
    elif not isinstance(size_in_gb, int):
        raise TypeError
    size_in_gi = round(bitmath.GB(size_in_gb).to_GiB().value, 2)
    return f"{size_in_gi}Gi"


def read_csv_data(file_path: str) -> list[dict]:
    """reads data from the csv file specified in "file_path" arg, and returns the data as a list of dictionaries"""
    data = []

    with open(file_path, mode='r') as file:
        csv_file = csv.DictReader(file)
        for row_data in csv_file:
            data.append(row_data)

    return data


def generate_random_password(length=12):
    # Define characters to use for generating the password
    allowed_characters = string.ascii_letters + string.digits
    # Ensure that at least one special character is included
    password = [secrets.choice(ALLOWED_SPECIAL_CHARACTERS)]
    # Generate the remaining characters for the password
    password += [secrets.choice(allowed_characters) for _ in range(length - 1)]
    # Shuffle the characters to make the password random
    secrets.SystemRandom().shuffle(password)

    return ''.join(password)


def convert_to_base64(text_to_encode):
    encoded_text = base64.b64encode(text_to_encode.encode()).decode()
    return encoded_text


def get_basic_auth_header_from_uname_passwd(username, password):
    basic_auth_token = convert_to_base64(f"{username}:{password}")
    return f"Basic {basic_auth_token}"


def is_internal_customer(customer_email: str) -> bool:
    if E2E_EMAIL_DOMAIN in customer_email:
        return True
    return False


def convert_py_object_to_hex_str(obj):
    return pickle.dumps(obj).hex()


def get_py_object_from_hex_str(hex_string):
    return pickle.loads(bytes.fromhex(hex_string))


def convert_base64_to_string(base64_string):
    decoded_bytes = base64.b64decode(base64_string)
    decoded_string = decoded_bytes.decode('utf-8')
    return decoded_string


def validate_name_pattern(name):
    if not re.fullmatch(NAME_REGEX, name):
        return False, NAME_INVALID
    return True, ""


def get_pk_or_name_from_value(obj_id: str):
    '''
    function to check/patch, if obj_id passed in api was the id/primary_key or name of resource
    :returns:
        tuple: A tuple containing two elements:
            - int | None: int, if passed value is pk else None
            - str | None: str, if passed value is name else None
    '''
    try:
        obj_id = int(obj_id)
        return obj_id, None
    except Exception:
        return None, obj_id


def advanced_search_filter(query_set, filter_key_mapping: dict, exclude_key_mapping: dict, single_value_lookup_key_mapping: dict = {}, **search_kwargs):
    """
    :param query_set QuerySet: QuerySet to be filtered
    :param filter_key_mapping dict: A dict where keys represent the model fields and values represent the corresponding model field lookup.
    :param exclude_key_mapping dict: A dict where keys represent the model fields and values represent the corresponding model field lookup. The keys should be prefixed with `not_` to denote exclude query.
    :param single_value_lookup_key_mapping dict: A dict where keys represent the model fields and single value represent the corresponding model field lookup.

    The keys in the filter_key_mapping, exclude_key_mapping and single_value_lookup_key_mapping dict are the keys for API QueryParams. To search on multiple field values, pass all the values as a comma-separated string.
    These QueryParams for AdvancedSearch should be passed as keyword arguments to this function.
    """
    filter_dict = {
        filter_key_mapping[key]: value.split(',')
        for key, value in search_kwargs.items()
        if key in filter_key_mapping and value
    }
    filter_dict.update({
        single_value_lookup_key_mapping[key]: value
        for key, value in search_kwargs.items()
        if key in single_value_lookup_key_mapping and value
    })
    query_set = query_set.filter(**filter_dict)
    exclude_dict = {
        exclude_key_mapping[key]: value.split(',')
        for key, value in search_kwargs.items()
        if key in exclude_key_mapping and value
    }
    # exclude to be applied in cascade for each lookup so that it evaluates to `SELECT ... WHERE NOT item1=value1 AND NOT item1=value1 ...`
    for item in exclude_dict:
        query_set = query_set.exclude(**{item: exclude_dict[item]})
    return query_set


def order_queryset(resource_qs, resource_order_key_mapping, status_priority_dict={}, **kwargs):
    """
    Args:
        resource_qs (query_set): query_set to be ordered
        resource_order_key_mapping (dict): A dict where keys represent the fields to be ordered and values represent the corresponding model field.
        kwargs: A kwarg with key("order_by") and comma seperated string value representing fields denoting sort order. Example: {"order_by": "status,-name"}

    Returns:
        query_set: ordered query_set | if no field provided then default ordering on basis of created_at
    """
    order_by_fields = kwargs.get("order_by", "")
    order_by_fields_list = [resource_order_key_mapping[value] for value in order_by_fields.split(',') if value in resource_order_key_mapping]
    if STATUS_PRIORITY in order_by_fields_list or "-"+STATUS_PRIORITY in order_by_fields_list:
        resource_qs = make_status_priority_alias(resource_qs, status_priority_dict)
    return resource_qs.order_by(*order_by_fields_list, "-created_at")


def validate_boolean(value: str | bool) -> bool:
    '''
    function to validate string representation of boolean values and return corresponding python bool type. If the input value is a python bool, it is returned as-is. Raises ValidationError if invalid input is provided.

    :param value str|bool: value to process and convert. This can be either a python bool or any of the following string representations (case-insensitive):
                            - True values: 'true', '1', 't', 'yes', 'y', 1
                            - False values: 'false', '0', 'f', 'no', 'n', 0

    :returns bool: the converted boolean value if the input is a recognized string representation else raises ValidationError.
    '''
    bool_field = serializers.BooleanField()
    validated_bool = bool_field.run_validation(value)
    return validated_bool


def process_boolean(value: str | bool, default_value: bool) -> bool:
    '''
    function to process and convert string representation of boolean values to python bool type. If the input value is a python bool, it is returned as-is.

    :param value str|bool: value to process and convert. This can be either a python bool or any of the following string representations (case-insensitive):
                            - True values: 'true', '1', 't', 'yes', 'y', 1
                            - False values: 'false', '0', 'f', 'no', 'n', 0

    :param default_value bool: a defualt value that will be returned in case of an invalid input

    :returns bool: the converted boolean value if the input is a recognized string representation else returns default_value.
    '''
    try:
        return validate_boolean(value)
    except serializers.ValidationError:
        return default_value


def get_timezone_from_name(timezone_name):
    return pytz.timezone(timezone_name)


def make_status_priority_alias(resource_qs, status_priority_dict):
    cases_for_status = [When(status=status, then=Value(status_priority)) for status, status_priority in status_priority_dict.items()]

    status_priority = Case(
        *cases_for_status,
        default=100
    )

    resource_qs_with_status_priority_alias = resource_qs.alias(status_priority=status_priority)
    return resource_qs_with_status_priority_alias
