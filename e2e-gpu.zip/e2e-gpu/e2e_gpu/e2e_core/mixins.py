from django.conf import settings
from django.db import models
from safedelete import safedelete_mixin_factory, utils

policy = settings.SAFE_DELETE_POLICY_SET[settings.SAFE_DELETE_POLICY]

# this mixin enables the soft-delete functionality
safe_delete_mixin = safedelete_mixin_factory(policy=policy)


class SafeDeleteMixinExtended(safe_delete_mixin):
    """
    Safe delete mixin doesn't support cascade delete and un-delete
    So this will add the functionality to it.
    """

    def delete(self, *args, **kwargs):
        if policy == settings.SAFE_DELETE_POLICY_SET["SOFT_DELETE"]:
            related_objects = utils.related_objects(self)
            for related_object in related_objects:
                related_object.delete()
            self.deleted = True
            self.save(keep_deleted=True)
        else:
            super(self).delete()

    def undelete(self, *args, **kwargs):
        if policy == settings.SAFE_DELETE_POLICY_SET["SOFT_DELETE"]:
            related_objects = utils.related_objects(self)
            for related_object in related_objects:
                related_object.undelete()
            self.deleted = False
            self.save(keep_deleted=False)
        else:
            super(self).undelete()

    class Meta:
        abstract = True


class BaseMixin(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)  # This should add the created date on its own only once.
    updated_at = models.DateTimeField(auto_now=True)  # This should add the updated date every time.

    class Meta:
        abstract = True


class ReadOnlyModel(models.Model):
    '''Unmanaged readonly model, to ensure that django doesn't modify the model, 
    also overriding all save-delete methods to avoid any possible writes'''

    class Meta:
        # Set managed to False, to ensure that django does not manage/modify/migrate this table
        # This tells Django that this model is linked to an existing table
        abstract = True
        managed = False
    
    def save(self, *args, **kwargs):
        # This ensures that there are no writes to the model
        "overriding all save-delete methods to avoid any possible writes"
        return

    def delete(self, *args, **kwargs):
        # This ensures that there are no writes to the model
        "overriding all save-delete methods to avoid any possible writes"
        return
