from __future__ import absolute_import, unicode_literals

import os
import socket

from celery import Celery
from celery.signals import task_failure
from django.conf import settings
from django.core.mail import mail_admins

# Set the default Django settings module for the 'celery' program.
# TODO: Below line always sets the environment to Production. As a result, Production settings variables are getting selected. Fix:TODO 
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "e2e_gpu.config.production")

app = Celery('e2e_gpu')

# Using a string here means the worker doesn't have to serialize
# the configuration object to child processes.
# - namespace='CELERY' means all celery-related configuration keys
#   should have a `CELERY_` prefix.
app.config_from_object('django.conf:settings', namespace='CELERY')

# Load task modules from all registered Django apps.
app.autodiscover_tasks()

@app.task(bind=True)
def debug_task(self):
    print(f'Request: {self.request!r}')


@task_failure.connect
def celery_task_failure_email(**kwargs):
    """ celery 4.0 onward has no method to send emails on failed tasks
    so this event handler is intended to replace it
    """

    subject = "[{queue_name}@{host}] Error: Task {sender.name} ({task_id}): {exception}".format(
        queue_name='celery',  # `sender.queue` doesn't exist in 4.1?
        host=socket.gethostname(),
        **kwargs
    )

    message = """Task {sender.name} with id {task_id} raised exception:
{exception!r}


Task was called with args: {args} kwargs: {kwargs}.

The contents of the full traceback was:

{einfo}
    """.format(
        **kwargs
    )

    mail_admins(subject, message)
