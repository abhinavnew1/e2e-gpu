import sentry_sdk

from e2e_gpu.settings import *
from sentry_sdk.integrations.django import DjangoIntegration

ENVIRONMENT = "Production"
print(f"{ENVIRONMENT} environment")

sentry_sdk.init(
    dsn="https://69f156de9e1442bf90ebdea83e9c3b82@o1335030.ingest.sentry.io/4505267175555072",
    integrations=[
        DjangoIntegration(),
    ],

    # Set traces_sample_rate to 1.0 to capture 100%
    # of transactions for performance monitoring.
    # We recommend adjusting this value in production.
    traces_sample_rate=1.0,

    # If you wish to associate users to errors (assuming you are using
    # django.contrib.auth) you may enable sending PII data.
    send_default_pii=True
)

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'gpunotebook',
        'USER': 'gpuproject',
        'PASSWORD': 'eXscyykZ0nFWNrGd',
        'HOST': '172.16.34.3',
        'PORT': '3306',
    },
    'kubeflow_pipeline_db': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': '',
        'USER': '',
        'PASSWORD': '',
        'HOST': '',
        'PORT': '',
    }
}

# Vault settings
VAULT_URL = 'http://172.16.33.65:8200'
VAULT_TOKEN = '150f0e7a-2738-e8b0-722a-bfebf2c6b277'

## Redirects all HTTP requests to HTTPS
# SECURE_SSL_REDIRECT = False

SITE_ID = 1

# setting for enabling the error page
DEBUG = False

ALLOWED_HOSTS = ['*',]#TODO
ADMIN_HOSTS = ['*'],#TODO

# CACHES = {
#     'default': {
#         'BACKEND': 'django.core.cache.backends.db.DatabaseCache',
#         'LOCATION': 'my_cache_table',
#     }
# }

# ACCOUNT_DEFAULT_HTTP_PROTOCOL = "https"

# SESSION_FILE_PATH = "/tmp/"


MYACCOUNT_LB_URL = "http://webserver.e2enetworks.com/"
MY_ACCOUNT_API_LB_URL = "https://api.e2enetworks.com/myaccount/"
MYACCOUNT_INTERNAL_ACC_PROJECT_ID = 0

# EOS settings
EOS_BASE_URL = MYACCOUNT_LB_URL + "api/v1"
EOS_MINIO_ENDPOINT = {
    DELHI_LOCATION: "https://objectstore.e2enetworks.net",
    MUMBAI_LOCATION: "https://mum-objectstore.e2enetworks.net",
}

# Groot Base URLs
GROOT_BASE_URL = "http://127.0.0.1:8000/"
PIPELINE_BASE_URL = "https://pipelines.e2enetworks.net/pipeline/"
NOTEBOOK_BASE_URL = "https://notebooks.e2enetworks.com/"


# celery settings
CELERY_ENV = 'e2e_gpu.config.production'
CELERY_BROKER_URL = 'amqp://gpu-admin:GPU@e2e2023@172.16.33.29:5672/gpu'
DEFAULT_RABBITMQ_QUEUE = "gpu_project_queue"


# crontab settings
CRONTAB_LOCK_JOBS = True
CRONTAB_DJANGO_SETTINGS_MODULE = 'e2e_gpu.config.production'
CRONTAB_DJANGO_MANAGE_PATH = '/home/e2e-gpu/worker_e2e-gpu/e2e-gpu/e2e_gpu/manage.py'


PROMETHEUS_SERVER_URL = "http://216.48.188.176:8080"


MANDRILL_WEBHOOK_KEY = "zN1ldAJXhNkKq0y37xNaUg"

# email addresses & mailing lists
CLOUD_PROCESS_EMAIL = "cloud-process@e2enetworks.com"  # to be used for internal emails, tickets & notifications
CLOUD_PLATFORM_EMAIL = "cloud-platform@e2enetworks.com"  # to be used when email is also sent to the customer
EMAIL_HOST_USER = "noreply@e2enetworks.com"
SALES_EMAIL = "sales@e2enetworks.com"
SALES_NOTIFY_EMAIL = "sales-internal@e2enetworks.com"

SKU_INVENTORY_REQUEST_MAIL_LIST = [SALES_NOTIFY_EMAIL, CLOUD_PROCESS_EMAIL]
SUPPORT_EMAILS = [CLOUD_PROCESS_EMAIL]

ELASTIC_APM = {
'SERVICE_NAME': 'AI-ML-service',
'DEBUG': True,
'SERVER_URL': 'http://172.16.33.4:8200',
'LOG_LEVEL': "info",
'ENABLED': True
}

S3_ENDPOINT = "objectstore.e2enetworks.net"
E2E_CONTAINER_REGISTRY_ENDPOINT = "registry.e2enetworks.net"
INFERENCE_PROMETHEUS_SERVER_URL = "http://216.48.188.75:9090/"
HELLO_WORLD_YAML_FILE = "/home/e2e"
GPU_POLICY_SET = "165"
INFLUX_DB_MODEL_PLAYGROUND = {
    "host": "",
    "port": "",
    "database": "",
    "username": "",
    "password": ""
}

# api_key specifically for gpu-sdk or internal uses
GPU_DEFAULT_API_KEY = "e4adbc86-39e7-46d0-a760-773858d163f7"

# pipeline-run logs bucket credentials
LOGS_BUCKET_NAME = ""
LOGS_ACCESS_KEY = ""
LOGS_SECRET_KEY = ""
CUSTOM_TOKEN_PRIVATE_KEY = b'-----BEGIN RSA PRIVATE KEY-----\nMIIEogIBAAKCAQEAujbvUNMrcGNiRJx9hFISk1tZ5OFyWuSfRd4sVT6azyLnoqKY\nhFg97jl+ync8d5cAPoUjMDDJ9hVkPe1WMhTIuohSE2ISWgTABAhI6Sd22UDdsTdU\nXP1Kn9sF1rJ3fXt1lQaK4Hlldn7b3Nr7V0Xg9wzxAFUTtWzDlJDIWMUCBmz3qq/s\nk+g+k7ZgrxD6nXWW2LAKAPt9/3aisKd1G+S0Iqu+3hplqtzVXKrvS1FQMwWJOwi9\n1h+64wrrztyocNKczwDx2aA70iw02Uu0xsDbcvAiVVXppDDV8PaQIbdpb4uIBA7G\nF2s/1CPUYlJ4k5QkeytdIwqXqLzz56kXINOUiwIDAQABAoIBABD4dLL0VnR1pOev\n2K3jH5eXrwecQY8QYDDpNeJxmYDgeM+/lbq/TVWVSSgr2bI5wWdGkZW7ZzcqwpSf\njp1zJh//Jcu9F627L8IDp0a9tqfHW5eM/VPu2YrcARo3RYswDIqPqr8ZESrNa5LN\nz4jSm3/9s/EIeoqsO4l3RcBL+V/wYi/u3FYVbHlZV0hskZx+mtRYdKAC0x/wbA8m\nYoXEs6UUujdoPRuegGsPMTPKF76DqKnz3G7PY7xCR5x7dAyvjt2ZCaHLnyCL2qCn\n+eJBtFAVarkm9WGvRytDXLREz5NYSVfkWDG7iMLRWpSgwQzuryyWQgwecyWgGA8G\nRnMO4nECgYEA+hUTp1zcjC60gSqDGJ80h3/ddiwS4u/wL2cQcSTf+WPSUAZKUdtR\nPUeOiYmMyDVYJGPvmeVYjHM6NujA4ZGKavSMASD4Z4Fy6hWSrEkB1/V1b0LCnTLc\nNdDDOu7QzAFkAAK65FK5YZvG16qGUFPGqI/+VjNgeB2TEpG47aofxRUCgYEAvp73\ncMA20hRKvWjmfbyF9CkMQbAvbA0do4Lc7ExuxDaIT6mPP4HlblqQXuKv8utxmAi1\ntniSfrfLSHRACzd658RYHOtLEK+xPafO3p6RRRP2/jpdaZ5OrIhVDWDIrOk7MI8o\nKLc/byKy4TON2Yoi+YkL4cXlTdwelAWhD7fLmx8CgYAlC3I53HufGFwMtittPkgd\nukcn9idmDnzZyL6axAeZfbvttsDTl1VVaoAmx4VfMue3nEYl2d9gDsGU2K2ZvGFw\nroD+uc+SJY7MNh3f/4CSaP3YWV9SwfH01tPUqwOq9JnHlp/wqoBjgRvXXp8+zuoi\nlhHq2vlzUY4ztfpa2lSScQKBgHnhyvUc8fCBaQiS+k2LLVtgo6WcsbW07S6PjhLJ\nDEoJVD8be6xvsfNNlOIWr8nzIT7E0utJTOIZQrGhIxII910Z/fz/tY+Fxx5VHcDa\nQqiYi2UijHfr8QIAaeGT8LwepOn3nwXppXW6CgZUoG5oFNTY++/wSR3vkN20e7dB\nHb6hAoGAcHslpIUA7vNqCVOtW5orFmu5RyVLRzC/Pbg1pVvhjLcxfJRRxTcDuB2k\nSCAO0aECkx76ru+b1YTaEhkm7hBsukm1Gur1ZzVPXLMjO1xbNPZgNVIzxgizJVAx\nf4EPe8nfWr7lGahGKC05Bli2QGAPYTSCcNHagXNK+ZuKe0suX/8=\n-----END RSA PRIVATE KEY-----\n'
CUSTOM_TOKEN_PUBLIC_KEY = b'-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAujbvUNMrcGNiRJx9hFIS\nk1tZ5OFyWuSfRd4sVT6azyLnoqKYhFg97jl+ync8d5cAPoUjMDDJ9hVkPe1WMhTI\nuohSE2ISWgTABAhI6Sd22UDdsTdUXP1Kn9sF1rJ3fXt1lQaK4Hlldn7b3Nr7V0Xg\n9wzxAFUTtWzDlJDIWMUCBmz3qq/sk+g+k7ZgrxD6nXWW2LAKAPt9/3aisKd1G+S0\nIqu+3hplqtzVXKrvS1FQMwWJOwi91h+64wrrztyocNKczwDx2aA70iw02Uu0xsDb\ncvAiVVXppDDV8PaQIbdpb4uIBA7GF2s/1CPUYlJ4k5QkeytdIwqXqLzz56kXINOU\niwIDAQAB\n-----END PUBLIC KEY-----\n'
POWERDNS_CREDENTIALS = {
    "BASE_URL": "http://thor-dns.e2enetworks.net/api/v1/",
    "API_KEY": "quovantise2e123",
    "DOMAIN_TTL": 86400,
    "RECORD_TTL": 14400,
    "PTR_TTL": 86400
}
DNS_NAMESERVERS = ['integration-dns.e2enetworks.net.']

VECTOR_DB_DNS_RECORD_NAME = '{}-vectordatabase.e2enetworks.net'
ISTIO_INGRESSGATEWAY_IP = '216.48.183.16'

# Testing Container Registry Urls
HARBOR_URL = "https://registry-beta.e2enetworks.net"
DOMAIN_NAME = "registry-beta.e2enetworks.net"
HARBOR_BASIC_AUTH = ('admin', 'Harbor12345')

MYACCOUNT_PROD_LB_URL = "https://api.e2enetworks.com/myaccount/"

URL_FOR_QDRANT_SNAPSHOT_ENDPOINT = MY_ACCOUNT_API_LB_URL
QDRANT_MINIO_ENDPOINT = S3_ENDPOINT
QDRANT_MINIO_ACCESS_KEY = "0X4L4M8MPBC6NFOMCMWG"
QDRANT_MINIO_SECRET_KEY = "FA5GZPHII538OA4K46YDZWA9EXZGOF6U422AWHHG"
QDRANT_MINIO_BUCKET_NAME = "qdrant-snapshot"


AWS_S3_DEFINITION_ID = "a2875f8f-63b8-4f3a-a6d9-3a60e92296d9"
MINIO_DEFINITION_ID = "c9ba5b62-fd47-4e96-8271-5c0a47d9f724"
GCS_DEFINITION_ID = "8aa9836d-fa23-406a-8362-b946800621b5"
GOOGLE_DRIVE_STORAGE_DEFINITION_ID = "58887141-d559-43ac-ae24-084bbb985030"
AZURE_BLOB_STORAGE_DEFINITION_ID = "d517c02b-a11d-4100-a761-2bbaff064e48"

AIRBYTE_DESTINATION_DEFINITION_ID = "fa417072-d6e1-404d-85a8-f5ca9ab6b023"
AIRBYTE_BASE_URL = "http://216.48.185.34/"
AIRBYTE_USERNAME = "tir-airbyte-admin"
AIRBYTE_PASSWORD = "judcy9-VW_-u4aaF2+MS9c-hynhYv~xLZKr^?j26X"
AIRBYTE_WORKSPACE_ID = "f9d6cc08-0932-4eff-a6a6-96203fa57c17"
AIRBYTE_WEBHOOK_PAYLOAD_TOKEN = "t3Qb3Ig-1Ll6S-6rhjK95H__7Xe2U"

SOURCE_CATALOG_ID_MINIO = "0271e78d-5cf2-4c68-a03d-da3d34d725af"
SOURCE_CATALOG_ID_S3 = "bac3c131-04d0-4d2b-838d-542e8327f74e"
SOURCE_CATALOG_ID_GCS = "064160de-94eb-4aa0-9655-a2eb06f85e5c"
SOURCE_CATALOG_ID_GOOGLE_DRIVE_STORAGE = "1b057ed9-ea4c-4946-a3a4-a77d8f3592e1"
SOURCE_CATALOG_ID_AZURE_BLOB_STORAGE = "c4731d73-6cf0-4bed-8110-43a602bab705"
