from e2e_gpu.settings import *

ENVIRONMENT = "Thor"
print(f"{ENVIRONMENT} environment")

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'gpudatabase',
        'USER': 'e2e-gpu',
        'PASSWORD': 'qwQW12!@',
        'HOST': '172.16.231.173',
        'PORT': '3306',
    },
    'kubeflow_pipeline_db': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'mlpipeline',
        'USER': 'tir',
        'PASSWORD': 'E2e#pipeline-dev',
        'HOST': '164.52.212.194',
        'PORT': '3306',
    }
}

# Vault settings
VAULT_URL = 'http://172.16.231.12:8200'
VAULT_TOKEN = 's.cIH463sqrFH3Y15PriorTs1p'

## Redirects all HTTP requests to HTTPS
# SECURE_SSL_REDIRECT = False

SITE_ID = 1

# setting for enabling the error page
DEBUG = True

# it prevent redirection due to end slash
APPEND_SLASH = False

ALLOWED_HOSTS = ['*']
# ADMIN_HOSTS = ['myaccount-groot.e2enetworks.net', ]

# CACHES = {
#     'default': {
#         'BACKEND': 'django.core.cache.backends.db.DatabaseCache',
#         'LOCATION': 'my_cache_table',
#     }
# }

# ACCOUNT_DEFAULT_HTTP_PROTOCOL = "https"

# SESSION_FILE_PATH = "/tmp/"


# LB domain names may be different for different test environments depending on the env-architecture-setup
MY_ACCOUNT_FRONTEND_URL = 'https://myaccount-thor.e2enetworks.net/'
TIR_FRONTEND_URL = 'https://thor-gpu.e2enetworks.net/'
MYACCOUNT_LB_URL = "https://api-thor.e2enetworks.net/"
MY_ACCOUNT_API_LB_URL = MYACCOUNT_LB_URL

MYACCOUNT_PROD_LB_URL = "https://api.e2enetworks.com/myaccount/"
MYACCOUNT_INTERNAL_ACC_PROJECT_ID = 7585
MYACCOUNT_SFS_LOCATION = 'Delhi'
MYACCOUNT_INTERNAL_ACC_VPC_ID = 10121
MYACCOUNT_INTERNAL_ACC_API_KEY = 'c097ce0d-810a-478a-97dc-d3b26f2d027f'
MYACCOUNT_INTERNAL_ACC_AUTH_TOKEN = 'Bearer eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJGSjg2R2NGM2pUYk5MT2NvNE52WmtVQ0lVbWZZQ3FvcXRPUWVNZmJoTmxFIn0.eyJleHAiOjE3NDAyMjA2NTEsImlhdCI6MTcwODY4NDY1MSwianRpIjoiMTc4MDIwMmEtOGRkMS00MGY4LTkxYTYtMmQwM2MyZDA5ZTBiIiwiaXNzIjoiaHR0cDovL2dhdGV3YXkuZTJlbmV0d29ya3MuY29tL2F1dGgvcmVhbG1zL2FwaW1hbiIsImF1ZCI6ImFjY291bnQiLCJzdWIiOiI2YTcwNDgzNC1hZmI0LTRlNTYtODM0Yi02NDc5ZDgzM2U0NzEiLCJ0eXAiOiJCZWFyZXIiLCJhenAiOiJhcGltYW51aSIsInNlc3Npb25fc3RhdGUiOiI3NTY3NGU1Yi0wNTUzLTQ0NjEtOWNiYy0wMzMyYTNmMmFhOTIiLCJhY3IiOiIxIiwiYWxsb3dlZC1vcmlnaW5zIjpbIiJdLCJyZWFsbV9hY2Nlc3MiOnsicm9sZXMiOlsib2ZmbGluZV9hY2Nlc3MiLCJ1bWFfYXV0aG9yaXphdGlvbiIsImFwaXVzZXIiLCJkZWZhdWx0LXJvbGVzLWFwaW1hbiJdfSwicmVzb3VyY2VfYWNjZXNzIjp7ImFjY291bnQiOnsicm9sZXMiOlsibWFuYWdlLWFjY291bnQiLCJtYW5hZ2UtYWNjb3VudC1saW5rcyIsInZpZXctcHJvZmlsZSJdfX0sInNjb3BlIjoicHJvZmlsZSBlbWFpbCIsInNpZCI6Ijc1Njc0ZTViLTA1NTMtNDQ2MS05Y2JjLTAzMzJhM2YyYWE5MiIsImVtYWlsX3ZlcmlmaWVkIjpmYWxzZSwibmFtZSI6IkFtb2wgVW1iYXJrYXIiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJhbW9sLnVtYmFya2FyQGUyZW5ldHdvcmtzLmNvbSIsImdpdmVuX25hbWUiOiJBbW9sIiwiZmFtaWx5X25hbWUiOiJVbWJhcmthciIsImVtYWlsIjoiYW1vbC51bWJhcmthckBlMmVuZXR3b3Jrcy5jb20ifQ.IfFITmsHTJ7XHnKOHe8i5aIzBLvrXmLqhQrOCooN-wvHTLy-JeLg1vIoe3mAnh7LvlDwb5YwacM7bYe7oNHUM3FaA4K2P-OHOo9__HFmua6XWRXWDdjDrlOjrv-NepjcnxtyfVtWwdPtL_QUZnIZ8djxgGtEYrVIDDegncwDNrI'

# EOS settings
EOS_BASE_URL = MYACCOUNT_LB_URL + "api/v1"
EOS_MINIO_ENDPOINT = {
    DELHI_LOCATION: "https://eos-thor.devteame2enetworks.com",
    MUMBAI_LOCATION: "https://eos-thor.devteame2enetworks.com",
}

# Groot Base URLs
GROOT_BASE_URL = "http://172.16.231.34:8000/"  # groot being served on 0.0.0.0:8000 on thor env
NOTEBOOK_BASE_URL = "https://jupyterlabs.e2enetworks.net/"  # "http://216.48.188.198/"
PIPELINE_BASE_URL = "http://216.48.188.198/pipeline/"

# celery settings
CELERY_ENV = 'e2e_gpu.config.thor'
CELERY_BROKER_URL = 'amqp://gpu:gpuuser@172.16.231.17:5672/gpu'
DEFAULT_RABBITMQ_QUEUE = "gpu_project_queue"


# crontab settings
CRONTAB_LOCK_JOBS = True
CRONTAB_DJANGO_SETTINGS_MODULE = 'e2e_gpu.config.thor'
CRONTAB_DJANGO_MANAGE_PATH = '/home/awakening/worker_e2e-gpu/e2e-gpu/e2e_gpu/manage.py'


PROMETHEUS_SERVER_URL = "http://216.48.188.206:8080/"

# email addresses & mailing lists
CLOUD_PROCESS_EMAIL = "dev-alerts+process@e2enetworks.com"  # to be used for internal emails, tickets & notifications
CLOUD_PLATFORM_EMAIL = "dev-alerts+platform@e2enetworks.com"  # to be used when email is also sent to the customer
EMAIL_HOST_USER = "noreply@e2enetworks.com"
SALES_EMAIL = "dev-alerts+sales@e2enetworks.com"
SALES_NOTIFY_EMAIL = SALES_EMAIL

SKU_INVENTORY_REQUEST_MAIL_LIST = ["shivansh.jain@e2enetworks.com", "jagmeet.singh@e2enetworks.com",]  # [SALES_NOTIFY_EMAIL, CLOUD_PROCESS_EMAIL]
SUPPORT_EMAILS = ["shivansh.jain@e2enetworks.com", "jagmeet.singh@e2enetworks.com", "aditya.yadav@e2enetworks.com"]  # [CLOUD_PROCESS_EMAIL]

ELASTIC_APM = {
'SERVICE_NAME': 'AI-ML-service',
'DEBUG': True,
'SERVER_URL': 'http://172.16.7.15:8200',
'LOG_LEVEL': "info",
'ENABLED': False
}
S3_ENDPOINT = "eos-thor.devteame2enetworks.com"
E2E_CONTAINER_REGISTRY_ENDPOINT = "registry-beta.e2enetworks.net"
INFERENCE_PROMETHEUS_SERVER_URL = "http://216.48.188.96:9090/"
GPU_POLICY_SET = "52"

# Testing Container Registry Urls
HARBOR_URL = "https://registry-beta.e2enetworks.net"
DOMAIN_NAME = "registry-beta.e2enetworks.net"
HARBOR_BASIC_AUTH = ('admin', 'Fa1IA@kLuU@W')

# api_key specifically for gpu-sdk or internal uses
GPU_DEFAULT_API_KEY = "a98665f0-ad9d-423c-a675-9b3cc2717a12"

#Db creadential for model playground logs and usage
INFLUX_DB_MODEL_PLAYGROUND = {
    "host": "216.48.179.55",
    "port": "8086",
    "database": "tir_influx",
    "username": "influx_admin",
    "password": "influx_admin"
}

# pipeline-run logs bucket credentials
LOGS_BUCKET_NAME = "amol-logbucket"
LOGS_ACCESS_KEY = "4BCRLIGN6TBN7T4DZOK5"
LOGS_SECRET_KEY = "V6NTF1EK5Y3G60HIDIIBNQ69TE7U26SE57AJEV5M"

ACCESS_LOGS_BUCKET = 'inference-logs-backup'
MINIO_SERVER = 'objectstore.e2enetworks.net'
ACCESS_LOGS_BUCKET_ACCESS_KEY = 'LJ7RPAMUGBT811862ADU'
ACCESS_LOGS_BUCKET_SECRET_KEY = 'DHHFP2CNB2K2FEGTVO0JJFQY7PW7NH36UC6XP7U2'
# GenAI data Upload Bucket Whisper (mounted as PVC on pod)
GENAI_INFERENCE_PROJECT_ID = 1017
GENAI_INFERENCE_TEAM_ID = 517
GENAI_DATASET_ID = 596
GENAI_AUTH_TOKEN = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJGSjg2R2NGM2pUYk5MT2NvNE52WmtVQ0lVbWZZQ3FvcXRPUWVNZmJoTmxFIn0.eyJleHAiOjE3NDE4MDI2NTAsImlhdCI6MTcxMDI2NjY1MCwianRpIjoiMGMwZDgxNTMtNjA3My00YmZjLTgxMGYtN2QwYTg2NzFmOTNlIiwiaXNzIjoiaHR0cDovLzE3Mi4xNi4yMzEuMTM6ODA4MC9hdXRoL3JlYWxtcy9hcGltYW4iLCJhdWQiOiJhY2NvdW50Iiwic3ViIjoiMGMxYjhiNmMtYTE2Yi00YzU2LTg0Y2EtOWI2ZjI3YTNkNjU2IiwidHlwIjoiQmVhcmVyIiwiYXpwIjoiYXBpbWFudWkiLCJzZXNzaW9uX3N0YXRlIjoiOGVhYmIyZDctZjZhOS00ZTE0LWExMmYtNGNiNDIyYWU4Y2U4IiwiYWNyIjoiMSIsImFsbG93ZWQtb3JpZ2lucyI6WyJodHRwOi8vMTcyLjE2LjIzMS4xMzo4MDgwIl0sInJlYWxtX2FjY2VzcyI6eyJyb2xlcyI6WyJvZmZsaW5lX2FjY2VzcyIsInVtYV9hdXRob3JpemF0aW9uIiwiYXBpdXNlciIsImRlZmF1bHQtcm9sZXMtYXBpbWFuIl19LCJyZXNvdXJjZV9hY2Nlc3MiOnsiYWNjb3VudCI6eyJyb2xlcyI6WyJtYW5hZ2UtYWNjb3VudCIsIm1hbmFnZS1hY2NvdW50LWxpbmtzIiwidmlldy1wcm9maWxlIl19fSwic2NvcGUiOiJwcm9maWxlIGVtYWlsIiwic2lkIjoiOGVhYmIyZDctZjZhOS00ZTE0LWExMmYtNGNiNDIyYWU4Y2U4IiwiZW1haWxfdmVyaWZpZWQiOmZhbHNlLCJuYW1lIjoiYXRoYXJ2YSIsInByaW1hcnlfZW1haWwiOiJhdGhhcnZhLnBha2FkZSt0aG9yQGUyZW5ldHdvcmtzLmNvbSIsImlzX3ByaW1hcnlfY29udGFjdCI6dHJ1ZSwicHJlZmVycmVkX3VzZXJuYW1lIjoiYXRoYXJ2YS5wYWthZGUrdGhvckBlMmVuZXR3b3Jrcy5jb20iLCJnaXZlbl9uYW1lIjoiYXRoYXJ2YSIsImZhbWlseV9uYW1lIjoiIiwiZW1haWwiOiJhdGhhcnZhLnBha2FkZSt0aG9yQGUyZW5ldHdvcmtzLmNvbSJ9.PDrBcfnN1HGbuehaZY-YTi15QGYK-3AOkSlGTevbA1Ss0vU5JQ2vNpFiwCmdHl5OSn5nrlvydejhc8veUgFQvK7QZhEKgcsvghEeCvC8Zq7Hx-bJM-s7HJR-BxNIaHtKaOsynynXuFJo9RkDfcB3SdbDe92rpUvRR9IHl29o_CQ"
GENAI_PVC_MOUNT_PATH = "/mnt/data"
CUSTOM_TOKEN_PRIVATE_KEY = b'-----BEGIN RSA PRIVATE KEY-----\nMIIEogIBAAKCAQEAujbvUNMrcGNiRJx9hFISk1tZ5OFyWuSfRd4sVT6azyLnoqKY\nhFg97jl+ync8d5cAPoUjMDDJ9hVkPe1WMhTIuohSE2ISWgTABAhI6Sd22UDdsTdU\nXP1Kn9sF1rJ3fXt1lQaK4Hlldn7b3Nr7V0Xg9wzxAFUTtWzDlJDIWMUCBmz3qq/s\nk+g+k7ZgrxD6nXWW2LAKAPt9/3aisKd1G+S0Iqu+3hplqtzVXKrvS1FQMwWJOwi9\n1h+64wrrztyocNKczwDx2aA70iw02Uu0xsDbcvAiVVXppDDV8PaQIbdpb4uIBA7G\nF2s/1CPUYlJ4k5QkeytdIwqXqLzz56kXINOUiwIDAQABAoIBABD4dLL0VnR1pOev\n2K3jH5eXrwecQY8QYDDpNeJxmYDgeM+/lbq/TVWVSSgr2bI5wWdGkZW7ZzcqwpSf\njp1zJh//Jcu9F627L8IDp0a9tqfHW5eM/VPu2YrcARo3RYswDIqPqr8ZESrNa5LN\nz4jSm3/9s/EIeoqsO4l3RcBL+V/wYi/u3FYVbHlZV0hskZx+mtRYdKAC0x/wbA8m\nYoXEs6UUujdoPRuegGsPMTPKF76DqKnz3G7PY7xCR5x7dAyvjt2ZCaHLnyCL2qCn\n+eJBtFAVarkm9WGvRytDXLREz5NYSVfkWDG7iMLRWpSgwQzuryyWQgwecyWgGA8G\nRnMO4nECgYEA+hUTp1zcjC60gSqDGJ80h3/ddiwS4u/wL2cQcSTf+WPSUAZKUdtR\nPUeOiYmMyDVYJGPvmeVYjHM6NujA4ZGKavSMASD4Z4Fy6hWSrEkB1/V1b0LCnTLc\nNdDDOu7QzAFkAAK65FK5YZvG16qGUFPGqI/+VjNgeB2TEpG47aofxRUCgYEAvp73\ncMA20hRKvWjmfbyF9CkMQbAvbA0do4Lc7ExuxDaIT6mPP4HlblqQXuKv8utxmAi1\ntniSfrfLSHRACzd658RYHOtLEK+xPafO3p6RRRP2/jpdaZ5OrIhVDWDIrOk7MI8o\nKLc/byKy4TON2Yoi+YkL4cXlTdwelAWhD7fLmx8CgYAlC3I53HufGFwMtittPkgd\nukcn9idmDnzZyL6axAeZfbvttsDTl1VVaoAmx4VfMue3nEYl2d9gDsGU2K2ZvGFw\nroD+uc+SJY7MNh3f/4CSaP3YWV9SwfH01tPUqwOq9JnHlp/wqoBjgRvXXp8+zuoi\nlhHq2vlzUY4ztfpa2lSScQKBgHnhyvUc8fCBaQiS+k2LLVtgo6WcsbW07S6PjhLJ\nDEoJVD8be6xvsfNNlOIWr8nzIT7E0utJTOIZQrGhIxII910Z/fz/tY+Fxx5VHcDa\nQqiYi2UijHfr8QIAaeGT8LwepOn3nwXppXW6CgZUoG5oFNTY++/wSR3vkN20e7dB\nHb6hAoGAcHslpIUA7vNqCVOtW5orFmu5RyVLRzC/Pbg1pVvhjLcxfJRRxTcDuB2k\nSCAO0aECkx76ru+b1YTaEhkm7hBsukm1Gur1ZzVPXLMjO1xbNPZgNVIzxgizJVAx\nf4EPe8nfWr7lGahGKC05Bli2QGAPYTSCcNHagXNK+ZuKe0suX/8=\n-----END RSA PRIVATE KEY-----\n'
CUSTOM_TOKEN_PUBLIC_KEY = b'-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAujbvUNMrcGNiRJx9hFIS\nk1tZ5OFyWuSfRd4sVT6azyLnoqKYhFg97jl+ync8d5cAPoUjMDDJ9hVkPe1WMhTI\nuohSE2ISWgTABAhI6Sd22UDdsTdUXP1Kn9sF1rJ3fXt1lQaK4Hlldn7b3Nr7V0Xg\n9wzxAFUTtWzDlJDIWMUCBmz3qq/sk+g+k7ZgrxD6nXWW2LAKAPt9/3aisKd1G+S0\nIqu+3hplqtzVXKrvS1FQMwWJOwi91h+64wrrztyocNKczwDx2aA70iw02Uu0xsDb\ncvAiVVXppDDV8PaQIbdpb4uIBA7GF2s/1CPUYlJ4k5QkeytdIwqXqLzz56kXINOU\niwIDAQAB\n-----END PUBLIC KEY-----\n'
POWERDNS_CREDENTIALS = {
    "BASE_URL": "http://thor-dns.e2enetworks.net/api/v1/",
    "API_KEY": "quovantise2e123",
    "DOMAIN_TTL": 86400,
    "RECORD_TTL": 14400,
    "PTR_TTL": 86400
}
DNS_NAMESERVERS = ['integration-dns.e2enetworks.net.']

VECTOR_DB_DNS_RECORD_NAME = '{}-vdb-thor.e2enetworks.net'
ISTIO_INGRESSGATEWAY_IP = '216.48.188.198'

URL_FOR_QDRANT_SNAPSHOT_ENDPOINT = "https://43.252.90.208"
QDRANT_MINIO_ENDPOINT = "objectstore.e2enetworks.net"
QDRANT_MINIO_ACCESS_KEY = "MN5L20QP1G91R6GEY7KG"
QDRANT_MINIO_SECRET_KEY = "TZR7PIB46T7V9MZB2NR329U6LYF5OVE1PLHCB351"
QDRANT_MINIO_BUCKET_NAME = "testbucket123"

AWS_S3_DEFINITION_ID = "2e04ce94-3ecf-4b1e-9335-4b71cfae65f6"
MINIO_DEFINITION_ID = "b9f635b9-1c19-458e-bfff-12f174dee6b9"
GCS_DEFINITION_ID = "b7eba835-b640-4fbb-a4d9-785c1e4d46dd"
GOOGLE_DRIVE_STORAGE_DEFINITION_ID = "62a612af-1951-4ca4-bb03-618ba55ac553"
AZURE_BLOB_STORAGE_DEFINITION_ID = "a5dec6dc-f539-4b54-808d-3466301065ce"

AIRBYTE_DESTINATION_DEFINITION_ID = "f2d4b0aa-362b-480d-8c71-38a473d53fee"
AIRBYTE_BASE_URL = "http://216.48.188.79/"
AIRBYTE_USERNAME = "ayush"
AIRBYTE_PASSWORD = "ayush"
AIRBYTE_WORKSPACE_ID = "9b9c0004-05e0-4dfd-acb6-582bd59d415d"
AIRBYTE_WEBHOOK_PAYLOAD_TOKEN = "vl-Ru_QOZaiV7_M7WGgk-sw6-YHT"

SOURCE_CATALOG_ID_MINIO = "ad0624cf-8b60-4f9b-87a8-4305a9a81934"
SOURCE_CATALOG_ID_S3 = "c7ae3c92-1d5b-487b-abfa-4fbc498ecc49"
SOURCE_CATALOG_ID_GCS = "46f7d73c-18b8-4dd1-8d21-9c816dbf350b"
SOURCE_CATALOG_ID_GOOGLE_DRIVE_STORAGE = "f960fe8e-de53-4853-963a-40ec57c3e76f"
SOURCE_CATALOG_ID_AZURE_BLOB_STORAGE = "05370589-36b3-4ca5-a713-e2d46cef4668"
