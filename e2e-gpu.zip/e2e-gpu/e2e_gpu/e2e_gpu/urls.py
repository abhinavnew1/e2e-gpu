"""
 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path

from authtoken.api.v1 import urls as token_urls
from billing.api.v1 import urls as billing_urls
from container_registry.api.v1 import urls as container_registry_urls
from customer.api.v1 import urls as customer_urls
from dataset.api.v1 import urls as dataset_urls
from data_syncer.api.v1 import urls as data_syncer_urls
from data_syncer.api.v1.views import ConnectionSyncStatusWebhookView
from deprovision.api.v1 import urls as de_provision_url
from distributed_jobs.api.v1 import urls as distributed_jobs_urls
from eos.api.v1 import urls as eos_urls
from eventlogs.api.v1 import urls as audit_log_service
from finetuning.api.v1 import urls as fine_tuning_urls
from gpu_service.api.v1 import urls as gpu_service_urls
from inferenceservice.api.v1 import urls as inference_urls
from integration.api.v1 import urls as integration_urls
from invites.api.v1 import urls as invites_urls
from model_playground.api.v1 import urls as model_playground_urls
from notebook.api.v1 import urls as notebook_urls
from notebook.api.v1.views import PreviewNotebookView
from pipelines.api.v1 import urls as pipeline_urls
from projects.api.v1 import urls as projects_urls
from rbac.api.v1 import urls as iams_urls
from ssh_keys.api.v1 import urls as ssh_keys_urls
from teams.api.v1 import urls as teams_urls
from user_policies.api.v1 import urls as policies_urls
from vector_db.api.v1 import urls as vector_db_urls
from vector_db.api.v1.views import SnapshotUpdateStatusHookView


urlpatterns = [
    path("admin/insights/", include("explorer.urls")),
    path("admin/", admin.site.urls),
    path("api/v1/gpu/audit-logs/", include(audit_log_service, namespace="audit_log_service")),
    path("api/v1/gpu/billing/", include(billing_urls, namespace="billing")),
    path("api/v1/gpu/customer/", include(customer_urls, namespace="customer")),
    path("api/v1/gpu/gpu_service/", include(gpu_service_urls, namespace="gpu_service")),
    path("api/v1/gpu/users/", include(iams_urls, namespace="user_iams_urls")),
    path("api/v1/gpu/users/invites/", include(invites_urls, namespace="user_invites")),
    path("api/v1/gpu/de-provision/", include(de_provision_url, namespace="de-provision")),
    path("api/v1/gpu/ssh_keys/", include(ssh_keys_urls, namespace="ssh_keys")),
    path("api/v1/gpu/teams/<int:team_id>/projects/<int:project_id>/notebooks/", include(notebook_urls, namespace="notebook")),
    path("api/v1/gpu/teams/<int:team_id>/projects/<int:project_id>/datasets/", include(dataset_urls, namespace="dataset")),
    path("api/v1/gpu/teams/<int:team_id>/projects/<int:project_id>/model/", include(inference_urls, namespace="model")),
    path("api/v1/gpu/teams/<int:team_id>/projects/<int:project_id>/serving/", include(inference_urls, namespace="model_serving")),
    path("api/v1/gpu/teams/<int:team_id>/projects/<int:project_id>/integrations/", include(integration_urls, namespace="integration")),
    path("api/v1/gpu/teams/<int:team_id>/projects/<int:project_id>/eos/", include(eos_urls, namespace="eos")),
    path("api/v1/gpu/teams/<int:team_id>/projects/<int:project_id>/model_playground/", include(model_playground_urls, namespace="model_playground")),
    path("api/v1/gpu/teams/<int:team_id>/projects/<int:project_id>/container_registry/", include(container_registry_urls, namespace="container_registry")),
    path('api/v1/gpu/teams/<int:team_id>/projects/<int:project_id>/vector_db/', include(vector_db_urls, namespace="vector_db")),
    path('api/v1/gpu/teams/<int:team_id>/projects/<int:project_id>/distributed_jobs/', include(distributed_jobs_urls, namespace='distributed_jobs')),
    path("api/v1/gpu/teams/<int:team_id>/projects/<int:project_id>/auth-token/", include(token_urls, namespace="auth-token")),
    path("api/v1/gpu/teams/<int:team_id>/projects/<int:project_id>/users/policies/", include(policies_urls, namespace="user_policies")),
    path("api/v1/gpu/teams/<int:team_id>/projects/", include(projects_urls, namespace="projects")),
    path("api/v1/gpu/teams/", include(teams_urls, namespace="teams")),
    path("api/v1/gpu/teams/<int:team_id>/projects/<int:project_id>/data_syncer/", include(data_syncer_urls, namespace="data_syncer")),
    # with only project
    path("api/v1/gpu/projects/<int:project_id>/pipelines/", include(pipeline_urls, namespace="pipelines")),
    path("api/v1/gpu/projects/<int:project_id>/finetuning/", include(fine_tuning_urls)),
    # public apis
    path('publicapi/v1/gpu/vector_db/<int:vector_db_id>/snapshot/<int:snapshot_id>/update/status/hook/<operation>/', SnapshotUpdateStatusHookView.as_view(), name='snapshot-update-status'),
    path("publicapi/v1/gpu/notebooks/preview/", PreviewNotebookView.as_view(), name="notebook-preview"),
    path("publicapi/v1/gpu/data_syncer/airbyte-webhook/sync-status/", ConnectionSyncStatusWebhookView.as_view(), name="connection-state"),
]

urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
