from django.contrib import admin
from safedelete.admin import SafeDeleteAdmin

from eos.models import AccessKey, Bucket


class AccessKeyAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "deleted_at",
        "id",
        "is_managed",
        "tag",
    )
    raw_id_fields = ()
    search_fields = ("id", "tag",)
    list_filter = ("is_managed", "deleted_at", "deleted",)
    list_display_links = ("id",)
    readonly_fields = ()


class BucketAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "deleted_at",
        "id",
        "bucket_name",
        "is_managed",
        "bucket_url",
        "endpoint",
        "eos_bucket_permission_id",
    )
    raw_id_fields = ()
    search_fields = ("id", "bucket_name", "endpoint",)
    list_filter = ("is_managed", "endpoint", "deleted_at", "deleted",)
    list_display_links = ("id", "bucket_name",)
    readonly_fields = ()


admin.site.register(AccessKey, AccessKeyAdmin)
admin.site.register(Bucket, BucketAdmin)
