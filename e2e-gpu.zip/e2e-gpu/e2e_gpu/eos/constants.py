from django.conf import settings

# MyAccount EOS URLs
BASE_URL = settings.EOS_BASE_URL
# bucket
CREATE_BUCKET_URL = BASE_URL + "/storage/buckets/{bucket_name}/?location={location}"
LIST_BUCKETS_URL = BASE_URL + "/storage/bucket-list/?location={location}"
BUCKET_DETAILS_URL = BASE_URL + "/storage/buckets/{bucket_name}/?location={location}"
EMPTY_BUCKET_URL = BASE_URL + "/storage/buckets/{bucket_name}/?location={location}"
DELETE_BUCKET_URL = BASE_URL + "/storage/buckets/{bucket_name}/?location={location}"
ENABLE_VERSIONING_URL = BASE_URL + "/storage/bucket_versioning/{bucket_name}/?location={location}"
DISABLE_VERSIONING_URL = BASE_URL + "/storage/bucket_versioning/{bucket_name}/?location={location}"
# objects url
OBJECT_UPLOAD_DOWNLOAD_URL = BASE_URL + "/storage/urls/object/?bucket_name={bucket_name}&object_name={object_name}&method={method}&location={location}"
LIST_OBJECTS_URL = BASE_URL + "/storage/list/objects?bucket_name={bucket_name}&prefix={prefix}&page=&location={location}"
DELETE_OBJECT_URL = BASE_URL + "/storage/objects/?bucket_name={bucket_name}&object_ids={object_name}&location={location}"
# access key
CREATE_ACCESS_KEY_URL = BASE_URL + "/storage/core/users/?location={location}"
LIST_ACCESS_KEYS_URL = BASE_URL + "/storage/core/list/users/?location={location}"
DELETE_ACCESS_KEY_URL = BASE_URL + "/storage/core/users/?access_key={access_key_value}&location={location}"
# permissions
ATTACH_PERMISSIONS_URL = BASE_URL + "/storage/bucket_perms/?bucket_name={bucket_name}&location={location}"
DELETE_PERMISSIONS_URL = BASE_URL + "/storage/bucket_perm/{bucket_permission_id}/?bucket_name={bucket_name}&location={location}"
# end

EOS_BUCKET_URL = "s3://{bucket_name}/"

BUCKET_ADMIN = "Bucket Admin"
BUCKET_WRITER = "Bucket Writer"
BUCKET_READER = "Bucket Reader"
ACCESS_ROLE_CHOICES = (
    (BUCKET_ADMIN, BUCKET_ADMIN),
    (BUCKET_WRITER, BUCKET_WRITER),
    (BUCKET_READER, BUCKET_READER),
)

# Objects upload/download
OBJECT_UPLOAD_ACTION = "upload"
OBJECT_DOWNLOAD_ACTION = "download"
OBJECT_ACTION_METHOD_MAPPING = {
    OBJECT_UPLOAD_ACTION: "PUT",
    OBJECT_DOWNLOAD_ACTION: "GET",
}

# Vault path
ACCESS_KEY_PATH = "secret/gpu_notebook/access-key-{access_key_obj_id}"
SECRET_KEY_PATH = "secret/gpu_notebook/secret-key-{access_key_obj_id}"

# Support ticket message
DATASET_EOS_SUPPORT_MESSAGE = "Failed to delete Dataset EOS resources on Project Deletion for customer: {email_id}"
DATASET_EOS_CLEANUP_MESSAGE = "Failed to delete EOS resources for dataset: {dataset_id} on deletion of\
      project: {project_id}.\nerrors: {errors}"

FAILED_TO_DELETE_BUCKET = "Failed to delete bucket for customer: {email_id}"
FAILED_TO_DELETE_ACCESS_KEY = "Failed to delete access key for customer: {email_id}"
FAILED_TO_DETACH_ACCESS_KEY_MESSAGE = "Failed to detach access key from bucket: {bucket_name}\
    with permission id: {permission_id} and access key: {access_key} with tag: {access_tag}. \n errors: {errors}"
FAILED_TO_DELETE_BUCKET_MESSAGE = "Failed to delete bucket: {bucket_name}.\n errors: {errors}"
FAILED_TO_DELETE_ACCESS_KEY_MESSAGE = "Failed to delete access key: {access_key}.\n errors: {errors}"
FAILED_TO_EMPTY_BUCKET_MESSAGE = "Failed to empty EOS Bucket: {bucket_name} with permission id: {permission_id}.\
    errors: {errors}"
FAILED_TO_EMPTY_BUCKET_SUBJECT = "Failed to empty EOS Bucket for customer {email_id}"
FAILED_TO_DELETE_PERMISSIONS_MESSAGE = "Failed to Delete EOS Bucket permissions for bucket: {bucket_name}\
      and permissions id: {permission_id}.\n errors: {errors}"
FAILED_TO_DELETE_PERMISSIONS_SUBJECT = "Failed to Delete EOS Bucket for customer: {email_id}"

# celery task
DELETE_OBJECT_STORAGE_FOR_DATASET_TASK = "delete_object_storage_for_dataset_task"
COUNTDOWN_FOR_MODEL_OBJECT_STORAGE_DELETION = 5
INVALID_PATH = "Invalid Path"
FAILURE_FROM_EOS = "SOMETHING WENT WRONG IN EOS"
ACCESS_KEY_IS_MANDATORY = "Access Key is Missing"
SECRET_KEY_IS_MANDATORY = "Secret Key is Missing"
BUCKET_NAME_IS_MANDATORY = "Bucket Name is Missing"
EOS_BUCKET_ADMIN_PERMISSION_ID = 1
ACCESS_KEY_DELETION_ERROR = "Error in Access Key Deletion"
BUCKET_DELETION_ERROR = "Error in Bucket Deletion"
DELETED_SUCCESSFULLY = "Deleted Successfully"
ACCESS_KEY_NOT_FOUND = "AccessKey not Found"
BUCKET_NOT_FOUND = "Bucket Not Found"
