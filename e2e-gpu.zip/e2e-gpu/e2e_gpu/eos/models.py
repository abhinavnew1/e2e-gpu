from datetime import datetime

from django.conf import settings
from django.db import models
from django.db.models import Q

from e2e_core.api.v1.services.vault import VaultService
from e2e_core.jsonfield import JSONField
from e2e_core.mixins import BaseMixin, SafeDeleteMixinExtended
from eos.constants import ACCESS_KEY_PATH, SECRET_KEY_PATH


class AccessKey(SafeDeleteMixinExtended, BaseMixin):
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    tag = models.CharField(max_length=128, default=None, null=True, blank=True)
    is_managed = models.BooleanField()
    details = JSONField(default=None, null=True, blank=True)
    # access_role = models.CharField(choices=ACCESS_ROLE_CHOICES, max_length=64)#TODO: save the default role or not ??

    def __str__(self):
        return f"<AccessKey({self.id}: {self.tag})>"

    @property
    def access_key(self):
        """get access_key_from_vault"""
        access_key_path = ACCESS_KEY_PATH.format(access_key_obj_id=self.id)
        access_key = VaultService().get_secret(access_key_path)
        if access_key["errors"]:
            raise access_key["errors"]#TODO _vault check: raise errors ?
        return access_key["data"]["value"]

    @property
    def secret_key(self):
        """get secret_key_from_vault"""
        secret_key_path = SECRET_KEY_PATH.format(access_key_obj_id=self.id)
        secret_key = VaultService().get_secret(secret_key_path)
        if secret_key["errors"]:
            raise secret_key["errors"]
        return secret_key["data"]["value"]

    def store_access_key_in_vault(self, access_key):
        VaultService().create_secret(
            ACCESS_KEY_PATH.format(access_key_obj_id=self.id),
            access_key
        )

    def store_secret_key_in_vault(self, secret_key):
        VaultService().create_secret(
            SECRET_KEY_PATH.format(access_key_obj_id=self.id),
            secret_key
        )

    def mark_deleted(self):
        if self.deleted_at is None:
            self.deleted_at = datetime.now()
            self.save(update_fields=['deleted_at', 'updated_at',])


class Bucket(SafeDeleteMixinExtended, BaseMixin):
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    bucket_name = models.CharField(max_length=256)
    bucket_url = models.CharField(max_length=300)  # URLField doesn't consider s3://bucket_name/ as valid url
    endpoint = models.URLField(default=settings.EOS_MINIO_ENDPOINT[settings.DEFAULT_LOCATION])
    is_managed = models.BooleanField()
    details = JSONField(default=None, null=True, blank=True)
    eos_bucket_permission_id = models.IntegerField()

    def __str__(self):
        return f"<Bucket({self.id}: {self.bucket_name})>"

    def mark_deleted(self):
        if self.deleted_at is None:
            self.deleted_at = datetime.now()
            self.save(update_fields=['deleted_at', 'updated_at',])

    def can_delete_bucket(self):
        """func to cehck whether we can delete the bucket from eos"""
        if not self.is_managed:
            return False
        is_bucket_attached_to_other_resources = Bucket.objects.filter(
                                                    Q(dataset__deleted_at__isnull=True) |
                                                    Q(model__deleted_at__isnull=True),
                                                    deleted_at__isnull=True,
                                                    bucket_name=self.bucket_name,
                                                ).distinct().exclude(id=self.id).exists()
        return not is_bucket_attached_to_other_resources
