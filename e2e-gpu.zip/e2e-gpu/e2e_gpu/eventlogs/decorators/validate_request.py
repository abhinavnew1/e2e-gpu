from rest_framework.response import Response

from e2e_core.datetime_helper import date_filter_validator


def validate_date_filter(func):
    def wrapper_func(*args, **kwargs):
        query_params = args[2]
        status, err = date_filter_validator(**query_params)
        if not status:
            response = args[0].get_baked_400_response(err)
            return Response(response, status=response.get("code"))
        return func(*args, **kwargs)

    return wrapper_func
