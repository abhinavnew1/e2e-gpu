from django.db import models

from authtoken.models import ApiToken, CustomAPIToken
from customer.models import Customer, CustomerConsent
from dataset.models import Dataset
from data_syncer.models import Source, Destination, Connection
from distributed_jobs.models import Cluster, Job, SfsDetail
from e2e_core.jsonfield import JSONField
from e2e_core.mixins import BaseMixin, SafeDeleteMixinExtended
from eventlogs.constants import (EVENT_TYPE_CHOICES, EVENTLOG_DEFAULT_STATUS,
                                 EVENTLOG_STATUS_CHOICES,
                                 RESOURCE_NAME_MAX_LENGTH)
from finetuning.models import FineTuning
from inferenceservice.models import Inference, Model
from integration.models import Integration
from invites.models import Invites
from notebook.models import Notebook
from pipelines.models import (CommonTemplateRun, Experiments, Pipelines,
                              PipelineVersions, Runs, ScheduledJobs)
from projects.models import ProjectMembers, Projects
from rbac.models import IAM, IAMConsent
from teams.models import TeamMembers, Teams
from user_policies.models import UserPolicies
from vector_db.models import VectorDB, VectorDBSnapshots


class BaseEventLog(SafeDeleteMixinExtended, BaseMixin):
    service = models.CharField(max_length=50)
    resource_name = models.CharField(max_length=RESOURCE_NAME_MAX_LENGTH)
    resource_id = models.CharField(max_length=50)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    event = models.CharField(max_length=50)
    client_ip = models.CharField(max_length=20)
    detailed_info = JSONField(default={}, blank=True)
    status = models.CharField(max_length=50, choices=EVENTLOG_STATUS_CHOICES, default=EVENTLOG_DEFAULT_STATUS)
    event_type = models.CharField(max_length=10, choices=EVENT_TYPE_CHOICES)

    class Meta:
        abstract = True


class CustomerConsentEventLog(BaseEventLog):
    # PBAC_TODO: remove this table after pbac deployment
    resource_obj = models.ForeignKey(CustomerConsent, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class IAMConsentEventLog(BaseEventLog):
    resource_obj = models.ForeignKey(IAMConsent, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class InviteEventLog(BaseEventLog):
    resource_obj = models.ForeignKey(Invites, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class IAMEventLog(BaseEventLog):
    resource_obj = models.ForeignKey(IAM, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class TeamMemberEventLog(BaseEventLog):
    resource_obj = models.ForeignKey(TeamMembers, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class ProjectMemberEventLog(BaseEventLog):
    resource_obj = models.ForeignKey(ProjectMembers, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class UserPoliciesEventLog(BaseEventLog):
    resource_obj = models.ForeignKey(UserPolicies, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class ProjectEventLog(BaseEventLog):
    resource_obj = models.ForeignKey(Projects, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class NotebookEventLog(BaseEventLog):
    resource_obj = models.ForeignKey(Notebook, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class DatasetEventLog(BaseEventLog):
    resource_obj = models.ForeignKey(Dataset, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class MemberManagementEventLog(BaseEventLog):
    # PBAC_TODO: remove this table after pbac deployment
    resource_obj = models.ForeignKey(TeamMembers, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class TeamEventLog(BaseEventLog):
    resource_obj = models.ForeignKey(Teams, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class ModelEventLog(BaseEventLog):
    resource_obj = models.ForeignKey(Model, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class InferenceEventLog(BaseEventLog):
    resource_obj = models.ForeignKey(Inference, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class APITokenEventLog(BaseEventLog):
    resource_obj = models.ForeignKey(ApiToken, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class PipelinesAuditLogs(BaseEventLog):
    resource_obj = models.ForeignKey(Pipelines, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class PipelineVersionsAuditLogs(BaseEventLog):
    resource_obj = models.ForeignKey(PipelineVersions, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class ExperimentsAuditLogs(BaseEventLog):
    resource_obj = models.ForeignKey(Experiments, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class RunsAuditLogs(BaseEventLog):
    resource_obj = models.ForeignKey(Runs, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class ScheduledJobsAuditLogs(BaseEventLog):
    resource_obj = models.ForeignKey(ScheduledJobs, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class CommonTemplateRunsAuditLogs(BaseEventLog):
    resource_obj = models.ForeignKey(CommonTemplateRun, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class IntegrationEventLog(BaseEventLog):
    resource_obj = models.ForeignKey(Integration, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class FineTuningModelEventLog(BaseEventLog):
    resource_obj = models.ForeignKey(FineTuning, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class JobsModelEventLog(BaseEventLog):
    resource_obj = models.ForeignKey(Job, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class JobsSfsModelEventLog(BaseEventLog):
    resource_obj = models.ForeignKey(SfsDetail, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class JobsClusterModelEventLog(BaseEventLog):
    resource_obj = models.ForeignKey(Cluster, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class VectorDBEventLog(BaseEventLog):
    resource_obj = models.ForeignKey(VectorDB, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event
    

class VectorDBSnapshotEventLog(BaseEventLog):
    resource_obj = models.ForeignKey(VectorDBSnapshots, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class CustomAPITokenEventLog(BaseEventLog):
    resource_obj = models.ForeignKey(CustomAPIToken, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class DataSyncerSourceEventLog(BaseEventLog):
    resource_obj = models.ForeignKey(Source, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class DataSyncerDestinationEventlog(BaseEventLog):
    resource_obj = models.ForeignKey(Destination, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event


class DataSyncerConnectionEventLog(BaseEventLog):
    resource_obj = models.ForeignKey(Connection, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.customer.email + " " + self.service + " - " + self.event

