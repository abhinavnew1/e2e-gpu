from django.contrib import admin
from safedelete.admin import SafeDeleteAdmin

from finetuning.models import FineTuning, FineTuningModelTypes


class FineTuningModelTypesAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "name",
        "description",
        "supported_dataset",
        "deleted_at",
        "created_by",
        "created_at",
        "updated_at",
        "is_internal"
    )
    raw_id_fields = ("created_by",)
    search_fields = ("id", "created_by__email",)
    list_filter = (
        "deleted", "deleted_at", "created_by__email", "is_internal")
    list_display_links = ("id", "name")
    list_select_related = ("created_by", )


class FineTuningAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "deleted_at", 'id',
        'name', 'model_name', 'description', 'sku_item_price', "failure_reason",
        'project', 'status', 'created_by', 'created_at'
    )

    raw_id_fields = ("created_by", "project")
    search_fields = ("id", "name", "project__name", "created_by__email", "dataset")
    list_filter = (
        "deleted", "deleted_at", "status", "project", "project__name")
    list_display_links = ("id", "name")
    list_select_related = ("created_by", "project", "sku_item_price")


admin.site.register(FineTuningModelTypes, FineTuningModelTypesAdmin)
admin.site.register(FineTuning, FineTuningAdmin)
