from django.conf import settings
from e2e_core.constants import MAX_LENGTH_ERROR

LLAMA2 = "meta-llama/Llama-2-7b-hf"
MISTRAL_7B = "mistralai/Mistral-7B-v0.1"
MISTRAL_7B_INST = "mistralai/Mistral-7B-Instruct-v0.2"
FALCON_7B = "Falcon 7B"
STABLE_DIFFUSION_2_1 = "stabilityai/stable-diffusion-2-1"
MISTRAL_8X7B = "mistralai/Mixtral-8x7B-v0.1"
GEMMA_7B = "google/gemma-7b"
GEMMA_7B_INST = "google/gemma-7b-it"
LLAMA3_8B = "meta-llama/Meta-Llama-3-8B"
LLAMA3_8B_INST = "meta-llama/Meta-Llama-3-8B-Instruct"
STABLE_DIFFUSION_SDXL = "stabilityai/stable-diffusion-xl-base-1.0"

# YAML file paths
LLAMA2_FINETUNING_YAML_FILE = f"{settings.BASE_DIR}/finetuning/api/v1/yaml_files/llama2_fine_tuning.yaml"
MISTRAL_FINETUNING_YAML_FILE = f"{settings.BASE_DIR}/finetuning/api/v1/yaml_files/mistral_fine_tuning.yaml"
MISTRAL_INST_FINETUNING_YAML_FILE = f"{settings.BASE_DIR}/finetuning/api/v1/yaml_files/mistral_7b_inst_finetuning.yaml"
STABLE_DIFFUSION_FINETUNING_YAML_FILE = f"{settings.BASE_DIR}/finetuning/api/v1/yaml_files/stable_diffusion_2_1_fine_tuning.yaml"
MISTRAL_8X7B_FINETUNING_YAML_FILE = f"{settings.BASE_DIR}/finetuning/api/v1/yaml_files/mistral_8x7b_fine_tuning.yaml"
GEMMA_7B_FINETUNING_YAML_FILE = f"{settings.BASE_DIR}/finetuning/api/v1/yaml_files/gemma_7b_finetuning.yaml"
GEMMA_7B_INST_FINETUNING_YAML_FILE = f"{settings.BASE_DIR}/finetuning/api/v1/yaml_files/gemma_7b_inst_finetuning.yaml"
LLAMA3_FINETUNING_YAML_FILE = f"{settings.BASE_DIR}/finetuning/api/v1/yaml_files/llama3_8b_fine_tuning.yaml"
LLAMA3_INST_FINETUNING_YAML_FILE = f"{settings.BASE_DIR}/finetuning/api/v1/yaml_files/llama3_8b_inst_finetuning.yaml"
STABLE_DIFFUSION_SDXL_YAML_FILE = f"{settings.BASE_DIR}/finetuning/api/v1/yaml_files/stable_diffusion_sdxl_finetuning.yaml"

FINE_TUNING_MODEL_TYPES = (
   (LLAMA2, LLAMA2), (STABLE_DIFFUSION_2_1, STABLE_DIFFUSION_2_1),
   (MISTRAL_7B, MISTRAL_7B), (FALCON_7B, FALCON_7B),
   (MISTRAL_8X7B, MISTRAL_8X7B), (GEMMA_7B, GEMMA_7B),
   (LLAMA3_8B, LLAMA3_8B), (MISTRAL_7B_INST, MISTRAL_7B_INST),
   (GEMMA_7B_INST, GEMMA_7B_INST), (LLAMA3_8B_INST, LLAMA3_8B_INST),
   (STABLE_DIFFUSION_SDXL, STABLE_DIFFUSION_SDXL),
   )
FINE_TUNING_TEXT_MODELS_LIST = [
   LLAMA2, LLAMA3_8B, MISTRAL_7B,
   MISTRAL_8X7B, GEMMA_7B, MISTRAL_7B_INST,
   GEMMA_7B_INST, LLAMA3_8B_INST,
   ]
FINE_TUNING_IMAGE_MODELS_LIST = [
   STABLE_DIFFUSION_SDXL,
   STABLE_DIFFUSION_2_1,
   ]
MODEL_TYPE_MAX_LENGTH = 64
NAME_MAX_LENGTH = MODEL_TYPE_MAX_LENGTH
STORAGE_TYPE_MAXIMUM_LENGTH = MODEL_TYPE_MAX_LENGTH
STATUS_MAX_LENGTH = MODEL_TYPE_MAX_LENGTH
MANAGED_STORAGE = "managed"
E2E_OBJECT_STORAGE = "e2e_s3"
STORAGE_TYPE_CHOICES = (
   (MANAGED_STORAGE, MANAGED_STORAGE),
   (E2E_OBJECT_STORAGE, E2E_OBJECT_STORAGE)
)
PENDING = "Pending"
CREATING = "Creating"
READY = "Ready"
DELETED = "Done"
DELETING = "Deleting"
ERROR = "Error"
MODEL_STATUS_CHOICES = (
   (PENDING, PENDING),
   (CREATING, CREATING),
   (READY, READY),
   (DELETED, DELETED),
   (DELETING, DELETING),
   (ERROR, ERROR)
)
NAME_ALREADY_EXISTS = "Fine-tuning with the same name already exists in the Project"
TRAINING_INPUTS_ERROR = "training_inputs has error: {errors}"
NAME_MAX_LENGTH_ERROR = MAX_LENGTH_ERROR.format(field_name="FineTuning Name", max_length=NAME_MAX_LENGTH)
NAME_REGEX = r'[a-z0-9]([-a-z0-9]*[a-z0-9])?'
INVALID_NAME = "name should start and end with an alphanumeric character and can contain lowercase " \
                     "letters, digits and hyphen only."
FINE_TUNING = "finetuning"
FINE_TUNING_DOES_NOT_EXIST = "FineTuning Does Not Exist"
FINE_TUNING_CREATE_EVENT = "FINE_TUNING_CREATE"
FINE_TUNING_DELETE_EVENT = "FINE_TUNING_DELETE"
FINE_TUNING_ACTION_EVENT = "FINE_TUNING_{}_ACTION"
FINE_TUNING_DELETE_TASK = "finetuning_delete_task"
FINE_TUNING_CREATE_TASK = "finetuning_create_task"
FINE_TUNING_DELETE_TASK_ERROR = "Finetuning delete task error"

CUSTOM = "Custom"
LLAMA_DATASETS = [
   {
      "group":"Hugging Face",
      "name":"vicgalle/alpaca-gpt4"
   },
   {
      "group":"Hugging Face",
      "name":"mlabonne/guanaco-llama2-1k"
   },
   {
      "group":"Hugging Face",
      "name":"tatsu-lab/alpaca"
   }
]
LLAMA3_DATASETS = [
   {
      "group":"Hugging Face",
      "name":"mlabonne/guanaco-llama2-1k"
   },
   {
      "group":"Hugging Face",
      "name":"vicgalle/alpaca-gpt4"
   },
   {
      "group":"Hugging Face",
      "name":"tatsu-lab/alpaca"
   }
]
MISTRAL_7B_DATASETS = [
   {
      "group":"Hugging Face",
      "name":"vicgalle/alpaca-gpt4"
   },
   {
      "group":"Hugging Face",
      "name":"mlabonne/guanaco-llama2-1k"
   },
   {
      "group":"Hugging Face",
      "name":"tatsu-lab/alpaca"
   }
]
MISTRAL_8X7B_DATASETS = [
   {
      "group":"Hugging Face",
      "name":"vicgalle/alpaca-gpt4"
   },
   {
      "group":"Hugging Face",
      "name":"mlabonne/guanaco-llama2-1k"
   },
   {
      "group":"Hugging Face",
      "name":"tatsu-lab/alpaca"
   }
]
GEMMA_7B_DATASETS = [
   {
      "group":"Hugging Face",
      "name":"vicgalle/alpaca-gpt4"
   },
   {
      "group":"Hugging Face",
      "name":"mlabonne/guanaco-llama2-1k"
   },
   {
      "group":"Hugging Face",
      "name":"tatsu-lab/alpaca"
   }
]

WANDB_SERIALIZATION_ERROR = "Either provide both wandb_integration_id and wandb_integration_run_name, or leave them " \
                            "both"
MAX_INTEGER_LENGTH = 20000000

HUGGING_FACE = "huggingface"
EOS_BUCKET = "eos-bucket"
DATASET_TYPES = (
    (HUGGING_FACE, HUGGING_FACE),
    (EOS_BUCKET, EOS_BUCKET)
)

NO_SAVE = 'no'
EPOCH = 'epoch'
STEPS = 'steps'
SAVE_STRATEGY_TYPES = (
    (NO_SAVE, NO_SAVE),
    (EPOCH, EPOCH),
    (STEPS, STEPS),
)
DEFAULT_SAVE_STEPS = 500
DEFAULT_SAVE_LIMIT = 10

DATASET_NAME = "dataset_name"
HUGGING_FACE_DATASET_NAME = "hugging_face_dataset_name"
OTHER_HUGGING_FACE = "Other_Hugging_Face"
DEFAULT_GRADIENT_ACCUMULATION_STEPS = 1
DEFAULT_BATCH_SIZE = 4
MAX_TRAINING_EVAL_RECORDS_COUNT_DEFAULT = -1

# text model finetuning const/msg
PROMPT_TEMPLATE_ERROR = "prompt template error : can't have target_field as well as prompt template"
PROMPT_TEMPLATE_MAX_LENGTH = 1000
DEFAULT_IMAGE_COLUMN = 'image'
DEFAULT_TEXT_COLUMN = 'text'
DEFAULT_STABLE_DIFFUSION_TRAIN_DIRECTORY = "/mnt/workspace/custom_dataset/"
REGEX_PROMPT_CONFIG_STABLE_DIFFUSION = r'\[([^]]+)\]'
DEFAULT_CHECKPOINTING_STEPS = 500
DEFAULT_CHECKPOINTS_TOTAL_LIMIT = 10

# lora configuration constants
LORA_DROPOUT_DEFAULT = 0.05
LORA_DROPOUT_LIMIT = 'Lora dropout must be between 0.0 and 1.0'
BIAS_DEFAULT = 'none'
NONE = 'none'
ALL = 'all'
LORA_ONLY = 'lora_only'
BIAS_TYPES = (
   (NONE, NONE),
   (ALL, ALL),
   (LORA_ONLY, LORA_ONLY)
)
BOOLEAN_CHOICES = (
   (True, 'True'),
   (False, 'False'),
)

# quantization configuration constants
FLOAT32 = 'float32'
FLOAT16 = 'float16'
BFLOAT16 = 'bfloat16'
COMPUTE_DTYPE_TYPES = (
   (BFLOAT16, BFLOAT16),
   (FLOAT32, FLOAT32),
   (FLOAT16, FLOAT16)
)
COMPUTE_DTYPE_DEFAULT = BFLOAT16
FP4 = 'fp4'
NF4 = 'nf4'
QUANT_TYPE_CHOICES = (
   (FP4, FP4),
   (NF4, NF4)
)
QUANT_DEFAULT = FP4

# training metric
TRAINING_METRIC_FILE = 'tensorboard_logs/all_finetuning_metric.json'
METRIC_NOT_AVAILABLE_YET = 'Training_metric not available yet, Please wait!!'
METRIC_NOT_FOUND = 'Training_metric not available!! Cause: either repo was modified or failed export'
ALLOWED_TRAINING_METRIC_LIST = ["train/loss", "train/grad_norm", "train/learning_rate", "train/epoch"]
ALLOWED_TRAINING_METRIC_DESC = {"train/loss": 'This metric represents the loss value calculated on the training data during the training process',
                                "train/grad_norm": 'This metric indicates the norm of the gradients of the model parameters',
                                "train/learning_rate": 'This metric tracks the learning rate used by the optimizer at each training step',
                                "train/epoch": 'This metric represents the epoch number during training'}

# model files
CONFIG_FILE_NAME = 'config.json'
SAFETENSORS_FILE_NAME = '.safetensors'
TOKENIZER_FILE_NAME = 'tokenizer.json'
FILES_AVAILABLE = 'Files available'
MODEL_FILES_MISSING = 'Either of *config.json, .safetensors, tokenizer.json files are missing'
BASE_MODEL_FOLDER_NAME = 'base_model'
TENSORBOARD_LOGS_FOLDER_NAME = 'tensorboard_logs'
FOLDER_NOT_ALLOWED_FOR_FINETUNING = 'Given path not allowed for finetuning'
BASE_MODEL = 'base_model'
PREV_CHECKPOINT = 'prev_checkpoint'
SOURCE_REPOSITORY_TYPE = (
    (BASE_MODEL, BASE_MODEL),
    (PREV_CHECKPOINT, PREV_CHECKPOINT)
)

# For stable diffusion SDXL
DEFAULT_MAX_TRAIN_STEPS = -1
DEFAULT_CHECKPOINTING_TOTAL_LIMIT = 10
CHECKPOINTING_TOTAL_LIMIT_ERROR = 'Checkpointing total limit must be greater than 0'
DEFAULT_RESOLUTION = 1024
DEFAULT_R_RANK = 16
DEFAULT_APLHA_RANK = 32
BF16 = 'bf16'
FP16 = 'fp16'
NO = 'no'
DEFAULT_MIXED_PRECISION = NO
MIXED_PRECISION_CHOICES = (
   (NO, NO),
   (BF16, BF16),
   (FP16, FP16),
)
DEFAULT_VALIDATION_PROMPT = 'A photo of naruto with green eyes'
DEFAULT_NUM_VALIDATION_IMAGES = 2
LOGGING_STEPS_ERROR = 'Logging steps are used for training metrics and must be greater than 0'
DEFAULT_LOGGING_STEPS = 5
OPTIMIZER_FILE_NAME = "optimizer.bin"
SCHEDULER_FILE_NAME = "scheduler.bin"
YAML_FILE_PATH = 'text/yaml'
