import logging

from django.db.models import Q
from rest_framework.response import Response

from e2e_core.api.v1.services.base import BaseService
from e2e_core.constants import (INVALID_ACTION, NOT_FOUND_ERROR,
                                PARAMS_MISSING_OR_INVALID, UNAUTHORIZED_ACCESS)
from e2e_core.helpers import get_pk_or_name_from_value
from finetuning.models import FineTuning

logger = logging.getLogger(__name__)


def validate_finetuning_request(func):
    def wrapper_func(*args, **kwargs):
        fine_tuning_id, finetuning_name = get_pk_or_name_from_value(kwargs.get("fine_tuning_id", ""))
        project_id = kwargs.get("project_id")
        fine_tuning = FineTuning.objects.filter(Q(id=fine_tuning_id) | Q(name=finetuning_name), project_id=project_id, deleted_at__isnull=True).\
            select_related("sku_item_price", "wandb_integration", "huggingface_integration", "run", "dataset", "project").order_by("-created_at").last()
        if not fine_tuning:
            response = BaseService.get_404_response(NOT_FOUND_ERROR.format(service="fine_tuning"))
            return Response(response, status=response.get("code"))
        kwargs["fine_tuning"] = fine_tuning
        kwargs["fine_tuning_id"] = fine_tuning.id
        return func(*args, **kwargs)

    return wrapper_func
