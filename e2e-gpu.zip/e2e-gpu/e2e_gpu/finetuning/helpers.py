import json
import logging

from django.conf import settings
from rest_framework import serializers

from dataset.constants import PVC
from dataset.models import Dataset
from e2e_core.constants import NOT_FOUND_ERROR, PARAMS_MISSING_OR_INVALID
from eos.api.v1.services.minio_service import MinioService
from finetuning.constants import (
    BASE_MODEL, BASE_MODEL_FOLDER_NAME,
    CONFIG_FILE_NAME, EOS_BUCKET,
    FILES_AVAILABLE,
    FOLDER_NOT_ALLOWED_FOR_FINETUNING,
    HUGGING_FACE, MODEL_FILES_MISSING,
    PREV_CHECKPOINT, SAFETENSORS_FILE_NAME,
    TENSORBOARD_LOGS_FOLDER_NAME,
    TOKENIZER_FILE_NAME,
    FINE_TUNING_TEXT_MODELS_LIST,
    FINE_TUNING_IMAGE_MODELS_LIST,
    SCHEDULER_FILE_NAME,
    OPTIMIZER_FILE_NAME,
)
from inferenceservice.models import Model
from integration.constants import HUGGING_FACE_INTEGRATION, WEIGHTS_BIASES
from integration.models import Integration

logger = logging.getLogger(__name__)
INVALID_INFO = 'Invalid value/info given : {}'


class FineTuningValidator:

    @classmethod
    def validate_dataset_info(cls, serializer_instance, data):
        dataset_type = data.get('training_inputs', {}).get('dataset_type')
        if dataset_type == EOS_BUCKET:
            try:
                dataset_info = data['training_inputs']['dataset']
                dataset_sub_str = dataset_info.split('/')
                object_name = dataset_info.replace(f"{dataset_sub_str[0]}/", '', 1)
                if len(dataset_sub_str) == 0 or not object_name:
                    raise serializers.ValidationError({'dataset': INVALID_INFO.format('path missing')})
                data['dataset_id'] = dataset_sub_str[0]
                data['training_inputs']['dataset_name'] = object_name
            except Exception as e:
                raise serializers.ValidationError({'dataset': INVALID_INFO.format(str(e))})
            if isinstance(data['dataset_id'], str):
                dataset = Dataset.objects.filter(
                    deleted_at__isnull=True,
                    name=data['dataset_id'],
                    project=serializer_instance.context.get("project"),
                    bucket__isnull=False,
                    access_key__isnull=False,
                    pvc__isnull=True).exclude(storage_type=PVC).last()
                if not dataset:
                    raise serializers.ValidationError({'dataset': INVALID_INFO.format('')})
                data['dataset_id'] = dataset.id
        if dataset_type == HUGGING_FACE:
            data['training_inputs']['dataset_name'] = data.get('training_inputs', {}).get('dataset')

    @classmethod
    def validate_source_model_repo_info(cls, serializer_instance, data):
        training_inputs = data.get('training_inputs', {})
        model_name = data.get('model_name')
        source_model_repo_info: str = training_inputs.get('source_model_repo_info')
        source_repository_type: str = training_inputs.get('source_repository_type')
        if source_repository_type not in [BASE_MODEL, PREV_CHECKPOINT]:
            raise serializers.ValidationError({'source_repository_type': PARAMS_MISSING_OR_INVALID.format(param='source_repository_type')})
        if source_repository_type == BASE_MODEL:
            data['training_inputs']['source_model_path'] = ''
            data['training_inputs']['source_model_repo_info'] = ''
            return
        model_repo_sub_str = source_model_repo_info.split('/')
        source_model_name = model_repo_sub_str[0]
        source_model_path = source_model_repo_info.replace(f"{source_model_name}/", '', 1)
        if len(model_repo_sub_str) <= 1 or not source_model_path:
            raise serializers.ValidationError({'source_model_name_info': INVALID_INFO.format('path missing')})
        if source_model_path.startswith(BASE_MODEL_FOLDER_NAME) or source_model_path.startswith(TENSORBOARD_LOGS_FOLDER_NAME):
            raise serializers.ValidationError({'source_model_name_info': INVALID_INFO.format(FOLDER_NOT_ALLOWED_FOR_FINETUNING)})
        model_repo = Model.objects.filter(
            deleted_at__isnull=True,
            name=source_model_name,
            project=serializer_instance.context.get("project")).last()
        if not model_repo or not model_repo.finetuning:
            raise serializers.ValidationError({'source_model_name_info': PARAMS_MISSING_OR_INVALID.format(param='model_repo')})
        if model_repo.finetuning.model_name != data['model_name']:
            raise serializers.ValidationError({'source_model_name_info': PARAMS_MISSING_OR_INVALID.format(param='model_repo architecture')})

        if model_name in FINE_TUNING_TEXT_MODELS_LIST:
            is_base_model_valid, msg = is_model_repo_valid_for_text_finetuning(model_repo, f"{BASE_MODEL_FOLDER_NAME}/")
            if not is_base_model_valid:
                raise serializers.ValidationError({'source_model_name_info': f"{BASE_MODEL_FOLDER_NAME} : {msg}"})
            is_checkpoint_valid, msg = is_model_repo_valid_for_text_finetuning(model_repo, source_model_path)
            if not is_checkpoint_valid:
                raise serializers.ValidationError({'source_model_name_info': f"{source_model_path} : {msg}"})

        elif model_name in FINE_TUNING_IMAGE_MODELS_LIST:
            is_checkpoint_valid, msg = is_model_repo_valid_for_image_finetuning(model_repo, source_model_path)
            if not is_checkpoint_valid:
                raise serializers.ValidationError({'source_model_name_info': f"{source_model_path} : {msg}"})

        data['source_model_repo_id'] = model_repo.id
        data['training_inputs']['source_model_path'] = source_model_path
        data['training_inputs']['source_repository_type'] = PREV_CHECKPOINT

    @classmethod
    def validate_huggingface_integration_info(cls, serializer_instance, data):
        '''used to extract huggingface_integration_id i.e pk of huggingface_integration from name for api flexiblity'''
        huggingface_integration_id = data.get("huggingface_integration_id")
        if isinstance(huggingface_integration_id, str):
            # here huggingface_integration_id refers to name of huggingface_integration
            hugging_face_integration = Integration.objects.filter(deleted_at__isnull=True,
                                                                  name=huggingface_integration_id,
                                                                  project=serializer_instance.context.get("project"),
                                                                  integration_type=HUGGING_FACE_INTEGRATION).last()
            if not hugging_face_integration:
                raise serializers.ValidationError({'hugging_face_integration': INVALID_INFO.format('')})
            data["huggingface_integration_id"] = hugging_face_integration.id

    @classmethod
    def validate_wandb_integration_info(cls, serializer_instance, data):
        '''used to extract wandb_integration_id i.e pk of wandb_integration from name for api flexiblity'''
        wandb_integration_id = data.get("wandb_integration_id")
        if isinstance(wandb_integration_id, str):
            # here wandb_integration_id refers to name of wandb_integration
            wandb_integration = Integration.objects.filter(deleted_at__isnull=True,
                                                           name=wandb_integration_id,
                                                           project=serializer_instance.context.get("project"),
                                                           integration_type=WEIGHTS_BIASES).last()
            if not wandb_integration:
                raise serializers.ValidationError({'wandb_integration': INVALID_INFO.format('')})
            data["wandb_integration_id"] = wandb_integration.id


def is_model_repo_valid_for_text_finetuning(model_repo: Model, path: str):
    minio_client = MinioService(model_repo.access_key.access_key, model_repo.access_key.secret_key, endpoint=settings.S3_ENDPOINT)
    is_success, response = minio_client.get_bucket_contents(model_repo.bucket.bucket_name, prefix=path)
    if not is_success:
        return is_success, response
    has_config = has_safetensors = has_tokenizer = False
    for file in response:
        if file.size is None:
            continue
        if file.object_name.endswith(CONFIG_FILE_NAME):
            has_config = True
        if file.object_name.endswith(SAFETENSORS_FILE_NAME):
            has_safetensors = True
        if file.object_name.endswith(TOKENIZER_FILE_NAME):
            has_tokenizer = True
    if has_config and has_safetensors and has_tokenizer:
        return True, FILES_AVAILABLE
    return False, MODEL_FILES_MISSING


def is_model_repo_valid_for_image_finetuning(model_repo: Model, path: str):
    minio_client = MinioService(model_repo.access_key.access_key, model_repo.access_key.secret_key, endpoint=settings.S3_ENDPOINT)
    is_success, response = minio_client.get_bucket_contents(model_repo.bucket.bucket_name, prefix=path)
    if not is_success:
        return is_success, response
    has_optimizer = has_safetensor = has_scheduler = False
    for file in response:
        if file.size is None:
            continue
        if file.object_name.endswith(OPTIMIZER_FILE_NAME):
            has_optimizer = True
        if file.object_name.endswith(SAFETENSORS_FILE_NAME):
            has_safetensor = True
        if file.object_name.endswith(SCHEDULER_FILE_NAME):
            has_scheduler = True
    if has_optimizer and has_safetensor and has_scheduler:
        return True, FILES_AVAILABLE
    return False, MODEL_FILES_MISSING
