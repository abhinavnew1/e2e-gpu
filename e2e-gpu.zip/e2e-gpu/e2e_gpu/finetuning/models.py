from datetime import datetime

from django.db import models

from customer.models import Customer
from dataset.models import Dataset
from e2e_core.helpers import mark_delete_related_objects
from e2e_core.mixins import BaseMixin, SafeDeleteMixinExtended
from finetuning.constants import (CREATING, DATASET_TYPES, DEFAULT_BATCH_SIZE,
                                  DEFAULT_GRADIENT_ACCUMULATION_STEPS, DELETED,
                                  DELETING, ERROR, FINE_TUNING_MODEL_TYPES,
                                  HUGGING_FACE,
                                  MAX_TRAINING_EVAL_RECORDS_COUNT_DEFAULT,
                                  MODEL_STATUS_CHOICES, MODEL_TYPE_MAX_LENGTH,
                                  NAME_MAX_LENGTH, STATUS_MAX_LENGTH,
                                  STORAGE_TYPE_CHOICES,
                                  STORAGE_TYPE_MAXIMUM_LENGTH)
from gpu_service.models import SkuItemPrice
from integration.models import Integration
from pipelines.models import Experiments, Pipelines, PipelineVersions, Runs
from projects.models import Projects


class FineTuningModelTypes(SafeDeleteMixinExtended, BaseMixin):
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    name = models.CharField(choices=FINE_TUNING_MODEL_TYPES, max_length=MODEL_TYPE_MAX_LENGTH)
    supported_dataset = models.JSONField(default=dict)
    description = models.TextField()
    created_by = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True)
    is_internal = models.BooleanField(default=False)
    model_icon_url = models.CharField(max_length=128, null=True, blank=True)
    is_displayed_on_dashboard = models.BooleanField(default=False, help_text="Boolean field for displaying models on dashboard")

    def mark_deleted(self):
        if self.deleted_at is None:
            mark_delete_related_objects(self)
            self.deleted_at = datetime.now()
            self.save(update_fields=['deleted_at', 'updated_at'])


class FineTuning(SafeDeleteMixinExtended, BaseMixin):
    # please don't add unnecessary keys/fields in this table, prioritise training_inputs if possible
    name = models.CharField(max_length=NAME_MAX_LENGTH)
    model_name = models.CharField(choices=FINE_TUNING_MODEL_TYPES, max_length=MODEL_TYPE_MAX_LENGTH)
    source_model_repo = models.ForeignKey("inferenceservice.Model", related_name="finetuning_source_model_repo", on_delete=models.DO_NOTHING, null=True, blank=True)

    # all models training arguments/inputs to be passed here as json, after validation from relevant serializer
    training_inputs = models.JSONField(default=dict)
    description = models.TextField(default=None, null=True, blank=True)
    training_type = models.CharField(max_length=MODEL_TYPE_MAX_LENGTH)

    # credentials
    huggingface_integration = models.ForeignKey(Integration, related_name="finetuning_huggingface_integration", on_delete=models.DO_NOTHING, null=True, blank=True)
    wandb_integration = models.ForeignKey(Integration, related_name="finetuning_wandb_integration", on_delete=models.DO_NOTHING, null=True, blank=True)
    wandb_integration_run_name = models.CharField(max_length=256, blank=True, null=True)

    # eos-dataset to use for finetuning
    dataset = models.ForeignKey(Dataset, related_name="mounted_on_finetuning", null=True, blank=True, on_delete=models.DO_NOTHING)

    # related pipeline and run for finetuning
    run = models.OneToOneField(Runs, null=True, blank=True, on_delete=models.DO_NOTHING)

    # foreign keys
    project = models.ForeignKey(Projects, on_delete=models.CASCADE)
    sku_item_price = models.ForeignKey(SkuItemPrice, on_delete=models.PROTECT)
    # Extra Information
    copy_from = models.ForeignKey('self', on_delete=models.DO_NOTHING, null=True)
    status = models.CharField(choices=MODEL_STATUS_CHOICES, max_length=STATUS_MAX_LENGTH, default=CREATING)
    failure_reason = models.TextField()
    created_by = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True)
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)

    class Meta:
        # Define unique-together constraint for sdk api calls
        unique_together = ['name', 'project']

    def __str__(self):
        return f"<FineTuning({self.id}: {self.name}: {self.model_name})>"

    @property
    def experiment(self):
        return self.run.experiment if self.run else None

    @property
    def pipeline_version(self):
        return self.run.pipeline_version if self.run else None

    @property
    def pipeline(self):
        return self.pipeline_version.pipeline if self.pipeline_version else None

    def mark_deleted(self):
        if self.deleted_at is None:
            mark_delete_related_objects(self)
            self.status = DELETED
            self.deleted_at = datetime.now()
            self.save(update_fields=['deleted_at', 'status', 'updated_at'])

    def mark_deleting(self):
        self.status = DELETING
        self.save(update_fields=['status', 'updated_at'])

    def mark_error(self, reason):
        self.status = ERROR
        self.failure_reason = reason
        self.save(update_fields=['status', 'failure_reason', 'updated_at'])
