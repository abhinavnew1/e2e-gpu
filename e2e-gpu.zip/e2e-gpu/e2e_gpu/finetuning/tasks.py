import logging

from rest_framework import status

from e2e_gpu.celery import app
from finetuning.api.v1.services.setup_pipeline_run import \
    SetupPipeLineRunService
from finetuning.constants import (FINE_TUNING, FINE_TUNING_CREATE_TASK,
                                  FINE_TUNING_DELETE_TASK, READY)

logger = logging.getLogger(__name__)


@app.task(
    name=FINE_TUNING_DELETE_TASK,
    bind=True,
)
def delete_finetuning_task(self, *args, **kwargs):
    fine_tuning = kwargs.get("fine_tuning")
    customer_auth_header = kwargs.get("customer_auth_header")
    customer = kwargs.get("customer")
    project = kwargs.get("project")
    SetupPipeLineRunService(customer=customer, project=project, auth_header=customer_auth_header). \
        delete_pipeline_experiment_run(fine_tuning)
    fine_tuning.mark_deleted()


@app.task(
    name=FINE_TUNING_CREATE_TASK,
    bind=True,
)
def create_finetuning_task(self, *args, **kwargs):
    try:
        fine_tuning = kwargs.get("fine_tuning")
        customer_auth_header = kwargs.get("customer_auth_header")
        customer = kwargs.get("customer")
        project = kwargs.get("project")
        response = SetupPipeLineRunService(customer=customer, project=project, auth_header=customer_auth_header). \
            setup_pipeline_experiment_run(fine_tuning.name,
                                          fine_tuning.description,
                                          fine_tuning)
        if response["code"] != status.HTTP_200_OK:
            return response
        fine_tuning.status = READY
        fine_tuning.save()
    except Exception as e:
        fine_tuning.mark_error(f"Finetuning Creation Task Error - {e}")
