from django.contrib import admin, messages
from safedelete.admin import SafeDeleteAdmin
from simple_history.admin import SimpleHistoryAdmin

from gpu_service.constants import (CPU_SERIES, GPU_SERIES,
                                   SKU_AVAILABILITY_ADMIN_INVALID_VALUE_ERROR,
                                   SKU_AVAILABILITY_ADMIN_NULL_VALUE_ERROR)
from gpu_service.models import (Currency, Image, ImageVersion,
                                SKUAvailability, SkuItemPrice,
                                StockKeepingUnit, TirServices, 
                                TirServicesDependency, K8sNode)


class ImageVersionInline(admin.TabularInline):
    model = ImageVersion
    extra = 0
    can_delete = False

    def has_add_permission(self, request, obj=None):
        return False


class ImageAdmin(SafeDeleteAdmin, SimpleHistoryAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "name",
        "image_type",
        "is_active",
        "image_pull_policy",
        "slug_name",
        "active_start_date",
        "active_end_date",
        "created_at",
        "updated_at",
    )
    raw_id_fields = ()
    search_fields = ("id", "name", "image_type",)
    list_filter = ("deleted", "image_type", "is_active", "image_pull_policy",)
    list_display_links = ("id", "name",)
    readonly_fields = ()
    inlines = [ImageVersionInline]


class ImageVersionAdmin(SafeDeleteAdmin, SimpleHistoryAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "image",
        "version",
        "is_active",
        "cpu_image_url",
        "gpu_image_url",
        "is_jupyterlab_enabled",
    )
    raw_id_fields = ("image",)
    search_fields = ("id", "image__name", "image__slug_name",)
    list_filter = ("deleted", "is_active", "image__is_active", "image", "is_jupyterlab_enabled")
    list_display_links = ("id", "image", "version",)
    list_select_related = ("image",)
    readonly_fields = ()


class SkuItemPriceInline(admin.TabularInline):
    model = SkuItemPrice
    extra = 0
    can_delete = False

    def has_add_permission(self, request, obj=None):
        return False


class StockKeepingUnitAdmin(SafeDeleteAdmin):
	list_display = SafeDeleteAdmin.list_display + (
		"id",
		"name",
		"category",
		"series",
		# "cpu",
		# "gpu",
		# "memory",
		"is_free",
		"is_active",
		"sku_type",
		"gpu_card_type",
		# "active_start_date",
		# "active_end_date",
		# "created_at",
		"local_storage",
	)
	raw_id_fields = ()
	search_fields = ("id", "name", "sku_type",)
	list_filter = ("deleted", "category", "series", "is_active", "is_free", "cpu", "gpu", "memory", "sku_type", "gpu_switch_type", "gpu_card_type")
	list_display_links = ("id", "name",)
	readonly_fields = ()
	inlines = [SkuItemPriceInline]


class SkuItemPriceAdmin(SafeDeleteAdmin):
	list_display = SafeDeleteAdmin.list_display + (
		"id",
		'sku',
		'currency',
		'location',
		'is_active',
		'active_start_date',
		'active_end_date',
		'description',
	)
	raw_id_fields = ('sku',)
	search_fields = ("sku__name", "currency__name", "location",)
	list_filter = ("deleted", "is_active", "currency", "location", "sku__category", "sku__is_free", "sku",)
	list_display_links = ("id", "sku",)
	list_select_related = ("sku", "currency",)
	readonly_fields = ()


class CurrencyAdmin(SafeDeleteAdmin):
	list_display = SafeDeleteAdmin.list_display + (
		"id",
		"name",
	)
	raw_id_fields = ()
	search_fields = ("id", "name",)
	list_filter = ("deleted",)
	list_display_links = ("id", "name",)
	readonly_fields = ()


class SKUAvailabilityAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "sku_type",
        "sku_series",
        "is_active",
        "cpu",
        "gpu",
    )
    raw_id_fields = ()
    search_fields = ("id", "sku_type",)
    list_filter = ("is_active", "sku_series", "deleted",)
    list_display_links = ("id", "sku_type",)
    readonly_fields = ()

    def save_model(self, request, obj, form, change):
        if (
            obj.sku_series == CPU_SERIES and obj.cpu is None
            or obj.sku_series == GPU_SERIES and obj.gpu is None
        ):
            messages.set_level(request, messages.ERROR)
            messages.add_message(
                request,
                messages.ERROR,
                SKU_AVAILABILITY_ADMIN_NULL_VALUE_ERROR.format(sku_series=obj.sku_series),
            )
        elif obj.sku_series == CPU_SERIES and obj.gpu != 0:
            messages.set_level(request, messages.ERROR)
            messages.add_message(
                request,
                messages.ERROR,
                SKU_AVAILABILITY_ADMIN_INVALID_VALUE_ERROR.format(sku_series=obj.sku_series),
            )
        else:
            return super(SKUAvailabilityAdmin, self).save_model(request, obj, form, change)


class TirServicesAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + ("service_id", "alias_name", "description", "is_internal_service", "order", "is_active")
    search_fields = ("service_id", "alias_name")
    list_filter = ("deleted", "is_active", "is_internal_service")
    list_display_links = ("service_id", "alias_name")


class TirServicesDependencyAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + ("id", "required_permissions", "service", "dependency", "is_active")
    raw_id_fields = ("service", "dependency")
    search_fields = ("service__alias_name", "service__service_id", "dependency__alias_name", "dependency__service_id")
    list_filter = ("deleted", "required_permissions", "is_active")
    list_display_links = ("id", "required_permissions")
    list_select_related = ("service", "dependency")


class K8sNodeAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "name",
        "worker_type",
        "status",
        "is_node_visible_in_k8s",
        "total_gpu",
        "available_gpu",
        "available_cpu",
        "available_memory",
    )
    raw_id_fields = ()
    search_fields = ("id", "name", "worker_type",)
    list_filter = ("deleted", "status", "is_node_visible_in_k8s", "total_gpu", "available_gpu", "worker_type")
    list_display_links = ("id", "name",)
    readonly_fields = ("name", "worker_type", "total_gpu", "available_gpu", "total_memory", "available_memory",)


admin.site.register(StockKeepingUnit, StockKeepingUnitAdmin)
admin.site.register(Image, ImageAdmin)
admin.site.register(ImageVersion, ImageVersionAdmin)
admin.site.register(SkuItemPrice, SkuItemPriceAdmin)
admin.site.register(Currency, CurrencyAdmin)
admin.site.register(SKUAvailability, SKUAvailabilityAdmin)
admin.site.register(K8sNode, K8sNodeAdmin)
admin.site.register(TirServices, TirServicesAdmin)
admin.site.register(TirServicesDependency, TirServicesDependencyAdmin)
