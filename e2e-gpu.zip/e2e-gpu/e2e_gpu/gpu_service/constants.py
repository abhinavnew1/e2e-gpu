from django.conf import settings
from rbac.constants import NOTEBOOK, INFERENCE_SERVICE, PIPELINE, MODEL_PLAYGROUND, VECTOR_DB, DISTRIBUTED_JOB
from inferenceservice.constants import (GEMMA_2B, GEMMA_2B_IT, GEMMA_7B, GEMMA_7B_IT, STABLE_DIFFUSION,
                                        STABLE_DIFFUSION_XL, LLMA, MIXTRAL8X7B_INSTRUCT, MIXTRAL7B,
                                        MIXTRAL7B_INSTRUCT, LLAMA_3_8B_INSTRUCT, STARCODER2_7B,
                                        PHI_3_MINI_128K_INSTRUCT, MPT, CODE_LLAMA, VLLM, NEMOTRON_3_8B_CHAT_4K_RLHF,
                                        LLAMA_3_1_8B_INSTRUCT)


DELHI_LOCATION = settings.DELHI_LOCATION
MUMBAI_LOCATION = settings.MUMBAI_LOCATION
DEFAULT_LOCATION = settings.DEFAULT_LOCATION
E2E_REGION_CHOICES_LIST = [
    DELHI_LOCATION,
    MUMBAI_LOCATION,
]
E2E_REGION_CHOICES = tuple(
    (region, region) for region in E2E_REGION_CHOICES_LIST
)

DEFAULT_IMAGE_PULL_POLICY = "Always"
DEFAULT_IMAGE_SERVER_TYPE = "jupyter"

INR_CURRENCY = "INR"
DEFAULT_CURRENCY = INR_CURRENCY
INR_CURRENCY_TEXT = "Rs."

# sku types
HOURLY = "hourly"
COMMITTED = "committed"
SKU_TYPE_LIST = [HOURLY, COMMITTED]
SKU_TYPE_CHOICES = tuple(
    (sku_type, sku_type) for sku_type in SKU_TYPE_LIST
)

# sku category
STORAGE = "storage" 
SKU_CATEGORY_LIST = [NOTEBOOK, INFERENCE_SERVICE, PIPELINE, STORAGE, MODEL_PLAYGROUND, VECTOR_DB, DISTRIBUTED_JOB]
SKU_CATEGORY_CHOICES = tuple(
    (category, category) for category in SKU_CATEGORY_LIST
)

# sku texts
COMMITTED_TEXT = "{} for committed-{}-days"
HOURLY_TEXT = "{} hourly"

# sku series
CPU_SERIES = "CPU"
GPU_SERIES = "GPU"
SKU_SERIES_LIST = [CPU_SERIES, GPU_SERIES]
SKU_SERIES_CHOICES = (
    (CPU_SERIES, CPU_SERIES),
    (GPU_SERIES, GPU_SERIES),
)

# Card Type
GPU_H100 = "H100"
GPU_A100 = "A100"
GPU_T4 = "T4"
GPU_V100 = "V100"
GPU_A30 = "A30"
GPU_A40 = "A40"
GPU_L4 = "L4"
GPU_L40S = "L40S"
GPU_RTX = "RTX"

GPU_CARD_TYPES = [GPU_H100, GPU_A100, GPU_T4, GPU_V100, GPU_A30, GPU_A40, GPU_L4, GPU_L40S, GPU_RTX]
GPU_CARD_TYPES_CHOICES = tuple((card_type, card_type) for card_type in GPU_CARD_TYPES)

# k8s worker nodes status
READY = "Ready"
NOT_READY = "Not Ready"
K8S_NODE_STATUS_CHOICES = (
    (READY, READY),
    (NOT_READY, NOT_READY),
)

GPU_CARD_LISTING_ORDER = [
    GPU_H100, GPU_A100, GPU_T4, GPU_V100, GPU_A30, GPU_A40, GPU_L4, GPU_L40S, GPU_RTX
]
GPU_CARD_TYPE_REGEX = r"H100|A100|T4|V100|A30|A40|L4|L40S|RTX"

FRAMEWORK_SUPPORTED_GPU_CARD_TYPE_MAPPING = {
    MPT: [GPU_H100, GPU_A100, GPU_L4, GPU_A40, GPU_A30],
    GEMMA_2B: [GPU_H100, GPU_A100, GPU_L4, GPU_A40, GPU_A30],
    GEMMA_2B_IT: [GPU_H100, GPU_A100, GPU_L4, GPU_A40, GPU_A30],
    GEMMA_7B: [GPU_H100, GPU_A100, GPU_L4, GPU_A40, GPU_A30],
    GEMMA_7B_IT: [GPU_H100, GPU_A100, GPU_L4, GPU_A40, GPU_A30],
    MIXTRAL8X7B_INSTRUCT: [GPU_A100, GPU_H100],
    MIXTRAL7B_INSTRUCT: [GPU_H100, GPU_A100],
    STARCODER2_7B: [GPU_H100, GPU_A100, GPU_L4, GPU_A40, GPU_A30],
    CODE_LLAMA: [GPU_H100, GPU_A100, GPU_L4, GPU_A40, GPU_A30],
    LLAMA_3_8B_INSTRUCT: [GPU_H100, GPU_A100, GPU_L4, GPU_A40, GPU_A30],
    LLMA: [GPU_H100, GPU_A100, GPU_L4, GPU_A40, GPU_A30],
    PHI_3_MINI_128K_INSTRUCT: [GPU_H100, GPU_A100, GPU_L4, GPU_A40, GPU_A30],
    VLLM: [GPU_H100, GPU_A100, GPU_L4, GPU_A40, GPU_A30],
    NEMOTRON_3_8B_CHAT_4K_RLHF: [GPU_H100, GPU_A100],
    LLAMA_3_1_8B_INSTRUCT: [GPU_H100, GPU_A100, GPU_L4, GPU_A40, GPU_A30]
}

CPU_INCOMPATIBLE_FRAMEWORKS = [GEMMA_2B, GEMMA_2B_IT, GEMMA_7B_IT, MPT, STABLE_DIFFUSION, STABLE_DIFFUSION_XL, MIXTRAL7B, MIXTRAL8X7B_INSTRUCT, CODE_LLAMA, LLAMA_3_8B_INSTRUCT, LLMA, PHI_3_MINI_128K_INSTRUCT, NEMOTRON_3_8B_CHAT_4K_RLHF, LLAMA_3_1_8B_INSTRUCT]
GPU_INCOMPATIBLE_FRAMEWORKS = []

# images
# Name strings for the images need to exactly same as their slug_name in DB
CUDA = "ubuntu-cuda-jupyter"
DIFFUSERS = "nvidia-pytorch-diffusers"
FAST_AI = "nvidia-pytorch-fastai"
JUPYTER = "jupyter-python-cuda"
NEMO = "nvidia-nemo"
PYTORCH = "nvidia-pytorch"
PYTORCH_LITE = "pytorch-cuda"
RAPIDS = "nvidia-rapids-cuda"
SCIPY = "scipy-python-cuda"
TENSORFLOW = "nvidia-tensorflow"
TRANSFORMERS = "nvidia-pytorch-transformers"
UBUNTU = "ubuntu-jupyter"

IMAGE_LISTING_ORDER = [
    TRANSFORMERS, PYTORCH, PYTORCH_LITE, TENSORFLOW, DIFFUSERS, NEMO, RAPIDS, FAST_AI, SCIPY, JUPYTER, CUDA, UBUNTU
]

MYACCOUNT_CUSTOMER_DETAILS_API = settings.MYACCOUNT_LB_URL + "api/v1/customer/details/?contact_person_id=null"
MYACCOUNT_CUSTOMER_INFO_API = settings.MYACCOUNT_LB_URL + "api/v1/customer-info/?customer_email={}&token={}"

SKU_INVENTORY_REQUEST_EMAIL_TEMPLATE_NAME = "sku/sku_inventory_request.html"

# error messages
INVENTORY_AVAILABLE = "Inventory is available"
SKU_AVAILABILITY_ADMIN_NULL_VALUE_ERROR = "'{sku_series}' field cannot be blank for sku series: {sku_series}"
SKU_AVAILABILITY_ADMIN_INVALID_VALUE_ERROR = "Sku series: {sku_series} cannot have GPU card count > 0"
SKU_INVENTORY_REQUEST_SUCCESS = "Request placed successfully! You'll be notified shortly."
SKU_INVENTORY_REQUEST_FAILED = "Failed to place your request! Please try again."
REPLICA_IS_MANDATORY = "Replica is Mandatory"
VALID = "valid"
CREDIT_FETCH_ERROR = "Unable to fetch Customer Credit Balance"
INSUFFICIENT_CREDITS_COMMITTED = "Insufficient Credits! Please buy additional {credits} credits to launch the committed resource"
INSUFFICIENT_CREDITS_HOURLY = "Insufficient Credits! Please buy additional {credits} credits to launch the resource & use it for about " + str(settings.HOURLY_SKU_MINIMUM_BILLING_HOURS) + " hours"

# disk prices
DISK_PRICE_FOR_INR = 5
DISK_PRICE_FOR_USD = 0.0750075

# GPU Services constant
TIR_SERVICE_NAME_MAX_LENGTH = 50
SERVICE_ID_NOT_FOUND = "Service validation failed: Invalid service."

# memory filters are commented for now as it is not an integer field
SKU_FILTER_KEY_MAPPING = {
    "name": "name__in",
    "series": "series__in",
    "cpu": "cpu__in",
    "gpu": "gpu__in",
    "memory": "memory__in",
    "card": "gpu_card_type__in",
}
SKU_COMPARISON_FILTER_KEY_MAPPING = {
    "cpu_gt": "cpu__gt",
    "cpu_gte": "cpu__gte",
    "cpu_lt": "cpu__lt",
    "cpu_lte": "cpu__lte",
    "gpu_gt": "gpu__gt",
    "gpu_gte": "gpu__gte",
    "gpu_lt": "gpu__lt",
    "gpu_lte": "gpu__lte",
    "memory_gt": "memory__gt",
    "memory_gte": "memory__gte",
    "memory_lt": "memory__lt",
    "memory_lte": "memory__lte",
}
SKU_FILTER_EXCLUDE_KEY_MAPPING = {
    "not_name": "name__in",
    "not_series": "series__in",
    "not_cpu": "cpu__in",
    "not_gpu": "gpu__in",
    "not_memory": "memory__in",
    "not_card": "gpu_card_type__in",
}
