import logging
from rest_framework import serializers

from e2e_core.constants import PARAMS_MISSING_OR_INVALID
from e2e_core.helpers import validate_boolean
from gpu_service.constants import SKU_CATEGORY_LIST
from inferenceservice.constants import FRAMEWORKS_VALUES
from gpu_service.models import ImageVersion, StockKeepingUnit
from rbac.constants import NOTEBOOK, INFERENCE_SERVICE

logger = logging.getLogger(__name__)


def validate_sku_listing_args(func):
    def wrapper_func(self, **kwargs):
        service = kwargs.get("service")
        image_version_id = kwargs.get("image_version_id")
        framework = kwargs.get("framework")
        
        if service not in SKU_CATEGORY_LIST:
            return self.get_400_response(PARAMS_MISSING_OR_INVALID.format(param="service"))
        
        if service == INFERENCE_SERVICE and framework not in FRAMEWORKS_VALUES:
            return self.get_400_response(PARAMS_MISSING_OR_INVALID.format(param="framework"))
   
        if image_version_id and not ImageVersion.get_version_qs(image_version_id).exists():
            return self.get_400_response(PARAMS_MISSING_OR_INVALID.format(param="Image Version"))

        return func(self, **kwargs)

    return wrapper_func


def validate_sku_inventory_request(func):
    def wrapper_func(*args, **kwargs):
        sku_id = args[1]
        sku = StockKeepingUnit.get_active_sku(sku_id)
        if not sku:
            return args[0].get_baked_404_response(PARAMS_MISSING_OR_INVALID.format(param="SKU ID"))
        kwargs["sku"] = sku
        return func(*args, **kwargs)

    return wrapper_func


def validate_image_listing_request(func):
    def wrapper_func(*args, **kwargs):
        jupyterlab = kwargs.get("is_jupyterlab_enabled")
        try:
            kwargs["is_jupyterlab_enabled"] = validate_boolean(jupyterlab)  # raises validation error in case jupyterlab not in valid boolean form
        except serializers.ValidationError:
            return args[0].get_baked_404_response(PARAMS_MISSING_OR_INVALID.format(param="is_jupyterlab_enabled"))
        return func(*args, **kwargs)
    return wrapper_func
