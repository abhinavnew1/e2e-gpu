from django.conf import settings
from django.db.models import ExpressionWrapper, F, IntegerField, Sum
from django.forms.models import model_to_dict

from customer.helpers import get_prepaid_credit_balance_via_user_email
from gpu_service.constants import (COMMITTED, CPU_SERIES, CREDIT_FETCH_ERROR,
                                   GPU_SERIES, HOURLY, INSUFFICIENT_CREDITS_COMMITTED,
                                   INSUFFICIENT_CREDITS_HOURLY)
from gpu_service.models import Currency, SKUAvailability, SkuItemPrice, StockKeepingUnit
from inferenceservice.constants import DEPLOYING, RETRYING, WAITING
from inferenceservice.models import Inference
from notebook.constants import READY, SUSPENDED, WAITING
from notebook.models import Notebook
from pipelines.models import RunHistory
from vector_db.constants import CREATING, RUNNING
from vector_db.models import VectorDB


def get_sku_wise_available_gpu_inventory_count():
    sku_wise_total_gpu_count = SKUAvailability.get_all_gpu_inventory_count()
    sku_wise_used_gpu_count = get_sku_wise_used_gpu_count()
    sku_wise_available_gpu_count = {}
    for sku_type in sku_wise_total_gpu_count.keys():
        sku_wise_available_gpu_count[sku_type] = sku_wise_total_gpu_count[sku_type] - sku_wise_used_gpu_count.get(sku_type, 0)
    return sku_wise_available_gpu_count


def get_sku_wise_used_gpu_count():
    gpu_notebooks_count = Notebook.objects.filter(
                                        deleted_at__isnull=True,
                                        status__in=[WAITING, READY],
                                        sku_item_price__sku__series=GPU_SERIES,
                                    )\
                                    .annotate(worker_type=F("sku_item_price__sku__sku_type"))\
                                    .values("worker_type")\
                                    .annotate(gpu_count=Sum("sku_item_price__sku__gpu"))
    gpu_inference_count = Inference.objects.filter(
                                        deleted_at__isnull=True,
                                        status__in=[WAITING, READY, DEPLOYING, RETRYING],
                                        sku__series=GPU_SERIES,
                                    )\
                                    .annotate(worker_type=F("sku__sku_type"))\
                                    .values("worker_type")\
                                    .annotate(gpu_count=Sum(F("sku__gpu") * F("replica")))
    pipeline_run_count = RunHistory.objects.filter(
        start_date__isnull=False,
        end_date__isnull=True,
        sku_item_price__sku__series=GPU_SERIES,
    ) \
        .annotate(worker_type=F("sku_item_price__sku__sku_type")) \
        .values("worker_type") \
        .annotate(gpu_count=Sum("sku_item_price__sku__gpu"))

    gpu_vectordb_count = VectorDB.objects.filter(
        deleted_at__isnull=True,
        status__in=[RUNNING, CREATING],
        sku_item_price__sku__series=GPU_SERIES,
    )\
        .annotate(worker_type=F("sku_item_price__sku__sku_type"))\
        .values("worker_type")\
        .annotate(gpu_count=Sum(F("sku_item_price__sku__gpu") * F("qdrant__replicas")))

    sku_wise_gpu_count = {sku_item["worker_type"]: sku_item["gpu_count"] for sku_item in gpu_notebooks_count}
    for sku_item in gpu_inference_count:
        sku_type = sku_item["worker_type"]
        sku_wise_gpu_count[sku_type] = sku_wise_gpu_count.get(sku_type, 0) + sku_item["gpu_count"]

    for sku_item in pipeline_run_count:
        sku_type = sku_item["worker_type"]
        sku_wise_gpu_count[sku_type] = sku_wise_gpu_count.get(sku_type, 0) + sku_item["gpu_count"]

    for sku_item in gpu_vectordb_count:
        sku_type = sku_item["worker_type"]
        sku_wise_gpu_count[sku_type] = sku_wise_gpu_count.get(sku_type, 0) + sku_item["gpu_count"]
    return sku_wise_gpu_count


def get_sku_wise_available_cpu_inventory_count():
    sku_wise_total_cpu_count = SKUAvailability.get_all_cpu_inventory_count()
    sku_wise_used_cpu_count = get_sku_wise_used_cpu_count()
    sku_wise_available_cpu_count = {}
    for sku_type in sku_wise_total_cpu_count.keys():
        sku_wise_available_cpu_count[sku_type] = sku_wise_total_cpu_count[sku_type] - sku_wise_used_cpu_count.get(sku_type, 0)
    return sku_wise_available_cpu_count


def get_sku_wise_used_cpu_count():
    cpu_notebooks_count = Notebook.objects.filter(
                                        deleted_at__isnull=True,
                                        status__in=[WAITING, READY],
                                        sku_item_price__sku__series=CPU_SERIES,
                                    )\
                                    .annotate(worker_type=F("sku_item_price__sku__sku_type"))\
                                    .values("worker_type")\
                                    .annotate(cpu_count=Sum("sku_item_price__sku__cpu"))
    cpu_inference_count = Inference.objects.filter(
                                        deleted_at__isnull=True,
                                        status__in=[WAITING, READY],
                                        sku__series=CPU_SERIES,
                                    )\
                                    .annotate(worker_type=F("sku__sku_type"))\
                                    .values("worker_type")\
                                    .annotate(cpu_count=Sum(F("sku__cpu") * F("replica")))

    cpu_vectordb_count = VectorDB.objects.filter(
        deleted_at__isnull=True,
        status__in=[RUNNING, CREATING],
        sku_item_price__sku__series=CPU_SERIES,
    )\
        .annotate(worker_type=F("sku_item_price__sku__sku_type"))\
        .values("worker_type")\
        .annotate(cpu_count=Sum(F("sku_item_price__sku__cpu") * F("qdrant__replicas")))

    sku_wise_cpu_count = {sku_item["worker_type"]: sku_item["cpu_count"] for sku_item in cpu_notebooks_count}
    for sku_item in cpu_inference_count:
        sku_type = sku_item["worker_type"]
        sku_wise_cpu_count[sku_type] = sku_wise_cpu_count.get(sku_type, 0) + sku_item["cpu_count"]
    for sku_item in cpu_vectordb_count:
        sku_type = sku_item["worker_type"]
        sku_wise_cpu_count[sku_type] = sku_wise_cpu_count.get(sku_type, 0) + sku_item["cpu_count"]
    return sku_wise_cpu_count


def is_sku_inventory_available(sku, inventory_availability_count_dict, replicas=1):  # TODO: in service ??
    if isinstance(sku, StockKeepingUnit):
        series_type_count = sku.gpu if sku.series == GPU_SERIES else sku.cpu
        sku_type = sku.sku_type
    else:
        series_type_count = sku[sku["series"].lower()]
        sku_type = sku["sku_type"]
    return False if inventory_availability_count_dict.get(sku_type) is not None and int(series_type_count) * replicas > inventory_availability_count_dict[sku_type] else True
    # TODO: currently, if inventory not maintained in SKUAvailability, we are returning true


def check_inventory_availability_status(sku, replicas=1):
    if sku.series == GPU_SERIES:
        gpu_inventory_availability_count = get_sku_wise_available_gpu_inventory_count()
        is_inventory_available = is_sku_inventory_available(sku, gpu_inventory_availability_count, replicas)
    else:  # sku.series == CPU_SERIES
        cpu_inventory_availability_count = get_sku_wise_available_cpu_inventory_count()
        is_inventory_available = is_sku_inventory_available(sku, cpu_inventory_availability_count, replicas)
    return is_inventory_available


def get_currency_based_sku_price_dict(sku):
    price_dict = {}
    for currency in Currency.objects.all():
        price_dict[currency.name] = sku.get_sku_price_per_hour(currency)
    return price_dict


def check_credit_sufficiency(sku_item_price, is_prepaid_customer, customer_credit_balance, replicas, **kwargs):
    if sku_item_price.sku.is_free:
        return True, None

    minimum_credits_required = sku_item_price.unit_price * replicas if sku_item_price.sku_type == COMMITTED \
                                else sku_item_price.unit_price * replicas * settings.HOURLY_SKU_MINIMUM_BILLING_HOURS
    if is_prepaid_customer and minimum_credits_required > customer_credit_balance:
        return False, round((minimum_credits_required - customer_credit_balance), 2)

    return True, 0


def is_credit_sufficient_for_inventory_launch(billable_customer, sku_item_price, replicas=1, **kwargs):
    is_prepaid, customer_credit_balance = get_prepaid_credit_balance_via_user_email(billable_customer.email)
    if is_prepaid is None:
        return False, CREDIT_FETCH_ERROR
    else:
        is_credit_sufficient, additional_required_credits = check_credit_sufficiency(
                                                                sku_item_price,
                                                                is_prepaid,
                                                                customer_credit_balance,
                                                                replicas
                                                            )
        if not is_credit_sufficient:
            err_msg = INSUFFICIENT_CREDITS_COMMITTED.format(credits=additional_required_credits)\
                        if sku_item_price.sku_type == COMMITTED\
                        else INSUFFICIENT_CREDITS_HOURLY.format(credits=additional_required_credits)
            return False, err_msg

        return True, None


def get_hourly_sku_item_price_from_committed(sku_item_price):
    new_sku_price =  SkuItemPrice.objects.filter(sku_type=HOURLY, currency=sku_item_price.currency, location=sku_item_price.location,
                                                 is_active=True, sku=sku_item_price.sku
                                                 ).last()
    return new_sku_price
