import json
import re

import jwt
from django.conf import settings
from django.utils.deprecation import MiddlewareMixin
from rest_framework import exceptions
from rest_framework.renderers import JSONRenderer
from rest_framework.response import Response

from customer.api.v1.services.customer_service import CustomerCreationService
from e2e_core.api.v1.services.base import BaseService
from e2e_core.constants import AUTHENTICATION_FAILED
from e2e_core.exceptions import ObjectNotFoundError
from projects.models import Projects
from rbac.models import IAM
from teams.models import Teams

INVALID_USER_DETAILS = "Invalid User details"
SUSPENDED_CUSTOMER = "Customer is suspended!"
USER_NOT_FOUND_ERROR = "User not found. Please verify the team, project, or active user."
USER_NOT_FOUND = "User not found"
SUSPENDED = "Suspended"
ADMIN_URL = "/admin"
STATIC_URL = "/static"
BILLING_API = "/api/v1/gpu/billing/"
CUSTOMER_ACCOUNT_STATUS_API = "/api/v1/gpu/customer/account-status/"
CUSTOMER_DETAILS_API = "/api/v1/gpu/customer/details/"
CUSTOMER_IAM_ACCOUNTS_API = "/api/v1/gpu/users/iam-accounts/"
CUSTOMER_INVITES_API = "/api/v1/gpu/users/invites/"
MYACCOUNT_IAM_REMOVE = "/api/v1/gpu/users/iams/myaccount/remove/"
GPU_DE_PROVISION_API = "/api/v1/gpu/de-provision/"
NOTEBOOOK_PREVIEW_URL = "/publicapi/v1/gpu/notebooks/preview/"
VECTOR_DB_SNAPSHOT_STATUS_UPDATE_URL = "/publicapi/v1/gpu/vector_db/"
DATA_SYNCER_AIRBYTE_WEBHOOK_SUCCESSFUL_SYNC_URL = "/publicapi/v1/gpu/data_syncer/airbyte-webhook/sync-status/"
TEAM_PROJECT_URL_PATTERN = r"^/api/v1/gpu/teams/(\d+)/.*$"
PROJECT_URL_PATTERN = r"^/api/v1/gpu/projects/(\d+)/.*$"


class JWTTokenAuthenticationMiddleware(MiddlewareMixin):
    """Middleware to get the user from JWT auth token payload"""

    def process_request(self, request):
        self.request = request
        if self._is_authentication_required():
            try:
                encoded_jwt = self.get_jwt_token()
                payload = jwt.decode(encoded_jwt, options={"verify_signature": False})
                user_details = self.extract_user_details(payload)
                login_customer = self.get_or_create_customer(user_details)
                setattr(self.request, "customer", login_customer)
            except Exception as e:
                return self.set_response(BaseService.get_401_response(str(e), message=AUTHENTICATION_FAILED))
            try:
                active_iam = self.get_active_iam(login_customer)
                is_customer_auth_required = self._only_customer_auth_required()
                if active_iam:
                    if not is_customer_auth_required and active_iam.owner.is_suspended:
                        return self.set_response(BaseService.get_403_response(errors=SUSPENDED_CUSTOMER, message=SUSPENDED))
                    setattr(self.request, "iam", active_iam)
                elif not is_customer_auth_required:
                    return self.set_response(BaseService.get_403_response(errors=USER_NOT_FOUND_ERROR, message=USER_NOT_FOUND))
            except Exception as e:
                return self.set_response(BaseService.get_403_response(str(e)))

    def get_jwt_token(self):
        auth_header = self.request.headers.get("Authorization", "")
        auth_header = auth_header.split(" ")
        if not auth_header:
            raise exceptions.AuthenticationFailed()
        if len(auth_header) == 1:
            raise exceptions.NotAuthenticated()
        elif len(auth_header) > 2:
            raise exceptions.AuthenticationFailed()
        return auth_header[1]

    def get_or_create_customer(self, user_details):
        if not user_details["email"] or not user_details["username"] or user_details["email"] != user_details["username"]:
            raise exceptions.AuthenticationFailed(INVALID_USER_DETAILS)
        customer_service = CustomerCreationService(self.request.headers.get("Authorization"))
        customer = customer_service.get_or_create_customer(
            email=user_details["email"],
            default_data=user_details,
        )
        if not customer.is_active:
            customer_service.activate_customer(customer, user_details)
        if customer.currency is None:
            customer_service.update_user_currency_from_myaccount(customer)
        return customer

    def extract_user_details(self, payload):
        return {
            "email": payload.get("email", None),
            "username": payload.get("preferred_username", None),
            "first_name": payload.get("given_name", None),
            "last_name": payload.get("family_name", None),
            "phone": payload.get("phone", None),
            # TODO: temporary fix. only for existing primary customers, is_primary_contact & primary_email will be None
            "is_primary_contact": payload.get("is_primary_contact", True),
            "primary_email": payload.get("primary_email", payload.get("email")),
        }

    def set_response(self, response_data):
        response = Response(response_data, status=response_data.get("code"))
        response.accepted_renderer = JSONRenderer()
        response.accepted_media_type = "application/json"
        response.renderer_context = {}
        response.render()
        return response

    def get_active_iam(self, login_customer):
        active_iam_id = self.request.GET.get("active_iam", None)
        active_iam = None
        try:
            if active_iam_id:
                return self.get_iam(id=active_iam_id, added_user=login_customer)
            path_url = self.request.path
            team_project_url_match = re.match(TEAM_PROJECT_URL_PATTERN, path_url)
            project_url_match = re.match(PROJECT_URL_PATTERN, path_url)
            if team_project_url_match:
                team_id = team_project_url_match.groups()[0]
                team = Teams.objects.get(deleted_at__isnull=True, id=team_id)
                active_iam = self.get_iam(owner_id=team.owner_id, added_user=login_customer)
            elif project_url_match:
                project_id = project_url_match.groups()[0]
                project = Projects.objects.filter(deleted_at__isnull=True, id=project_id).select_related("team").first()
                active_iam = self.get_iam(owner_id=project.team.owner_id, added_user=login_customer)
            elif login_customer.is_primary_contact:
                # This case handles scenarios where the primary user logs in for the first time
                # and we don't have team_id or active_iam_id. If the customer is only a contact person,
                # an IAM user will not be found since we do not create IAMs for contact persons.
                active_iam = self.get_iam(owner=login_customer, added_user=login_customer)
            return active_iam
        except Exception:
            raise ObjectNotFoundError(USER_NOT_FOUND)

    def get_iam(self, **filters):
        return IAM.objects.filter(deleted_at__isnull=True, **filters).select_related("owner").first()

    def _is_authentication_required(self):
        if (
            self.is_admin_url()
            or self.is_static_url()
            or self.is_myaccount_billing_api_request()
            or self.is_de_provision_request()
            or self.is_customer_account_status_request()
            or self.is_myaccount_iam_remove_url()
            or self.is_public_url()
        ):
            return False
        return True

    def _only_customer_auth_required(self):
        api_pattern = re.compile(f"^{CUSTOMER_DETAILS_API}|^{CUSTOMER_IAM_ACCOUNTS_API}|^{CUSTOMER_INVITES_API}")
        return bool(api_pattern.match(self.request.path))

    def is_admin_url(self):
        return self.request.path.startswith(ADMIN_URL)

    def is_static_url(self):
        return self.request.path.startswith(STATIC_URL)

    def is_billing_url(self):
        return self.request.path.startswith(BILLING_API)

    def is_customer_account_status_url(self):
        return self.request.path.startswith(CUSTOMER_ACCOUNT_STATUS_API)

    def is_de_provision_url(self):
        return self.request.path.startswith(GPU_DE_PROVISION_API)

    def is_de_provision_request(self):
        return self.is_de_provision_url() and json.loads(self.request.body).get("token") == settings.GPU_BILLING_API_TOKEN

    def is_myaccount_billing_api_request(self):
        return self.is_billing_url() and self.request.GET.get("token") == settings.GPU_BILLING_API_TOKEN

    def is_customer_account_status_request(self):
        return self.is_customer_account_status_url() and self.request.GET.get("token") == settings.GPU_BILLING_API_TOKEN

    def is_public_url(self):
        if (
            self.is_notebook_preview_url()
            or self.is_vector_db_snapshot_status_update_url()
            or self.is_data_syncer_airbyte_webhook_succesful_sync_url()
        ):
            return True
        return False

    def is_notebook_preview_url(self):
        return self.request.path.startswith(NOTEBOOOK_PREVIEW_URL)

    def is_vector_db_snapshot_status_update_url(self):
        return self.request.path.startswith(VECTOR_DB_SNAPSHOT_STATUS_UPDATE_URL)

    def is_data_syncer_airbyte_webhook_succesful_sync_url(self):
        return self.request.path.startswith(DATA_SYNCER_AIRBYTE_WEBHOOK_SUCCESSFUL_SYNC_URL)

    def is_myaccount_iam_remove_url(self):
        return self.request.path.startswith(MYACCOUNT_IAM_REMOVE)
