import logging

from django.conf import settings
from django.db import models
from simple_history.models import HistoricalRecords

from e2e_core.mixins import BaseMixin, SafeDeleteMixinExtended
from gpu_service.constants import (COMMITTED, COMMITTED_TEXT, CPU_SERIES,
                                   DEFAULT_CURRENCY, DEFAULT_IMAGE_PULL_POLICY,
                                   DEFAULT_IMAGE_SERVER_TYPE, DEFAULT_LOCATION,
                                   E2E_REGION_CHOICES, GPU_SERIES, TIR_SERVICE_NAME_MAX_LENGTH, HOURLY,
                                   HOURLY_TEXT, INR_CURRENCY_TEXT,
                                   SKU_CATEGORY_CHOICES, SKU_SERIES_CHOICES, K8S_NODE_STATUS_CHOICES,
                                   SKU_TYPE_CHOICES, GPU_CARD_TYPES_CHOICES)
from notebook.constants import H100_SKU_NAME
from rbac.constants import ACCESS_CONTROL_CHOICES, NO_PERMISSION_VALUE

logger = logging.getLogger(__name__)


class Image(SafeDeleteMixinExtended, BaseMixin):
    name = models.CharField(max_length=50, help_text="Image display name")
    slug_name = models.CharField(max_length=50)
    image_pull_policy = models.CharField(max_length=50, default=DEFAULT_IMAGE_PULL_POLICY)
    image_type = models.CharField(max_length=50, default=DEFAULT_IMAGE_SERVER_TYPE)
    is_active = models.BooleanField(default=True)
    active_start_date = models.DateTimeField(blank=True, null=True)
    active_end_date = models.DateTimeField(blank=True, null=True)
    icon_url = models.CharField(max_length=128, null=True, blank=True)
    description = models.TextField(max_length=512, null=True, blank=True)

    history = HistoricalRecords()

    def __str__(self):
        return f"<Image({self.id}: {self.name})>"

    @classmethod
    def get_active_image(cls, id):
        if not id:
            return None
        return cls.objects.filter(id=id, is_active=True).first()


class ImageVersion(SafeDeleteMixinExtended, BaseMixin):
    image = models.ForeignKey(Image, on_delete=models.CASCADE)
    version = models.CharField(max_length=50)
    cpu_image_url = models.CharField(max_length=512, null=True, blank=True)
    gpu_image_url = models.CharField(max_length=512, null=True, blank=True)
    is_jupyterlab_enabled = models.BooleanField(default=True)
    is_active = models.BooleanField(default=True)
    active_start_date = models.DateTimeField(blank=True, null=True)
    active_end_date = models.DateTimeField(blank=True, null=True)
    description = models.TextField(max_length=512, null=True, blank=True)

    history = HistoricalRecords()

    def __str__(self):
        return f"<ImageVersion({self.id}: {self.image.name}: {self.version})>"

    @classmethod
    def get_active_version_qs(cls, id):
        return cls.objects.filter(
                    id=id, is_active=True, image__is_active=True, image__deleted=False
                ).select_related("image")

    @classmethod
    def get_version_qs(cls, id):
        return cls.objects.filter(
                    id=id, image__deleted=False
                ).select_related("image")


class Currency(SafeDeleteMixinExtended, BaseMixin):
    name = models.CharField(max_length=100)

    def __str__(self):
        return f"<Currency({self.name})>"

    @property
    def display_text(self):
        if self.name == DEFAULT_CURRENCY:
            return INR_CURRENCY_TEXT
        return self.name

    @classmethod
    def get_currency_object(cls, currency_name):
        return cls.objects.filter(name=currency_name).first()


class StockKeepingUnit(SafeDeleteMixinExtended, BaseMixin):
    name = models.CharField(max_length=128)
    series = models.CharField(choices=SKU_SERIES_CHOICES, max_length=64)

    cpu_str = models.CharField(max_length=64)
    cpu = models.IntegerField(default=0)

    gpu_str = models.CharField(max_length=64, default=None, blank=True, null=True)
    gpu = models.IntegerField(default=0)

    memory_str = models.CharField(max_length=64)
    memory = models.IntegerField(default=0, help_text="memory in GB")

    gpu_card_type = models.CharField(choices=GPU_CARD_TYPES_CHOICES, max_length=64, null=True, blank=True)
    sku_type = models.CharField(max_length=128, help_text="worker_type of the corresponding node in k8s")
    is_free = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    active_start_date = models.DateTimeField(blank=True, null=True)
    active_end_date = models.DateTimeField(blank=True, null=True)
    category = models.CharField(choices=SKU_CATEGORY_CHOICES, max_length=64)
    gpu_switch_type = models.CharField(max_length=64, default=None, blank=True, null=True)
    local_storage = models.IntegerField(default=0, help_text="local storage size in GB")


    def __str__(self):
        return f"<SKU({self.id}: {self.name}: {self.category})>"
    
    @property
    def is_local_storage_provided(self):
        return (
            self.local_storage > 0
        )

    @property
    def display_memory(self):
        return f"{self.memory}GB"

    @classmethod
    def get_active_sku(cls, id):
        if not id:
            return None
        return cls.objects.filter(id=id, is_active=True).first()

    def get_sku_price_per_hour(self, currency, location=DEFAULT_LOCATION, **kwargs):
        sku_item_price = SkuItemPrice.objects.filter(
            sku=self, is_active=True, currency=currency, location=location, sku_type=HOURLY
        ).first()
        if not sku_item_price:
            logger.error(f"GET_SKU_PRICE_PER_HOUR | CRITICAL_RED | SKU_ITEM_PRICE_NOT_FOUND | SKU:{self.id}-{self.name}--CURRENCY:{currency.name}--LOCATION:{location}")
            return None
        return sku_item_price.unit_price


class SkuItemPrice(SafeDeleteMixinExtended, BaseMixin):
    sku = models.ForeignKey(StockKeepingUnit, on_delete=models.CASCADE)
    currency = models.ForeignKey(Currency, on_delete=models.CASCADE)
    location = models.CharField(choices=E2E_REGION_CHOICES, default=DEFAULT_LOCATION, max_length=50)
    sku_type = models.CharField(choices=SKU_TYPE_CHOICES, default=HOURLY, max_length=50)
    committed_days = models.IntegerField(default=0)
    unit_price = models.FloatField()
    is_active = models.BooleanField(default=True)
    active_start_date = models.DateTimeField(null=True, blank=True)
    active_end_date = models.DateTimeField(null=True, blank=True)
    description = models.CharField(max_length=500, default=None, null=True, blank=True)

    def __str__(self):
        committed_days_str = f"_{self.committed_days}" if self.sku_type == COMMITTED else ""
        return f"<SkuItemPrice({self.sku.name}: {self.sku_type}{committed_days_str}: {self.currency.name}--{self.location})>"

    @property
    def display_text(self):
        return COMMITTED_TEXT.format(self.unit_price, self.committed_days) if self.sku_type == COMMITTED else HOURLY_TEXT.format(self.unit_price)

    @property
    def price_per_month(self):
        if self.sku_type == HOURLY:
            return self.unit_price * settings.HOURS_PER_MONTH
        return None


class SKUAvailability(SafeDeleteMixinExtended, BaseMixin):
    sku_type = models.CharField(max_length=128, unique=True, help_text="worker_type of the corresponding node in k8s")
    sku_series = models.CharField(choices=SKU_SERIES_CHOICES, max_length=64)
    cpu = models.PositiveIntegerField(null=True, blank=True)
    gpu = models.PositiveIntegerField(default=0, help_text="Total no. of GPU Cards")
    is_active = models.BooleanField(default=True)

    @classmethod
    def get_all_gpu_inventory_count(cls):
        all_gpu_inventory = cls.objects.filter(sku_series=GPU_SERIES, is_active=True)
        return {
            inventory.sku_type: inventory.gpu for inventory in all_gpu_inventory
        }

    @classmethod
    def get_all_cpu_inventory_count(cls):
        all_cpu_inventory = cls.objects.filter(sku_series=CPU_SERIES, is_active=True)
        return {
            inventory.sku_type: inventory.cpu for inventory in all_cpu_inventory
        }


class TirServices(SafeDeleteMixinExtended, BaseMixin):
    service_id = models.CharField(unique=True, primary_key=True, max_length=TIR_SERVICE_NAME_MAX_LENGTH)
    alias_name = models.CharField(max_length=TIR_SERVICE_NAME_MAX_LENGTH)
    description = models.TextField()
    is_internal_service = models.BooleanField(default=False)
    order = models.PositiveSmallIntegerField(unique=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['order']

    def __str__(self):
        return f"<TirServices({self.service_id}: {self.alias_name})>"


class TirServicesDependency(SafeDeleteMixinExtended, BaseMixin):
    required_permissions = models.PositiveSmallIntegerField(choices=ACCESS_CONTROL_CHOICES, default=NO_PERMISSION_VALUE)
    service = models.ForeignKey(TirServices, on_delete=models.CASCADE, to_field='service_id', related_name="dependencies",)
    dependency = models.ForeignKey(TirServices, on_delete=models.CASCADE, to_field='service_id', related_name="services")
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"<TirServicesDependency({self.id}: {self.service_id}: {self.dependency_id})>"


class K8sNode(SafeDeleteMixinExtended, BaseMixin):
    name = models.CharField(max_length=128, unique=True)
    worker_type = models.CharField(max_length=128, help_text="worker_type label of the node in k8s")
    total_cpu = models.PositiveIntegerField(help_text="Number of total CPU in m (Millicores)")
    total_gpu = models.PositiveIntegerField(help_text="Total number of GPU card. For example an 8x GPU node will have 8 as total number of GPUs")
    total_memory = models.PositiveIntegerField(help_text="Total Memory in MiB")
    available_cpu = models.PositiveIntegerField(help_text="Number of available CPU in m (Millicores)")
    available_gpu = models.PositiveIntegerField()
    available_memory = models.PositiveIntegerField(help_text="Available Memory in MiB")
    is_node_visible_in_k8s = models.BooleanField(default=True)
    status = models.CharField(choices=K8S_NODE_STATUS_CHOICES, max_length=16)

    def __str__(self):
        return f"<Nodes({self.id}: {self.name}: {self.worker_type})>"
