from django.contrib import admin
from safedelete.admin import SafeDeleteAdmin

from inferenceservice.models import (FrameworkDetail, Inference, InferenceHistory, Model,
                                     ModelTypes, AutoScalePolicy)


class ModelTypesAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "name",
        "deleted_at",
        "created_by",
        "created_at",
        "updated_at"
    )
    raw_id_fields = ("created_by",)
    search_fields = ("id", "created_by__email",)
    list_filter = (
        "deleted", "deleted_at", "created_by__email")
    list_display_links = ("id",)
    list_select_related = ("created_by",)


class ModelAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "deleted_at",
        "id",
        "name",
        "status",
        "created_by",
        "created_at",
        "updated_at",
        "bucket",
        "project",
        "secret",
        "service_account"
    )
    raw_id_fields = ("created_by", "project", "bucket", "access_key",)
    search_fields = ("id", "bucket__bucket_name", "project__name", "created_by__email",)
    list_filter = (
        "deleted", "deleted_at", "status", "bucket", "bucket__bucket_name", "project", "project__name")
    list_display_links = ("id",)
    list_select_related = ("created_by", "project", "bucket",)


class InferenceAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "deleted_at",
        "id",
        "name",
        "sku",
        "status",
        "created_by",
        "project",
        "replica",
        "desired_replica",
        "framework",
        "custom_endpoint_details",
        "is_auto_scale_enabled",
        "created_at",
        "updated_at",
    )
    raw_id_fields = ("sku", "created_by", "project", "auto_scale_policy", "model", "sku_item_price", "registry_namespace",)
    search_fields = ("id", "sku__name", "created_by__email", "custom_endpoint_details", "project__id")
    list_filter = (
        "deleted", "deleted_at", "status", "sku__series", ("sku", admin.RelatedOnlyFieldListFilter), "sku__is_free", "framework")
    list_display_links = ("id",)
    list_select_related = ("sku", "created_by", "project",)


class InferenceHistoryAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "customer",
        "inference",
        "start_date",
        "end_date",
        "sku",
        "replica"
    )
    raw_id_fields = ("customer", "inference", "sku", "sku_item_price",)
    search_fields = ("id", "inference__name", "customer__email",)
    list_filter = ("start_date", "end_date", "sku__series", ("sku", admin.RelatedOnlyFieldListFilter),)
    list_display_links = ("id",)
    list_select_related = ("customer", "inference", "sku",)


class AutoScalePolicyAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "min_replicas",
        "max_replicas",
        "rules",
        "stability_period"
    )
    search_fields = ("id", "min_replicas", "max_replicas", "stability_period")


class FrameworkDetailAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "name",
        "supported_models"
    )
    list_display_links = ("id",)
    search_fields = ("name",)

admin.site.register(ModelTypes, ModelTypesAdmin)
admin.site.register(Model, ModelAdmin)
admin.site.register(Inference, InferenceAdmin)
admin.site.register(InferenceHistory, InferenceHistoryAdmin)
admin.site.register(AutoScalePolicy, AutoScalePolicyAdmin)
admin.site.register(FrameworkDetail, FrameworkDetailAdmin)
