from django.conf import settings

from e2e_core.constants import MAX_LENGTH_ERROR

INFERENCE_NAME_MAX_LENGTH = 128
STORAGE_URL_MAX_LENGTH = 256
STATUS_MAX_LENGTH = 128
MAX_DISK_SIZE = 1000

READY = "ready"
WAITING = "waiting"
WARNING = "warning"
ERROR = "error"
UNINITIALIZED = "uninitialized"
UNAVAILABLE = "unavailable"
TERMINATING = "terminating"
STOPPED = "stopped"
RUNNING = "running"
PATCH = 'patch'
UPDATE = 'update'
RETRYING = "retrying"
DONE = "Done"
DEPLOYING = "deploying"
RESTARTING = "restarting"

INFERENCE_SERVICE_STATUS_CHOICES = (
    (READY, READY),
    (WARNING, WARNING),
    (ERROR, ERROR),
    (UNINITIALIZED, UNINITIALIZED),
    (UNAVAILABLE, UNAVAILABLE),
    (TERMINATING, TERMINATING),
    (RUNNING, RUNNING),
    (STOPPED, STOPPED),
    (RETRYING, RETRYING),
    (DONE, DONE),
    (WAITING, WAITING),
    (DEPLOYING, DEPLOYING),
    (RESTARTING, RESTARTING),
)
INFERENCE_SERVICE_CREATED_BY = "inference_service_created_by"

CREATE_MODEL_CONFIG_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/model-config"
DELETE_MODEL_CONFIG_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/model-config/{model_id}"
CREATE_INFERENCE_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/inference"
CUSTOM_INFERENCE_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/custom-inference"
PATCH_CUSTOM_INFERENCE_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/custom-inference/{custom_inference}"
LIST_INFERENCES_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/inferences"
INFERENCE_DETAILS_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/inference/{inference}"
INFERENCE_LOGS_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/inference/{inference}/logs"
INFERENCE_REPLICA_LOGS_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/inference/{inference}/logs/{pod_name}"
AUTO_SCALE_DETAILS_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/inference/{inference}/hpa"
DELETE_INFERENCE_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/inference/{inference}"
CREATE_USER_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/user"
SECRET_AND_SERVICE_ACCOUNT_INFERENCE_URL = settings.GROOT_BASE_URL + \
                                           "api/namespaces/{namespace}/secret/{secret}/{service_account}"
START_STOP_INFERENCE_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/notebooks/{notebook_slug}"
INFERENCE_LAB_URL = settings.GROOT_BASE_URL + "notebook/{namespace}/{notebook_slug}/doc"
UPGRADE_DOWNGRADE_INFERENCE_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/notebooks/{notebook_slug}"
GET_INFERENCE_PODS_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/inference/{inference_id}/list_pods"
GET_INFERENCE_POD_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/pod/{pod_name}"
RESTART_INFERENCE_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/custom-inference/{inference_id}/restart"
CREATE_CUSTOM_HPA = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/inference/{inference_id}/custom-hpa"
INFERENCE_NAME_ALREADY_EXISTS = "Inference With Same Name Already exists"
NAME_REGEX = r'^[A-Za-z0-9_-]{1,}$'
NAME_INVALID = "Project name should contain letters, digits, underscore and hyphen only."

INFERENCE_NAME_MAX_LENGTH_ERROR = MAX_LENGTH_ERROR.format(field_name="Inference Name",
                                                          max_length=INFERENCE_NAME_MAX_LENGTH)
INFERENCE_CREATE_EVENT = "INFERENCE_CREATE"
INFERENCE_DELETE_EVENT = "INFERENCE_DELETE"
INFERENCE_PATCH_EVENT = "INFERENCE_PATCH"
MODEL_CREATE_EVENT = "MODEL_CREATE"
MODEL_DELETE_EVENT = "MODEL_DELETE"
MODEL_UPDATE_EVENT = "MODEL_UPDATE"
MODEL_OBJECT_DELETE_EVENT = "MODEL_OBJECT_DELETE"
MODEL_OBJECT_UPLOAD_EVENT = "MODEL_OBJECT_UPLOAD"
OBJECT_UPLOAD_ACTION = "upload"
OBJECT_DOWNLOAD_ACTION = "download"

MANAGED_STORAGE = "managed"
EXTERNAL_STORAGE = "external"
ACCESS_KEY_ATTACH_FAILED = "Error while attaching Access Key to Dataset Bucket"

MODEL_NAME_MAX_LENGTH = 50
MODEL_NAME_MAX_LENGTH_ERROR = MAX_LENGTH_ERROR.format(field_name="Dataset Name", max_length=MODEL_NAME_MAX_LENGTH)
E2E_OBJECT_STORAGE = "e2e_s3"
EXTERNAL_BUCKET = "external"
STORAGE_TYPE_CHOICES = (
    (MANAGED_STORAGE, MANAGED_STORAGE),
    (E2E_OBJECT_STORAGE, E2E_OBJECT_STORAGE),
    (EXTERNAL_BUCKET, EXTERNAL_BUCKET),
)
OK = "OK"
DONE = "Done"
PENDING = "pending"
MODEL_STATUS_CHOICES = (
    (PENDING, PENDING),
    (OK, OK),
    (DONE, DONE),
)

MODEL_NAME_REGEX = r'[a-z0-9]([-a-z0-9]*[a-z0-9])?'
INVALID_INFERENCE_NAME = "Inference name should start and end with an alphanumeric character and can contain " \
                         "lowercase letters, digits and hyphen only."
INVALID_MODEL_NAME = "Model name should start and end with an alphanumeric character and can contain lowercase " \
                     "letters, digits and hyphen only."
MODEL_NAME_ALREADY_EXISTS = "Model with the same name already exists in the Project"
DELETE_OBJECT_STORAGE_FOR_MODEL_TASK = "delete_object_storage_for_model_task"
INFERENCE_SERVICE_MODEL = "INFERENCE_SERVICE_MODEL"
CUSTOM = "custom"
TRITON = "triton"
TENSORRT = "tensorrt"
PYTORCH = "pytorch"
VLLM = "vllm"
MODEL_TYPE = ((TRITON, TRITON), (PYTORCH, PYTORCH), (CUSTOM, CUSTOM), (TENSORRT, TENSORRT), (VLLM, VLLM))
MODEL_TYPE_MAX_LENGTH = 64
STORAGE_URL_PREFIX = "s3://"
INFERENCE_SERVICE_NOT_DELETED = "PLEASE DELETE INFERENCE SERVICE BEFORE DELETING THE MODEL"
FAILED_TO_VALIDATE_MODEL = "failed to validate the bucket path"
FILES_NOT_FOUND = "No files found at the given path"  # Frontend dependent message. any change needs to be notified to frontend
MODEL_NOT_FOUND = "no model found at the given path"
VALID = "valid"
INFERENCE_IS_NOT_RUNNING = "INFERENCE SHOULD BE IN RUNNING STATE"
INFERENCE_IS_NOT_STOPPED = "INFERENCE SHOULD BE IN STOPPED STATE"
ACTION_NOT_ALLOWED = "action not allowed"
INFERENCE_STOPPED = "INFERENCE STOPPED"
INFERENCE_STARTED = "INFERENCE STARTED"
INVALID_NEMO_RAG_CONFIG = "Invalid value for '{key}' in config yaml file. '{param}' is either missing or invalid"
NEMO_RAG_CONFIG_FETCH_ERROR = "Unable to fetch config yaml file"
NEMO_RAG_CONFIG_MISSING_ERROR = "config yaml file not found at given path"  # Frontend dependent message. any change needs to be notified to frontend
NEMO_RAG_CONFIG_MISSING_KEY_ERROR = "'{key}' key is missing in config yaml file"
FAILED_TO_CREATE_MODEL = "failed to create model"
INVALID_SKU_PROVIDED = "Please Provide Sku of Inference type"
ERROR_FROM_GROOT = "ERROR FROM GROOT"
PARAMS_MISSING_OR_INVALID = "{param} is either invalid or not provided"
DEFAULT_REGISTRY_SECRET_NAME = "namespace-secret-{registry_id}"
FAILED_TO_DELETE_ACCESS_KEY_MESSAGE = "Failed to delete access key: {access_key}.\n errors: {errors}"
FAILED_TO_DELETE_ACCESS_KEY = "Failed to delete access key for customer: {email_id}"
FAILED_TO_DELETE_BUCKET_MESSAGE = "Failed to delete bucket: {bucket_name}.\n errors: {errors}"
FAILED_TO_DELETE_BUCKET = "Failed to delete bucket for customer: {email_id}"
STORAGE_TYPE_MAXIMUM_LENGTH = 64
ERROR_IN_OBJECT_LISTING = "Error While Fetching Objects- Either Bucket Does not Exist Or You Don't have Permission"
BUCKET_NAME_IS_MANDATORY = "Bucket Name is mandatory"
BUCKET_DOES_NOT_EXIST = "Bucket Doest Not Exist"
INVENTORY_UNAVAILABLE = "SKU Inventory temporarily unavailable. Please try again."
INFERENCE_SERVICE = "inference_service"
NOT_FOUND_ERROR = "{service} not found"
SKU = 'plan'
MODEL = 'model'
STORAGE_URL = "s3://{bucket_name}/{path}"
PVC = "pvc"
NO_OBJECTS_FETCH_FOR_PVC = "No objects fetched for disk dataset"
FETCH_OBJECTS_ERROR = "Error while fetching objects"
GET_OBJECTS_URL_ERROR = "Error in getting object {action} url"



LLMA = "llma"
LLAMA_3_8B_INSTRUCT = "llama-3-8b-instruct"
LLAMA_3_1_8B_INSTRUCT = "llama-3_1-8b-instruct"
STABLE_DIFFUSION = "stable_diffusion"
STABLE_DIFFUSION_XL = "stable_diffusion_xl"
YOLO = 'yolov8'
MPT = "mpt"
CODE_LLAMA = "codellama"
FINETUNED = "finetuned"
PLAYGROUND = 'playground'
MIXTRAL8X7B = 'mixtral8x7b'
MIXTRAL7B = 'mixtral7b'
MIXTRAL7B_INSTRUCT = "mistral-7b-instruct"
MIXTRAL8X7B_INSTRUCT = "mixtral-8x7b-instruct"
GEMMA_7B_IT = "gemma-7b-it"
GEMMA_7B = "gemma-7b"
GEMMA_2B = "gemma-2b"
GEMMA_2B_IT = "gemma-2b-it"
PHI_3_MINI_128K_INSTRUCT = "Phi-3-mini-128k-instruct"
STARCODER2_7B = "starcoder2-7b"
NEMO_RAG_SERVICE = 'nemo-rag'
NEMOTRON_3_8B_CHAT_4K_RLHF = "nemotron-3-8b-chat-4k-rlhf"
STABLE_VIDEO_DIFFUSION_XT = "stable-video-diffusion-img2vid-xt"
NVIDIA_NV_EMBED_V1 = "nvidia-nv-embed-v1"
PRE_BUILD = [] # for kserve protocol
TRITON_SERVER = 'triton-server'
VLLM_SERVER = 'vllm-server'
KSERVER_SERVER = 'kserve-server'
TORCH_SERVER = 'torch-server'
FINETUNED_VLLM_OPENAI_IMAGE = 'vllm/vllm-openai:latest'
FINETUNED_VLLM_OPENAI_IMAGE_WITHOUT_VERSION = 'vllm/vllm-openai:'
FINETUNED_MISTRAL_8X7B_INFERENCE_IMAGE = 'registry.e2enetworks.net/aimle2e/finetuned-mixtral8x7b-server:v1'
FINETUNED_STABLE_DIFFUSION_2_INFERENCE_IMAGE = 'registry.e2enetworks.net/aimle2e/finetuned-stable-diff-2:v1'
FINETUNED_STABLE_DIFFUSION_XL_INFERENCE_IMAGE = 'registry.e2enetworks.net/aimle2e/finetuned-stable-diff-sdxl:v1'
TIR_CUSTOM_FRAMEWORKS = [LLMA, STABLE_DIFFUSION, STABLE_DIFFUSION_XL, YOLO, MPT, CODE_LLAMA, MIXTRAL7B, MIXTRAL8X7B, MIXTRAL7B_INSTRUCT, MIXTRAL8X7B_INSTRUCT, GEMMA_7B_IT, GEMMA_7B, GEMMA_2B, GEMMA_2B_IT, TENSORRT, PYTORCH, TRITON, LLAMA_3_8B_INSTRUCT, VLLM, STARCODER2_7B, PHI_3_MINI_128K_INSTRUCT, NEMO_RAG_SERVICE, STABLE_VIDEO_DIFFUSION_XT, NEMOTRON_3_8B_CHAT_4K_RLHF, NVIDIA_NV_EMBED_V1, LLAMA_3_1_8B_INSTRUCT]  # custom model inferences provided by E2E
FRAMEWORKS_VALUES = [TRITON, PYTORCH, TENSORRT, CUSTOM, LLMA, STABLE_DIFFUSION, STABLE_DIFFUSION_XL, YOLO, MPT, CODE_LLAMA, FINETUNED, MIXTRAL7B, MIXTRAL8X7B, MIXTRAL7B_INSTRUCT, MIXTRAL8X7B_INSTRUCT, GEMMA_7B_IT, GEMMA_7B, GEMMA_2B, GEMMA_2B_IT, LLAMA_3_8B_INSTRUCT, VLLM, STARCODER2_7B, PHI_3_MINI_128K_INSTRUCT, NEMO_RAG_SERVICE, STABLE_VIDEO_DIFFUSION_XT, NEMOTRON_3_8B_CHAT_4K_RLHF, NVIDIA_NV_EMBED_V1, LLAMA_3_1_8B_INSTRUCT]
FRAMEWORKS_SERVER_TYPE_MAPPING = {
    TRITON: TRITON_SERVER,
    TENSORRT: TRITON_SERVER,
    LLMA: VLLM_SERVER,
    CODE_LLAMA: VLLM_SERVER,
    LLAMA_3_8B_INSTRUCT: VLLM_SERVER,
    GEMMA_7B_IT : VLLM_SERVER,
    GEMMA_7B: TRITON_SERVER,
    GEMMA_2B: TRITON_SERVER,
    GEMMA_2B_IT: VLLM_SERVER,
    VLLM: VLLM_SERVER,
    MIXTRAL7B_INSTRUCT: VLLM_SERVER,
    MIXTRAL8X7B_INSTRUCT: VLLM_SERVER,
    STARCODER2_7B: VLLM_SERVER,
    MPT: VLLM_SERVER,
    CUSTOM: KSERVER_SERVER,
    FINETUNED: KSERVER_SERVER,
    STABLE_DIFFUSION: KSERVER_SERVER,
    YOLO: KSERVER_SERVER,
    PYTORCH: TORCH_SERVER,
    PHI_3_MINI_128K_INSTRUCT: VLLM_SERVER,
    STABLE_DIFFUSION_XL: KSERVER_SERVER,
    STABLE_VIDEO_DIFFUSION_XT: KSERVER_SERVER,
    NEMOTRON_3_8B_CHAT_4K_RLHF: TRITON_SERVER,
    NVIDIA_NV_EMBED_V1: KSERVER_SERVER,
    LLAMA_3_1_8B_INSTRUCT: VLLM_SERVER
}
TRITON_SERVER_READINESS_PATH = "/v2/health/ready"
KSERVER_SERVER_READINESS_URL = "/v2/health/ready"
VLLM_SERVER_READINESS_URL = "/health"
TORCH_SERVER_READINESS_URL = "/ping"
FINETUNED_FRAMEWORKS_READINESS_URL_MAPPING = {
    FINETUNED_VLLM_OPENAI_IMAGE: VLLM_SERVER_READINESS_URL,
    FINETUNED_MISTRAL_8X7B_INFERENCE_IMAGE: KSERVER_SERVER_READINESS_URL,
    FINETUNED_STABLE_DIFFUSION_2_INFERENCE_IMAGE: KSERVER_SERVER_READINESS_URL,
    FINETUNED_STABLE_DIFFUSION_XL_INFERENCE_IMAGE: KSERVER_SERVER_READINESS_URL,
}
SERVER_TYPE_READINESS_URL_MAPPING = {
    TRITON_SERVER: TRITON_SERVER_READINESS_PATH,
    VLLM_SERVER: VLLM_SERVER_READINESS_URL,
    KSERVER_SERVER: KSERVER_SERVER_READINESS_URL,
    TORCH_SERVER: TORCH_SERVER_READINESS_URL
}
FRAMEWORKS = tuple(
    (framework, framework) for framework in FRAMEWORKS_VALUES
)
VLLM_FRAMEWORK_LIST = [VLLM, STARCODER2_7B, MIXTRAL8X7B_INSTRUCT, MIXTRAL7B_INSTRUCT, PHI_3_MINI_128K_INSTRUCT, MPT, GEMMA_7B_IT, GEMMA_2B_IT, LLAMA_3_8B_INSTRUCT, LLMA, CODE_LLAMA, LLAMA_3_1_8B_INSTRUCT]
ADDITIONAL_PLAYGROUND_FRAMEWORKS = [NEMO_RAG_SERVICE]
PLAYGROUND_FRAMEWORK_LIST = VLLM_FRAMEWORK_LIST + ADDITIONAL_PLAYGROUND_FRAMEWORKS
PUBLIC = "public"
PRIVATE = "private"
CONTAINER_TYPE = ((PUBLIC, PUBLIC), (PRIVATE, PRIVATE))
PASSWORD_AUTH = "pass"
DOCKET_CONFIG = "docker"
AUTH_TYPES = ((PASSWORD_AUTH, PASSWORD_AUTH), (DOCKET_CONFIG, DOCKET_CONFIG))
TCP = "tcp"
HTTP = "http"
HTTPS = "https"
PROTOCOL_TYPE = ((TCP, TCP), (HTTP, HTTP), (HTTPS, HTTPS))

VLLM_OPENAI_ONLY_IMAGE = 'vllm/vllm-openai'
ALLOWED_CONTAINER_IMAGES = {
    STARCODER2_7B: [VLLM_OPENAI_ONLY_IMAGE],
    GEMMA_7B: ['aimle2e/triton_trt_llm', 'registry.e2enetworks.net/aimle2e/triton_trt_llm'],
    GEMMA_7B_IT: [VLLM_OPENAI_ONLY_IMAGE],
    GEMMA_2B: ['aimle2e/triton_trt_llm', 'registry.e2enetworks.net/aimle2e/triton_trt_llm'],
    GEMMA_2B_IT: [VLLM_OPENAI_ONLY_IMAGE],
    LLMA: [VLLM_OPENAI_ONLY_IMAGE],
    STABLE_DIFFUSION: ['registry.e2enetworks.net/aimle2e/stable-diffusion-2-1', ],
    YOLO: ['registry.e2enetworks.net/aimle2e/yolov8', ],
    MPT: [VLLM_OPENAI_ONLY_IMAGE],
    CODE_LLAMA: [VLLM_OPENAI_ONLY_IMAGE],
    STABLE_DIFFUSION_XL: ['registry.e2enetworks.net/aimle2e/stable-diffusion-xl-base-1.0'],
    FINETUNED: ['registry.e2enetworks.net/aimle2e/finetuned-mixtral8x7b-server',
                'registry.e2enetworks.net/aimle2e/finetuned-stable-diff-sdxl',
                'registry.e2enetworks.net/aimle2e/finetuned-stable-diff-2',
                VLLM_OPENAI_ONLY_IMAGE, ],
    MIXTRAL7B: ['registry.e2enetworks.net/aimle2e/mistral-7b-v0.1', ],
    MIXTRAL8X7B: ['registry.e2enetworks.net/aimle2e/mistral-8x7b-v0.1', ],
    MIXTRAL7B_INSTRUCT: ['registry.e2enetworks.net/aimle2e/mistral-7b-instruct-v0.1', VLLM_OPENAI_ONLY_IMAGE],
    MIXTRAL8X7B_INSTRUCT: ['registry.e2enetworks.net/aimle2e/mixtral-8x7b-instruct-v0.1', VLLM_OPENAI_ONLY_IMAGE],
    TENSORRT: ['registry.e2enetworks.net/aimle2e/tritonserver',],
    PYTORCH: ['',],
    TRITON: ['',],
    LLAMA_3_8B_INSTRUCT: [VLLM_OPENAI_ONLY_IMAGE],
    VLLM: [VLLM_OPENAI_ONLY_IMAGE],
    PHI_3_MINI_128K_INSTRUCT: [VLLM_OPENAI_ONLY_IMAGE],
    STABLE_VIDEO_DIFFUSION_XT: ['aimle2e/stable-video-diffusion'],
    NEMOTRON_3_8B_CHAT_4K_RLHF: ['aimle2e/nemotron'],
    NVIDIA_NV_EMBED_V1: ['aimle2e/nv_embed_v1'],
    LLAMA_3_1_8B_INSTRUCT: [VLLM_OPENAI_ONLY_IMAGE]
}

NEMO_RAG_CONFIG_VLLM_ENGINE = "vllm_openai"
NEMO_RAG_CONFIG_VLLM_REQUIRED_KEYS = ["openai_api_base", "openai_api_key", "model_name"]

INVALID_CONTAINER_IMAGE = "Inference container image should be in {allowed_images}"
VAULT_INFERENCE_USERNAME_PATH = "secret/inference/username-{inference_id}"
VAULT_INFERENCE_PASSWORD_PATH = "secret/inference/password-{inference_id}"
INTERVAL_TO_TIME_FORMAT_MAPPING = {
                                        '5m' : [300, '%I:%M:%S%p', 15],
                                        '1h' : [3600, '%I:%M%p', 180],
                                        '1d' : [86400, '%I:%M:%p', 3600],
                                        '7d' : [604800, '%m/%d/%Y, %I%p', 28800],
                                        '1mn' : [2592000, '%m/%d/%Y', 86400]
                                }
DEFAULT_SERVICE_NAME_INFERENCE = "is-{}-predictor-default" #format it with inference id
INFERENCE_ID_ERROR = "Inference ID not found"
INFERENCE_NOT_FOUND_ERROR = "Invalid Inference ID"
INFERENCE_MONITORING_DATA_GET_ERROR = "Monitoring data not available at this moment!"
INVALID_MODEL_TYPE_FOR_MONITORING = "Monitoring data not available!"
CONTAINER_CPU_USAGE_KEY = "container_cpu_usage_seconds_total"
P50 = 'p50'
P90 = 'p90'
P99 = 'p99'
QPS = 'qps'
TRITON_METRICS_NAME_TO_PROMETHEUS_QUERY_MAP = {
                                            P50 : "nv_inference_request_duration_us",
                                            P90 : "nv_inference_request_duration_us",
                                            P99 : "nv_inference_request_duration_us",
                                            QPS : "nv_inference_count",
                                        }
PYTORCH_METRICS_NAME_TO_PROMETHEUS_QUERY_MAP = {
                                            P50 : "ts_inference_latency_microseconds",
                                            P90 : "ts_inference_latency_microseconds",
                                            P99 : "ts_inference_latency_microseconds",
                                            QPS : "ts_inference_requests_total",
                                        }

INVENTORY_NOT_AVAILABLE_BEFORE_SCALING_TEMPLATE = 'inference/inventory_not_avalailable_before_scaling.html'
UPDATE_AUTO_SCALE_POLICY_ERROR = "error in updating auto scale policy"
UPDATE_AUTO_SCALE_SUCCESS = "auto scale policy updated"
DISABLE_AUTO_SCALE_SUCCESS = "disabled auto_scale_policy"
DEFAULT_SCALE_VALUE = 80
REPLICAS_NOT_PROVIDED = "replicas not provided"
DEFAULT_MIN_REPLICAS = 1
DEFAULT_MAX_REPLICAS = 1
REPLICA_MAX_VALUE = 5
DEFAULT_GRPC_PORT = {
    PYTORCH: 7070,
    TRITON: 9000,
    TENSORRT: 9000,
    NEMOTRON_3_8B_CHAT_4K_RLHF: 8001
}
DEFAULT_SERVICE_GRPC_PORT = {
    PYTORCH: 7070,
    TRITON: 9000,
    TENSORRT: 9000,
    NEMOTRON_3_8B_CHAT_4K_RLHF: 9000
}
NEMOTRON_3_8B_CHAT_4K_RLHF_METRIC_PORT = 8002
NEMOTRON_3_8B_CHAT_4K_RLHF_SERVICE_METRICS_PORT = 8082
DEFAULT_CONTAINER_PORT = 8080
DEFAULT_SERVICE_PORT = 80
DEFAULT_METRICS_PORT = 8082
DEFAULT_SERVICE_METRICS_PORT = 8082
VLLM_METRICS_PORT = 8080
DEFAULT_VLLM_TENSOR_PARALLEL_SIZE = "1"
GET_ACCESS_LOGS_ERROR  = "error getting access logs"
GET_ACCESS_LOGS_FILE_LIST_ERROR = "error getting access logs per hour file list"
LOG_FILE_NOT_DEFINED = "log file not defined"
DEFAULT_ARGS_VLLM = ["--model", "", "--port", "8080", "--tensor-parallel-size", "", "--trust-remote-code"]
DEFAULT_COMMAND_VLLM = ["python3", "-m", "vllm.entrypoints.openai.api_server"]
NEMOTRON_3_8B_CHAT_4K_RLHF_HF_MODEL_ID = "nvidia/nemotron-3-8b-chat-4k-rlhf"
DEFAULT_READINESS_INITIAL_DELAY_SECONDS = 10
DEFAULT_READINESS_PERIOD_SECONDS = 10
DEFAULT_READINESS_TIMEOUT_SECONDS = 10
DEFAULT_READINESS_SUCCESS_THRESHOLD = 1
DEFAULT_READINESS_FAILURE_THRESHOLD = 3
DEFAULT_READINESS_PROTOCOL = 'http'
DEFAULT_READINESS_PORT = '8080'
DEFAULT_READINESS = {
    "initial_delay_seconds": DEFAULT_READINESS_INITIAL_DELAY_SECONDS,
    "period_seconds": DEFAULT_READINESS_PERIOD_SECONDS,
    "timeout_seconds": DEFAULT_READINESS_TIMEOUT_SECONDS,
    "success_threshold": DEFAULT_READINESS_SUCCESS_THRESHOLD,
    "failure_threshold": DEFAULT_READINESS_FAILURE_THRESHOLD,
    "protocol": DEFAULT_READINESS_PROTOCOL,
    "port": DEFAULT_READINESS_PORT
}
EXEC_PROBE_PROTOCOL = 'exec'
DEFAULT_IMAGE_PULL_POLICY = "Always"
WRONG_FORMAT_ARGS_COMMANDS = 'inappropriate format of args and commands'
WRONG_FORMAT_PROBE_EXEC_COMMAND = 'inapproptriate command format in {} probe'

# inference filter keys dict mapping
INFERENCE_FILTER_KEY_MAPPING = {
    "name": "name__in",
    "model_ids": "model__id__in",
    "status": "status__in",
    "sku_name": "sku__name__in",
    "framework": "framework__in",
    "gpu_card_type": "sku__gpu_card_type__in",
    "created_by": "created_by__email__in",
}
INFERENCE_EXCLUDE_KEY_MAPPING = {
    "not_name": "name__in",
    "not_model_ids": "model__id__in",
    "not_status": "status__in",
    "not_sku_name": "sku__name__in",
    "not_framework": "framework__in",
    "not_gpu_card_type": "sku__gpu_card_type__in",
    "not_created_by": "created_by__email__in",
}
CANNOT_RESTART_INFERENCE = "Model endpoint cannot be restarted when in {status} status"
INFERENCE_RESTARTING_FAILED = "Failed to restart Model Endpoint"
INFERENCE_RESTARTED = "Model Endpoint restarted successfully"


# model repo search filter
MODEL_REPO_FILTER_KEY_MAPPING = {
    "name": "name__in",
    "finetuning_id": "finetuning_id__in",
    "created_by": "created_by__email__in",
}
MODEL_REPO_EXCLUDE_KEY_MAPPING = {
    "not_name": "name__in",
    "not_created_by": "created_by__email__in",
}
INFERENCE_ALREADY_STOPPED = "Inference already stopped"
COMMITTED_INFERENCE_STOP_NOT_ALLOWED = "Committed Model Endpoints cannot be Stopped"
CHANGE_UPDATION_POLICY_UPDATE = "Updation policy for reserved instance updated"
MODEL_LOAD_INTEGRATION_ID = "model_load_integration_id"
HF_MODEL_ID = "hugging_face_id"

FRAMEWORK_TO_HF_MODEL_ID_MAPPING = {
    NEMOTRON_3_8B_CHAT_4K_RLHF: NEMOTRON_3_8B_CHAT_4K_RLHF_HF_MODEL_ID,
    NVIDIA_NV_EMBED_V1: "nvidia/NV-Embed-v1",
    STABLE_DIFFUSION: "stabilityai/stable-diffusion-2-1",
    STABLE_DIFFUSION_XL: "stabilityai/stable-diffusion-xl-base-1.0",
    STABLE_VIDEO_DIFFUSION_XT: "stabilityai/stable-video-diffusion-img2vid-xt",
}
