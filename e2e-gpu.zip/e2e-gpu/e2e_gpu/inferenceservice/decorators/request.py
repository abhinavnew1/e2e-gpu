import json
import logging

from django.db.models import Q
from rest_framework.response import Response

from e2e_core.api.v1.services.base import BaseService
from e2e_core.constants import (INVALID_ACTION, NOT_FOUND_ERROR,
                                PARAMS_MISSING_OR_INVALID, UNAUTHORIZED_ACCESS)
from e2e_core.helpers import get_pk_or_name_from_value
from eos.constants import OBJECT_DOWNLOAD_ACTION, OBJECT_UPLOAD_ACTION
from gpu_service.constants import COMMITTED
from gpu_service.models import Image, StockKeepingUnit, SkuItemPrice
from inferenceservice.constants import INVALID_SKU_PROVIDED
from inferenceservice.models import Inference, Model
from rbac.constants import INFERENCE_SERVICE
from reserve_instance.constants import (AUTO_RENEW_STATUS, CONVERT_TO_HOURLY_BILLING, INSTANCE_UPDATION_LIST,
                                        INVALID_SKU_AND_UPDATION_POLICY, INVALID_UPDATION_POLICY)
logger = logging.getLogger(__name__)


def load_model(func):
    def wrapper_func(*args, **kwargs):
        # todo(amol): need to check user has access to the project?
        model_id = kwargs.get("model_id", "")
        if not model_id:
            request_body = json.loads(args[0].request.body)
            model_id = request_body.get("model_id")

        model_id, model_name = get_pk_or_name_from_value(model_id)
        project_id = kwargs.get("project_id", "")
        model = Model.objects.filter(Q(id=model_id) | Q(name=model_name),
                                     deleted_at__isnull=True, project_id=project_id).\
            select_related("project", "bucket").last()

        if not model:
            response = BaseService.get_404_response(NOT_FOUND_ERROR.format(service="Model"))
            return Response(response, status=response.get("code"))
        kwargs["model"] = model
        return func(*args, **kwargs)

    return wrapper_func


def validate_object_upload_download_action(func):
    def wrapper_func(*args, **kwargs):
        query_params = args[2]
        file_name = query_params.get("file_name")
        if not file_name:
            return BaseService.get_baked_412_response(PARAMS_MISSING_OR_INVALID.format(param="file_name"))
        action = query_params.get("action")
        if not (action == OBJECT_UPLOAD_ACTION or action == OBJECT_DOWNLOAD_ACTION):
            return BaseService.get_baked_400_response(INVALID_ACTION)
        return func(*args, **kwargs)

    return wrapper_func


def load_sku(func):
    def wrapper_func(*args, **kwargs):
        request_body = json.loads(args[0].request.body)
        sku_id = request_body.get("sku_id")
        sku = StockKeepingUnit.objects.filter(id=sku_id).last()
        if not sku:
            response = BaseService.get_404_response(NOT_FOUND_ERROR.format(service=INFERENCE_SERVICE))
            return Response(response, status=response.get("code"))

        if sku.category != INFERENCE_SERVICE:
            response = BaseService.get_412_response(INVALID_SKU_PROVIDED)
            return Response(response, status=response.get("code"))

        kwargs["sku"] = sku
        return func(*args, **kwargs)

    return wrapper_func


def load_inference(func):
    def wrapper_func(*args, **kwargs):
        inference_id = kwargs.get("inference_id")
        
        inference = Inference.objects.filter(id=inference_id, deleted_at__isnull=True).last()
        if not inference:
            response = BaseService.get_404_response(NOT_FOUND_ERROR.format(service="Inference"))
            return Response(response, status=response.get("code"))
        kwargs["inference"] = inference
        return func(*args, **kwargs)

    return wrapper_func


def validate_reserve_instance_policy_update(func):
    def wrapper_func(*args, **kwargs):
        committed_instance_policy = args[2].get("committed_instance_policy")
        next_sku_item_price_id = args[2].get("next_sku_item_price_id")
        next_sku_item_price = kwargs.get("next_sku_item_price", SkuItemPrice.objects.filter(id=next_sku_item_price_id, is_active=True, sku__is_active=True).first())
        inference = args[1]
        committed_instance = inference.get_reserve_instance_entry()
        sku_item_price = committed_instance.sku_item_price
        if committed_instance_policy not in INSTANCE_UPDATION_LIST:
            return args[0].get_baked_400_response(INVALID_UPDATION_POLICY)
        if committed_instance_policy in [CONVERT_TO_HOURLY_BILLING, AUTO_RENEW_STATUS] and not isinstance(next_sku_item_price_id, int):
            return args[0].get_baked_400_response(INVALID_SKU_AND_UPDATION_POLICY)
        if next_sku_item_price_id and next_sku_item_price.sku != sku_item_price.sku:
            return args[0].get_baked_400_response(PARAMS_MISSING_OR_INVALID.format(param="next_sku_item_price_id"))
        kwargs["next_sku_item_price"] = next_sku_item_price
        kwargs["committed_instance"] = committed_instance
        return func(*args, **kwargs)
    return wrapper_func
