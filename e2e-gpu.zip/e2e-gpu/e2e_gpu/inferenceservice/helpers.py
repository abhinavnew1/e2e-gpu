import logging
import re
import yaml

from minio import Minio
from django.conf import settings
from django.template.loader import get_template
from dbtemplates.models import Template
from rest_framework import status
from django.db.models import Q

from e2e_core.api.v1.services.base import BaseService
from e2e_core.api.v1.services.mandrill import Mandrill
from e2e_core.helpers import advanced_search_filter, process_boolean
from gpu_service.constants import GPU_SERIES
from gpu_service.helpers import (check_inventory_availability_status,
                                 get_sku_wise_available_gpu_inventory_count)
from inferenceservice.constants import (ERROR, ERROR_IN_OBJECT_LISTING,
                                        FAILED_TO_VALIDATE_MODEL,
                                        INFERENCE_NAME_ALREADY_EXISTS,
                                        INVENTORY_NOT_AVAILABLE_BEFORE_SCALING_TEMPLATE,
                                        INVENTORY_UNAVAILABLE, MODEL_NOT_FOUND,
                                        NAME_INVALID, NAME_REGEX,
                                        NEMO_RAG_CONFIG_FETCH_ERROR, NEMO_RAG_CONFIG_MISSING_ERROR,
                                        PRE_BUILD, READY,
                                        STOPPED, TERMINATING, VALID, WAITING, RUNNING, 
                                        RETRYING, WARNING, NOT_FOUND_ERROR, MODEL, STORAGE_URL, 
                                        INFERENCE_SERVICE, INVALID_SKU_PROVIDED, SKU,
                                        INFERENCE_FILTER_KEY_MAPPING, INFERENCE_EXCLUDE_KEY_MAPPING,
                                        MODEL_REPO_FILTER_KEY_MAPPING, MODEL_REPO_EXCLUDE_KEY_MAPPING,
                                        PLAYGROUND, FINETUNED, PLAYGROUND_FRAMEWORK_LIST,
                                        FINETUNED_VLLM_OPENAI_IMAGE_WITHOUT_VERSION)
from inferenceservice.models import FrameworkDetail, Inference, Model
from teams.helpers import get_team_owner_admin_email_list

logger = logging.getLogger(__name__)

mandrill_manager = Mandrill(mandrill_api_token=settings.MANDRILL_API_TOKEN, bcc="",
                            from_email=settings.NOTIFY_FROM, notify=settings.NOTIFY_FROM)


def update_inferences_data(inferences, groot_inferences_list, *args, **kwargs):
    messages = {}
    for inference in inferences:
        inf_data = groot_inferences_list.get(f"is-{inference.id}") or groot_inferences_list.get(f"{inference.id}")
        if inf_data and inf_data.get('status') and inf_data['status'].get("phase"):
            if inf_data['status']["phase"] == WAITING and inf_data['status']['state'] == "UNSCHEDULABLE":
                inference.status = ERROR
                inference.update_end_date_in_inference_history()
            elif inf_data['status']["phase"] in [READY, RUNNING, RETRYING, WARNING, WAITING]:
                inference.status = inf_data['status']["phase"]
                inference.create_inference_history()
            else:
                inference.status = inf_data['status']["phase"]
                inference.update_end_date_in_inference_history()
            messages[inference.id] = inf_data['status']['message']
        else:
            inference.status = STOPPED
            inference.update_end_date_in_inference_history()
    Inference.objects.bulk_update(inferences, ['status'])
    return messages


def validate_inference_name(name):
    """validates the inference name
    :returns:
        :boolean: is_valid: whether the name is valid or not
        :string: error: why the inference name is not valid
    """
    if not re.fullmatch(NAME_REGEX, name):
        return False, NAME_INVALID
    if Inference.objects.filter(deleted_at__isnull=True, name=name).exists():
        return False, INFERENCE_NAME_ALREADY_EXISTS
    return True, ""


def inference_inventory_check(sku, replica):
    replica = int(replica)
    is_inventory_available = check_inventory_availability_status(sku)

    if not is_inventory_available:
        return False

    if sku.series == GPU_SERIES:

        all_gpus = get_sku_wise_available_gpu_inventory_count()
        current_sku_type_gpus = all_gpus.get(sku.sku_type)
        replica = int(replica) if replica else 1
        if not current_sku_type_gpus or replica > current_sku_type_gpus:
            return False

    return True


def send_inventory_not_available_mail(inference_obj, customer_obj, team_id, team_name, current_replica):
    cc_email_list = get_team_owner_admin_email_list(team_id, emails_to_exclude=[customer_obj.email])
    template_object = Template.objects.filter(name=INVENTORY_NOT_AVAILABLE_BEFORE_SCALING_TEMPLATE).first()
    if not template_object:
        logger.error("INFERENCE | CRITICAL_RED | SEND_INVENTORY_NOT_AVAILABLE_MAIL | INVENTORY_NOT_AVAILABLE_BEFORE_SCALING_TEMPLATE NOT_FOUND")
        return
    subject = template_object.subject
    body = get_template(INVENTORY_NOT_AVAILABLE_BEFORE_SCALING_TEMPLATE).render(
        {"inference_name": inference_obj.name, "project_name": inference_obj.project.name,
         "plan_name": inference_obj.sku.name, "team_name": team_name , "replica_count": current_replica,
         "cloud_support_email_address": settings.CLOUD_PLATFORM_EMAIL}
    )
    try:
        mandrill_manager.send_email([], [customer_obj.email], body, subject, cc_email_list=cc_email_list)
    except Exception as e:
        logger.error(f"INFERENCE | CRITICAL_RED | SEND_INFERENCE_INVENTORY_NOT_AVAILABLE_EMAIL | MAIL - {customer_obj.email} | ERROR_IN_SENDING_EMAIL - {e}")


def read_bucket_file_data(object_name):
    client = Minio(settings.MINIO_SERVER,
                access_key=settings.ACCESS_LOGS_BUCKET_ACCESS_KEY,
                secret_key=settings.ACCESS_LOGS_BUCKET_SECRET_KEY,
                secure=True)
    response = client.get_object(settings.ACCESS_LOGS_BUCKET, object_name)
    file_contents = response.read().decode('utf-8')
    response = [line for line in file_contents.split('\n') if line]
    return response


def get_objects_list_with_prefix(prefix):
    client = Minio(settings.MINIO_SERVER,
                access_key=settings.ACCESS_LOGS_BUCKET_ACCESS_KEY,
                secret_key=settings.ACCESS_LOGS_BUCKET_SECRET_KEY,
                secure=True)
    object_list = client.list_objects(settings.ACCESS_LOGS_BUCKET, prefix=prefix)
    return object_list

def sku_inference_check(sku, replica):
    if not sku:
        response = BaseService.get_404_response(NOT_FOUND_ERROR.format(service=SKU))
        return response

    if sku.category != INFERENCE_SERVICE:
        response = BaseService.get_412_response(INVALID_SKU_PROVIDED)
        return response
    
    if not inference_inventory_check(sku, replica):
        return BaseService.get_412_response(INVENTORY_UNAVAILABLE)
    return BaseService.get_200_response('sku changed successfully')


def inferences_search_filter(inferences_qs, **kwargs):
    # advanced search
    if process_boolean(kwargs.get("is_advanced_search"), False):
        inferences_qs = advanced_search_filter(
            inferences_qs, INFERENCE_FILTER_KEY_MAPPING, INFERENCE_EXCLUDE_KEY_MAPPING, **kwargs
        )
    return inferences_qs


def playground_search_filter(inferences_qs, **kwargs):
    # Filters the inferences queryset to include only those compatible with playground.
    if kwargs.get('inference_support') == PLAYGROUND:
        inferences_qs = inferences_qs.filter(
            Q(framework__in=PLAYGROUND_FRAMEWORK_LIST) |
            (Q(framework=FINETUNED) & Q(custom_endpoint_details__container__container_name__startswith=FINETUNED_VLLM_OPENAI_IMAGE_WITHOUT_VERSION))
        )
    return inferences_qs


def get_framework_entry(framework_name):
    framework_detail = FrameworkDetail.objects.filter(name=framework_name).last()
    return framework_detail


def validate_nemo_rag_config_yaml(dataset, config_path):
    from inferenceservice.api.v1.serializers import NemoRAGConfigValidator
    bkt = dataset.bucket.bucket_name
    client = Minio(settings.S3_ENDPOINT,
                   access_key=dataset.access_key.access_key,
                   secret_key=dataset.access_key.secret_key)

    # fetch config.yaml
    if not config_path.endswith('/'):
        config_path += '/'
    objects = client.list_objects(bkt, prefix=config_path)
    config_name = ""
    for obj in objects:
        if "config.yml" in obj.object_name or "config.yaml" in obj.object_name:
            config_name = obj.object_name
            break
    if not config_name:
        return False, NEMO_RAG_CONFIG_MISSING_ERROR

    # validate config.yaml
    resp = client.get_object(bkt, config_name)
    if resp.status != status.HTTP_200_OK:
        return False, NEMO_RAG_CONFIG_FETCH_ERROR
    config_yaml_str = resp.read().decode('utf-8')
    config_yaml_json = yaml.safe_load(config_yaml_str)
    config_data = NemoRAGConfigValidator(data=config_yaml_json)
    if not config_data.is_valid():
        return False, config_data.errors

    return True, ""


def model_repo_search_filter(model_repo_qs, **kwargs):
    # normal search
    if kwargs.get("search_string"):
        search_string = kwargs.get("search_string")
        model_repo_qs = model_repo_qs.filter(name__icontains=search_string)

    # advanced search
    if bool(kwargs.get("is_advanced_search", False)):
        model_repo_qs = advanced_search_filter(
            model_repo_qs, MODEL_REPO_FILTER_KEY_MAPPING, MODEL_REPO_EXCLUDE_KEY_MAPPING, **kwargs
        )

    return model_repo_qs
