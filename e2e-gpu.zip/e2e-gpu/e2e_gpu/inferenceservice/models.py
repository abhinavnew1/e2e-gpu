from datetime import datetime, timedelta

from django.contrib.contenttypes.models import ContentType
from django.db import models

from customer.models import Customer
from dataset.models import Dataset
from e2e_core.helpers import mark_delete_related_objects
from e2e_core.mixins import BaseMixin, SafeDeleteMixinExtended
from eos.models import AccessKey, Bucket
from finetuning.models import FineTuning
from gpu_service.constants import COMMITTED
from gpu_service.models import Image, SkuItemPrice, StockKeepingUnit
from inferenceservice.constants import (DEPLOYING, DONE, FRAMEWORKS,
                                        INFERENCE_NAME_MAX_LENGTH,
                                        INFERENCE_SERVICE_CREATED_BY,
                                        INFERENCE_SERVICE_MODEL,
                                        INFERENCE_SERVICE_STATUS_CHOICES,
                                        MODEL_NAME_MAX_LENGTH,
                                        MODEL_STATUS_CHOICES, MODEL_TYPE,
                                        MODEL_TYPE_MAX_LENGTH, PENDING,
                                        PYTORCH, RESTARTING, STATUS_MAX_LENGTH, STOPPED,
                                        STORAGE_TYPE_CHOICES,
                                        STORAGE_TYPE_MAXIMUM_LENGTH,
                                        STORAGE_URL_MAX_LENGTH, TERMINATING, WAITING)
from integration.models import Integration
from projects.models import Projects
from container_registry.models import NamespaceDetail

CPU_MAX_LENGTH = INFERENCE_NAME_MAX_LENGTH
MEMORY_MAX_LENGTH = INFERENCE_NAME_MAX_LENGTH
GPU_MAX_LENGTH = INFERENCE_NAME_MAX_LENGTH


class ModelTypes(SafeDeleteMixinExtended, BaseMixin):
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    name = models.CharField(choices=MODEL_TYPE, max_length=MODEL_TYPE_MAX_LENGTH, default=PYTORCH)
    created_by = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True)

    def mark_deleted(self):
        if self.deleted_at is None:
            mark_delete_related_objects(self)
            self.deleted_at = datetime.now()
            self.save(update_fields=['deleted_at', 'updated_at'])


class Model(SafeDeleteMixinExtended, BaseMixin):
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    model_type = models.CharField(choices=MODEL_TYPE, max_length=MODEL_TYPE_MAX_LENGTH, default=PYTORCH)
    name = models.CharField(max_length=MODEL_NAME_MAX_LENGTH)
    project = models.ForeignKey(Projects, on_delete=models.CASCADE)
    description = models.TextField(default=None, null=True, blank=True)
    storage_type = models.CharField(choices=STORAGE_TYPE_CHOICES, max_length=STORAGE_TYPE_MAXIMUM_LENGTH)
    bucket = models.ForeignKey(Bucket, on_delete=models.PROTECT)
    access_key = models.ForeignKey(AccessKey, on_delete=models.PROTECT)
    secret = models.CharField(max_length=MODEL_NAME_MAX_LENGTH, null=True)
    service_account = models.CharField(max_length=MODEL_NAME_MAX_LENGTH, null=True)
    status = models.CharField(choices=MODEL_STATUS_CHOICES, max_length=STATUS_MAX_LENGTH, default=PENDING)
    created_by = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True)
    finetuning = models.ForeignKey(FineTuning, on_delete=models.PROTECT, null=True, blank=True)
    score = models.JSONField(default={})

    class Meta:
        # Define unique-together constraint for sdk api calls
        unique_together = ['name', 'project']

    def __str__(self):
        return f"<Model({self.id}: {self.name}: {self.storage_type})>"

    def mark_deleted(self):
        if self.deleted_at is None:
            mark_delete_related_objects(self)
            self.bucket.mark_deleted()
            self.access_key.mark_deleted()
            self.status = DONE
            self.deleted_at = datetime.now()
            self.save(update_fields=['deleted_at', 'status', 'updated_at'])


class AutoScalePolicy(SafeDeleteMixinExtended, BaseMixin):
    min_replicas = models.IntegerField(default=1)
    max_replicas = models.IntegerField(default=1)
    rules = models.JSONField(default=dict)
    stability_period = models.CharField(max_length=10)


class Inference(SafeDeleteMixinExtended, BaseMixin):
    created_by = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True,
                                   related_name=INFERENCE_SERVICE_CREATED_BY)
    name = models.CharField(max_length=INFERENCE_NAME_MAX_LENGTH)
    model = models.ForeignKey(Model, on_delete=models.SET_NULL, null=True, related_name=INFERENCE_SERVICE_MODEL, blank=True)
    dataset = models.ForeignKey(Dataset, on_delete=models.SET_NULL, null=True, blank=True)
    project = models.ForeignKey(Projects, on_delete=models.CASCADE)
    model_type = models.CharField(max_length=INFERENCE_NAME_MAX_LENGTH, null=True, blank=True)
    storage_url = models.CharField(max_length=STORAGE_URL_MAX_LENGTH, null=True, blank=True)
    dataset_storage_url = models.CharField(max_length=STORAGE_URL_MAX_LENGTH, null=True, blank=True)
    sku = models.ForeignKey(StockKeepingUnit, on_delete=models.SET_NULL, null=True) # to be removed
    sku_item_price = models.ForeignKey(SkuItemPrice, on_delete=models.SET_NULL, null=True, blank=True)  # sku_item_price will change form committed to hourly when the committed inference is scaled
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    status = models.CharField(choices=INFERENCE_SERVICE_STATUS_CHOICES, max_length=STATUS_MAX_LENGTH, default=DEPLOYING)
    detailed_info = models.JSONField(default=None, null=True, blank=True)
    replica = models.IntegerField(default=1)
    desired_replica = models.IntegerField(default=1)
    committed_replicas = models.IntegerField(default=0)
    framework = models.CharField(choices=FRAMEWORKS, max_length=STATUS_MAX_LENGTH)
    custom_endpoint_details = models.JSONField(default=dict, blank=True)
    is_auto_scale_enabled = models.BooleanField(default=False)
    auto_scale_policy = models.ForeignKey(AutoScalePolicy, null=True, blank=True, on_delete=models.SET_NULL)
    registry_namespace = models.ForeignKey(NamespaceDetail, on_delete=models.SET_NULL, null=True, blank=True)
    model_load_integration = models.ForeignKey(Integration, on_delete=models.SET_NULL, null=True, blank=True)

    def mark_deleted(self):
        if self.deleted_at is None:
            self.status = DONE
            self.deleted_at = datetime.now()
            self.save(update_fields=['deleted_at', 'status', 'updated_at', ])
            self.update_end_date_in_inference_history(end_date=self.deleted_at)
            self.terminate_reserve_instance()

    def stop(self):
        self.status = STOPPED
        self.save(update_fields=['status', 'updated_at', ])

    def mark_waiting(self):
        self.status = WAITING
        self.save(update_fields=['status', 'updated_at', ])

    def mark_terminating(self):
        self.status = TERMINATING
        self.save(update_fields=['status', 'updated_at', ])

    def mark_restarting(self):
        self.status = RESTARTING
        self.save(update_fields=['status', 'updated_at', ])

    def create_inference_history(self, start_date=None, *args, **kwargs):
        start_date = start_date if start_date else datetime.now()
        billable_customer = self.project.team.owner.get_primary_contact()
        inference_history = InferenceHistory.objects.filter(inference=self, customer=billable_customer, sku_item_price=self.sku_item_price,
                                                            end_date__isnull=True).last()
        if inference_history:
            return inference_history
        last_committed_history = InferenceHistory.objects.filter(inference=self, customer=billable_customer,
                                                                sku_item_price__sku_type=COMMITTED, end_date__gte=datetime.now()).last()
        if last_committed_history and self.sku_item_price.sku_type == COMMITTED:
            return last_committed_history

        if  self.replica > self.committed_replicas:
            return InferenceHistory.objects.create(
                customer=billable_customer, inference=self, start_date=start_date,
                sku=self.sku, replica=self.replica - self.committed_replicas,
                sku_item_price=self.sku_item_price
            )
        end_date = start_date + timedelta(days=self.sku_item_price.committed_days) if self.sku_item_price.sku_type == COMMITTED else None
        replica = self.committed_replicas if self.sku_item_price.sku_type == COMMITTED else self.replica
        inference_history = InferenceHistory.objects.create(
            customer=billable_customer, inference=self, start_date=start_date,
            sku=self.sku, replica=replica, end_date=end_date,
            sku_item_price=self.sku_item_price
        )
        if self.sku_item_price.sku_type == COMMITTED:
            from reserve_instance.helpers import deduct_reserve_instance_price_on_my_account
            deduct_reserve_instance_price_on_my_account(billable_customer, self.sku_item_price, inference_history.id, self.name, self.committed_replicas)

        return inference_history

    def update_end_date_in_inference_history(self, end_date=None, *args, **kwargs):
        end_date = end_date if end_date else datetime.now()
        billable_customer = self.project.team.owner.get_primary_contact()
        inf_history = InferenceHistory.objects.filter(inference=self, customer=billable_customer, sku_item_price=self.sku_item_price,
                                                      end_date__isnull=True).last()
        if inf_history:
            inf_history.end_date = end_date
            inf_history.save(update_fields=['end_date', 'updated_at'])

    def is_committed(self):
        from reserve_instance.models import ReserveInstance
        reserve_instance = ReserveInstance.objects.filter(
                content_type_id=ContentType.objects.get_for_model(type(self)).id,
                resource_id=self.id, sku_item_price__sku_type=COMMITTED
            ).last()
        return True if reserve_instance else False

    def get_reserve_instance_entry(self):
        from reserve_instance.models import ReserveInstance

        return ReserveInstance.objects.filter(
                        content_type_id=ContentType.objects.get_for_model(type(self)).id,
                        resource_id=self.id
                    ).last()

    def create_reserve_instance_entry(self, reserve_instance_data, start_date=None):
        if self.sku_item_price.sku_type == COMMITTED:
            from reserve_instance.models import ReserveInstance
            start_date = start_date if start_date else datetime.now()
            reserve_instance = self.get_reserve_instance_entry()
            if not reserve_instance:
                reserve_instance = ReserveInstance.objects.create(resource=self, sku_item_price=self.sku_item_price, next_sku_item_price_id=reserve_instance_data.get("next_sku_item_price_id"),
                                                                  updation_policy=reserve_instance_data["committed_instance_policy"])
            reserve_instance.sku_item_price = self.sku_item_price
            reserve_instance.next_sku_item_price_id = reserve_instance_data.get("next_sku_item_price_id")
            reserve_instance.updation_policy = reserve_instance_data["committed_instance_policy"]
            reserve_instance.save(update_fields=['sku_item_price', 'next_sku_item_price_id', 'updation_policy', 'updated_at',])
            reserve_instance.create_new_transaction(start_date)

    def terminate_reserve_instance(self):
        reserve_instance = self.get_reserve_instance_entry()
        if reserve_instance:
            reserve_instance.terminate()

    @property
    def committed_sku_item_price(self):
        reserve_instance = self.get_reserve_instance_entry()
        if reserve_instance:
            return reserve_instance.sku_item_price
        return self.sku_item_price

    @property
    def committed_info(self):
        return self.get_reserve_instance_entry()


class InferenceHistory(SafeDeleteMixinExtended, BaseMixin):
    customer = models.ForeignKey(Customer, null=True, on_delete=models.SET_NULL)
    inference = models.ForeignKey(Inference, null=True, on_delete=models.SET_NULL)
    start_date = models.DateTimeField()
    end_date = models.DateTimeField(default=None, null=True, blank=True)
    sku = models.ForeignKey(StockKeepingUnit, null=True, on_delete=models.SET_NULL)
    sku_item_price = models.ForeignKey(SkuItemPrice, on_delete=models.SET_NULL, null=True, blank=True)
    replica = models.IntegerField(default=1)

    def __str__(self):
        return f"<InferenceHistory:({self.id}: {self.inference.name}: {self.customer.email})>"


class FrameworkDetail(SafeDeleteMixinExtended, BaseMixin):
    name = models.CharField(choices=FRAMEWORKS, max_length=STATUS_MAX_LENGTH, unique=True)
    supported_models = models.JSONField(default=dict, blank=True)
