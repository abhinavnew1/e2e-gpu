from gpu_service.constants import HOURLY, DELHI_LOCATION
from gpu_service.models import SkuItemPrice
from inferenceservice.models import InferenceHistory, Inference


def update_inferences():
    active_inferences = Inference.objects.filter(deleted_at__isnull=True)
    inference_list = []
    for inference in active_inferences:
        try:
            sku = inference.sku
            if sku:
                sku_item_price = None
                if not inference.sku_item_price:
                    sku_item_price = SkuItemPrice.objects.filter(sku=sku, is_active=True, sku_type=HOURLY,
                                                                 location=DELHI_LOCATION, currency=inference.project.team.owner.currency).last()
                if sku_item_price:
                    inference.sku_item_price = sku_item_price
                    inference_list.append(inference)
        except Exception as e:
            print(f"Error in updating inference sku_item_price | {e}")
    Inference.objects.bulk_update(inference_list, ['sku_item_price'])
    print("update inference completed")


def update_inference_histories():
    history_list = []
    histories = InferenceHistory.objects.filter(sku_item_price__isnull=True)
    for history in histories:
        try:
            sku = history.sku
            if sku:
                sku_item_price = None
                if not history.sku_item_price:
                    sku_item_price = SkuItemPrice.objects.filter(sku=sku, is_active=True, sku_type=HOURLY,
                                                                 location=DELHI_LOCATION, currency=history.inference.project.team.owner.currency).last()
                if sku_item_price:
                    history.sku_item_price = sku_item_price

                    history_list.append(history)
        except Exception as e:
            print(f"Error in updating inference history sku_item_price | {e}")
    InferenceHistory.objects.bulk_update(history_list, ["sku_item_price"])
    print("update inference history completed")


def run():
    update_inferences()
    update_inference_histories()


run()
