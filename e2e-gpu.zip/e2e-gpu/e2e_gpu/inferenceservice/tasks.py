import logging

from e2e_gpu.celery import app
from inferenceservice.constants import DELETE_OBJECT_STORAGE_FOR_MODEL_TASK

logger = logging.getLogger(__name__)


@app.task(
    name=DELETE_OBJECT_STORAGE_FOR_MODEL_TASK,
    bind=True,
)
def delete_object_storage_for_model_task(self, *args, **kwargs):
    from inferenceservice.api.v1.services.model_service import ModelService
    model = kwargs.get("model")
    customer_auth_header = kwargs.get("customer_auth_header")
    customer = kwargs.get("customer")
    project = kwargs.get("project")
    ModelService(customer, project).delete_model_bucket(model, customer_auth_header)
