from django.contrib import admin
from safedelete.admin import SafeDeleteAdmin

from integration.models import Integration


class IntegrationAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "deleted_at",
        "id",
        "name",
        "project",
        "created_by",
        "integration_type",
        "integration_details",
        "created_at",
        "updated_at",
    )
    raw_id_fields = (
        "project",
        "created_by",
    )
    search_fields = (
        "id",
        "name",
        "project__name",
        "created_by__email",
    )
    list_filter = (
        "deleted",
        "deleted_at",
        "integration_type",
    )
    list_display_links = (
        "id",
        "name",
    )
    list_select_related = (
        "project",
        "created_by",
    )


admin.site.register(Integration, IntegrationAdmin)
