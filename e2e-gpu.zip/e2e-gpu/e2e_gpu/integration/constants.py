from django.conf import settings

from e2e_core.constants import MAX_LENGTH_ERROR

CREATE_REGISTRY_SECRET_URL = (
    settings.GROOT_BASE_URL + "api/namespaces/{namespace}/docker-secret"
)
DELETE_REGISTRY_SECRET_URL = (
    settings.GROOT_BASE_URL + "api/namespaces/{namespace}/docker-secret/{secret}"
)
CUSTOM_CONTAINER_REGISTRY = "Custom container registry"
E2E_CONTAINER_REGISTRY = "E2E container registry"
DOCKER_HUB_CONTAINER_REGISTRY = "Docker Hub"
DEFAULT_VAULT_PATH_INTEGRATION = "secret/integration/integration-{integration_id}"
INTEGRATION_NAME_MAX_LENGTH = 128
INTEGRATION_NAME_MAX_LENGTH_ERROR = MAX_LENGTH_ERROR.format(
    field_name="Integration Name", max_length=INTEGRATION_NAME_MAX_LENGTH
)
INTEGRATION_NAME_ALREADY_EXISTS = (
    "Integration with the same name already exists in the Project."
)
INTEGRATION_VAULT_ERROR = "Integration Can not be saved. Please try again!"
INTEGRATION_FILTER_KEY_MAPPING = {
    "name": "name__in",
    "created_by": "created_by__email__in",
}
INTEGRATION_EXCLUDE_KEY_MAPPING = {
    "not_name": "name__in",
    "not_created_by": "created_by__email__in",
}
INTEGRATION_CREATE_EVENT = "INTEGRATION_CREATE"
INTEGRATION_DELETE_EVENT = "INTEGRATION_DELETE"
INTEGRATION_UPDATE_EVENT = "INTEGRATION_UPDATE"
INTEGRATION_INVALID_REQUEST = "Invalid Request! Integration not found"
E2E = "E2E"
INTEGRATION_DETAILS_NOT_EXISTS = (
    "Invalid Request! Integration details not found"
)
INVALID_INTEGRATION_TYPE_ERROR = "Invalid Integration type found!"
CUSTOM = "Custom"
INTEGRATION_REGISTRY_ENDPOINT_NOT_EXISTS = (
    "Invalid Request! Integration registry endpoint not found"
)
INTEGRATION_AUTH_DETAILS_NOT_EXISTS = (
    "Invalid Request! Integration registry auth details not found"
)
INTEGRATION_UPDATE_SUCCESS = "Integration updated successfully"
INTEGRATION_GROOT_CREATION_FAILED = (
    "Failed to create registry integration currently. Please try again!"
)
INTEGRATION_GROOT_DELETION_FAILED = (
    "Failed to delete registry integration currently. Please try again!"
)
INTEGRATION_GROOT_UPDATION_FAILED = (
    "Failed to update registry integration currently. Please try again!"
)
DEFAULT_SECRET_NAME = "secret-{}"
DOCKER_REGISTRY = "registry"
GITHUB = "github"
WEIGHTS_BIASES = "weights_biases"
HUGGING_FACE_INTEGRATION = "hugging_face"
INTEGRATION_DETAILS = "integration_details"
HF_USERNAME = "hugging_face_username"
HF_TOKEN = "hugging_face_token"
INTEGRATION_TYPE_CHOICES = ((DOCKER_REGISTRY, DOCKER_REGISTRY), (GITHUB, GITHUB), (WEIGHTS_BIASES, WEIGHTS_BIASES), (HUGGING_FACE_INTEGRATION, HUGGING_FACE_INTEGRATION))
INTEGRATION_WANDB_PROJECT_NOT_EXISTS = "Invalid Request! Integration wandB project name not found"
INTEGRATION_HUGGING_FACE_NOT_EXISTS = "Invalid Request! Integration with hugging_face not found"
INTEGRATION_HUGGING_FACE_FAILED_TO_VALIDATE_TOKEN = "Failed to validate huggingface token"
INTEGRATION_VALIDATION_NOT_SUPPORTED = "Validation for {integration_type} is currently not supported "
INTEGRATION_HF_TOKEN_MISSING = f"{HF_TOKEN} field is missing in request body"
INTEGRATION_HF_VALIDATION_FAILED = "Failed to validate huggingface token"
INTEGRATION_HF_VALIDATION_SUCCESS = "Huggingface token validated successfully"
INVALID_INTEGRATION_TYPE = "{integration_type} integration type does not support this method"
HF_MODEL_ACCESS_MISSING_FIELDS = "{HF_MODEL_ID} field is missing from the request body"
HF_MODEL_GIT_LS_URL = "https://huggingface.co/{hf_model_id}/info/refs?service=git-upload-pack"
HF_MODEL_ACCESS_SUCCESS = "Huggingface Token has access to {hf_model_id} model"
HF_MODEL_ACCESS_UNAUTHORIZED = "Huggingface Token does not have access to gated {hf_model_id} model"
HF_MODEL_ACCESS_FAILED = "Failed to access {hf_model_id} model with hugginface token"
