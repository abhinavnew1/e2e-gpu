import logging

from rest_framework import status

from eventlogs.api.v1.services.eventlog_service import EventLogService
from eventlogs.constants import (
    CREATE,
    DELETE,
    EVENTLOG_FAILED_STATUS,
    EVENTLOG_SUCCESS_STATUS,
    INTEGRATION_SERVICE_CODE,
    UPDATE,
)
from integration.constants import (
    INTEGRATION_CREATE_EVENT,
    INTEGRATION_DELETE_EVENT,
    INTEGRATION_UPDATE_EVENT,
)
from integration.models import Integration

logger = logging.getLogger(__name__)


def integration_create_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(INTEGRATION_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=INTEGRATION_CREATE_EVENT,
            resource_name=request.data.get("name"),
            resource_id="",
            detailed_info={
                "integration_type": request.data.get("integration_type"),
                "project_id": kwargs.get("project_id"),
            },
            resource_obj_id=None,
            event_type=CREATE,
        )
        response = func(*args, **kwargs)
        if response.status_code == status.HTTP_201_CREATED:
            event_log.update_log(
                status=EVENTLOG_SUCCESS_STATUS,
                resource_id=response.data["data"]["id"],
                detailed_info={
                    "integration_type": response.data.get("data").get(
                        "integration_type"
                    ),
                    "project_id": kwargs.get("project_id"),
                },
                resource_obj_id=response.data["data"]["id"],
            )
        else:
            event_log.log_event_failure()
        return response

    return wrapper_func


def integration_delete_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(INTEGRATION_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=INTEGRATION_DELETE_EVENT,
            resource_name=kwargs.get("integration").name,
            resource_id=kwargs.get("integration_id"),
            resource_obj_id=kwargs.get("integration_id"),
            detailed_info={"project_id": kwargs.get("project_id")},
            event_type=DELETE,
        )
        response = func(*args, **kwargs)
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else event_log.log_event_failure()
        return response

    return wrapper_func


def integration_update_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(INTEGRATION_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=INTEGRATION_UPDATE_EVENT,
            resource_name=kwargs.get("integration").name,
            resource_id=kwargs.get("integration_id"),
            resource_obj_id=kwargs.get("integration_id"),
            detailed_info={"project_id": kwargs.get("project_id")},
            event_type=UPDATE,
        )
        response = func(*args, **kwargs)
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else event_log.log_event_failure()
        return response

    return wrapper_func
