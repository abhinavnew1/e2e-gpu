import logging

from rest_framework.response import Response

from e2e_core.api.v1.services.base import BaseService
from integration.constants import INTEGRATION_INVALID_REQUEST
from integration.models import Integration

logger = logging.getLogger(__name__)


def validate_integration_request(func):
    def wrapper_func(*args, **kwargs):
        integration_id = kwargs.get("integration_id")
        project_id = kwargs.get("project_id")
        integration = (
            Integration.objects.filter(
                deleted_at__isnull=True, id=integration_id, project_id=project_id
            )
            .select_related("project")
            .first()
        )
        if not integration:
            response = BaseService.get_404_response(INTEGRATION_INVALID_REQUEST)
            return Response(response, status=response.get("code"))
        kwargs["integration"] = integration
        return func(*args, **kwargs)

    return wrapper_func
