from base64 import b64encode
import logging
import requests

from rest_framework import status, serializers

from huggingface_hub import HfApi

from e2e_core.api.v1.services.base import BaseService
from e2e_core.helpers import advanced_search_filter, process_boolean
from integration.constants import (INTEGRATION_EXCLUDE_KEY_MAPPING,
                                   INTEGRATION_FILTER_KEY_MAPPING,
                                   HF_MODEL_GIT_LS_URL, HF_MODEL_ACCESS_SUCCESS,
                                   HF_MODEL_ACCESS_UNAUTHORIZED, HF_MODEL_ACCESS_FAILED,
                                   INTEGRATION_HUGGING_FACE_NOT_EXISTS, HF_USERNAME,
                                   INTEGRATION_HUGGING_FACE_FAILED_TO_VALIDATE_TOKEN)
from integration.models import Integration

logger = logging.getLogger(__name__)


def integrations_search_filter(integration_qs, **kwargs):
    # normal search
    if kwargs.get("search_string"):
        search_string = kwargs.get("search_string")
        integration_qs = integration_qs.filter(name__icontains=search_string)

    # advanced search
    if process_boolean(kwargs.get("is_advanced_search"), False):
        integration_qs = advanced_search_filter(
            integration_qs, INTEGRATION_FILTER_KEY_MAPPING, INTEGRATION_EXCLUDE_KEY_MAPPING, **kwargs
        )

    return integration_qs

def get_registry_integration_obj(integration_name, project_id):
    try:
        return Integration.objects.get(deleted_at__isnull=True, name=integration_name, project_id=project_id)
    except Exception:
        return None


def validate_hf_token(token):
    hf_api = HfApi(token=token)
    try:
        user_info = hf_api.whoami()
        username = user_info["name"]
    except Exception:
        return False, None
    return True, username


def validate_model_access_on_hf_token(hf_model_id, hf_token):
    base64_hf_token = b64encode(f":{hf_token}".encode('utf-8')).decode("ascii")
    headers = {"Authorization": f"Basic {base64_hf_token}"}
    url = HF_MODEL_GIT_LS_URL.format(hf_model_id=hf_model_id)
    response = requests.request("GET", url, headers=headers)

    if response.status_code == status.HTTP_200_OK:
        return BaseService.get_200_response(HF_MODEL_ACCESS_SUCCESS.format(hf_model_id=hf_model_id))
    elif response.status_code == status.HTTP_401_UNAUTHORIZED:
        return BaseService.get_401_response(HF_MODEL_ACCESS_UNAUTHORIZED.format(hf_model_id=hf_model_id))
    else:
        return BaseService.get_412_response(HF_MODEL_ACCESS_FAILED.format(hf_model_id=hf_model_id))


def serializer_validate_hf_integration(integration_details, hf_token):
    if not hf_token:
        raise serializers.ValidationError(INTEGRATION_HUGGING_FACE_NOT_EXISTS)

    is_valid, username = validate_hf_token(hf_token)
    if is_valid:
        integration_details[HF_USERNAME] = username
    else:
        raise serializers.ValidationError(INTEGRATION_HUGGING_FACE_FAILED_TO_VALIDATE_TOKEN)
    return integration_details
