import logging
from datetime import datetime

from django.db import models

from customer.models import Customer
from e2e_core.api.v1.services.vault import VaultService
from e2e_core.helpers import mark_delete_related_objects
from e2e_core.jsonfield import JSONField
from e2e_core.mixins import BaseMixin, SafeDeleteMixinExtended
from integration.constants import (
    DEFAULT_VAULT_PATH_INTEGRATION,
    INTEGRATION_TYPE_CHOICES,
    DOCKER_REGISTRY
)
from projects.models import Projects

logger = logging.getLogger(__name__)


class Integration(SafeDeleteMixinExtended, BaseMixin):
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    name = models.CharField(max_length=50)
    integration_type = models.CharField(
        choices=INTEGRATION_TYPE_CHOICES, max_length=50, default=DOCKER_REGISTRY
    )
    project = models.ForeignKey(Projects, on_delete=models.CASCADE)
    created_by = models.ForeignKey(
        Customer,
        on_delete=models.SET_NULL,
        null=True,
        related_name="integration_created_by",
    )
    integration_details = JSONField(default={})

    class Meta:
        # Define unique-together constraint for sdk api calls
        unique_together = ['name', 'project']

    def __str__(self):
        return f"<Integration({self.id}: {self.name}: {self.integration_type})>"

    def store_auth_details(self, auth_dict):
        try:
            VaultService().create_secret(
                DEFAULT_VAULT_PATH_INTEGRATION.format(integration_id=self.id), auth_dict
            )
            return True
        except Exception as e:
            logger.error(
                f"STORE_AUTH_DETAILS_FAILED | CRITICAL_RED | ERROR {e} INTEGRATION_ID {self.id}"
            )
            return False

    def get_auth_details(self):
        try:
            response = VaultService().get_secret(
                DEFAULT_VAULT_PATH_INTEGRATION.format(integration_id=self.id)
            )
            return response.get("data", {}).get("value", {})
        except Exception as e:
            logger.error(
                f"GET_AUTH_DETAILS_FAILED | CRITICAL_RED | ERROR {e} INTEGRATION_ID {self.id}"
            )
            return {}

    def mark_deleted(self):
        if self.deleted_at is None:
            mark_delete_related_objects(self)
            self.deleted_at = datetime.now()
            self.save(
                update_fields=[
                    "deleted_at",
                    "updated_at",
                ]
            )
