from django.contrib import admin
from safedelete.admin import SafeDeleteAdmin

from invites.models import Invites


class InvitesAdmin(SafeDeleteAdmin):
    raw_id_fields = ("invited_by", "iam_user")
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "deleted_at",
        "email",
        "role",
        "invited_by",
        "iam_user",
        "status",
        "accepted_at",
        "rejected_at",
        "created_at",
        "updated_at",
    )
    search_fields = ("email", "status")
    list_filter = ("deleted", "deleted_at", "status", "role")
    list_display_links = ("id", "email")
    list_select_related = ("invited_by", "iam_user")


admin.site.register(Invites, InvitesAdmin)
