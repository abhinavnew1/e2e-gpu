from rbac.constants import ADMIN, IAM_USER, MEMBER, PROJECT_LEAD, TEAM_LEAD, TEAM_MEMBER


INVITE_IAM_ROLE_CHOICES = (
    (ADMIN, ADMIN),
    (IAM_USER, IAM_USER),
)

INIVTE_TEAM_MEMBER_ROLE_CHOICES = (
    (TEAM_LEAD, TEAM_LEAD),
    (TEAM_MEMBER, TEAM_MEMBER),
)

INVITE_PROJECT_MEMBER_ROLE_CHOICES = (
    (PROJECT_LEAD, PROJECT_LEAD),
    (MEMBER, MEMBER),
)

# invite status
PENDING = "PENDING"
ACCEPTED = "ACCEPTED"
REJECTED = "REJECTED"
CANCELLED = "CANCELLED"
EXPIRED = "EXPIRED"

INVITATION_STATUS_CHOICES = (
    (PENDING, PENDING),
    (ACCEPTED, ACCEPTED),
    (REJECTED, REJECTED),
    (CANCELLED, CANCELLED),
    (EXPIRED, EXPIRED),
)

INVITE_EXPIRY_DAYS = 7

# audit log  actions constants
INVITE_RESOURCE = "invite"

ACCEPT_INVITE_EVENT = "ACCEPT_INVITE"
REJECT_INVITE_EVENT = "REJECT_INVITE"
CREATE_INVITE_EVENT = 'INVITE_USER'
RESEND_INVITE_EVENT = "RESEND_INVITE"
DELETE_INVITE_EVENT = "DELETE_INVITE"

INVITATION_MAIL_TEMPLATE = "invite/add_user_invitation.html"

# invite error/success message
RESEND_INVITE_ALREAY_ACCEPTED = "The invitation has already been accepted"
ON_MYACCOUNT_IAM_CREATION_FAILED = 'Unable to create a user on MyAccount'

INVITE_NOT_FOUND = "The invitation does not exist"
INVITATION_EXPIRED = "The invitation has expired"
INVITE_ALREADY_EXIST = "An invite already exists for this email"
IAM_USER_ALREADY_EXIST = "The IAM user with this email address already exists"

ASSIGN_ROLE_ERROR = "Do not have permission to add user as {role}"
TEAMS_ACCESS_ERROR = "Access Denied: You are not authorized to assign the team with id: {team_id}"
PROJECTS_ACCESS_ERROR = "Access Denied: You are not authorized to assign the  project with id:{project_id}"
USER_POLICIES_ACCESS_ERROR = "Access Denied: You are not authorized to assign the specified policies"
