from datetime import datetime, timedelta
import base64
import json
import logging

import jwt
import requests
from dbtemplates.models import Template
from django.conf import settings
from django.template.loader import get_template

from e2e_core.api.v1.services.mandrill import Mandrill
from e2e_gpu.settings import USER_INVITE_SECRET_KEY
from invites.constants import INVITATION_MAIL_TEMPLATE, INVITE_EXPIRY_DAYS


logger = logging.getLogger(__name__)


CUSTOMER_DETAILS_ENDPOINT = settings.MYACCOUNT_LB_URL + "api/v1/customer-exist/?contact_person_id=null"
CREATE_MYCCOUNT_IAMUSER = settings.MYACCOUNT_LB_URL + "myaccount/publicapi/v1/iam/sync-tir-iam/"
ADD_CONTACT_PERSON_ENDPOINT = settings.MY_ACCOUNT_FRONTEND_URL + "accounts/account-activation/?token={token}"

mandrill_manager = Mandrill(
    mandrill_api_token=settings.MANDRILL_API_TOKEN,
    bcc="",
    from_email=settings.NOTIFY_FROM,
    notify=settings.NOTIFY_FROM,
)


def check_customer_in_my_account(request, email):
    auth_header = request.headers.get("Authorization")
    data = {"email": email}
    url = CUSTOMER_DETAILS_ENDPOINT
    headers = {"Authorization": auth_header, "Content-Type": "application/json"}
    response = requests.request("POST", url, data=json.dumps(data), headers=headers)
    return response


def create_invite_token(owner_email, added_user_email):
    now = datetime.now()
    expiry = now + timedelta(INVITE_EXPIRY_DAYS)
    payload = {
        "owner_user": owner_email,
        "added_user": added_user_email,
        "service_name": "tir-gpu",
        "iat": int(now.timestamp()),
        "exp": int(expiry.timestamp()),
    }
    token = jwt.encode(payload, USER_INVITE_SECRET_KEY, algorithm="HS256").encode("utf-8")

    # Encode the JWT token as a URL-safe base64 string
    url_safe_token = base64.urlsafe_b64encode(token).decode("utf-8").rstrip("=")
    return url_safe_token


def verify_invite_token(token):
    token += "=" * ((4 - len(token) % 4) % 4)
    token_bytes = base64.urlsafe_b64decode(token.encode("utf-8"))
    payload = jwt.decode(token_bytes, USER_INVITE_SECRET_KEY, algorithms=["HS256"])
    if payload["exp"] < datetime.now().timestamp():
        return False
    return True


def create_myaccount_iamuser(request, token):
    auth_header = request.headers.get("Authorization")
    data = {"token": token}
    url = CREATE_MYCCOUNT_IAMUSER
    headers = {"Authorization": auth_header, "Content-Type": "application/json"}
    response = requests.request("POST", url, data=json.dumps(data), headers=headers)
    return response


def send_invitation_mail(owner, email, invite_url=settings.TIR_FRONTEND_URL):
    try:
        invitation_template = INVITATION_MAIL_TEMPLATE
        mail_body = get_template(invitation_template).render(
            {
                "invitation_url": invite_url,
                "customer_name": owner.full_name,
            }
        )
        mail_subject = str(Template.objects.get(name=invitation_template).subject)
        mandrill_manager.send_email([], [email], mail_body, mail_subject)
    except Exception as e:
        logger.error(f"INVITE_SERVICE | SEND_INVITATION_MAIL_FAILED | CRITICAL_RED  | TO_EMAIL:{email} | ERROR: {str(e)}")
