from datetime import datetime
from django.db import models
from e2e_core.helpers import mark_delete_related_objects
from e2e_core.mixins import BaseMixin, SafeDeleteMixinExtended
from customer.models import Customer
from invites.constants import ACCEPTED, INVITATION_STATUS_CHOICES, INVITE_IAM_ROLE_CHOICES, PENDING, REJECTED
from rbac.constants import IAM_USER
from rbac.models import IAM


class Invites(SafeDeleteMixinExtended, BaseMixin):
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    email = models.EmailField(default=None)  # field required # PBAC_TODO: make field required after deployment
    role = models.CharField(choices=INVITE_IAM_ROLE_CHOICES, max_length=250, default=IAM_USER)
    token = models.TextField(default=None)  # PBAC_TODO: make field required after deployment
    teams = models.JSONField(default=list)
    invited_by_deprecated = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True, related_name="invited_by_rel")  # this will be deleted
    invited_by = models.ForeignKey(IAM, on_delete=models.PROTECT, null=True, related_name="invited_user")  # PBAC_TODO: REMOVE NULL
    iam_user = models.OneToOneField(IAM, null=True, default=None, on_delete=models.CASCADE, related_name="invite")
    status = models.CharField(choices=INVITATION_STATUS_CHOICES, default=PENDING, max_length=32)
    accepted_at = models.DateTimeField(default=None, null=True, blank=True)
    rejected_at = models.DateTimeField(default=None, null=True, blank=True)

    class Meta:
        ordering = ["-updated_at"]

    def __str__(self):
        return f"<Invites({self.id}: {self.email}:{self.status})>"

    def mark_deleted(self):
        if self.deleted_at is None:
            mark_delete_related_objects(self)
            self.deleted_at = datetime.now()
            self.save(update_fields=["deleted_at", "updated_at"])

    @classmethod
    def get_active_invites(cls, **filters):
        return cls.objects.filter(deleted_at__isnull=True, **filters)

    def accept_invite(self):
        self.status = ACCEPTED
        self.accepted_at = datetime.now()
        self.save(update_fields=["status", "accepted_at", "updated_at"])

    def reject_invite(self):
        self.status = REJECTED
        self.rejected_at = datetime.now()
        self.save(update_fields=["status", "rejected_at", "updated_at"])
