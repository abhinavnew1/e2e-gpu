from django.contrib import admin

from k8s_tracking.models import K8sEvent


class K8sEventAdmin(admin.ModelAdmin):
    actions = None
    list_display = admin.ModelAdmin.list_display + (
        'id',
        'name',
        'event_uid',
        'reason',
        'message',
        'event_namespace',
        'involved_object_uid',
        'involved_object_name',
        'involved_object_kind',
        'involved_object_namespace',
        'event_time',
        'fetch_time'
    )
    readonly_fields = list_display
    search_fields = ("id", "reason", "message", "involved_object_name", "involved_object_kind", "event_namespace", "involved_object_namespace")
    list_filter = ("involved_object_kind",)


admin.site.register(K8sEvent, K8sEventAdmin)
