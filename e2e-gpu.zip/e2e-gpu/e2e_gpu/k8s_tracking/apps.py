from django.apps import AppConfig


class K8STrackingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'k8s_tracking'
