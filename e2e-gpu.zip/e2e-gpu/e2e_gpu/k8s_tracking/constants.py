from django.conf import settings


# groot urls
GET_ALL_NAMESPACE_EVENTS_URL = settings.GROOT_BASE_URL + "api/get_all_namespace_events"

PV_KIND = "PersistentVolume"
POD_KIND = "Pod"
