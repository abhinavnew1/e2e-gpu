from datetime import datetime, timedelta
import logging
import pickle

from e2e_core.helpers import get_py_object_from_hex_str
from k8s_tracking.helpers import (get_all_namespace_events_from_groot,
                                  get_event_time)
from k8s_tracking.models import K8sEvent
from k8s_watcher.models import K8sPodEvent

logger = logging.getLogger(__name__)


class K8sEventHandler:
    """Used to insert K8s events into gpu backend db, for billing/tracking"""

    def run(self):
        self.insert_new_events()
        self.remove_old_events()

    def insert_new_events(self):

        is_success, events_hex_str = get_all_namespace_events_from_groot()

        if not is_success:
            logger.error("INSERT_K8_EVENTS | CRITICAL_RED | ERROR_DURING_FETCH_EVENT")
            return

        fetch_time = datetime.utcnow()
        events = get_py_object_from_hex_str(events_hex_str)

        received_events_uid = []
        uid_to_events_mapping = {}
        for event in events.items:
            received_events_uid.append(event.metadata.uid)
            uid_to_events_mapping[event.metadata.uid] = event

        self.remove_already_inserted_events(received_events_uid, uid_to_events_mapping)

        new_event_entries = []
        for uid, event in uid_to_events_mapping.items():
            self.construct_new_db_events(uid, event, new_event_entries, fetch_time)

        try:
            write_result = K8sEvent.objects.bulk_create(new_event_entries)
            if len(new_event_entries) == len(write_result):
                logger.info("INSERT_K8_EVENTS | SUCCESSFULLY_INSERTED_EVENT_BULK_CREATE")
            else:
                logger.error(f"INSERT_K8_EVENTS | CRITICAL_RED | PARTIALLY_INSERTED_EVENT_BULK_CREATE | new_event_entries={new_event_entries} | res={write_result}")
        except Exception as e:
            logger.error(f"INSERT_K8_EVENTS | CRITICAL_RED | ERROR_DURING_EVENT_BULK_CREATE => ERROR={e}")

    def construct_new_db_events(self, uid, event, new_event_entries, fetch_time):
        occurance_time = get_event_time(event)
        if occurance_time is None:
            logger.info(f"INSERT_K8_EVENTS | CRITICAL_RED | EVENT_OCCURANCE_TIME_UNDETERMINED | EVENT={event}")
        db_event = K8sEvent(name=event.metadata.name,
                            event_uid=uid,
                            reason=event.reason,
                            message=event.message,
                            fetch_time=fetch_time,
                            event_time=occurance_time,
                            event_namespace=event.metadata.namespace,
                            involved_object_uid=event.involved_object.uid,
                            involved_object_name=event.involved_object.name,
                            involved_object_kind=event.involved_object.kind,
                            involved_object_namespace=event.involved_object.namespace,
                            event_data_binary=pickle.dumps(event)
                            )
        new_event_entries.append(db_event)

    def remove_already_inserted_events(self, received_events_uid: list, uid_to_events_mapping: dict):
        events_already_present_in_db = K8sEvent.objects.filter(event_uid__in=received_events_uid)
        for event in events_already_present_in_db:
            try:
                uid_to_events_mapping.pop(event.event_uid)
            except Exception as e:
                logger.error(f"INSERT_K8_EVENTS | CRITICAL_RED => event={event} => ERROR={e}")

    def remove_old_events(self):
        date_time_now = datetime.now()
        events_older_than_7_days = K8sEvent.objects.filter(fetch_time__lte=date_time_now-timedelta(days=7))
        events_older_than_7_days.delete()
        logger.info("SUCCESSFULLY_REMOVED_OLD_K8s_EVENTS")
        pod_events_older_than_35_days = K8sPodEvent.objects.filter(fetch_time__lte=datetime.utcnow()-timedelta(days=35))
        pod_events_older_than_35_days.delete()
        logger.info("SUCCESSFULLY_REMOVED_OLD_K8s_POD_EVENTS")


run = K8sEventHandler().run
