import pickle
import requests
from datetime import datetime

from rest_framework import status

from k8s_tracking.constants import GET_ALL_NAMESPACE_EVENTS_URL


def get_all_namespace_events_from_groot():
    url = GET_ALL_NAMESPACE_EVENTS_URL
    response = requests.request("GET", url, headers={"e2e-userid": "", "Content-Type": "application/json"})
    if response.status_code != status.HTTP_200_OK:
        return False, response
    return True, response.json()["all_events"]


def get_event_time(event):
    if hasattr(event, "event_time") and isinstance(event.event_time, datetime):
        return event.event_time

    if hasattr(event, "first_timestamp") and isinstance(event.first_timestamp, datetime):
        first_timestamp = event.first_timestamp
    if hasattr(event, "last_timestamp") and isinstance(event.last_timestamp, datetime) :
        last_timestamp = event.last_timestamp
    if first_timestamp == last_timestamp:
        return last_timestamp

    if hasattr(event.metadata, "creation_timestamp") and isinstance(event.metadata.creation_timestamp, datetime):
        creation_timestamp =  event.metadata.creation_timestamp
    if creation_timestamp == last_timestamp:
        return last_timestamp

    return None


# approx time logic for future
# if creation_timestamp + timedelta(seconds=5) > last_timestamp:
#     return last_timestamp