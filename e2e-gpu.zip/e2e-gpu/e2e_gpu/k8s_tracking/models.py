
from datetime import datetime
import pickle

from django.db import models

from e2e_core.mixins import BaseMixin


class K8sEvent(BaseMixin):
    name = models.CharField(max_length=255)
    event_uid = models.CharField(max_length=255, unique=True)
    reason = models.TextField(null=True)
    message = models.TextField(null=True)
    event_namespace = models.CharField(max_length=255, null=True)
    involved_object_uid = models.CharField(max_length=255, null=True)
    involved_object_name = models.CharField(max_length=255, null=True)
    involved_object_kind = models.CharField(max_length=255, null=True)
    involved_object_namespace = models.CharField(max_length=255, null=True)
    event_data_binary = models.BinaryField()
    event_time = models.DateTimeField(null=True)
    fetch_time = models.DateTimeField()

    def __str__(self):
        return f"<K8sEvent({self.name}:{self.id})>"

    def event_data(self):
        return pickle.loads(self.event_data_binary)

    def _delete(self):
        super().delete()

    def delete(self):
        return
