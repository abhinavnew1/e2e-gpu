from django.apps import AppConfig


class K8SWatcherConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'k8s_watcher'
