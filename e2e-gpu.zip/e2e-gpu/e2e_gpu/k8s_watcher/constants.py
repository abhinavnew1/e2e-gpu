NOTEBOOK_CREATE_HOOK = "notebook_create_hook"
NOTEBOOK_UPDATE_HOOK = "notebook_update_hook"
NOTEBOOK_DELETE_HOOK = "notebook_delete_hook"

HPA_CREATE_HOOK = "hpa_create_hook"
HPA_UPDATE_HOOK = "hpa_update_hook"
HPA_DELETE_HOOK = "hpa_delete_hook"

INFERENCE_POD_CREATE_HOOK = "inference_pod_create_hook"
INFERENCE_POD_UPDATE_HOOK = "inference_pod_update_hook"
INFERENCE_POD_DELETE_HOOK = "inference_pod_delete_hook"

INFERENCE_SERVICE_CREATE_HOOK = "inference_service_create_hook"
INFERENCE_SERVICE_UPDATE_HOOK = "inference_service_update_hook"
INFERENCE_SERVICE_DELETE_HOOK = "inference_service_delete_hook"
MODEL_UP_TO_DATE_STATUS = "UpToDate"
MODEL_BLOCKED_BY_FAILED_STATUS = "BlockedByFailedLoad"

POD_NOT_SCHEDULED_STATE = "POD_NOT_SCHEDULED"
POD_UNAVAILABLE_STATE = "POD_UNAVAILABLE"

POD_EVENT_HOOK = "pod_event_hook"
PYTORCH_JOB_UPDATE_STATUS_HOOK = "pytorch_jobs_update_status_hook"

WORKFLOW_EVENT_HOOK = 'workflow_event_hook'
PIPELINE_WORKFLOW_IDENTIFICATION_LABEL = "pipeline/runid"

# fetch time format
FETCH_TIME_FORMAT = '%Y-%m-%dT%H:%M:%S.%fZ'

# pod watcher events type
POD_ADDED = "ADDED"
POD_DELETED = "DELETED"
POD_MODIFIED = "MODIFIED"

RUN_CREATE_HOOK = "run_create_hook"
RUN_DELETE_HOOK = "run_delete_hook"
RUN_UPDATE_HOOK = "run_update_hook"
RUN_POD_IDENTIFICATION_LABEL = "pipeline/runid"
RUN_MAIN_CONTAINER = "main"

# pod status/phases
POD_FAILED = "Failed"
POD_RUNNING = "Running"
POD_PENDING = "Pending"
POD_COMPLETED_CONDITION = 'PodCompleted'
POD_FAILED_CONDITION = 'PodFailed'
POD_SCHEDULED_CONDITION = 'PodScheduled'
