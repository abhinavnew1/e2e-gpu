import logging
from datetime import datetime, timedelta

from crons.base_crons import BaseCrons
from e2e_core.helpers import convert_py_object_to_hex_str
from k8s_watcher.constants import FETCH_TIME_FORMAT
from k8s_watcher.models import K8sPodEvent
from k8s_watcher.tasks import pod_event_hook

logger = logging.getLogger(__name__)
MIN_5 = 5
MIN_10 = 10
HOURS_12 = 12
PROCESS_PENDING_K8S_POD_EVENT_CRON_MAIL_SUBJECT = "PROCESS_PENDING_K8S_POD_EVENTS_RESULT"
PROCESS_PENDING_K8S_POD_EVENT_DESCRIPTION = "PROCESS PENDING K8S POD EVENT CRON: This Cron runs all unprocessed/pending K8sPodEvent hooks, whose execution failed or error occured"


class ProcessPendingK8sPodEventCron(BaseCrons):
    """Used to process and generate report of un-processed/failed K8sPodEvent"""

    def __init__(self, *args, **kwargs):
        super().__init__()

    def run(self):
        unprocessed_events = self.get_pending_unprocessed_events()
        self.process_events(unprocessed_events)
        self._send_report(
            self._errors,
            self._success,
            subject=PROCESS_PENDING_K8S_POD_EVENT_CRON_MAIL_SUBJECT,
            body_description=PROCESS_PENDING_K8S_POD_EVENT_DESCRIPTION
        )

    def get_pending_unprocessed_events(self):
        return K8sPodEvent.objects.filter(is_processed=False,
                                          created_at__lte=datetime.now()-timedelta(minutes=MIN_5),
                                          created_at__gte=datetime.now()-timedelta(minutes=MIN_10, hours=HOURS_12))

    def process_events(self, unprocessed_events):
        for event in unprocessed_events:
            try:
                kwargs = {'event_hex_str': convert_py_object_to_hex_str(event.event_data()),
                          'fetch_time': event.fetch_time.strftime(FETCH_TIME_FORMAT)}
                pod_event_hook(**kwargs)
                self._success.append(f"K8sPodEvent-{event.id}->PROCESSED_SUCCCESSFULLY")
            except Exception as e:
                self._errors.append(f"K8sPodEvent-{event.id}->ERROR={e}")


run = ProcessPendingK8sPodEventCron().run
