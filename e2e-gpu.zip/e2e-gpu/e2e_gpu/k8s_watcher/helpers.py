import logging

from crons.k8s_node_resources_update import UpdateSkuResource
from e2e_core.helpers import process_boolean
from gpu_service.constants import COMMITTED, HOURLY
from gpu_service.helpers import get_hourly_sku_item_price_from_committed
from inferenceservice.helpers import (
    inference_inventory_check,
    send_inventory_not_available_mail,
)
from k8s_watcher.constants import RUN_POD_IDENTIFICATION_LABEL

POD_SCHEDULED = "PodScheduled"
TRUE = "True"
RUN_PHASES = ["Succeeded", "Failed"]
MODIFIED = "MODIFIED"
DELETED = "DELETED"

logger = logging.getLogger(__name__)


def is_run_related_pod(object):
    return object.get("metadata", {}).get("labels", {}).get(RUN_POD_IDENTIFICATION_LABEL, None)


def email_if_inventory_not_available(inference, current_replica):
    if int(current_replica) > inference.replica and not inference_inventory_check(
        inference.sku, int(current_replica) - inference.replica
    ):
        send_inventory_not_available_mail(
            inference,
            inference.created_by,
            inference.project.team.id,
            inference.project.team.name,
            int(current_replica),
        )


def update_sku_item_price_when_replica_count_change(inference, current_replica):
    if (
        inference.sku_item_price
        and inference.sku_item_price.sku_type == COMMITTED
        and current_replica > inference.committed_replicas
    ):
        inference.sku_item_price = get_hourly_sku_item_price_from_committed(
            inference.sku_item_price
        )
        logger.info(f"HPA_WATCHER | CRITICAL_YELLOW | COMMITTED_TO_HOURLY_SKU_ITEM_PRICE | ID:{inference.id}")
    elif (
        inference.sku_item_price
        and inference.sku_item_price.sku_type == HOURLY
        and inference.replica > current_replica
        and current_replica == inference.committed_replicas
    ):
        reserve_instance_entry = inference.get_reserve_instance_entry()
        if reserve_instance_entry:
            inference.sku_item_price = reserve_instance_entry.sku_item_price
            logger.info(f"HPA_WATCHER | CRITICAL_YELLOW | HOURLY_TO_COMMITTED_SKU_ITEM_PRICE | ID:{inference.id}")
    inference.save(update_fields=["sku_item_price"])
    return inference


def process_inventory(event):
    """
    Based on the pod events that occur the database is updated with the latest node information based on the following conditions:
    1. If the pod is related to a run and the phase is either Succeeded or Failed.
        Note: It is impossible to distinguish the event of completed pod.
        This results in the node being updated upto 5 to 6 times for a single run pod.
    2. If it is a non run pod then it is updated when:
        a. If the pod is being scheduled on the node and the event type is MODIFIED.
        b. If the pod is being deleted and the event type is DELETED.
    """
    try:
        pod_event_type = event.get('type', None)
        pod_name = event.get('raw_object', {}).get('metadata', {}).get('name', None)
        is_run_related = is_run_related_pod(event.get('raw_object')) != None
        node_name = event.get('raw_object', {}).get('spec', {}).get('nodeName', None)
        pod_conditions = event.get('raw_object', {}).get('status', {}).get('conditions', [{}])
        phase = event.get('raw_object', {}).get('status', {}).get('phase', None)
        is_scheduled = pod_conditions[0].get('type', None) == POD_SCHEDULED and process_boolean(pod_conditions[0].get('status', False), False)
        if node_name and ((is_run_related and phase in RUN_PHASES) or (pod_event_type == MODIFIED and is_scheduled) or (pod_event_type == DELETED)):
            UpdateSkuResource().update_node_db(node_name)
    except Exception as e:
        logger.error(f"POD_WATCHER | FAILED_TO_UPDATE_INVENTORY | POD_NAME - {pod_name} | K8S_NODE - {node_name} | CONDITION - {pod_conditions} | PHASE - {phase} | ERROR - {e}")
