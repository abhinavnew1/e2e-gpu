from datetime import datetime
import pickle

from django.db import models

from e2e_core.mixins import BaseMixin


class K8sPodEvent(BaseMixin):
    pod_name = models.CharField(max_length=255)
    pod_uid = models.CharField(max_length=255)
    resource_version = models.CharField(max_length=255)
    event_type = models.CharField(max_length=255)
    pod_namespace = models.CharField(max_length=255)
    event_data_binary = models.BinaryField()
    fetch_time = models.DateTimeField()
    is_processed = models.BooleanField(default=False)
    # all time related info is in utc

    class Meta:
        # Define unique-together constraint
        unique_together = ['pod_uid', 'resource_version', 'pod_namespace']

    def __str__(self):
        return f"<K8sPodEvent({self.pod_name}:{self.id})>"

    def event_data(self):
        return pickle.loads(self.event_data_binary)

    def delete(self):
        return
