import datetime
import logging
import pickle

from e2e_gpu.celery import app
from e2e_core.helpers import get_py_object_from_hex_str
from k8s_watcher.api.v1.services import HPAWatcher
from k8s_watcher.api.v1.services.inference_pod_watcher import \
    InferencePodWatcher
from k8s_watcher.api.v1.services.inference_service_watcher import \
    InferenceServiceWatcher
from k8s_watcher.api.v1.services.run_watcher import RunWatcher
from k8s_watcher.api.v1.services.pipeline_workflow_watcher import PipelineWorkflowWatcher
from k8s_watcher.api.v1.services.pytorch_jobs_watcher import PytorchJobWatcher
from k8s_watcher.constants import (FETCH_TIME_FORMAT, HPA_CREATE_HOOK, HPA_DELETE_HOOK,
                                   HPA_UPDATE_HOOK, INFERENCE_POD_CREATE_HOOK,
                                   INFERENCE_POD_DELETE_HOOK,
                                   INFERENCE_POD_UPDATE_HOOK,
                                   INFERENCE_SERVICE_CREATE_HOOK,
                                   INFERENCE_SERVICE_DELETE_HOOK,
                                   INFERENCE_SERVICE_UPDATE_HOOK,
                                   NOTEBOOK_CREATE_HOOK, NOTEBOOK_DELETE_HOOK,
                                   NOTEBOOK_UPDATE_HOOK, WORKFLOW_EVENT_HOOK,
                                   POD_EVENT_HOOK, PYTORCH_JOB_UPDATE_STATUS_HOOK)
from k8s_watcher.helpers import is_run_related_pod, process_inventory
from k8s_watcher.models import K8sPodEvent

logger = logging.getLogger(__name__)


# ----- pod watcher tasks -----

@app.task(name=POD_EVENT_HOOK, bind=True)
def pod_event_hook(self, **kwargs):
    event = get_py_object_from_hex_str(kwargs['event_hex_str'])
    fetch_time = datetime.datetime.strptime(kwargs['fetch_time'], FETCH_TIME_FORMAT)

    pod_name = event.get('raw_object').get('metadata').get('name')
    pod_namespace = event.get('raw_object').get('metadata').get('namespace')
    pod_uid = event.get('raw_object').get('metadata').get('uid')
    event_type = event.get('type')
    resource_version = event.get('object').metadata.resource_version
    obj, is_created = K8sPodEvent.objects.get_or_create(pod_name=pod_name, pod_uid=pod_uid, pod_namespace=pod_namespace,
                                                    resource_version=resource_version, event_type=event_type,
                                                    defaults={"fetch_time": fetch_time,
                                                              "event_data_binary": pickle.dumps(event)})

    if is_created:
        process_inventory(event)

    if obj.is_processed:
        return

    if is_run_related_pod(event.get('object')):
        logger.info(f"RUN_WATCHER | POD_EVENT_HOOK | namespace={pod_namespace}, pod_name={pod_name}, pod_uid={pod_uid}")
        RunWatcher(event.get('type'), event.get('object'),
                   event.get('raw_object'), obj).update_run_related_pods(obj)


# ----- pipeline workflows watcher tasks -----

@app.task(name=WORKFLOW_EVENT_HOOK, bind=True)
def workflow_event_hook(self, **kwargs):
    event = get_py_object_from_hex_str(kwargs['event_hex_str'])
    _ = datetime.datetime.strptime(kwargs['fetch_time'], FETCH_TIME_FORMAT)

    workflow_name = event.get('raw_object').get('metadata').get('name')
    workflow_namespace = event.get('raw_object').get('metadata').get('namespace')
    workflow_uid = event.get('raw_object').get('metadata').get('uid')
    _ = event.get('type')
    _ = event.get('raw_object').get('metadata').get('resourceVersion')

    logger.info(f"WORKFLOW_EVENT_HOOK | namespace={workflow_namespace}, workflow_name={workflow_name}, workflow_uid={workflow_uid}")
    PipelineWorkflowWatcher(event.get('type'), event.get('object'),
                            event.get('raw_object')).update_workflow_related_info()


# ----- notebook watcher tasks -----

@app.task(name=NOTEBOOK_CREATE_HOOK, bind=True)
def notebook_create_hook(self, **kwargs):  # to be implemented along with notebook watcher 
    pass


@app.task(name=NOTEBOOK_UPDATE_HOOK, bind=True)
def notebook_update_hook(self, **kwargs):  # to be implemented along with notebook watcher
    pass


@app.task(name=NOTEBOOK_DELETE_HOOK, bind=True)
def notebook_delete_hook(self, **kwargs):  # to be implemented along with notebook watcher
    pass


# ----- HPA watcher tasks -----

@app.task(name=HPA_CREATE_HOOK, bind=True)
def hpa_create_hook(self, **kwargs):
    HPAWatcher(kwargs.get('object', {})).on_create_hook()


@app.task(name=HPA_UPDATE_HOOK, bind=True)
def hpa_update_hook(self, **kwargs):
    HPAWatcher(kwargs.get('object', {})).on_update_hook()


@app.task(name=HPA_DELETE_HOOK, bind=True)
def hpa_delete_hook(self, **kwargs):
    HPAWatcher(kwargs.get('object', {})).on_delete_hook()


#---- inference pods tasks ----

@app.task(name=INFERENCE_POD_CREATE_HOOK, bind=True)
def inference_pod_create_hook(self, **kwargs):
    InferencePodWatcher(kwargs.get('object', {})).on_create_hook()


@app.task(name=INFERENCE_POD_UPDATE_HOOK, bind=True)
def inference_pod_update_hook(self, **kwargs):
    InferencePodWatcher(kwargs.get('object', {})).on_update_hook()


@app.task(name=INFERENCE_POD_DELETE_HOOK, bind=True)
def inference_pod_delete_hook(self, **kwargs):
    InferencePodWatcher(kwargs.get('object', {})).on_delete_hook()


#---- inference service tasks ----

@app.task(name=INFERENCE_SERVICE_CREATE_HOOK, bind=True)
def inference_service_create_hook(self, **kwargs):
    InferenceServiceWatcher(kwargs.get('object', {})).on_create_hook()


@app.task(name=INFERENCE_SERVICE_UPDATE_HOOK, bind=True)
def inference_service_update_hook(self, **kwargs):
    InferenceServiceWatcher(kwargs.get('object', {})).on_update_hook()


@app.task(name=INFERENCE_SERVICE_DELETE_HOOK, bind=True)
def inference_service_delete_hook(self, **kwargs):
    InferenceServiceWatcher(kwargs.get('object', {})).on_delete_hook()


@app.task(name=PYTORCH_JOB_UPDATE_STATUS_HOOK, bind=True)
def pytorch_jobs_update_status_hook(self, **kwargs):
    event = get_py_object_from_hex_str(kwargs["event_hex_str"])
    logger.debug(f"PYTIRCH_JOBS_EVENT_DATA: {event}")
    PytorchJobWatcher(event.get("raw_object")).update_status(event)
