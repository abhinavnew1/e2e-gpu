from django.contrib import admin, messages
from safedelete.admin import SafeDeleteAdmin
from simple_history.admin import SimpleHistoryAdmin

from model_playground.models import BillableModelParameters, ModelPlayground


class BillableModelParametersInline(admin.TabularInline):
    model = BillableModelParameters
    extra = 0
    can_delete = False

    def has_add_permission(self, request, obj=None):
        return False


class ModelPlaygroundAdmin(SafeDeleteAdmin, SimpleHistoryAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "name",
        "display_name",
        "category",
        "is_active",
        "is_internal",
    )
    raw_id_fields = ()
    search_fields = ("id", "name", "display_name")
    list_filter = (
        "deleted",
        "is_active",
        "category",
        "is_internal",
    )
    list_display_links = (
        "id",
        "name",
        "display_name",
    )
    readonly_fields = ()
    inlines = [BillableModelParametersInline]


class BillableModelParametersAdmin(SafeDeleteAdmin, SimpleHistoryAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "model",
        "parameter",
        "is_active",
    )
    raw_id_fields = ("model",)
    search_fields = ("id", "parameter", "model__name", "display_name")
    list_filter = ("deleted", "is_active", "model__is_active", "model__name", "model__category")
    list_display_links = ("id", "model", "parameter")
    readonly_fields = ()
    list_select_related = ("model",)


admin.site.register(ModelPlayground, ModelPlaygroundAdmin)
admin.site.register(BillableModelParameters, BillableModelParametersAdmin)
