from django.apps import AppConfig


class ModelPlaygroundConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "model_playground"
