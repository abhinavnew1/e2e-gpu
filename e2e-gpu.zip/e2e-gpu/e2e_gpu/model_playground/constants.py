MODEL_PLAYGROUND_BILLABLE_UNIT_SKU_NAME = "Model_Playground_Billable_Unit"
MODEL_PLAYGROUND_NAME_MAX_LENGTH = 50

# model categories
IMAGE_TO_IMAGE = "img2img"
IMAGE_TO_TEXT = "img2txt"
OBJECT_DETECTION = "object-detection"
SPEECH_TO_TEXT = "speech2txt"
TEXT_TO_IMAGE = "txt2img"
TEXT_TO_SPEECH = "txt2speech"
TEXT_TO_TEXT = "txt2txt"
MODEL_CATEGORY_LIST = [
    IMAGE_TO_IMAGE, IMAGE_TO_TEXT, OBJECT_DETECTION, SPEECH_TO_TEXT, TEXT_TO_IMAGE, TEXT_TO_SPEECH, TEXT_TO_TEXT
]
MODEL_CATEGORY_CHOICES = tuple(
    (category, category) for category in MODEL_CATEGORY_LIST
)

# INFLUX DB query constants
DATE_FORMAT_FOR_INFLUXDB_QUERY = "%Y-%m-%dT%H:%M:%SZ"
NAMESPACE_EXACT_FILTER = "= '{namespace_value}'"
NAMEPSACE_MULTIPLE_FILTER = "=~ {namespace_regex} GROUP BY \"e2e-project\""
PARAM_QUERY_FILTER_FORMAT = ", SUM({param}) AS {param}"
INFLUXDB_USER_MODEL_USAGE_QUERY = "SELECT SUM(request_count) AS runs_count, SUM(gpu_usage) AS gpu_usage {params_query_filter} FROM \"request_info_{model_name}\" WHERE time >= '{start_time}' AND time < '{end_time}' AND \"e2e-project\" {namespace_query_filter}"
INFLUXDB_TOTAL_RUNS_COUNTS_QUERY = 'SELECT COUNT(request_count) AS runs_count FROM "request_info_{model_name}"'

# error/success messages
ERROR_GETTING_USAGE = "Unable to retrive data for usage. Please try again!"
PLAYGROUND_MODEL_NOT_FOUND = "Playground Model Not Found!"
BILLABLE_UNIT_NOT_FOUND = "MODEL_PLAYGROUND_SKU_ITEM_PRICE_NOT_FOUND | CURRENCY_ID: {}"

# model request const
MODEL_REQUEST_MSG = "User placed requested for model : {name} in gen-api, project_id : {project_id}"
MODEL_REQUEST_IN_PLAYGROUND = "MODEL REQUEST IN PLAYGROUND"
