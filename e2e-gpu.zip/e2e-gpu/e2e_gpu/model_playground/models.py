import logging

from django.conf import settings
from django.db import models
from influxdb import InfluxDBClient

from e2e_core.jsonfield import JSONField
from e2e_core.mixins import BaseMixin, SafeDeleteMixinExtended
from gpu_service.constants import DEFAULT_LOCATION, HOURLY
from gpu_service.models import Currency, SkuItemPrice
from model_playground.constants import (INFLUXDB_TOTAL_RUNS_COUNTS_QUERY,
                                        MODEL_CATEGORY_CHOICES,
                                        MODEL_PLAYGROUND_BILLABLE_UNIT_SKU_NAME,
                                        MODEL_PLAYGROUND_NAME_MAX_LENGTH)
from rbac.constants import MODEL_PLAYGROUND
from simple_history.models import HistoricalRecords

logger = logging.getLogger(__name__)


class ModelPlayground(SafeDeleteMixinExtended, BaseMixin):
    name = models.CharField(max_length=MODEL_PLAYGROUND_NAME_MAX_LENGTH)
    display_name = models.CharField(max_length=MODEL_PLAYGROUND_NAME_MAX_LENGTH)
    category = models.CharField(choices=MODEL_CATEGORY_CHOICES, max_length=50)
    description = models.TextField(default=None, null=True, blank=True)
    is_active = models.BooleanField(default=True)
    is_internal = models.BooleanField(default=False)
    icon = models.CharField(max_length=128, null=True, blank=True)
    url_info = JSONField(default={}, null=True, blank=True)
    additional_info = JSONField(default={}, null=True, blank=True)
    is_inventory_available = models.BooleanField(default=True)
    is_displayed_on_dashboard = models.BooleanField(default=False, help_text="Boolean field for displaying models on dashboard")
    display_priority = models.IntegerField(default=100, help_text="Based on the value of this field the Models will be listed")

    def __str__(self):
        return f"<Model Playground({self.id}: {self.name})>"

    @property
    def total_runs_count(self):
        model_name = self.name
        runs_count = 0
        try:
            influx_client = InfluxDBClient(**settings.INFLUX_DB_MODEL_PLAYGROUND)
            result = influx_client.query(
                INFLUXDB_TOTAL_RUNS_COUNTS_QUERY.format(model_name=model_name)
            )
            for point in result.get_points():
                runs_count = point.get("runs_count", 0)
        except Exception as e:
            logger.error(
                f"MODEL_PLAYGROUND | CRITICAL_RED | TOTAL_RUNS_COUNT | ERROR:{str(e)}"
            )
        return runs_count

    @classmethod
    def get_active_models_qs(cls, order_by_priority=False):
        if order_by_priority:
            return cls.objects.filter(is_active=True).order_by("display_priority")
        return cls.objects.filter(is_active=True)

    @classmethod
    def get_all_models_qs(cls):
        return cls.objects.all()

    @classmethod
    def billable_unit(cls, currency: Currency) -> SkuItemPrice:
        return SkuItemPrice.objects.filter(
            sku__name=MODEL_PLAYGROUND_BILLABLE_UNIT_SKU_NAME,
            sku__is_active=True,
            sku__category=MODEL_PLAYGROUND,
            currency=currency,
            location=DEFAULT_LOCATION,
            sku_type=HOURLY,  # TODO: check for sku_type
            is_active=True,
        ).select_related("sku", "currency").last()


class BillableModelParameters(SafeDeleteMixinExtended, BaseMixin):
    model = models.ForeignKey(ModelPlayground, on_delete=models.CASCADE)
    parameter = models.CharField(max_length=50, help_text="paramteter name as being stored in influxdb")
    display_name = models.CharField(max_length=50, help_text="parameter name to be displayed to the user")
    count_per_billable_unit = models.FloatField(help_text="parameter count per billable_unit")
    display_cost_factor = models.IntegerField(default=100, help_text="parameter count in terms of which cost is to be shown to the user")
    is_active = models.BooleanField(default=True)
    active_start_date = models.DateTimeField(null=True, blank=True)
    active_end_date = models.DateTimeField(null=True, blank=True)
    description = models.CharField(max_length=500, null=True, blank=True)

    history = HistoricalRecords()

    def __str__(self):
        return f"<BillableModelParameters({self.id}: {self.model.name}: {self.parameter})>"

    @classmethod
    def get_active_billable_params_qs(cls):
        return cls.objects.filter(is_active=True).select_related("model")

    def get_currency_specific_pricing(self, billable_unit_sip: SkuItemPrice):
        cost_per_n_params = (billable_unit_sip.unit_price / self.count_per_billable_unit) * self.display_cost_factor
        param_count_per_unit_currency = self.count_per_billable_unit / billable_unit_sip.unit_price
        return {
            "currency": billable_unit_sip.currency.name,
            "param_count_per_unit_currency": int(round(param_count_per_unit_currency, 0)),
            "cost_per_n_params": round(cost_per_n_params, 2),
            "n_params": self.display_cost_factor,
        }
