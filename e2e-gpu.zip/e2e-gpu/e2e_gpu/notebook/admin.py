from django.contrib import admin
from safedelete.admin import SafeDeleteAdmin

from notebook.models import (Notebook, NotebookDatasetMapping, NotebookHistory,
                             NotebookPVCHistory, NotebookPVCStorage, EgressGatewayDetail)


class NotebookDatasetMappingInline(admin.TabularInline):
    model = NotebookDatasetMapping
    extra = 0
    can_delete = False
    verbose_name = "Mounted Datasets"
    verbose_name_plural = "Mounted Datasets"
    raw_id_fields = ("dataset",)

    def has_add_permission(self, request, obj=None):
        return False


class NotebookAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "deleted_at",
        "id",
        "name",
        "project",
        "image_version",
        "sku_item_price",
        "status",
        # "auto_shutdown_timeout",
        "created_by",
        "slug_name",
        "status_log",
        # "instance_type",
        # "last_activity",
        # "created_at",
        # "updated_at",
        "is_jupyterlab_enabled",
    )
    raw_id_fields = ("project", "image_version", "sku_item_price", "created_by", "pvc", "egress_gateway", "registry_namespace",)
    search_fields = ("id", "name", "project__name", "created_by__email", "slug_name",)
    list_filter = ("deleted", "deleted_at", "status", "sku_item_price__sku__series", "sku_item_price__sku__is_free",
                   "sku_item_price__sku_type", "sku_item_price__committed_days", "image_version__image", ("sku_item_price__sku", admin.RelatedOnlyFieldListFilter),
                   "instance_type", "is_jupyterlab_enabled",)
    list_display_links = ("id", "name",)
    readonly_fields = ("slug_name", "status_log",)
    list_select_related = ("project", "image_version", "image_version__image", "sku_item_price", "sku_item_price__sku", "sku_item_price__currency", "created_by",)
    filter_horizontal = ("ssh_keys",)
    inlines = (NotebookDatasetMappingInline,)


class NotebookHistoryAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "notebook",
        "customer",
        "start_date",
        "end_date",
        "sku_item_price",
    )
    raw_id_fields = ("notebook", "customer", "sku_item_price",)
    search_fields = ("id", "notebook__name", "customer__email", "start_date", "end_date",)
    list_filter = ("deleted", "sku_item_price__sku_type", "sku_item_price__committed_days", "sku_item_price__sku__is_free", ("sku_item_price__sku", admin.RelatedOnlyFieldListFilter),)
    list_display_links = ("id", "notebook",)
    list_select_related = ("notebook", "customer", "sku_item_price", "sku_item_price__sku", "sku_item_price__currency",)
    readonly_fields = ()


class NotebookPVCStorageAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "deleted_at",
        "id",
        "disk_size",
        "notebook",
    )
    raw_id_fields = ()
    search_fields = ("id", "disk_size", )
    list_filter = ("deleted", "deleted_at", )
    list_display_links = ("id", "disk_size",)
    list_select_related = ("notebook",)
    readonly_fields = ()


class NotebookPVCHistoryAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "notebook",
        "disk_size",
        "customer",
        "start_date",
        "end_date",
    )
    raw_id_fields = ("notebook", "customer", )
    search_fields = ("id", "notebook__name", "customer__email", "disk_size", )
    list_filter = ("deleted", )
    list_display_links = ("id", "notebook",)
    list_select_related = ("notebook", "customer",)
    readonly_fields = ()


class NotebookDatasetMappingAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "notebook",
        "dataset",
        "is_mounted",
        "mount_start_date",
        "mount_end_date",
    )
    raw_id_fields = ("notebook", "dataset", )
    search_fields = ("id", "notebook__name", "dataset__name", )
    list_filter = ("is_mounted", "deleted", )
    list_display_links = ("id", "notebook", "dataset")
    list_select_related = ("notebook", "dataset",)
    readonly_fields = ()


class EgressGatewayDetailAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "gateway_name",
        "public_ip",
        "is_active",
        "reserved",
    )
    search_fields = ("id", "gateway_name", "public_ip", )
    list_filter = ("is_active", "deleted", 'reserved')
    list_display_links = ("id", "gateway_name",)
    readonly_fields = ()


admin.site.register(Notebook, NotebookAdmin)
admin.site.register(NotebookHistory, NotebookHistoryAdmin)
admin.site.register(NotebookPVCHistory, NotebookPVCHistoryAdmin)
admin.site.register(NotebookPVCStorage, NotebookPVCStorageAdmin)
admin.site.register(NotebookDatasetMapping, NotebookDatasetMappingAdmin)
admin.site.register(EgressGatewayDetail, EgressGatewayDetailAdmin)