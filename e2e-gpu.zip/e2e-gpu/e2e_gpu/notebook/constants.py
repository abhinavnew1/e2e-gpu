from django.conf import settings

from e2e_core.constants import MAX_LENGTH_ERROR

# notebook groot urls
CREATE_NOTEBOOK_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/notebooks"
LIST_NOTEBOOKS_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/notebooks"
NOTEBOOK_DETAILS_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/notebooks/{notebook_slug}"
UPDATE_NOTEBOOK_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/notebooks/{notebook_slug}"
DELETE_NOTEBOOK_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/notebooks/{notebook_slug}"
DELETE_NOTEBOOK_PVC_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/pvcs/{pvc_name}"
UPGRADE_NOTEBOOK_PVC_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/pvcs/{pvc_name}"
START_STOP_NOTEBOOK_URL = UPDATE_NOTEBOOK_URL
RESTART_NOTEBOOK_URL = UPDATE_NOTEBOOK_URL
UPGRADE_DOWNGRADE_NOTEBOOK_URL = UPDATE_NOTEBOOK_URL
DELETE_NOTEBOOK_SSH_SERVICE = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/service/{service}"
GET_NOTEBOOK_SSH_SERVICE_IP = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/service/{service}"
CREATE_NOTEBOOK_SSH_SERVICE = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/notebooks/{notebook_name}/ssh_service"

NOTEBOOK_ADD_ON_ROOT_PATH = "/{add_on_name}/notebook/{namespace}/{notebook_slug}/"
NOTEBOOK_LAB_URL = settings.NOTEBOOK_BASE_URL + "notebook/{namespace}/{notebook_slug}/lab"

NAME_REGEX = r'^[A-Za-z0-9_-]{1,}$'
NOTEBOOK_NAME_MAX_LENGTH = 50
NOTEBOOK_NAME_MAX_LENGTH_ERROR = MAX_LENGTH_ERROR.format(field_name="Notebook Name", max_length=NOTEBOOK_NAME_MAX_LENGTH)

PVC_NAME_FORMAT = "{namespace}-{notebook_slug}-ws"

# Notebook status
WAITING = "waiting"
READY = "ready"
TERMINATING = "terminating"
STOPPED = "stopped"
DONE = "Done"
ERROR = "error"
WARNING = "warning"
UNINITIALIZED = "uninitialized"
UNAVAILABLE = "unavailable"
PENDING = "Pending"
SUSPENDED = "suspended"
NOTEBOOK_STATUS_CHOICES = (
    (WAITING, WAITING),
    (READY, READY),
    (TERMINATING, TERMINATING),
    (STOPPED, STOPPED),
    (DONE, DONE),
    (ERROR, ERROR),
    (WARNING, WARNING),
    (UNINITIALIZED, UNINITIALIZED),
    (UNAVAILABLE, UNAVAILABLE),
    (PENDING, PENDING),
)

# notebook actions
NOTEBOOK_ADD_ONS_UPDATE = "add_ons_update"
START_NOTEBOOK_ACTION = "start"
STOP_NOTEBOOK_ACTION = "stop"
RESTART_NOTEBOOK_ACTION = "restart"
RENAME_NOTEBOOK_ACTION = "rename"

# notebook auto shutdown timeout
NOTEBOOK_AUTO_SHUTDOWN_TIMEOUT_CHOICES = (
    (None, "No time limit"),
    (30, "30 Minutes"),
    (60, "1 Hour"),
    (120, "2 Hours"),
    (180, "3 Hours"),
    (240, "4 Hours"),
    (300, "5 Hours"),
    (360, "6 Hours"),
)

DEFAULT_PVC_DISK_SIZE = 30  # size in GB
MAXIMUM_PVC_DISK_SIZE = 5000  # size in GB

NVIDIA_GPU_VENDOR = "nvidia.com/gpu"

# notebook filter keys dict mapping
NOTEBOOK_FILTER_KEY_MAPPING = {
    "name": "name__in",
    "status": "status__in",
    "image_type": "image_type__in",
    "image": "image_version__image__name__in",
    "sku": "sku_item_price__sku__name__in",
    "sku_series": "sku_item_price__sku__series__in",
    "sku_type": "sku_item_price__sku_type__in",
    "created_by": "created_by__email__in",
}
NOTEBOOK_EXCLUDE_KEY_MAPPING = {
    "not_name": "name__in",
    "not_status": "status__in",
    "not_image_type": "image_type__in",
    "not_image": "image_version__image__name__in",
    "not_sku": "sku_item_price__sku__name__in",
    "not_sku_series": "sku_item_price__sku__series__in",
    "not_sku_type": "sku_item_price__sku_type__in",
    "not_created_by": "created_by__email__in",
}
STATUS_PRIORITY = "status_priority"
NOTEBOOK_ORDER_KEY_MAPPING = {
    "name": "name",
    "status": STATUS_PRIORITY,
    "updated_at": "updated_at",
    "created_at": "created_at",
    "-name": "-name",
    "-status": f"-{STATUS_PRIORITY}",
    "-updated_at": "-updated_at",
    "-created_at": "-created_at",
}

# Notebook instance types
FREE_USAGE = "free_usage"
AUTO_SHUTDOWN_FREE_USAGE = "free_usage-auto_shutdown"
AUTO_CONVERT_TO_PAID_USAGE = "free_usage-auto_convert_to_paid_usage"
PAID_USAGE = "paid_usage"
NOTEBOOK_INSTANCE_TYPE_CHOICES = (
    (FREE_USAGE, FREE_USAGE),
    (AUTO_SHUTDOWN_FREE_USAGE, AUTO_SHUTDOWN_FREE_USAGE),
    (AUTO_CONVERT_TO_PAID_USAGE, AUTO_CONVERT_TO_PAID_USAGE),
    (PAID_USAGE, PAID_USAGE),
)

# Notebook image types
PRE_BUILT_IMAGE = "pre-built"
CUSTOM_IMAGE = "custom"
NOTEBOOK_IMAGE_TYPE_LIST = [PRE_BUILT_IMAGE, CUSTOM_IMAGE]
NOTEBOOK_IMAGE_TYPE_CHOICES = tuple(
    (image_type, image_type) for image_type in NOTEBOOK_IMAGE_TYPE_LIST
)

NOTEBOOK_MINIMUM_BILLING_HOURS = 24

VOLUME_MOUNT = "mount"
VOLUME_UNMOUNT = "unmount"

# notebook add-ons
GRADIO = "gradio"
TENSORBOARD = "tensorboard"
NOTEBOOK_ADD_ONS_LIST = [GRADIO, TENSORBOARD]
NOTEBOOK_ADD_ON_CHOICES = tuple(
    (add_on, add_on) for add_on in NOTEBOOK_ADD_ONS_LIST
)

# notebook repository constants
VALID_NOTEBOOK_EXT = ".ipynb"
GITHUB_URL = "https://github.com/"
GIST_URL = "https://gist.github.com/"
COLAB_URL = "https://colab.research.google.com/"
GITHUB_RAW_CONTENT_URL = "https://raw.githubusercontent.com/"
COLAB_RAW_CONTENT_URL = "https://docs.google.com/uc?export=download&id="
GET_GIST_DATA_URL = "https://api.github.com/gists/{gist_id}"
GITHUB_PREFIX = "github/"
GIST_PREFIX = "gist/"
DRIVE_PREFIX = "drive/"
REQUIRED_KEYS_FOR_RAW_NOTEBOOK_JSON = [
    "nbformat", "nbformat_minor", "metadata", "cells"
]

# audit log constants
NOTEBOOK_RESOURCE = "notebook"
NOTEBOOK_ADD_ONS_UPDATE_EVENT = "ADD_ONS_UPDATE"
NOTEBOOK_CREATE_EVENT = "NOTEBOOK_CREATE"
NOTEBOOK_DELETE_EVENT = "NOTEBOOK_DELETE"
NOTEBOOK_START_EVENT = "NOTEBOOK_START"
NOTEBOOK_STOP_EVENT = "NOTEBOOK_STOP"
NOTEBOOK_RESTART_EVENT = "NOTEBOOK_RESTART"
NOTEBOOK_RENAME_EVENT = "NOTEBOOK_RENAME"
NOTEBOOK_SSH_UPDATE_EVENT = "NOTEBOOK_SSH_UPDATE"
NOTEBOOK_SSH_DELETE_EVENT = "NOTEBOOK_SSH_DELETE"
NOTEBOOK_UPGRADE_DOWNGRADE_EVENT = "NOTEBOOK_PLAN_CHANGE"
NOTEBOOK_PVC_UPGRADE_EVENT = "NOTEBOOK_PVC_UPGRADE"
MOUNTED_DATASETS_UPDATE_EVENT = "MOUNTED_DATASETS_UPDATE"
MOUNTED_SFS_UPDATE_EVENT = "MOUNTED_SFS_UPDATE"
NOTEBOOK_ACTION_EVENT_MAPPING = {
    NOTEBOOK_ADD_ONS_UPDATE: NOTEBOOK_ADD_ONS_UPDATE_EVENT,
    RENAME_NOTEBOOK_ACTION: NOTEBOOK_RENAME_EVENT,
    START_NOTEBOOK_ACTION: NOTEBOOK_START_EVENT,
    STOP_NOTEBOOK_ACTION: NOTEBOOK_STOP_EVENT,
    RESTART_NOTEBOOK_ACTION: NOTEBOOK_RESTART_EVENT,
}

# tasks constants
NOTEBOOK_AUTO_SHUTDOWN_TASK = "notebook_auto_shutdown_task"
NOTEBOOK_AUTO_SHUTDOWN_TASK_RETRY_LIMIT = 5
NOTEBOOK_AUTO_SHUTDOWN_TASK_RETRY_DELAY_TIME = 60
NOTEBOOK_PVC_DELETION_TASK = "notebook_pvc_deletion_task"
NOTEBOOK_PVC_DELETION_TASK_COUNTDOWN = 180
NOTEBOOK_PVC_DELETION_TASK_MAX_RETRIES = 10
SEND_NOTEBOOK_CREATION_EMAIL_TASK = "send_notebook_creation_email_task"
# error/success msgs
SSH_REQUIRED_FOR_NOTEBOOK_WITHOUT_JUPYTERLAB = "SSH is required for notebooks without JupyterLab."
NAME_INVALID = "Notebook name should contain letters, digits, underscore and hyphen only."
NOTEBOOK_ACTION_FAILED = "Notebook {action} failed"
NOTEBOOK_ACTION_SUCCESS = "Notebook {action} successfully"
NOTEBOOK_NAME_ALREADY_EXISTS = "Notebook with the same name already exists in the Project."
SKU_INVENTORY_UNAVAILABLE = "Inventory temporarily unavailable. Please try again after some time."
NOTEBOOK_ID_ERROR = "Notebook ID not found"
NOTEBOOK_NOTE_FOUND_ERROR = "Invalid Notebook ID"
NOTEBOOK_MONITORING_DATA_GET_ERROR = "Prometheus server connection error"
NOTEBOOK_INVALID_REQUEST = "Invalid Request! Notebook not found"
NOTEBOOK_ALREADY_STARTED = "Notebook is already started"
NOTEBOOK_ALREADY_STOPPED = "Notebook is already stopped"
RESTART_NOT_ALLOWED = "Restart action not allowed when notebook is stopped."
NOTEBOOK_MUST_STOP = "Please stop your notebook before Updation."
PLAN_ALREADY_SELECTED = "This plan is already selected"
INVALID_NOTEBOOK_ADD_ONS = "Invalid notebook add-ons: {}"
INVALID_SKU_ID = "Invalid SKU ID"
INVALID_SKU_ID_FOR_SELECTED_IMAGE = "Invalid SKU ID for the specified Image"
INVALID_INSTANCE_TYPE = "Invalid instance_type for the selected SKU"
NOTEBOOK_PVC_DELETION_FAILED = "Notebook PVC deletion failed"
NOTEBOOK_PVC_DELETION_FAILED_SUBJECT = "Notebook PVC deletion failed for customer {email_id}"
NOTEBOOK_PVC_DELETION_FAILED_MESSAGE = "Notebook PVC deletion failed for notebook: {notebook_id}. \n errors: {errors}"
CREDIT_FETCH_ERROR = "Unable to fetch Customer Credit Balance"
SUFFICIENT_CREDIT = "Customer has sufficient credits"
INSUFFICIENT_CREDIT_BALANCE = "Insufficient Credits! Please buy additional {credits} credits to launch Notebook & use it."
INSUFFICIENT_CREDIT_HOURLY = "Insufficient Credits! Please buy additional {credits} credits to launch Notebook & use it for about " + str(NOTEBOOK_MINIMUM_BILLING_HOURS) + " hours"
INVALID_PVC_DISK_SIZE = f"Disk Size should be an integer. It must be greater than the existing disk size and less than {MAXIMUM_PVC_DISK_SIZE}GB"
UPGRADE_PVC_SUCCESS = "Disk Size upgraded successfully. It can take a few minutes for the changes to get reflected"
FREE_NOTEBOOK_MAX_LIMIT = "Only 1 Free-Tier {sku_series} Notebook can be launched at a time"
GPU_FREE_USAGE_HOURS_EXHAUSTED = "You have reached your monthly free usage limit for GPU Machines"
NOTEBOOK_FREE_USAGE_EXPIRED = "Monthly free usage limit has been reached"  # frontend dependent message. any change here needs to be notified
UPGRADE_TO_FREE_PLAN_NOT_ALLOWED = "You cannot update notebook to a free plan"
INVENTORY_UNAVAILABLE_ON_NOTEBOOK_START = "Inventory temporarily unavailable. Please try again later or contact support if problem persists"
INVENTORY_REQUESTED_ON_NOTEBOOK_START = "Your Notebook is in queue. Due to increased load, it can take some time for your notebook to start"
INVALID_DATASET_MOUNT = "Some of the datasets are either invalid or not ready"
DATASET_MOUNT_UPDATE_FAILED = "Error while mounting/unmounting datasets on notebook"
INVALID_NOTEBOOK_URL = "Invalid Notebook URL!"
INVALID_NOTEBOOK = "Invalid Notebook!"
RAW_NOTEBOOK_DATA_FETCH_ERROR = "Unable to fetch notebook"
INVALID_PVC_DATASET_MOUNT = "Disk based dataset {dataset_name}, is already mounted to other notebook"
COMMMITTED_NOTEBOOK_STOP_START_NOT_ALLOWED = "Commmitted Notebook stop/start not allowed"
NOTEBOOK_WITH_LOCAL_STORAGE_STOP_NOT_ALLOWED = "Notebooks with Local NVMe Storage cannot be stopped"
SFS_MOUNT_UPDATE_FAILED = "Error while mounting/unmounting SFS on notebook"
INVALID_METRIC_NAME = "Invalid metric name"

# support ticket constants
NOTEBOOK_INCONSISTENCY_TICKET_SUBJECT = "Notebook does not exist on groot | NOTEBOOK_INCONSISTENCY"
NOTEBOOK_INCONSISTENCY_TICKET_MESSAGE = "Notebook '{notebook_name}' (ID:{notebook_id}) exists in our DB but does not exist on groot."

INTERVAL_TO_TIME_FORMAT_MAPPING = {
                                        '5m' : [300, '%I:%M:%S%p', 15],
                                        '1h' : [3600, '%I:%M%p', 180],
                                        '1d' : [86400, '%I:%M:%p', 3600],
                                        '7d' : [604800, '%m/%d/%Y, %I%p', 28800],
                                        '1mn' : [2592000, '%m/%d/%Y', 86400]
                                }
CONTAINER_CPU_USAGE_KEY = "container_cpu_usage_seconds_total"
KUBELET_VOLUME_STATS_USED_BYTES = "kubelet_volume_stats_used_bytes"
KUBELET_VOLUME_STATS_CAPACITY_BYTES = "kubelet_volume_stats_capacity_bytes"
CONTAINER_MEMORY_USAGE_BYTES = "container_memory_usage_bytes"
KUBE_POD_CONTAINER_RESOURCE_LIMITS = "kube_pod_container_resource_limits"

METRIC_NAME_PVC = "pvc"
METRIC_NAME_ALL = "all"
METRIC_NAME_MEMORY = "memory"
METRIC_NAME_LOCAL_STORAGE = "localstorage"

VALID_GAUGE_METRICS_NAME = [METRIC_NAME_PVC, METRIC_NAME_MEMORY, METRIC_NAME_ALL, METRIC_NAME_LOCAL_STORAGE]

# template name constants
NOTEBOOK_TEMPLATE_NAME = "notebook/notebook_creation_successful.html"
COMMITTED_NOTEBOOK_LAUNCH_TEMPLATE_NAME = "notebook/committed_notebook_launch.html"
NOTEBOOK_AUTO_CONVERT_TEMPLATE = "crons/notebook_free_usage_auto_convert.html"
NOTEBOOK_FREE_TIER_AUTO_CONVERT_FAILED_TEMPLATE = "crons/notebook_free_usage_auto_convert_failed.html"
SSH_DEFAULT_USER_NAME = "root"
DISABLE_PASSWORD_ACCESS = "false"
COUNTDOWN_FOR_NOTEBOOK_CREATION_MAIL = 60
SEND_NOTEBOOK_START_EMAIL_TASK = "send_notebook_start_email_task"
NOTEBOOK_START_TEMPLATE_NAME = "notebook/notebook_start_successful.html"
H100_SKU_NAME = "h100"
H100_PVC_NAME_FORMAT = "{namespace}-{notebook_slug}-localws"
NOTEBOOK_H100_PVC_DELETION_FAILED_SUBJECT = "Notebook H100 PVC deletion failed for customer {email_id}"
NOTEBOOK_H100_PVC_DELETION_FAILED_MESSAGE = "Notebook H100 PVC deletion failed for notebook: {notebook_id}. \n errors: {errors}"
NOTEBOOK_NOT_FOUND = "Notebook doesn't exists"
POD_DETAILS_ERROR = "error in getting pod details"

NOTEBOOK_STATUS_PRIORITY_MAPPING = {
    WAITING: 0,
    READY: 1,
    TERMINATING: 2,
    STOPPED: 3
}
