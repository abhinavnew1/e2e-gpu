import logging

from rest_framework import status

from eventlogs.api.v1.services.eventlog_service import EventLogService
from eventlogs.constants import (CREATE, DELETE, EVENTLOG_FAILED_STATUS,
                                 EVENTLOG_SUCCESS_STATUS,
                                 NOTEBOOK_SERVICE_CODE, UPDATE)
from notebook.constants import (MOUNTED_DATASETS_UPDATE_EVENT,
                                MOUNTED_SFS_UPDATE_EVENT,
                                NOTEBOOK_ACTION_EVENT_MAPPING,
                                NOTEBOOK_ADD_ONS_UPDATE, NOTEBOOK_CREATE_EVENT,
                                NOTEBOOK_DELETE_EVENT,
                                NOTEBOOK_PVC_UPGRADE_EVENT,
                                NOTEBOOK_SSH_DELETE_EVENT,
                                NOTEBOOK_SSH_UPDATE_EVENT,
                                NOTEBOOK_UPGRADE_DOWNGRADE_EVENT,
                                RENAME_NOTEBOOK_ACTION, VOLUME_MOUNT,
                                VOLUME_UNMOUNT)
from notebook.models import Notebook

logger = logging.getLogger(__name__)


def notebook_create_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(NOTEBOOK_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=NOTEBOOK_CREATE_EVENT,
            resource_name=request.data.get("name"),
            resource_id="",
            detailed_info={"request": request.data, "project_id": kwargs.get('project_id')},
            resource_obj_id=None,
            event_type=CREATE
        )
        response = func(*args, **kwargs)
        if response.status_code == status.HTTP_201_CREATED:
            event_log.update_log(status=EVENTLOG_SUCCESS_STATUS, resource_id=response.data["data"]["id"],
                                 detailed_info={"response": response.data["data"],
                                                "project_id": kwargs.get('project_id')},
                                 resource_obj_id=response.data["data"]["id"])
        else:
            event_log.log_event_failure()
        return response

    return wrapper_func


def notebook_delete_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(NOTEBOOK_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=NOTEBOOK_DELETE_EVENT,
            resource_name=kwargs.get("notebook").name,
            resource_id=kwargs.get("notebook_id"),
            resource_obj_id=kwargs.get("notebook_id"),
            detailed_info={"project_id": kwargs.get('project_id')},
            event_type=DELETE
        )
        response = func(*args, **kwargs)
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else \
            event_log.log_event_failure()
        return response

    return wrapper_func


def notebook_action_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(NOTEBOOK_SERVICE_CODE)
        action = request.GET.get("action").lower()
        nb_name = kwargs.get("notebook").name
        response = func(*args, **kwargs)
        log_status = EVENTLOG_SUCCESS_STATUS if response.status_code == status.HTTP_200_OK else EVENTLOG_FAILED_STATUS

        detailed_info = {"project_id": kwargs.get('project_id')}
        if action == RENAME_NOTEBOOK_ACTION:
            detailed_info["old_notebook_name"] = nb_name
        elif action == NOTEBOOK_ADD_ONS_UPDATE:
            detailed_info["add_ons"] = request.data.get("add_ons", [])

        event_log.create_log(
            request=request,
            event=NOTEBOOK_ACTION_EVENT_MAPPING.get(action, ""),
            resource_name=kwargs.get("notebook").name,
            resource_id=kwargs.get("notebook_id"),
            status=log_status,
            resource_obj_id=kwargs.get("notebook_id"),
            detailed_info=detailed_info,
            event_type=UPDATE
        )
        return response

    return wrapper_func


def notebook_upgrade_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(NOTEBOOK_SERVICE_CODE)
        response = func(*args, **kwargs)
        log_status = EVENTLOG_SUCCESS_STATUS if response.status_code == status.HTTP_200_OK else EVENTLOG_FAILED_STATUS
        event_log.create_log(
            request=request,
            event=NOTEBOOK_UPGRADE_DOWNGRADE_EVENT,
            resource_name=kwargs.get("notebook").name if kwargs.get("notebook") else "",
            resource_id=kwargs.get("notebook_id"),
            detailed_info={"update_data": request.data, "project_id": kwargs.get('project_id')},
            status=log_status,
            resource_obj_id=kwargs.get("notebook_id"),
            event_type=UPDATE
        )
        return response

    return wrapper_func


def notebook_pvc_upgrade_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(NOTEBOOK_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=NOTEBOOK_PVC_UPGRADE_EVENT,
            resource_name=kwargs.get("notebook").name if kwargs.get("notebook") else "",
            resource_id=kwargs.get("notebook_id"),
            detailed_info={"new_disk_size": f"{request.data.get('size')}GB"},
            resource_obj_id=kwargs.get("notebook_id"),
            event_type=UPDATE,
        )
        response = func(*args, **kwargs)
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else event_log.log_event_failure()
        return response

    return wrapper_func


def mounted_datasets_update_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        notebook_id = kwargs.get("notebook_id")
        notebook = kwargs.get("notebook", Notebook.objects.filter(id=notebook_id).first())
        action = request.GET.get("action")
        dataset_id_list = request.data.get("dataset_id_list", [])
        if action == VOLUME_UNMOUNT:
            datasets = list(notebook.get_mounted_datasets().filter(id__in=dataset_id_list).values_list("name", flat=True))
        event_log = EventLogService(NOTEBOOK_SERVICE_CODE)
        response = func(*args, **kwargs)
        if action == VOLUME_MOUNT:
            datasets = list(notebook.get_mounted_datasets().filter(id__in=dataset_id_list).values_list("name", flat=True))

        log_status = EVENTLOG_SUCCESS_STATUS if response.status_code == status.HTTP_200_OK else EVENTLOG_FAILED_STATUS
        event_log.create_log(
            request=request,
            event=MOUNTED_DATASETS_UPDATE_EVENT,
            resource_name=notebook.name,
            resource_id=notebook_id,
            status=log_status,
            detailed_info={
                "action": action,
                "datasets": datasets,
            },
            resource_obj_id=notebook_id,
            event_type=UPDATE,
        )
        return response

    return wrapper_func


def mounted_sfs_update_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        notebook_id = kwargs.get("notebook_id")
        notebook = kwargs.get("notebook", Notebook.objects.filter(id=notebook_id).first())
        action = request.data.get("action")
        sfs_id_list = request.data.get("sfs_ids", [])
        if action == VOLUME_UNMOUNT:
            sfs = list(notebook.sfs_mounted.filter(id__in=sfs_id_list).values_list("name", flat=True))
        event_log = EventLogService(NOTEBOOK_SERVICE_CODE)
        response = func(*args, **kwargs)
        if action == VOLUME_MOUNT:
            sfs = list(notebook.get_mounted_datasets().filter(id__in=sfs_id_list).values_list("name", flat=True))

        log_status = EVENTLOG_SUCCESS_STATUS if response.status_code == status.HTTP_200_OK else EVENTLOG_FAILED_STATUS
        event_log.create_log(
            request=request,
            event=MOUNTED_SFS_UPDATE_EVENT,
            resource_name=notebook.name,
            resource_id=notebook_id,
            status=log_status,
            detailed_info={
                "action": action,
                "datasets": sfs,
            },
            resource_obj_id=notebook_id,
            event_type=UPDATE,
        )
        return response

    return wrapper_func


def notebook_ssh_update_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(NOTEBOOK_SERVICE_CODE)
        response = func(*args, **kwargs)
        log_status = EVENTLOG_SUCCESS_STATUS if response.status_code == status.HTTP_200_OK else EVENTLOG_FAILED_STATUS
        event_log.create_log(
            request=request,
            event=NOTEBOOK_SSH_UPDATE_EVENT,
            resource_name=kwargs.get("notebook").name if kwargs.get("notebook") else "",
            resource_id=kwargs.get("notebook_id"),
            detailed_info={"update_data": request.data, "project_id": kwargs.get('project_id')},
            status=log_status,
            resource_obj_id=kwargs.get("notebook_id"),
            event_type=UPDATE
        )
        return response
    return wrapper_func


def notebook_ssh_delete_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(NOTEBOOK_SERVICE_CODE)
        response = func(*args, **kwargs)
        log_status = EVENTLOG_SUCCESS_STATUS if response.status_code == status.HTTP_200_OK else EVENTLOG_FAILED_STATUS
        event_log.create_log(
            request=request,
            event=NOTEBOOK_SSH_DELETE_EVENT,
            resource_name=kwargs.get("notebook").name if kwargs.get("notebook") else "",
            resource_id=kwargs.get("notebook_id"),
            detailed_info={"project_id": kwargs.get('project_id')},
            status=log_status,
            resource_obj_id=kwargs.get("notebook_id"),
            event_type=DELETE
        )
        return response
    return wrapper_func
