import logging

from customer.helpers import get_prepaid_credit_balance_via_user_email
from e2e_core.api.v1.services.base import BaseService
from gpu_service.constants import HOURLY
from notebook.constants import (CREDIT_FETCH_ERROR,
                                INSUFFICIENT_CREDIT_BALANCE,
                                INSUFFICIENT_CREDIT_HOURLY)
from notebook.helpers import is_credit_sufficient_to_launch_notebook

logger = logging.getLogger(__name__)


def minimum_billing_check(func):
    def wrapper_func(*args, **kwargs):
        is_prepaid, available_customer_credits = get_prepaid_credit_balance_via_user_email(kwargs.get("project").team.owner.get_primary_contact().email)
        sku_item_price = kwargs.get("sku_item_price")
        if is_prepaid is None:
            return BaseService.get_412_response(CREDIT_FETCH_ERROR)
        else:
            is_credit_sufficient, additional_required_credits = is_credit_sufficient_to_launch_notebook(
                                                                    args[0].customer,
                                                                    sku_item_price,
                                                                    is_prepaid,
                                                                    available_customer_credits
                                                                )
            if not is_credit_sufficient:
                msg = INSUFFICIENT_CREDIT_HOURLY.format(credits=additional_required_credits) if sku_item_price.sku_type == HOURLY else INSUFFICIENT_CREDIT_BALANCE.format(credits=additional_required_credits)
                return BaseService.get_412_response(msg)
            args[0].customer.is_prepaid = is_prepaid
        return func(*args, **kwargs)

    return wrapper_func
