import logging

from rest_framework.response import Response

from e2e_core.api.v1.services.base import BaseService
from e2e_core.constants import PARAMS_MISSING_OR_INVALID
from gpu_service.helpers import check_inventory_availability_status
from gpu_service.models import SkuItemPrice
from notebook.api.v1.serializers import NotebookCreateUpdateSerializer
from notebook.constants import (AUTO_SHUTDOWN_FREE_USAGE,
                                FREE_NOTEBOOK_MAX_LIMIT,
                                GPU_FREE_USAGE_HOURS_EXHAUSTED,
                                INVALID_PVC_DISK_SIZE,
                                NOTEBOOK_FREE_USAGE_EXPIRED,
                                NOTEBOOK_INVALID_REQUEST, NOTEBOOK_MUST_STOP,
                                PLAN_ALREADY_SELECTED,
                                SKU_INVENTORY_UNAVAILABLE, STOPPED,
                                UPGRADE_TO_FREE_PLAN_NOT_ALLOWED, VOLUME_MOUNT)
from notebook.helpers import (dataset_id_validator_for_mount,
                              is_customer_free_usage_hours_available,
                              is_customer_has_free_running_notebooks,
                              is_pvc_disk_size_valid, sku_id_validator)
from notebook.models import Notebook
from reserve_instance.constants import (AUTO_RENEW_STATUS, COMMITTED,
                                        CONVERT_TO_HOURLY_BILLING,
                                        INSTANCE_UPDATION_LIST,
                                        INVALID_SKU_AND_UPDATION_POLICY,
                                        INVALID_UPDATION_POLICY)

logger = logging.getLogger(__name__)


def validate_notebook_request(func):
    def wrapper_func(*args, **kwargs):
        notebook_id = kwargs.get("notebook_id")
        project_id = kwargs.get("project_id")
        notebook = Notebook.objects.filter(
                        deleted_at__isnull=True, id=notebook_id, project_id=project_id
                    ).select_related(
                        "project", "image_version", "image_version__image", "sku_item_price", "sku_item_price__sku"
                    ).first()
        if not notebook:
            response = BaseService.get_404_response(NOTEBOOK_INVALID_REQUEST)
            return Response(response, status=response.get("code"))
        kwargs["notebook"] = notebook
        return func(*args, **kwargs)

    return wrapper_func



def verify_update_preconditions(func):
    def wrapper_func(*args, **kwargs):
        request_data = args[1]
        sku_item_price_id = request_data.get("sku_item_price_id")
        committed_instance_policy = request_data.get("committed_instance_policy")
        next_sku_item_price_id = request_data.get("next_sku_item_price_id")
        try:
            sku_item_price_id = int(sku_item_price_id)
            next_sku_item_price_id = int(next_sku_item_price_id) if next_sku_item_price_id else None
        except Exception:
            return args[0].get_baked_400_response(PARAMS_MISSING_OR_INVALID.format(param="sku_item_price_id"))
        sku_item_price = kwargs.get("sku_item_price", SkuItemPrice.objects.filter(id=sku_item_price_id, is_active=True, sku__is_active=True).first())
        next_sku_item_price = kwargs.get("next_sku_item_price", SkuItemPrice.objects.filter(id=next_sku_item_price_id, is_active=True, sku__is_active=True).first())
        if sku_item_price.sku_type == COMMITTED:
            if committed_instance_policy not in INSTANCE_UPDATION_LIST:
                return args[0].get_baked_400_response(INVALID_UPDATION_POLICY)
            if committed_instance_policy in [CONVERT_TO_HOURLY_BILLING, AUTO_RENEW_STATUS] and not isinstance(next_sku_item_price_id, int):
                return args[0].get_baked_400_response(INVALID_SKU_AND_UPDATION_POLICY)
            if next_sku_item_price and next_sku_item_price.sku != sku_item_price.sku:
                return args[0].get_baked_400_response(PARAMS_MISSING_OR_INVALID.format(param="next_sku_item_price_id"))
        kwargs["sku_item_price"] = sku_item_price
        kwargs["next_sku_item_price"] = next_sku_item_price
        return func(*args, **kwargs)
    return wrapper_func


def validate_upgrade_downgrade_request(func):
    def wrapper_func(*args, **kwargs):
        notebook = kwargs.get("notebook")
        request_data = args[1]
        sku_item_price_id = request_data.get("sku_item_price_id")
        sku_item_price = kwargs.get("sku_item_price", SkuItemPrice.objects.filter(id=sku_item_price_id, is_active=True, sku__is_active=True).first())
        sku = kwargs.get("sku", sku_item_price.sku)
        if notebook.status != STOPPED:
            return args[0].get_baked_412_response(NOTEBOOK_MUST_STOP)
        if int(sku_item_price_id) == notebook.sku_item_price.id:
            return args[0].get_baked_400_response(PLAN_ALREADY_SELECTED)
        is_valid, err_str = sku_id_validator(sku.id, notebook.image_version_id)
        if not is_valid:
            return args[0].get_baked_400_response(err_str)
        if sku.is_free:
            return args[0].get_baked_400_response(UPGRADE_TO_FREE_PLAN_NOT_ALLOWED)
        kwargs["sku"] = sku
        kwargs["sku_item_price"] = sku_item_price
        return func(*args, **kwargs)
    return wrapper_func


def check_sku_inventory_availability(func):
    def wrapper_func(*args, **kwargs):
        data = args[1]
        sku_item_price_id = data.validated_data.get("sku_item_price_id") if isinstance(data, NotebookCreateUpdateSerializer) else data.get("sku_item_price_id")
        sku_item_price = kwargs.get("sku_item_price", SkuItemPrice.objects.filter(id=sku_item_price_id, is_active=True, sku__is_active=True).first())
        if not sku_item_price:
            return args[0].get_baked_412_response(PARAMS_MISSING_OR_INVALID.format(param="sku_item_price_id"))
        sku = kwargs.get("sku", sku_item_price.sku)
        is_inventory_available = check_inventory_availability_status(sku)
        if not is_inventory_available:
            return args[0].get_baked_412_response(SKU_INVENTORY_UNAVAILABLE)
        kwargs["sku"] = sku
        kwargs["sku_item_price"] = sku_item_price
        return func(*args, **kwargs)

    return wrapper_func


def validate_upgrade_pvc_request(func):
    def wrapper_func(*args, **kwargs):
        notebook = kwargs.get("notebook")
        new_disk_size = args[2]
        if not new_disk_size or not isinstance(new_disk_size, int):
            return args[0].get_baked_400_response(PARAMS_MISSING_OR_INVALID.format(param="Disk size"))
        existing_disk_size = notebook.disk_size
        is_new_disk_size_valid = is_pvc_disk_size_valid(new_disk_size, existing_disk_size)
        if not is_new_disk_size_valid:
            return args[0].get_baked_400_response(INVALID_PVC_DISK_SIZE)
        return func(*args, **kwargs)

    return wrapper_func


def validate_free_notebook_launch(func):
    def wrapper_func(*args, **kwargs):
        sku_item_price_id = args[1].validated_data.get("sku_item_price_id")
        sku_item_price = kwargs.get("sku_item_price", SkuItemPrice.objects.filter(id=sku_item_price_id, is_active=True, sku__is_active=True).first())
        sku = kwargs.get("sku", sku_item_price.sku)
        if sku.is_free and is_customer_has_free_running_notebooks(args[0].customer, sku.series):
            return args[0].get_baked_412_response(FREE_NOTEBOOK_MAX_LIMIT.format(sku_series=sku.series))
        if sku.is_free and not is_customer_free_usage_hours_available(args[0].customer, sku.series):
            return args[0].get_baked_412_response(GPU_FREE_USAGE_HOURS_EXHAUSTED)
        kwargs["sku"] = sku
        kwargs["sku_item_price"] = sku_item_price
        return func(*args, **kwargs)

    return wrapper_func


def check_for_notebook_free_usage_expiry(func):
    def wrapper_func(*args, **kwargs):
        notebook = args[0].notebook
        sku = notebook.sku
        if (
            sku.is_free
            and notebook.instance_type == AUTO_SHUTDOWN_FREE_USAGE
            and not is_customer_free_usage_hours_available(notebook.created_by, sku.series)
        ):
            return args[0].get_baked_412_response(GPU_FREE_USAGE_HOURS_EXHAUSTED, message=NOTEBOOK_FREE_USAGE_EXPIRED)  # message is frontend dependent. any change here needs to be notified
        return func(*args, **kwargs)

    return wrapper_func


def validate_dataset_list(func):
    def wrapper_func(*args, **kwargs):
        action = args[2]
        dataset_id_list = args[3]
        if not dataset_id_list:
            return args[0].get_baked_400_response(PARAMS_MISSING_OR_INVALID.format(param="dataset_id_list"))
        if action == VOLUME_MOUNT:
            is_valid, error, invalid_dataset_ids = dataset_id_validator_for_mount(
                dataset_id_list, args[0].project_id)
        else:
            is_valid, error, invalid_dataset_ids = True, "", []
        if not is_valid:
            return args[0].get_baked_400_response(error)
        return func(*args, **kwargs)

    return wrapper_func

