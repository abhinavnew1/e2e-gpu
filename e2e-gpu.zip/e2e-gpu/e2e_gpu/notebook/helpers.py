import logging
import re

import requests
from celery.execute import send_task
from dbtemplates.models import Template
from django.conf import settings
from django.db.models import Q
from django.template.loader import get_template
from rest_framework import status

from customer.helpers import get_prepaid_credit_balance_via_user_email
from dataset.constants import OK, PVC
from dataset.models import Dataset
from e2e_core.api.v1.services.mandrill import Mandrill
from e2e_core.helpers import (advanced_search_filter, process_boolean,
                              support_ticket_generator)
from gpu_service.api.v1.services.sku_service import SkuService
from gpu_service.constants import COMMITTED, CPU_SERIES, GPU_SERIES
from gpu_service.models import StockKeepingUnit
from notebook.api.v1.services.notebook_groot_service import \
    NotebookGrootService
from notebook.constants import (
    AUTO_SHUTDOWN_FREE_USAGE, COLAB_RAW_CONTENT_URL, COLAB_URL,
    COMMITTED_NOTEBOOK_LAUNCH_TEMPLATE_NAME,
    COUNTDOWN_FOR_NOTEBOOK_CREATION_MAIL, CUSTOM_IMAGE, DEFAULT_PVC_DISK_SIZE,
    DONE, DRIVE_PREFIX, ERROR, GET_GIST_DATA_URL, GIST_PREFIX, GIST_URL,
    GITHUB_PREFIX, GITHUB_RAW_CONTENT_URL, GITHUB_URL, INVALID_DATASET_MOUNT,
    INVALID_PVC_DATASET_MOUNT, INVALID_SKU_ID,
    INVALID_SKU_ID_FOR_SELECTED_IMAGE, MAXIMUM_PVC_DISK_SIZE, NAME_INVALID,
    NAME_REGEX, NOTEBOOK_ADD_ONS_LIST, NOTEBOOK_AUTO_CONVERT_TEMPLATE,
    NOTEBOOK_EXCLUDE_KEY_MAPPING, NOTEBOOK_FILTER_KEY_MAPPING,
    NOTEBOOK_FREE_TIER_AUTO_CONVERT_FAILED_TEMPLATE,
    NOTEBOOK_INCONSISTENCY_TICKET_MESSAGE,
    NOTEBOOK_INCONSISTENCY_TICKET_SUBJECT, NOTEBOOK_MINIMUM_BILLING_HOURS,
    NOTEBOOK_NAME_ALREADY_EXISTS, NOTEBOOK_START_TEMPLATE_NAME,
    NOTEBOOK_TEMPLATE_NAME, PENDING, READY, SEND_NOTEBOOK_START_EMAIL_TASK,
    SSH_DEFAULT_USER_NAME, START_NOTEBOOK_ACTION, SUSPENDED,
    VALID_NOTEBOOK_EXT, WAITING)
from notebook.models import EgressGatewayDetail, Notebook
from rbac.constants import NOTEBOOK
from teams.helpers import get_team_owner_admin_email_list

logger = logging.getLogger(__name__)

mandrill_manager = Mandrill(mandrill_api_token=settings.MANDRILL_API_TOKEN, bcc="",
                            from_email=settings.NOTIFY_FROM, notify=settings.NOTIFY_FROM)


def update_notebooks_data(notebook_qs, groot_notebooks_list, *args, **kwargs):
    """func to update notebooks' data from groot in DB"""
    nb_mapping = {nb["name"]: nb for nb in groot_notebooks_list}
    for notebook in notebook_qs:
        nb_data = nb_mapping.get(notebook.slug_name)
        if not nb_data:
            logger.error(f"NOTEBOOK_INCONSISTENCY | CRITICAL_RED | NOTEBOOK_DOES_NOT_EXIST_ON_GROOT | NOTEBOOK_SLUG:{notebook.slug_name}")
            if notebook.status != ERROR:
                notebook.status = ERROR
                generate_notebook_inconsistency_ticket(notebook)
            continue
        if notebook.status != PENDING or notebook.status == PENDING and nb_data["status"]["phase"] == READY:
            notebook.status = nb_data["status"]["phase"]
        notebook.status_log = nb_data["status"]
        notebook.last_activity = nb_data["last_activity"] if nb_data["last_activity"] else None
    Notebook.objects.bulk_update(notebook_qs, ['status', 'status_log', 'last_activity', 'updated_at', ])


def update_notebook_details(notebook, groot_data, *args, **kwargs):
    """func to update a notebook's data from groot in DB"""
    fields_to_update = ["status", "status_log", "last_activity", ]
    initial_status, initial_activity_timestamp = notebook.status, notebook.last_activity
    if notebook.status != PENDING or (notebook.status == PENDING and groot_data["status"]["phase"] == READY):
        notebook.status = groot_data["status"]["phase"]
    notebook.status_log = groot_data["status"]
    notebook.last_activity = groot_data["last_activity"] if groot_data["last_activity"] else None

    # change updated_at in DB only if there is any change in any of the said fields.
    if notebook.status != initial_status or notebook.last_activity != initial_activity_timestamp:
        fields_to_update.append("updated_at")
    notebook.save(update_fields=fields_to_update)
    return notebook


def validate_notebook_name(name, project_id, notebook_id=None):
    """validates the notebook name
    :returns:
        :boolean: is_valid: whether the name is valid or not
        :string: error: why the notebook name is not valid
    """
    if not re.fullmatch(NAME_REGEX, name):
        return False, NAME_INVALID
    if Notebook.objects.filter(deleted_at__isnull=True, project_id=project_id, name=name).exclude(id=notebook_id).exists():
        return False, NOTEBOOK_NAME_ALREADY_EXISTS
    return True, ""


def perform_shutdown_action(notebook):
    from notebook.api.v1.services.notebook_service import NotebookService

    # currently assuming customer=notebook.created_by ; #TODO: once invitations feature is live
    response = NotebookService(notebook.created_by, notebook.project.id)\
               .delete_notebook(notebook.id, notebook=notebook)
    return True if response.get("code") == status.HTTP_200_OK else False


def sku_id_validator(sku_id, image_version_id=None):
    """
    :params sku_id int: StockKeepingUnit object id to be validated
    :params image_version_id: ImageVersion object id to check for sku compatibility. required only for notebook with pre-built images. defaults to None
    """
    sku = StockKeepingUnit.get_active_sku(sku_id)
    if not sku or sku.category != NOTEBOOK:
        return False, INVALID_SKU_ID
    is_cpu_supported, is_gpu_supported = True, True
    if image_version_id:
        is_cpu_supported, is_gpu_supported = SkuService().get_sku_compatibility_for_image(image_version_id)
    if (sku.series == CPU_SERIES and not is_cpu_supported) or (sku.series == GPU_SERIES and not is_gpu_supported):
        return False, INVALID_SKU_ID_FOR_SELECTED_IMAGE
    return True, ""


def dataset_id_validator_for_mount(dataset_id_list, project_id):
    dataset_id_list = set(dataset_id_list)
    datasets_to_mount = Dataset.objects.filter(id__in=dataset_id_list)
    # pvc_disk mounting
    for dataset in datasets_to_mount:
        if dataset.storage_type == PVC and len(dataset.get_mounted_on_notebooks()) != 0:
            return False, INVALID_PVC_DATASET_MOUNT.format(dataset_name=dataset.name), [dataset.id]

    valid_ds_list = set(
        Dataset.objects.filter(
            deleted_at__isnull=True, id__in=dataset_id_list, status=OK, project_id=project_id
        ).values_list("id", flat=True)
    )
    invalid_dataset_ids = list(dataset_id_list - valid_ds_list)
    if invalid_dataset_ids:
        return False, INVALID_DATASET_MOUNT, invalid_dataset_ids
    return True, "", []


def send_notebook_creation_email(customer_obj, cc_emails, notebook_obj, team_name):
    notebook_creation_template = NOTEBOOK_TEMPLATE_NAME
    committed_upto = ""
    termination_policy= ""
    if notebook_obj.is_committed():
        notebook_creation_template = COMMITTED_NOTEBOOK_LAUNCH_TEMPLATE_NAME
        committed_info = notebook_obj.get_reserve_instance_entry()
        termination_policy = committed_info.updation_policy if committed_info else ""
        committed_upto = committed_info.reserveinstancetransaction_set.last().end_date if committed_info else ""
    notebook_creation_success_template_object = Template.objects.filter(name=notebook_creation_template).first()
    if not notebook_creation_success_template_object:
        logger.error("NOTEBOOK | SEND_NOTEBOOK_CREATION_EMAIL | NOTEBOOK_CREATION_SUCCESS_TEMPLATE_NOT_FOUND")
        return
    if not hasattr(customer_obj, "is_prepaid"):
        customer_obj.is_prepaid, _ = get_prepaid_credit_balance_via_user_email(notebook_obj.project.team.owner.get_primary_contact().email)
    subject = notebook_creation_success_template_object.subject
    ssh_details = get_ssh_details(notebook_obj.project.namespace, customer_obj, notebook_obj)
    nb_image = CUSTOM_IMAGE if notebook_obj.is_image_type_custom() else notebook_obj.image_version.image.name
    body = get_template(notebook_creation_template).render(
        {"notebook_name": notebook_obj.name, "project_name": notebook_obj.project.name,
         "plan_name": notebook_obj.sku.name, "image_name": nb_image, "team_name": team_name,
         "plan_type": notebook_obj.sku_item_price.sku_type, "termination_policy": termination_policy,
         "is_prepaid": customer_obj.is_prepaid,
         "sku_unit_price": notebook_obj.sku_item_price.unit_price, "committed_upto": committed_upto,
         **ssh_details,
         "cloud_support_email_address": settings.CLOUD_PLATFORM_EMAIL}
    )
    try:
        mandrill_manager.send_email([], [customer_obj.email], body, subject, cc_email_list=cc_emails)
    except Exception as e:
        logger.error(f"NOTEBOOK | SEND_NOTEBOOK_CREATION_EMAIL | Customer - {customer_obj.email} | MAIL - {customer_obj.email} | "
                     f"CRITICAL_RED | ERROR_IN_SENDING_EMAIL - {e}")


def send_notebook_auto_convert_email(to_email, cc_emails, notebook, free_sku, paid_sku_item_price, *args, **kwargs):
    nb_auto_convert_template_object = Template.objects.filter(name=NOTEBOOK_AUTO_CONVERT_TEMPLATE).first()
    if not nb_auto_convert_template_object:
        logger.error("NOTEBOOK | SEND_NOTEBOOK_AUTO_CONVERT_EMAIL | CRITICAL_RED | NOTEBOOK_AUTO_CONVERT_EMAIL_TEMPLATE_NOT_FOUND")
        return
    subject = nb_auto_convert_template_object.subject
    nb_image = notebook.image_version.image.name if notebook.image_version else CUSTOM_IMAGE
    body = get_template(NOTEBOOK_AUTO_CONVERT_TEMPLATE).render({
                "notebook_name": notebook.name,
                "team_name": notebook.project.team.name,
                "project_name": notebook.project.name,
                "image_name": nb_image,
                "free_plan_name": free_sku.name,
                "new_plan_name": notebook.sku.name,
                "new_plan_price": f"{paid_sku_item_price.currency.display_text} {paid_sku_item_price.unit_price} per hour",
                "cloud_support_email_address": settings.CLOUD_PLATFORM_EMAIL,
                "free_sku_series": free_sku.series,
            })
    try:
        mandrill_manager.send_email([], [to_email], body, subject, cc_email_list=cc_emails)
    except Exception as e:
        logger.error(f"NOTEBOOK | SEND_NOTEBOOK_AUTO_CONVERT_EMAIL | CRITICAL_RED | ERROR_IN_SENDING_EMAIL | TO_EMAIL:{to_email} | ERROR:{e}")


def is_credit_sufficient_to_launch_notebook(customer, sku_item_price, is_prepaid, credit_balance):
    if sku_item_price.sku.is_free:
        return True, None
    minimum_credits_required = sku_item_price.unit_price if sku_item_price.sku_type == COMMITTED \
        else sku_item_price.unit_price * NOTEBOOK_MINIMUM_BILLING_HOURS
    if is_prepaid and minimum_credits_required > credit_balance:
        return False, round((minimum_credits_required - credit_balance), 2)
    return True, None


def generate_notebook_inconsistency_ticket(notebook):
    support_ticket_generator(
        errors=NOTEBOOK_INCONSISTENCY_TICKET_MESSAGE.format(notebook_name=notebook.name, notebook_id=notebook.id),
        subject=NOTEBOOK_INCONSISTENCY_TICKET_SUBJECT,
        customer=notebook.created_by,
    )


def is_pvc_disk_size_valid(new_disk_size, existing_disk_size, is_pvc_create=False):
    if (
        is_pvc_create
        and isinstance(new_disk_size, int)
        and new_disk_size >= DEFAULT_PVC_DISK_SIZE
        and new_disk_size <= MAXIMUM_PVC_DISK_SIZE
    ):
        return True
    elif (
        not is_pvc_create
        and isinstance(new_disk_size, int)
        and new_disk_size > existing_disk_size
        and new_disk_size <= MAXIMUM_PVC_DISK_SIZE
    ):
        return True
    else:
        return False


def is_customer_has_free_running_notebooks(customer, sku_series):
    """Returns True if there is any free notebook launched for customer's primary account for the given sku_series else returns False"""
    customer = customer.get_primary_contact()
    if (
        Notebook.objects.filter(
            ~Q(status=DONE),  # stopped notebooks are taken into account for free-tier count
            deleted_at__isnull=True,
            sku_item_price__sku__is_free=True,
            sku_item_price__sku__series=sku_series,
            created_by__primary_email=customer.email,
        ).exists()
    ):
        return True
    return False


def is_customer_free_usage_hours_available(customer, sku_series):
    if sku_series == CPU_SERIES:
        return True
    if sku_series == GPU_SERIES and customer.gpu_free_hours_remaining > 0:
        return True
    return False


def get_payload_for_volume_mount(volumes_to_mount: list, volumes_to_unmount: list) -> dict:
    payload = {
        "volumes_update": {}
    }
    if volumes_to_mount:
        payload["volumes_update"]["volumes_to_mount"] = volumes_to_mount
    if volumes_to_unmount:
        payload["volumes_update"]["volumes_to_unmount"] = volumes_to_unmount
    return payload


def get_raw_content_url(notebook_url):
    if not notebook_url.endswith(VALID_NOTEBOOK_EXT):
        return None

    if notebook_url.startswith(GITHUB_URL):
        github_file_path = notebook_url.partition(GITHUB_URL)[2]
        raw_content_url = get_raw_github_user_content_url(github_file_path)

    elif notebook_url.startswith(GIST_URL):
        raw_content_url = get_raw_gist_user_content_url(notebook_url)

    elif notebook_url.startswith(COLAB_URL):
        file_path = notebook_url.partition(COLAB_URL)[2]

        if file_path.startswith(GITHUB_PREFIX):
            raw_content_url = get_raw_github_user_content_url(file_path.partition(GITHUB_PREFIX)[2])
        elif file_path.startswith(GIST_PREFIX):
            raw_content_url = get_raw_gist_user_content_url(file_path)
        elif file_path.startswith(DRIVE_PREFIX):
            # currently not allowing drive urls, as we aren't able to clone/download notebooks on drive to notebooks on TIR
            # raw_content_url = f"{COLAB_RAW_CONTENT_URL}{file_path.partition(DRIVE_PREFIX)[2]}"
            return None
        else:
            return None

    else:
        return None

    return raw_content_url


def get_raw_github_user_content_url(github_file_path):
    file_path_split = github_file_path.split("/")
    del file_path_split[2]  # remove the blob keyword present before the branch name
    return f"{GITHUB_RAW_CONTENT_URL}{'/'.join(file_path_split)}"


def get_raw_gist_user_content_url(notebook_url):
    url_split = notebook_url.split("/")
    file_name = url_split.pop(-1)
    gist_id = url_split[-1]
    gist_data = get_gist_data(gist_id)
    return gist_data.get("files", {}).get(file_name, {}).get("raw_url")


def get_gist_data(gist_id):
    try:
        resp = requests.get(GET_GIST_DATA_URL.format(gist_id=gist_id))
        return resp.json()
    except Exception:
        return {}


def notebooks_search_filter(notebook_qs, **kwargs):
    # normal search
    if kwargs.get("search_string"):
        search_string = kwargs.get("search_string")
        notebook_qs = notebook_qs.filter(
            Q(name__icontains=search_string) |
            Q(sku_item_price__sku__name__icontains=search_string)
        )

    # advanced search
    if process_boolean(kwargs.get("is_advanced_search"), False):
        notebook_qs = advanced_search_filter(
            notebook_qs, NOTEBOOK_FILTER_KEY_MAPPING, NOTEBOOK_EXCLUDE_KEY_MAPPING, **kwargs
        )

    return notebook_qs


def get_ssh_details(project_namespace, customer, notebook_obj):
    ssh_details = {}
    notebook_slug_name = notebook_obj.slug_name
    if not is_ssh_enabled(notebook_obj):
        return ssh_details
    ssh_service_name = f"ssh-{notebook_slug_name}"
    status, response = NotebookGrootService(project_namespace, customer).get_ssh_service_ip(ssh_service_name)
    if status:
        ssh_service_ip = response.get("LoadBalancerIP")
        ssh_details["ip"] = ssh_service_ip
        # commenting below code as disabled password is true
        # ssh_details["password"] = get_notebook_password(project_namespace, customer, notebook_slug_name)
        ssh_details["username"] = SSH_DEFAULT_USER_NAME
        ssh_details["show_ssh_content"] = True
    return ssh_details


def get_notebook_password(project_namespace, customer, notebook_slug_name):
    response = NotebookGrootService(project_namespace, customer).send_notebook_details_request(notebook_slug_name)
    try:
        return response.json().get("notebooks").get("notebook_password", "")
    except Exception:
        return ""


def is_ssh_enabled(notebook_obj):
    try:
        if notebook_obj.ssh_keys.exists():
            return True
    except Exception:
        return False


def send_notebook_start_email(customer_obj, cc_emails, notebook_obj, team_name):
    notebook_creation_template = NOTEBOOK_START_TEMPLATE_NAME

    notebook_start_success_template_object = Template.objects.filter(name=notebook_creation_template).first()
    if not notebook_start_success_template_object:
        logger.error("NOTEBOOK | SEND_NOTEBOOK_START_EMAIL | NOTEBOOK_START_SUCCESS_TEMPLATE_NOT_FOUND")
        return
    subject = notebook_start_success_template_object.subject
    ssh_details = get_ssh_details(notebook_obj.project.namespace, customer_obj, notebook_obj)
    nb_image = CUSTOM_IMAGE if notebook_obj.is_image_type_custom() else notebook_obj.image_version.image.name
    body = get_template(notebook_creation_template).render(
        {"notebook_name": notebook_obj.name, "project_name": notebook_obj.project.name,
         "plan_name": notebook_obj.sku.name, "image_name": nb_image, "team_name": team_name,
         **ssh_details,
         "cloud_support_email_address": settings.CLOUD_PLATFORM_EMAIL}
    )
    try:
        mandrill_manager.send_email([], [customer_obj.email], body, subject, cc_email_list=cc_emails)
    except Exception as e:
        logger.error(f"NOTEBOOK | SEND_NOTEBOOK_START_EMAIL | Customer - {customer_obj.email} | MAIL - {customer_obj.email} | "
                     f"CRITICAL_RED | ERROR_IN_SENDING_EMAIL - {e}")


def mail_customer_after_notebook_start(notebook, action, customer):
    if action != START_NOTEBOOK_ACTION and not is_ssh_enabled(notebook):
        return
    cc_email_list = get_team_owner_admin_email_list(notebook.project.team_id, emails_to_exclude=[customer.email])
    team_name = notebook.project.team.name
    send_task(
        SEND_NOTEBOOK_START_EMAIL_TASK,
        kwargs={"customer_obj": customer,
                'notebook': notebook,
                'cc_email_list': cc_email_list,
                'team_name': team_name,
                },
        countdown=COUNTDOWN_FOR_NOTEBOOK_CREATION_MAIL
    )


def get_unreserved_egress_gateway_obj():
    from random import choice
    egress_qs = EgressGatewayDetail.objects.filter(is_active=True, reserved=False)
    active_egress_pks = list(egress_qs.values_list('id', flat=True))
    try:
        random_egress_pk = choice(active_egress_pks)
        egress_gateway_obj = egress_qs.get(pk=random_egress_pk)
        return egress_gateway_obj
    except Exception:
        return None


def unreserved_egress_gateway_obj_on_notebook_deletion(notebook: object):
    if notebook.egress_gateway:
        notebook.egress_gateway.reserved = False
        notebook.egress_gateway.save()


def get_notebook_addon_env_vars(notebook: Notebook):
    addon_env_vars = {}
    for add_on in NOTEBOOK_ADD_ONS_LIST:
        add_on_uppercase = add_on.upper()
        addon_env_vars[f"{add_on_uppercase}_ROOT_PATH"] = notebook.get_add_on_root_path(add_on)
        addon_env_vars[f"{add_on_uppercase}_URL"] = notebook.get_add_on_url(add_on)
    return addon_env_vars


def send_free_tier_auto_convert_failed_email(notebook: Notebook, paid_sku_item_price):
    cc_emails = get_team_owner_admin_email_list(notebook.project.team.id, [notebook.created_by.email])
    to_email = notebook.created_by.email
    nb_auto_convert_failed_object = Template.objects.filter(name=NOTEBOOK_FREE_TIER_AUTO_CONVERT_FAILED_TEMPLATE).first()
    if not nb_auto_convert_failed_object:
        logger.error("NOTEBOOK | SEND_FREE_TIER_NOTEBOOK_AUTO_CONVERT_FAILED_EMAIL | CRITICAL_RED | NOTEBOOK_FREE_TIER_AUTO_CONVERT_FAILED_TEMPLATE_NOT_FOUND") 
        return
    subject = nb_auto_convert_failed_object.subject
    mail_subject = str(subject).format(notebook_name=notebook.name)
    body = get_template(NOTEBOOK_FREE_TIER_AUTO_CONVERT_FAILED_TEMPLATE).render({
        "notebook_name": notebook.name,
        "sku_pricing": paid_sku_item_price.unit_price * 24,
        "free_sku_series": notebook.sku_item_price.sku.series,
        "paid_sku": paid_sku_item_price.sku.name,
    })
    try:
        mandrill_manager.send_email([], [to_email], body, mail_subject, cc_email_list=cc_emails)
    except Exception as e:
        logger.error(f"NOTEBOOK | SEND_FREE_TIER_NOTEBOOK_AUTO_CONVERT_FAILED_EMAIL | CRITICAL_RED | ERROR_IN_SENDING_EMAIL | TO_EMAIL:{to_email} | ERROR: {e}")


def get_payload_for_sfs_mount_umount(sfs_to_mount: list, sfs_umount: list, sfs_path) -> dict:
    payload = {
        "sfs_update": {}
    }
    if sfs_to_mount:
        payload["sfs_update"]["sfs_mount"] = sfs_to_mount
        payload["sfs_update"]["sfs_path"] = sfs_path
    if sfs_umount:
        payload["sfs_update"]["sfs_umount"] = sfs_umount
    return payload
