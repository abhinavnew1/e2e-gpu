from datetime import datetime, timedelta
from urllib.parse import urljoin

from django.conf import settings
from django.contrib.contenttypes.models import ContentType
from django.db import models
from multiselectfield import MultiSelectField

from container_registry.models import NamespaceDetail
from customer.models import Customer
from dataset.models import Dataset
from distributed_jobs.models import SfsDetail
from e2e_core.helpers import mark_delete_related_objects
from e2e_core.jsonfield import JSONField
from e2e_core.mixins import BaseMixin, SafeDeleteMixinExtended
from gpu_service.constants import COMMITTED
from gpu_service.models import ImageVersion, SkuItemPrice
from notebook.constants import (CUSTOM_IMAGE, DEFAULT_PVC_DISK_SIZE,
                                DISABLE_PASSWORD_ACCESS, DONE,
                                NOTEBOOK_ADD_ON_CHOICES,
                                NOTEBOOK_ADD_ON_ROOT_PATH,
                                NOTEBOOK_AUTO_SHUTDOWN_TIMEOUT_CHOICES,
                                NOTEBOOK_IMAGE_TYPE_CHOICES,
                                NOTEBOOK_INSTANCE_TYPE_CHOICES,
                                NOTEBOOK_LAB_URL, NOTEBOOK_NAME_MAX_LENGTH,
                                NOTEBOOK_STATUS_CHOICES, PAID_USAGE, READY,
                                WAITING)
from projects.models import Projects
from ssh_keys.models import SSHKey


class NotebookPVCStorage(SafeDeleteMixinExtended, BaseMixin):
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    disk_size = models.IntegerField(default=DEFAULT_PVC_DISK_SIZE)

    def __str__(self):
        return self.disk_size_str

    @property
    def disk_size_str(self):
        return f"{self.disk_size}GB"

    def mark_deleted(self):
        if self.deleted_at is None:
            self.deleted_at = datetime.now()
            self.save(update_fields=['deleted_at', 'updated_at', ])


class NotebookDatasetMapping(SafeDeleteMixinExtended, BaseMixin):
    notebook = models.ForeignKey(to='notebook.Notebook', on_delete=models.CASCADE)
    dataset = models.ForeignKey(Dataset, on_delete=models.CASCADE)
    is_mounted = models.BooleanField(default=True)
    mount_start_date = models.DateTimeField()
    mount_end_date = models.DateTimeField(default=None, null=True, blank=True)

    def __str__(self):
        return f"{self.notebook.id}: {self.dataset.id}: {self.is_mounted}"

    def delete(self):
        self.is_mounted = False
        self.mount_end_date = datetime.now()
        super().delete()


class EgressGatewayDetail(SafeDeleteMixinExtended, BaseMixin):
    gateway_name = models.CharField(max_length=256)
    public_ip = models.CharField(max_length=256)
    reserved = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"EgressGatewayDetail:({self.id}: {self.gateway_name} :{self.public_ip} )"


class Notebook(SafeDeleteMixinExtended, BaseMixin):
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    name = models.CharField(max_length=NOTEBOOK_NAME_MAX_LENGTH)
    project = models.ForeignKey(Projects, on_delete=models.CASCADE)
    slug_name = models.CharField(unique=True, max_length=40, editable=False)
    image_type = models.CharField(choices=NOTEBOOK_IMAGE_TYPE_CHOICES, max_length=32)
    image_version = models.ForeignKey(ImageVersion, on_delete=models.SET_NULL, null=True, blank=True)
    sku_item_price = models.ForeignKey(SkuItemPrice, on_delete=models.SET_NULL, null=True)
    auto_shutdown_timeout = models.IntegerField(choices=NOTEBOOK_AUTO_SHUTDOWN_TIMEOUT_CHOICES, null=True, blank=True, default=None)
    status = models.CharField(choices=NOTEBOOK_STATUS_CHOICES, max_length=32, default=WAITING)
    status_log = JSONField(default=None, null=True, blank=True)
    last_activity = models.DateTimeField(default=None, null=True, blank=True)
    created_by = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True, related_name="notebook_created_by")
    pvc = models.OneToOneField(NotebookPVCStorage, on_delete=models.PROTECT)
    instance_type = models.CharField(choices=NOTEBOOK_INSTANCE_TYPE_CHOICES, max_length=50, default=PAID_USAGE)
    mounted_datasets = models.ManyToManyField(Dataset, through=NotebookDatasetMapping, related_name="mounted_on_notebooks")
    ssh_keys = models.ManyToManyField(SSHKey, blank=True)
    disable_ssh_login_password = models.BooleanField(default=True)
    custom_registry_image_url = models.TextField(null=True, blank=True)
    egress_gateway = models.ForeignKey(EgressGatewayDetail, on_delete=models.SET_NULL, null=True, blank=True)
    registry_namespace = models.ForeignKey(NamespaceDetail, on_delete=models.SET_NULL, null=True, blank=True)
    add_ons = MultiSelectField(choices=NOTEBOOK_ADD_ON_CHOICES, max_length=100, blank=True, help_text="notebook add-ons like tensorboard, gradio etc.")
    is_jupyterlab_enabled = models.BooleanField()
    sfs_mounted = models.ManyToManyField(SfsDetail, blank=True)

    def __str__(self):
        return f"<Notebook({self.id}: {self.name}: {self.status})>"

    @classmethod
    def get_notebook(cls, id):
        return cls.objects.filter(deleted_at__isnull=True, id=id)

    @property
    def sku(self):
        return self.sku_item_price.sku

    @property
    def lab_url(self):
        if self.is_jupyterlab_enabled and self.status == READY:
            return NOTEBOOK_LAB_URL.format(namespace=self.project.namespace, notebook_slug=self.slug_name)
        return None

    def get_add_on_root_path(self, add_on):
        return NOTEBOOK_ADD_ON_ROOT_PATH.format(
            add_on_name=add_on,
            namespace=self.project.namespace,
            notebook_slug=self.slug_name,
        )

    def get_add_on_url(self, add_on):
        return urljoin(settings.NOTEBOOK_BASE_URL, self.get_add_on_root_path(add_on))

    @property
    def disk_size(self):
        return self.pvc.disk_size

    def get_mounted_datasets(self):
        # self.mounted_datasets.all() does not filter the soft deleted records in NotebookDatasetMapping Model. Hence this method.
        return self.mounted_datasets.filter(
            notebookdatasetmapping__deleted=False, notebookdatasetmapping__is_mounted=True
        )

    def update_status(self, status):
        self.status = status
        self.save(update_fields=['status', 'updated_at',])

    def mark_deleted(self):
        from notebook.helpers import unreserved_egress_gateway_obj_on_notebook_deletion
        if self.deleted_at is None:
            mark_delete_related_objects(self)
            self.update_status(DONE)
            self.deleted_at = datetime.now()
            self.save(update_fields=['deleted_at', 'updated_at', ])
            self.update_end_date_in_notebook_history(end_date=self.deleted_at)
            self.terminate_reserve_instance()
            self.pvc.mark_deleted()
            self.update_end_date_in_notebook_pvc_history(end_date=self.deleted_at)
            self.mounted_datasets.clear()
            unreserved_egress_gateway_obj_on_notebook_deletion(self)

    def delete(self):
        self.update_status(DONE)
        self.pvc.delete()
        super().delete()

    def is_committed(self):
        if self.sku_item_price.sku_type == COMMITTED:
            return True
        return False

    def get_reserve_instance_entry(self):
        if self.is_committed():
            from reserve_instance.models import ReserveInstance
            return ReserveInstance.objects.filter(content_type_id=ContentType.objects.get_for_model(type(self)).id, resource_id=self.id).last()
        return None

    def create_reserve_instance_entry(self, reserve_instance_data, start_date=None):
        if self.is_committed():
            from reserve_instance.models import ReserveInstance
            start_date = start_date if start_date else datetime.now()
            reserve_instance = self.get_reserve_instance_entry()
            if not reserve_instance:
                reserve_instance = ReserveInstance.objects.create(resource=self, sku_item_price=self.sku_item_price, next_sku_item_price_id=reserve_instance_data.get("next_sku_item_price_id"),
                                                                  updation_policy=reserve_instance_data["committed_instance_policy"])
            reserve_instance.sku_item_price = self.sku_item_price
            reserve_instance.next_sku_item_price_id = reserve_instance_data.get("next_sku_item_price_id")
            reserve_instance.updation_policy = reserve_instance_data["committed_instance_policy"]
            reserve_instance.save(update_fields=['sku_item_price', 'next_sku_item_price_id', 'updation_policy', 'updated_at',])
            reserve_instance.create_new_transaction(start_date)

    def terminate_reserve_instance(self):
        if self.is_committed():
            reserve_instance = self.get_reserve_instance_entry()
            reserve_instance.terminate()

    def create_notebook_history(self, start_date=None, *args, **kwargs):
        history_start_date = start_date if start_date else datetime.now()
        billable_customer = self.project.team.owner.get_primary_contact()
        history_end_date = start_date + timedelta(days=self.sku_item_price.committed_days) if self.sku_item_price.sku_type == COMMITTED else None
        history_obj = NotebookHistory.objects.create(customer=billable_customer, notebook=self,
                                                     start_date=history_start_date, end_date=history_end_date, sku_item_price=self.sku_item_price)
        if self.is_committed():
            from reserve_instance.helpers import \
                deduct_reserve_instance_price_on_my_account
            deduct_reserve_instance_price_on_my_account(billable_customer, self.sku_item_price, history_obj.id, self.name)
        return history_obj

    def update_end_date_in_notebook_history(self, end_date=None, *args, **kwargs):
        end_date = end_date if end_date else datetime.now()
        nb_history = self.get_active_notebook_history()
        if nb_history:  # end date won't be null if notebook is stopped
            nb_history.end_date = end_date
            nb_history.save(update_fields=['end_date', 'updated_at', ])

    def get_active_notebook_history(self):
        billable_customer = self.project.team.owner.get_primary_contact()
        return NotebookHistory.objects.filter(
                    notebook=self, customer=billable_customer, sku_item_price=self.sku_item_price, end_date__isnull=True
                ).last()

    def create_notebook_pvc_history(self, start_date=None, *args, **kwargs):
        start_date = start_date if start_date else self.created_at
        billable_customer = self.project.team.owner.get_primary_contact()
        return NotebookPVCHistory.objects.create(
            customer=billable_customer, notebook=self, start_date=start_date, disk_size=self.disk_size
        )

    def update_end_date_in_notebook_pvc_history(self, end_date=None, *args, **kwargs):
        end_date = end_date if end_date else datetime.now()
        billable_customer = self.project.team.owner.get_primary_contact()
        pvc_history = NotebookPVCHistory.objects.filter(
            notebook=self, customer=billable_customer, disk_size=self.disk_size).last()
        pvc_history.end_date = end_date
        pvc_history.save(update_fields=['end_date', 'updated_at', ])

    def update_ssh_keys(self, customer, ssh_to_add=[], ssh_to_remove=[]):
        if ssh_to_remove:
            ssh_keys = SSHKey.objects.filter(ssh_key__in=ssh_to_remove, customer=customer)
            self.ssh_keys.remove(*list(ssh_keys))
        if ssh_to_add:
            ssh_keys = SSHKey.objects.filter(ssh_key__in=ssh_to_add, customer=customer)
            self.ssh_keys.add(*list(ssh_keys))

    def is_image_type_custom(self):
        if self.image_type == CUSTOM_IMAGE:
            return True
        return False


class NotebookHistory(SafeDeleteMixinExtended, BaseMixin):
    customer = models.ForeignKey(Customer, null=True, on_delete=models.SET_NULL)
    notebook = models.ForeignKey(Notebook, null=True, on_delete=models.SET_NULL)
    start_date = models.DateTimeField()
    end_date = models.DateTimeField(default=None, null=True, blank=True)
    sku_item_price = models.ForeignKey(SkuItemPrice, on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return f"<NotebookHistory:({self.id}: {self.notebook.name}: {self.customer.email})>"

    @property
    def sku(self):
        return self.sku_item_price.sku


class NotebookPVCHistory(SafeDeleteMixinExtended, BaseMixin):
    customer = models.ForeignKey(Customer, null=True, on_delete=models.SET_NULL)
    notebook = models.ForeignKey(Notebook, null=True, on_delete=models.SET_NULL)
    disk_size = models.IntegerField()
    start_date = models.DateTimeField()
    end_date = models.DateTimeField(default=None, null=True, blank=True)

    def __str__(self):
        return f"NotebookPVCHistory:({self.id}: {self.notebook.name}: {self.disk_size}GB)"
