import logging

from e2e_core.api.v1.services.base import BaseService
from e2e_core.helpers import support_ticket_generator
from e2e_gpu.celery import app
from notebook.api.v1.services.notebook_service import (NotebookGrootService,
                                                       NotebookService)
from notebook.constants import (H100_SKU_NAME, NOTEBOOK_AUTO_SHUTDOWN_TASK,
                                NOTEBOOK_AUTO_SHUTDOWN_TASK_RETRY_DELAY_TIME,
                                NOTEBOOK_AUTO_SHUTDOWN_TASK_RETRY_LIMIT,
                                NOTEBOOK_H100_PVC_DELETION_FAILED_MESSAGE,
                                NOTEBOOK_H100_PVC_DELETION_FAILED_SUBJECT,
                                NOTEBOOK_PVC_DELETION_FAILED_MESSAGE,
                                NOTEBOOK_PVC_DELETION_FAILED_SUBJECT,
                                NOTEBOOK_PVC_DELETION_TASK,
                                NOTEBOOK_PVC_DELETION_TASK_COUNTDOWN,
                                NOTEBOOK_PVC_DELETION_TASK_MAX_RETRIES,
                                SEND_NOTEBOOK_CREATION_EMAIL_TASK,
                                SEND_NOTEBOOK_START_EMAIL_TASK,)
from notebook.helpers import perform_shutdown_action
from notebook.models import Notebook

logger = logging.getLogger(__name__)

@app.task(
    name=NOTEBOOK_AUTO_SHUTDOWN_TASK,
    bind=True,
    # max_retries=NOTEBOOK_AUTO_SHUTDOWN_TASK_RETRY_LIMIT,
    # default_retry_delay=NOTEBOOK_AUTO_SHUTDOWN_TASK_RETRY_DELAY_TIME,
)
def notebook_auto_shutdown_task(self, *args, **kwargs):
    notebook_id = kwargs.get("notebook_id")
    count = kwargs.get("count", 0)
    notebook = Notebook.objects.filter(deleted_at__isnull=True, id=notebook_id).first()
    if notebook:
        is_success = perform_shutdown_action(notebook)
        # TODO: notify user?
        if not is_success and count!=NOTEBOOK_AUTO_SHUTDOWN_TASK_RETRY_LIMIT:
            kwargs["count"] = count + 1
            self.apply_async(args=args, kwargs=kwargs, countdown=NOTEBOOK_AUTO_SHUTDOWN_TASK_RETRY_DELAY_TIME)
        else:
            #TODO: generate support ticket
            pass
        # send any mail to customer ?


@app.task(
    name=NOTEBOOK_PVC_DELETION_TASK,
    bind=True,
    default_retry_delay=NOTEBOOK_PVC_DELETION_TASK_COUNTDOWN,
    max_retries=NOTEBOOK_PVC_DELETION_TASK_MAX_RETRIES,
)
def notebook_pvc_deletion_task(self, *args, **kwargs):
    project_namespace = kwargs.get("namespace")
    customer = kwargs.get("customer")
    notebook_id = kwargs.get("notebook_id")
    notebook = Notebook.objects.filter(id=notebook_id).first()

    if not notebook:
        logger.error(f"NOTEBOOK_PVC_DELETION_TASK | CRITICAL_RED | NOTEBOOK_NOT_FOUND | NOTEBOOK_ID:{notebook_id}")
        return

    if notebook.project.deleted_at is None:  # if namespace not already deleted
        status, response = NotebookGrootService(project_namespace, customer).delete_notebook_pvc_on_groot(notebook.slug_name)
        if not status:
            if self.request.retries == self.max_retries:
                error = response.json().get("log", "")
                support_ticket_generator(
                    errors=NOTEBOOK_PVC_DELETION_FAILED_MESSAGE.format(notebook_id=notebook.id, errors=error),
                    subject=NOTEBOOK_PVC_DELETION_FAILED_SUBJECT.format(email_id=customer.email),
                    customer=customer,
                )
            self.retry()

    if notebook.project.deleted_at is None and H100_SKU_NAME in notebook.sku.name.lower():  # if namespace not already deleted
        status, response = NotebookGrootService(project_namespace, customer).delete_notebook_h100_pvc_on_groot(notebook.slug_name)
        if not status:
            if self.request.retries == self.max_retries:
                error = response.json().get("log", "")
                support_ticket_generator(
                    errors=NOTEBOOK_H100_PVC_DELETION_FAILED_MESSAGE.format(notebook_id=notebook.id, errors=error),
                    subject=NOTEBOOK_H100_PVC_DELETION_FAILED_SUBJECT.format(email_id=customer.email),
                    customer=customer,
                )
            self.retry()


@app.task(
    name=SEND_NOTEBOOK_CREATION_EMAIL_TASK,
    bind=True,
)
def send_notebook_creation_email_task(self, *args, **kwargs):
    from notebook.helpers import send_notebook_creation_email
    customer_obj = kwargs.get('customer_obj')
    cc_email_list = kwargs.get('cc_email_list')
    notebook = kwargs.get('notebook')
    team_name = kwargs.get('team_name')
    send_notebook_creation_email(customer_obj, cc_email_list, notebook, team_name)

@app.task(
    name=SEND_NOTEBOOK_START_EMAIL_TASK,
    bind=True,
)
def send_notebook_start_email_task(self, *args, **kwargs):
    from notebook.helpers import send_notebook_start_email
    customer_obj = kwargs.get('customer_obj')
    cc_email_list = kwargs.get('cc_email_list')
    notebook = kwargs.get('notebook')
    team_name = kwargs.get('team_name')
    send_notebook_start_email(customer_obj, cc_email_list, notebook, team_name)
