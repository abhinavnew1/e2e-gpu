from django.contrib import admin
from safedelete.admin import SafeDeleteAdmin

from pipelines.models import (CommonTemplate, CommonTemplateRun, Experiments,
                              Pipelines, PipelineVersions, RunHistory, Runs,
                              ScheduledJobs)

class PipelinesAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "deleted_at",
        "id",
        "name",
        "pipeline_id",
        "project",
        "bucket",
        "access_key",
        "parameters",
        "pipeline_type",
        "created_by",
        "created_at",
        "updated_at",
        "description"
    )
    raw_id_fields = ("created_by", "project", "bucket", "access_key",)
    search_fields = ("id", "created_by__email", "name", "description", "project__name", "bucket__bucket_name",
                     "pipeline_id", "pipeline_type", "created_at", "updated_at")
    list_filter = ("deleted_at", "deleted")
    list_display_links = ("id", "name",)
    list_select_related = ("created_by", "project", "bucket", "access_key",)
    readonly_fields = ()


class PipelineVersionsAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "deleted_at",
        "id",
        "name",
        "pipeline",
        "version_id",
        "is_default_version",
        "created_by",
        "created_at",
        "updated_at",
        "description"
    )
    raw_id_fields = ("created_by", "pipeline",)
    search_fields = ("id", "created_by__email", "name", "description", "pipeline__name", "version_id", "created_at",
                     "updated_at")
    list_filter = ("deleted_at", "deleted")
    list_display_links = ("id", "name",)
    list_select_related = ("created_by", "pipeline",)
    readonly_fields = ()


class ExperimentsAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "deleted_at",
        "id",
        "name",
        "experiment_id",
        "project",
        "storage_state",
        "created_by",
        "created_at",
        "updated_at",
        "description"
    )
    raw_id_fields = ("created_by",)
    search_fields = ("id", "created_by__email", "name", "description", "experiment_id", "project__name",
                     "created_at", "updated_at")
    list_filter = ("deleted_at", "deleted")
    list_display_links = ("id", "name",)
    readonly_fields = ()


class RunsAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "deleted_at",
        "id",
        "name",
        "sku_item_price",
        "project",
        "created_by",
        "experiment",
        "pipeline_version",
        "run_id",
        "service_account",
        "pipeline_root",
        "state",
        "state_history",
        "scheduled_at",
        "finished_at",
        "parameters",
        "storage_state",
        "conditions",
        "pipeline_runtime",
        "runtime_parameters",
        "created_at",
        "updated_at",
        "description",
    )
    raw_id_fields = ("created_by", "sku_item_price", "project", "experiment", "pipeline_version")
    search_fields = ("id", "created_by__email", "name", "description", "project__name",
                     "experiment__name", "pipeline_version__name", "run_id", "service_account", "pipeline_root",
                     "state", "state_history", "scheduled_at", "finished_at", "parameters",
                     "storage_state", "conditions", "pipeline_runtime", "workflow_spec_manifest", "created_at",
                     "updated_at")
    list_filter = ("deleted_at", "deleted", "source")
    list_filter = ("deleted_at", "deleted", "source")
    list_display_links = ("id", "name",)
    list_select_related = ("project", "created_by", "sku_item_price", "sku_item_price__sku", "sku_item_price__currency",)
    readonly_fields = ()


class ScheduledJobsAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
    "id",
    "name",
    "description",
    "project",
    "created_by",
    "sku_item_price",
    "experiment",
    "pipeline_version",
    "job_id",
    "service_account",
    "max_concurrency",
    "is_enabled",
    "trigger",
    "parameters",
    "deleted_at",
    "source"
    )
    raw_id_fields = ("created_by", "sku_item_price", "project", "experiment", "pipeline_version")
    search_fields = ("id", "created_by__email", "name", "description", "project__name",
                     "experiment__name", "pipeline_version__name", "job_id", "service_account", "parameters",
                     "workflow_spec_manifest", "created_at")
    list_filter = ("deleted_at", "deleted", "source")
    list_display_links = ("id", "name",)
    list_select_related = ("project", "created_by", "sku_item_price", "sku_item_price__sku")
    readonly_fields = ("name", "description", "project", "created_by", "sku_item_price", "experiment", "pipeline_version", "job_id", 
                       "service_account", "max_concurrency", "is_enabled", "trigger", "parameters", "source")


class CommonTemplatesAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "name",
        "description",
        "yaml_file_text_content",
        "deleted_at",
        "created_by",
        "created_at",
        "updated_at",
    )
    raw_id_fields = ("created_by",)
    search_fields = ("id", "created_by__email", "name", "description", "created_at", "updated_at")
    list_filter = ("deleted_at", "deleted")
    list_display_links = ("id", "name",)
    list_select_related = ("created_by",)
    readonly_fields = ("id", "name", "description", "yaml_file_text_content", 
                       "deleted_at", "created_by", "created_at", "updated_at")


class CommonTemplateRunsAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "deleted_at",
        "id",
        "name",
        "status",
        "failure_reason",
        "project",
        "run_data",
        "template",
        "unique_id",
        "created_by",
        "created_at",
        "updated_at",
    )
    raw_id_fields = ("created_by", "project", "template")
    search_fields = ("id", "created_by__email", "name", "project__name", "created_at", "updated_at")
    list_filter = ("deleted_at", "deleted", "status")
    list_display_links = ("id", "name")
    list_select_related = ("project", "created_by", "template")
    readonly_fields = ("deleted_at", "id", "name", "status", "project", "run_data", "failure_reason",
                       "unique_id", "created_by", "created_at", "updated_at",)


class RunHistoryAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "run",
        "pod_name",
        "pod_uid",
        "sku_item_price",
        "start_date",
        "end_date",
        "customer",
        "created_at",
        "updated_at",
    )
    raw_id_fields = ("run", "sku_item_price", "customer",)
    search_fields = ("id", "customer__email", "run__name", "pod_name")
    list_filter = ("deleted",)
    list_display_links = ("id", "run")
    list_select_related = ("run", "sku_item_price", "customer",)
    readonly_fields = list_display


admin.site.register(Pipelines, PipelinesAdmin)
admin.site.register(PipelineVersions, PipelineVersionsAdmin)
admin.site.register(Experiments, ExperimentsAdmin)
admin.site.register(Runs, RunsAdmin)
admin.site.register(ScheduledJobs, ScheduledJobsAdmin)
admin.site.register(CommonTemplate, CommonTemplatesAdmin)
admin.site.register(CommonTemplateRun, CommonTemplateRunsAdmin)
admin.site.register(RunHistory, RunHistoryAdmin)
