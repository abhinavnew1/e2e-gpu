from django.conf import settings
from rbac.constants import PIPELINE, FINE_TUNING

# pipeline urls
PIPELINES_UPLOAD_URL_V1 = "apis/v1beta1/pipelines/upload?name={}&description={}&" \
                       "namespace={}"
PIPELINES_UPLOAD_EXISTING_URL_V1 = "apis/v1beta1/pipelines/upload_version?name={}&description={}&" \
                                   "namespace={}&pipelineid={}"
PIPELINES_RESOURCE_URL = "/apis/v1beta1/{}/"
PIPELINES_LIST_URL_V1 = "apis/v1beta1/{}?resource_reference_key.type=NAMESPACE&" \
                        "resource_reference_key.id={}&page_token={}&page_size={}&sort_by=created_at%20desc"
PIPELINE_URL_V1 = "apis/v1beta1/{}/{}?resource_reference_key.type=NAMESPACE&" \
                  "resource_reference_key.id={}&page_token=&page_size=10&sort_by=created_at%20desc"
PIPELINE_URL_UPDATE_V1 = "apis/v1beta1/{}/{}/{}?resource_reference_key.type=NAMESPACE&" \
                  "resource_reference_key.id={}&page_token=&page_size=10&sort_by=created_at%20desc"
PIPELINE_URL_UPDATE_V2 = "apis/v2beta1/{}/{}/{}?resource_reference_key.type=NAMESPACE&" \
                  "resource_reference_key.id={}&page_token=&page_size=10&sort_by=created_at%20desc"
PIPELINE_TEMPLATE_URL_V1 = "apis/v1beta1/{}/{}/{}?resource_reference_key.type=NAMESPACE&" \
                           "resource_reference_key.id={}&page_token=&page_size=10&sort_by=created_at%20desc"
RUNS_URL = "apis/v1beta1/runs?resource_reference_key.type=NAMESPACE&resource_reference_key.id={}&sort_by=created_at%20desc"

PIPELINE_VERSIONS_LIST_URL_V2 = "apis/v2beta1/pipelines/{}/versions?resource_key.type=NAMESPACE&" \
                           "resource_key.id={}&page_token={}&page_size={}&sort_by=created_at%20desc"
PIPELINE_VERSION_URL_V2 = "apis/v2beta1/pipelines/{}/versions/{}?resource_key.type=NAMESPACE&" \
                           "resource_key.id={}&page_size=10&sort_by=created_at%20desc"
LOG_URL = "k8s/pod/logs?podname={}&runid={}&podnamespace={}"

# scheduled jobs urls
PIPELINE_CREATE_LIST_JOBS_URL = "apis/v1beta1/jobs?resource_reference_key.type=NAMESPACE&resource_reference_key.id={}&sort_by=created_at%20desc"
PIPELINE_JOB_DETAILS_ACTION_URL = "apis/v1beta1/jobs/{}{}?resource_reference_key.type=NAMESPACE&resource_reference_key.id={}&sort_by=created_at%20desc"
GET_RUNS_FOR_JOB_ID_URL = "apis/v1beta1/runs?resource_reference_key.type=JOB&resource_reference_key.id={job_id}"

# V2 urls
PIPELINES_LIST_URL_V2 = "apis/v2beta1/{}?namespace={}&page_token={}&page_size={}&sort_by=created_at%20desc"
PIPELINE_URL_V2 = "apis/v2beta1/{}/{}?resource_reference_key.type=NAMESPACE&" \
                  "resource_reference_key.id={}&page_token=&page_size=10&sort_by=created_at%20desc"

# PIPELINE RELATED PODS NAME PATTERN
PIPELINE_GENERATE_NAME_PATTERN = "kfp-ver-"

# PIPELINE YAML INVALID/UPSUPPORTED
INVALID_PIPELINE_YAML_CONTENT = "The following argument is invalid/unsupported in yaml : {}"
CONTAINER_SET = 'containerSet'

# pipeline-run groot urls
PIPELINE_SETUP_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/pipeline-setup"
PIPELINE_RUN_POD_EVENTS_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/pod/{pod_name}"
PIPELINE_WORKFLOW_EGRESS_POLICY_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/workflow_egress_policy"
PIPELINE_WORKFLOW_EGRESS_POLICY_DETAILS_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/workflow_egress_policy/{egress_policy_name}"

# msg
SOMETHING_WENT_WRONG = "Error while fetching Details from kubenetes"
RUN_ACTION_FAILED = "Failed to {}"
PIPELINE_SETUP_SUCCESSFUL = "Pipeline Setup Successful"
PIPELINE_SETUP_FAILED_IN_GROOT = "Pipeline Setup Failed in Groot"
MANDATORY = "is mandatory"
ERROR_IN_RUN_CREATION_IN_KUBERNETES = "Error in Run Creation in Kubernetes"
ERROR_IN_EXPERIMENT_CREATION_IN_KUBERNETES = "Error in Experiment Creation in Kubernetes"
DELETE_FAILED_MSG = 'Failed to delete {}'

# logs msg recieved from kuberenetes, reused here
COULD_NOT_GET_MAIN_CONTAINER_LOGS = "Could not get main container logs:"
UNABLE_TO_RETRIEVE_CONTAINER_LOGS = "unable to retrieve container logs for containerd:"
BUCKET_MAIN_CONTAINER_LOGS_PATH = "projects/{namespace}/logs/pods/{pod_name}/main/"
LOGS_BYTE_STREAM_SIZE = 1024 * 1024  # chunk_size 1mb
INVALID_YAML_FILE = "Invalid Yaml File"
MAX_TEXT_LENGTH = 255
ARGO = "Argo"
KUBEFLOW = "Kubeflow"
NONE = "None"
PIPELINE_TYPES = ((ARGO, ARGO), (KUBEFLOW, KUBEFLOW), (NONE, NONE))
# services which use pipeline internally
PIPELINE_SOURCE_TYPES = ((PIPELINE, PIPELINE), (FINE_TUNING, FINE_TUNING))
# run actions
RETRY_RUN = "retry"
TERMINATE_RUN = "terminate"

# scheduled job constants
# services which use scheduled job internally
SCHEDULED_JOB_SOURCE_TYPES = ((PIPELINE, PIPELINE),)
# scheduled job actions
ENABLE = "enable"
DISABLE = "disable"
# scheduled job datetime format
SCHEDULED_JOB_TIME_FORMAT = '%Y-%m-%dT%H:%M:%S.%fZ'
GET_SCHEDULED_JOB_RELATED_RUNS = "get_related_runs"

# pipeline-run events
PIPELINE_CREATE_EVENT = "PIPELINE_CREATE"
PIPELINE_DELETE_EVENT = "PIPELINE_DELETE"
PIPELINE_VERSION_CREATE_EVENT = "PIPELINE_VERSION_CREATE"
PIPELINE_VERSION_DELETE_EVENT = "PIPELINE_VERSION_DELETE"
EXPERIMENT_CREATE_EVENT = "EXPERIMENT_CREATE"
EXPERIMENT_DELETE_EVENT = "EXPERIMENT_DELETE"
RUN_CREATE_EVENT = "RUN_CREATE"
RUN_DELETE_EVENT = "RUN_DELETE"
RUN_ACTION_EVENT = "RUN_{}_ACTION"
# scheduled job events
SCHEDULED_JOB_CREATE_EVENT = "SCHEDULED_JOB_CREATE"
SCHEDULED_JOB_DELETE_EVENT = "SCHEDULED_JOB_DELETE"
SCHEDULED_JOB_ACTION_EVENT = "SCHEDULED_JOB_{}_ACTION"
# common template events
TEMPLATE_RUN_CREATE_EVENT = "TEMPLATE_RUN_CREATE"

# run state/status
ERROR = 'Error'
FAILED = 'Failed'
PENDING = 'Pending'
RUNNING = 'Running'
SKIPPED = 'Skipped'
SUCCEEDED = 'Succeeded'
CACHED = 'Cached'
TERMINATING = 'Terminating'
TERMINATED = 'Terminated'
RETRYING = 'Retrying'
UNKNOWN = 'Unknown'
OMITTED = 'Omitted'
RUN_SUCCEEDED = "Succeeded"
RUN_STATES = ((ERROR, ERROR), (FAILED, FAILED), (PENDING, PENDING), (RUNNING, RUNNING), (SKIPPED, SKIPPED),
               (SUCCEEDED, SUCCEEDED), (CACHED, CACHED), (TERMINATING, TERMINATING), (TERMINATED, TERMINATED),
               (UNKNOWN, UNKNOWN), (OMITTED, OMITTED))
BILLABLE_RUN_STATES = [ERROR, RUNNING, TERMINATING]

# jobs task names
SYNC_SCHEDULED_JOBS_RELATED_RUNS_TASK = "sync_scheduled_jobs_related_runs_task"

# commom template run choices
RUN = 'run'
SCHEDULED_JOB = 'scheduled_job'
COMMON_TEMPLATE_RUN_TYPES = ((RUN, RUN),
                             (SCHEDULED_JOB, SCHEDULED_JOB))
CREATED_SUCCESSFULLY = 'created_successfully'
CREATION_ERROR = 'creation_error'
COMMON_TEMPLATE_RUN_STATUS = ((CREATED_SUCCESSFULLY, CREATED_SUCCESSFULLY),
                              (CREATION_ERROR, CREATION_ERROR))
CREATING_RUN_MSG = "Your Run Will be created Shortly"

# commom template task
CREATE_TEMPLATE_RUNS_TASK = "create_template_runs_task"

# pods constants
POD = 'Pod'
POD_PENDING = "Pending"
POD_RESOURCE_DURATION = "resourcesDuration"
POD_HOST_NODE_NAME = "hostNodeName"

# pipeline-run resource usage metric
INTERVAL_TO_TIME_FORMAT_MAPPING = {
    '5m': [300, '%I:%M:%S%p', 15],
    '1h': [3600, '%I:%M%p', 180],
    '1d': [86400, '%I:%M:%p', 3600],
    '7d': [604800, '%m/%d/%Y, %I%p', 28800],
    '1mn': [2592000, '%m/%d/%Y', 86400]
}
CONTAINER_CPU_USAGE_KEY = "container_cpu_usage_seconds_total"
PIPELINE_RUNS_MONITORING_DATA_GET_ERROR = "Can't get run monitoring data : {reason}"
START_END_MANDATORY = 'end_time/start_time both mandatory'
START_GREATER_THAN_END = 'start_time>end_time not possible'

# metrics type
DCGM_FI_DEV_GPU_UTIL = "DCGM_FI_DEV_GPU_UTIL"
DCGM_FI_DEV_MEM_COPY_UTIL = "DCGM_FI_DEV_MEM_COPY_UTIL"
DCGM_FI_DEV_GPU_TEMP = "DCGM_FI_DEV_GPU_TEMP"
DCGM_FI_DEV_POWER_USAGE = "DCGM_FI_DEV_POWER_USAGE"
CONTAINER_CPU_USAGE_SECONDS_TOTAL = "container_cpu_usage_seconds_total"
CONTAINER_MEMORY_USAGE_BYTES = "container_memory_usage_bytes"
DEFAULT = "default"
DEFAULT_METRICS = [DCGM_FI_DEV_GPU_UTIL, DCGM_FI_DEV_MEM_COPY_UTIL, DCGM_FI_DEV_GPU_TEMP, DCGM_FI_DEV_POWER_USAGE, CONTAINER_CPU_USAGE_SECONDS_TOTAL, CONTAINER_MEMORY_USAGE_BYTES]
