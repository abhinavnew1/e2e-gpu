import logging

from rest_framework import status

from eventlogs.api.v1.services.eventlog_service import EventLogService
from eventlogs.constants import (EVENTLOG_FAILED_STATUS,
                                 EVENTLOG_SUCCESS_STATUS,
                                 EXPERIMENT_SERVICE_CODE)
from pipelines.constants import (EXPERIMENT_CREATE_EVENT,
                                 EXPERIMENT_DELETE_EVENT)
from pipelines.models import Experiments
from rbac.constants import CREATE, DELETE, UPDATE

logger = logging.getLogger(__name__)


def experiment_create_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(EXPERIMENT_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=EXPERIMENT_CREATE_EVENT,
            resource_name=request.data.get("name"),
            resource_id="",
            detailed_info={"request": request.data, "project_id": kwargs.get('project_id')},
            resource_obj_id=None,
            event_type=CREATE,
        )
        response = func(*args, **kwargs)
        if response.status_code == status.HTTP_200_OK:
            event_log.update_log(status=EVENTLOG_SUCCESS_STATUS, resource_id=response.data["data"]["id"],
                                 resource_obj_id=response.data["data"]["id"])
        else:
            event_log.log_event_failure()
        return response

    return wrapper_func


def experiment_delete_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(EXPERIMENT_SERVICE_CODE)
        experiment = Experiments.objects.filter(experiment_id=kwargs.get("experiment_id"), deleted_at__isnull=True).last()
        event_log.create_log(
            request=request,
            event=EXPERIMENT_DELETE_EVENT,
            resource_name=experiment.name,
            resource_id=experiment.id,
            detailed_info={"project_id": kwargs.get('project_id')},
            resource_obj_id=experiment.id,
            event_type=DELETE,
        )
        response = func(*args, **kwargs)
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else \
            event_log.log_event_failure()
        return response

    return wrapper_func
