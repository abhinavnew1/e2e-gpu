import logging

from rest_framework import status

from eventlogs.api.v1.services.eventlog_service import EventLogService
from eventlogs.constants import (EVENTLOG_FAILED_STATUS,
                                 EVENTLOG_SUCCESS_STATUS,
                                 PIPELINE_VERSION_SERVICE_CODE)
from pipelines.constants import (PIPELINE_VERSION_CREATE_EVENT,
                                 PIPELINE_VERSION_DELETE_EVENT)
from pipelines.models import PipelineVersions
from rbac.constants import CREATE, DELETE, UPDATE

logger = logging.getLogger(__name__)


def pipeline_version_create_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(PIPELINE_VERSION_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=PIPELINE_VERSION_CREATE_EVENT,
            resource_name=request.query_params.get("name"),
            resource_id="",
            detailed_info={"request": request.query_params, "project_id": kwargs.get('project_id')},
            resource_obj_id=None,
            event_type=CREATE,
        )
        response = func(*args, **kwargs)
        if response.status_code == status.HTTP_200_OK:
            event_log.update_log(status=EVENTLOG_SUCCESS_STATUS, resource_id=response.data["data"]["new_version_id"],
                                 resource_obj_id=response.data["data"]["id"])
        else:
            event_log.log_event_failure()
        return response

    return wrapper_func


def pipeline_version_delete_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(PIPELINE_VERSION_SERVICE_CODE)
        version = PipelineVersions.objects.filter(version_id=kwargs.get("version_id"), deleted_at__isnull=True).last()
        if version:
            event_log.create_log(
                request=request,
                event=PIPELINE_VERSION_DELETE_EVENT,
                resource_name=version.name,
                resource_id=version.id,
                detailed_info={"project_id": kwargs.get('project_id')},
                resource_obj_id=version.id,
                event_type=DELETE,
            )
        response = func(*args, **kwargs)
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else \
            event_log.log_event_failure()
        return response

    return wrapper_func
