import logging

from rest_framework import status

from eventlogs.api.v1.services.eventlog_service import EventLogService
from eventlogs.constants import (EVENTLOG_FAILED_STATUS,
                                 EVENTLOG_SUCCESS_STATUS, RUN_SERVICE_CODE)
from pipelines.constants import RUN_CREATE_EVENT, RUN_DELETE_EVENT, RUN_ACTION_EVENT
from pipelines.models import Runs
from rbac.constants import CREATE, DELETE, UPDATE

logger = logging.getLogger(__name__)


def run_create_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(RUN_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=RUN_CREATE_EVENT,
            resource_name=request.data.get("name"),
            resource_id="",
            detailed_info={"request": request.data, "project_id": kwargs.get('project_id')},
            resource_obj_id=None,
            event_type=CREATE,
        )
        response = func(*args, **kwargs)
        if response.status_code == status.HTTP_200_OK:
            event_log.update_log(status=EVENTLOG_SUCCESS_STATUS, resource_id=response.data["data"]["id"],
                                 resource_obj_id=response.data["data"]["id"])
        else:
            event_log.log_event_failure()
        return response

    return wrapper_func


def run_delete_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(RUN_SERVICE_CODE)
        run = Runs.objects.filter(run_id=kwargs.get("run_id"), deleted_at__isnull=True).last()
        event_log.create_log(
            request=request,
            event=RUN_DELETE_EVENT,
            resource_name=run.name,
            resource_id=run.id,
            detailed_info={"project_id": kwargs.get('project_id')},
            resource_obj_id=run.id,
            event_type=DELETE,
        )
        response = func(*args, **kwargs)
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else \
            event_log.log_event_failure()
        return response

    return wrapper_func


def run_action_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(RUN_SERVICE_CODE)
        run = Runs.objects.filter(run_id=kwargs.get("run_id"), deleted_at__isnull=True).last()
        action = request.query_params.get("action", "")
        event_log.create_log(
            request=request,
            event=RUN_ACTION_EVENT.format(action.upper()),
            resource_name=run.name,
            resource_id=run.id,
            detailed_info={"project_id": kwargs.get('project_id')},
            resource_obj_id=run.id,
            event_type=UPDATE,
        )
        response = func(*args, **kwargs)
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else \
            event_log.log_event_failure()
        return response

    return wrapper_func
