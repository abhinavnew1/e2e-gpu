import logging

from rest_framework import status

from eventlogs.api.v1.services.eventlog_service import EventLogService
from eventlogs.constants import (EVENTLOG_FAILED_STATUS,
                                 EVENTLOG_SUCCESS_STATUS, SCHEDULED_JOB_SERVICE_CODE)
from pipelines.constants import SCHEDULED_JOB_CREATE_EVENT, SCHEDULED_JOB_DELETE_EVENT, SCHEDULED_JOB_ACTION_EVENT
from pipelines.models import ScheduledJobs
from rbac.constants import CREATE, DELETE, UPDATE

logger = logging.getLogger(__name__)


def scheduled_job_create_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(SCHEDULED_JOB_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=SCHEDULED_JOB_CREATE_EVENT,
            resource_name=request.data.get("name"),
            resource_id="",
            detailed_info={"request": request.data, "project_id": kwargs.get('project_id')},
            resource_obj_id=None,
            event_type=CREATE,
        )
        response = func(*args, **kwargs)
        if response.status_code in [status.HTTP_200_OK, status.HTTP_201_CREATED]:
            event_log.update_log(status=EVENTLOG_SUCCESS_STATUS, resource_id=response.data["data"]["id"],
                                 resource_obj_id=response.data["data"]["id"])
        else:
            event_log.log_event_failure()
        return response

    return wrapper_func


def scheduled_job_delete_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(SCHEDULED_JOB_SERVICE_CODE)
        scheduled_job = ScheduledJobs.objects.filter(job_id=kwargs.get("job_id"), deleted_at__isnull=True).last()
        event_log.create_log(
            request=request,
            event=SCHEDULED_JOB_DELETE_EVENT,
            resource_name=scheduled_job.name,
            resource_id=scheduled_job.id,
            detailed_info={"project_id": kwargs.get('project_id')},
            resource_obj_id=scheduled_job.id,
            event_type=DELETE,
        )
        response = func(*args, **kwargs)
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else \
            event_log.log_event_failure()
        return response

    return wrapper_func


def scheduled_job_action_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(SCHEDULED_JOB_SERVICE_CODE)
        scheduled_job = ScheduledJobs.objects.filter(job_id=kwargs.get("job_id"), deleted_at__isnull=True).last()
        action = request.query_params.get("action", "")
        event_log.create_log(
            request=request,
            event=SCHEDULED_JOB_ACTION_EVENT.format(action.upper()),
            resource_name=scheduled_job.name,
            resource_id=scheduled_job.id,
            detailed_info={"project_id": kwargs.get('project_id')},
            resource_obj_id=scheduled_job.id,
            event_type=UPDATE,
        )
        response = func(*args, **kwargs)
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else \
            event_log.log_event_failure()
        return response

    return wrapper_func
