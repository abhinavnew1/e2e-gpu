from django.db import models

from e2e_core.mixins import ReadOnlyModel
from pipelines.constants import MAX_TEXT_LENGTH


class KubeflowPipelines(ReadOnlyModel):
    '''This model is used as read only model to sync/read/view Kubeflow DB data, never attempt a write on this db model'''
    UUID = models.CharField(primary_key=True, unique=True, max_length=MAX_TEXT_LENGTH)
    Name = models.CharField(max_length=MAX_TEXT_LENGTH)
    Namespace = models.CharField(max_length=MAX_TEXT_LENGTH)

    class Meta:
        managed = False
        db_table = 'pipelines' 

    def __str__(self):
        return f"<KubeflowPipeline({self.name}:{self.uuid})>"


class KubeflowPipelineVersions(ReadOnlyModel):
    '''This model is used as read only model to sync/read/view Kubeflow DB data, never attempt a write on this db model'''
    UUID = models.CharField(primary_key=True, unique=True, max_length=MAX_TEXT_LENGTH)
    Name = models.CharField(max_length=MAX_TEXT_LENGTH)
    Namespace = models.CharField(max_length=MAX_TEXT_LENGTH)

    class Meta:
        managed = False
        db_table = 'pipeline_versions' 
    
    def __str__(self):
        return f"<KubeflowPipelineVersion({self.Name}:{self.UUID})>"


class KubeflowExperiments(ReadOnlyModel):
    '''This model is used as read only model to sync/read/view Kubeflow DB data, never attempt a write on this db model'''
    UUID = models.CharField(primary_key=True, unique=True, max_length=MAX_TEXT_LENGTH)
    Name = models.CharField(max_length=MAX_TEXT_LENGTH)
    Namespace = models.CharField(max_length=MAX_TEXT_LENGTH)

    class Meta:
        managed = False
        db_table = 'experiments' 
    
    def __str__(self):
        return f"<KubeflowExperiment({self.Name}:{self.UUID})>"


class KubeflowRundetails(ReadOnlyModel):
    '''This model is used as read only model to sync/read/view Kubeflow DB data, never attempt a write on this db model'''
    UUID = models.CharField(primary_key=True, unique=True, max_length=MAX_TEXT_LENGTH)
    ExperimentUUID = models.CharField(max_length=MAX_TEXT_LENGTH)
    JobUUID = models.CharField(null=True, max_length=MAX_TEXT_LENGTH)
    Name = models.CharField(max_length=MAX_TEXT_LENGTH)
    Namespace = models.CharField(max_length=MAX_TEXT_LENGTH)
    CreatedAtInSec = models.BigIntegerField()

    class Meta:
        managed = False
        db_table = 'run_details' 

    def __str__(self):
        return f"<KubeflowRundetails({self.Name}:{self.UUID})>"


class KubeflowJobs(ReadOnlyModel):
    '''This model is used as read only model to sync/read/view Kubeflow DB data, never attempt a write on this db model'''
    UUID = models.CharField(primary_key=True, unique=True, max_length=MAX_TEXT_LENGTH)
    ExperimentUUID = models.CharField(max_length=MAX_TEXT_LENGTH)
    Name = models.CharField(max_length=MAX_TEXT_LENGTH)
    Namespace = models.CharField(max_length=MAX_TEXT_LENGTH)

    class Meta:
        managed = False
        db_table = 'jobs' 

    def __str__(self):
        return f"<KubeflowJob({self.Name}:{self.UUID})>"


# KubeflowRundetails.objects.using('kubeflow_pipeline_db').filter(JobUUID='da3c7f4d-c3c6-4a80-a800-726feabea984')