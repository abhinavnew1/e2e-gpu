from _datetime import datetime

from django.db import models

from customer.models import Customer
from e2e_core.mixins import BaseMixin, SafeDeleteMixinExtended
from eos.models import AccessKey, Bucket
from gpu_service.models import SkuItemPrice
from notebook.models import EgressGatewayDetail
from pipelines.constants import (COMMON_TEMPLATE_RUN_TYPES, COMMON_TEMPLATE_RUN_STATUS, 
                                 ERROR, MAX_TEXT_LENGTH, PIPELINE,
                                 PIPELINE_SOURCE_TYPES, PIPELINE_TYPES,
                                 SCHEDULED_JOB_SOURCE_TYPES)
from projects.models import Projects


class Pipelines(SafeDeleteMixinExtended, BaseMixin):
    name = models.CharField(max_length=MAX_TEXT_LENGTH)
    pipeline_id = models.CharField(max_length=MAX_TEXT_LENGTH, unique=True, null=True)
    description = models.TextField(null=True)
    project = models.ForeignKey(Projects, on_delete=models.CASCADE)
    bucket = models.ForeignKey(Bucket, on_delete=models.PROTECT)
    access_key = models.ForeignKey(AccessKey, on_delete=models.PROTECT)
    parameters = models.TextField()
    pipeline_type = models.CharField(choices=PIPELINE_TYPES, max_length=MAX_TEXT_LENGTH)
    created_by = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True)
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    source = models.CharField(choices=PIPELINE_SOURCE_TYPES, null=True, max_length=MAX_TEXT_LENGTH)

    def __str__(self):
        return f"<Pipeline({self.name}:{self.id})>"

    def mark_deleted(self):
        if not self.deleted_at:
            self.deleted_at = datetime.now()
            self.save(update_fields=['deleted_at', 'updated_at'])


class PipelineVersions(SafeDeleteMixinExtended, BaseMixin):
    name = models.CharField(max_length=MAX_TEXT_LENGTH)
    description = models.TextField(null=True)
    pipeline = models.ForeignKey(Pipelines, on_delete=models.CASCADE)
    version_id = models.CharField(max_length=MAX_TEXT_LENGTH, unique=True, null=True)
    is_default_version = models.BooleanField()
    created_by = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True)
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    source = models.CharField(choices=PIPELINE_SOURCE_TYPES, null=True, max_length=MAX_TEXT_LENGTH)

    def __str__(self):
        return f"<PipelineVersion({self.name}:{self.id})>"

    def mark_deleted(self):
        if not self.deleted_at:
            self.deleted_at = datetime.now()
            self.save(update_fields=['deleted_at', 'updated_at'])


class Experiments(SafeDeleteMixinExtended, BaseMixin):
    name = models.CharField(max_length=MAX_TEXT_LENGTH)
    experiment_id = models.CharField(max_length=MAX_TEXT_LENGTH)
    project = models.ForeignKey(Projects, on_delete=models.CASCADE)
    created_by = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True)
    description = models.TextField(null=True)
    storage_state = models.CharField(max_length=MAX_TEXT_LENGTH)
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    source = models.CharField(choices=PIPELINE_SOURCE_TYPES, null=True, max_length=MAX_TEXT_LENGTH)

    def __str__(self):
        return f"<Experiment({self.name}:{self.id})>"

    def mark_deleted(self):
        if not self.deleted_at:
            self.deleted_at = datetime.now()
            self.save(update_fields=['deleted_at', 'updated_at'])


class Runs(SafeDeleteMixinExtended, BaseMixin):
    name = models.CharField(max_length=MAX_TEXT_LENGTH)
    description = models.TextField(null=True)
    project = models.ForeignKey(Projects, on_delete=models.CASCADE)
    created_by = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True)
    sku_item_price = models.ForeignKey(SkuItemPrice, on_delete=models.PROTECT)
    # sku_item_price_to_pod_mapping = models.JSONField(default=dict)
    experiment = models.ForeignKey(Experiments, on_delete=models.CASCADE)
    pipeline_version = models.ForeignKey(PipelineVersions, on_delete=models.CASCADE)
    scheduled_job = models.ForeignKey("pipelines.ScheduledJobs", null=True, on_delete=models.CASCADE)
    run_id = models.CharField(max_length=MAX_TEXT_LENGTH, unique=True)
    workflow_name = models.CharField(max_length=MAX_TEXT_LENGTH, null=True)
    service_account = models.CharField(max_length=MAX_TEXT_LENGTH)
    pipeline_root = models.CharField(max_length=MAX_TEXT_LENGTH)
    state = models.CharField(max_length=MAX_TEXT_LENGTH)
    progress = models.CharField(max_length=MAX_TEXT_LENGTH)
    state_history = models.TextField(null=True)
    conditions = models.CharField(max_length=MAX_TEXT_LENGTH)
    pipeline_runtime = models.TextField(null=True)
    workflow_spec_manifest = models.TextField(null=True)
    workflow_runtime_manifest = models.TextField(null=True)
    scheduled_at = models.DateTimeField(null=True)
    finished_at = models.DateTimeField(null=True)
    runtime_parameters = models.TextField(null=True)
    parameters = models.TextField(null=True)
    storage_state = models.CharField(max_length=MAX_TEXT_LENGTH)
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    source = models.CharField(choices=PIPELINE_SOURCE_TYPES, null=True, max_length=MAX_TEXT_LENGTH)

    def __str__(self):
        return f"<Run({self.name}:{self.id})>"

    def mark_deleted(self):
        if not self.deleted_at:
            self.deleted_at = datetime.now()
            self.save(update_fields=['deleted_at', 'updated_at'])


class RunHistory(SafeDeleteMixinExtended, BaseMixin):
    run = models.ForeignKey(Runs, on_delete=models.DO_NOTHING)
    pod_name = models.CharField(max_length=MAX_TEXT_LENGTH)
    pod_uid = models.CharField(max_length=MAX_TEXT_LENGTH, unique=True)
    sku_item_price = models.ForeignKey(SkuItemPrice, on_delete=models.PROTECT)
    start_date = models.DateTimeField(default=None, null=True, blank=True)
    end_date = models.DateTimeField(default=None, null=True, blank=True)
    customer = models.ForeignKey(Customer, on_delete=models.PROTECT)
    # all time related info is in utc

    class Meta:
        # Define unique-together constraint
        unique_together = ['pod_uid', 'pod_name']

    def __str__(self):
        return f"<RunHistory({self.pod_name}:{self.id})>"


class ScheduledJobs(SafeDeleteMixinExtended, BaseMixin):
    name = models.CharField(max_length=MAX_TEXT_LENGTH)
    description = models.TextField(null=True)
    project = models.ForeignKey(Projects, on_delete=models.CASCADE)
    created_by = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True)
    sku_item_price = models.ForeignKey(SkuItemPrice, on_delete=models.PROTECT)
    experiment = models.ForeignKey(Experiments, on_delete=models.CASCADE)
    pipeline_version = models.ForeignKey(PipelineVersions, on_delete=models.CASCADE)
    job_id = models.CharField(max_length=MAX_TEXT_LENGTH, unique=True)
    service_account = models.CharField(max_length=MAX_TEXT_LENGTH)
    max_concurrency = models.PositiveIntegerField(default=1)
    is_enabled = models.BooleanField(default=True)
    trigger = models.JSONField(default=dict)
    workflow_spec_manifest = models.TextField(null=True)
    pipeline_name = models.CharField(null=True, max_length=MAX_TEXT_LENGTH)
    parameters = models.TextField(null=True)
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    source = models.CharField(choices=SCHEDULED_JOB_SOURCE_TYPES, default=PIPELINE, max_length=MAX_TEXT_LENGTH)

    def __str__(self):
        return f"<ScheduledJob({self.name}:{self.id})>"

    def mark_deleted(self):
        if not self.deleted_at:
            self.deleted_at = datetime.now()
            self.save(update_fields=['deleted_at', 'updated_at'])


class CommonTemplate(SafeDeleteMixinExtended, BaseMixin):
    name = models.CharField(max_length=MAX_TEXT_LENGTH)
    readme_file = models.BinaryField()
    yaml_file_binary = models.BinaryField()
    yaml_file_text_content = models.TextField()
    description = models.TextField(null=True)
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    created_by = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return f"<CommonTemplate({self.name}:{self.id})>"

    def mark_deleted(self):
        if not self.deleted_at:
            self.deleted_at = datetime.now()
            self.save(update_fields=['deleted_at', 'updated_at'])


class CommonTemplateRun(SafeDeleteMixinExtended, BaseMixin):
    name = models.CharField(max_length=MAX_TEXT_LENGTH)
    unique_id = models.CharField(null=True, max_length=MAX_TEXT_LENGTH)
    run_data = models.JSONField(default=dict)
    run_type = models.CharField(choices=COMMON_TEMPLATE_RUN_TYPES, max_length=MAX_TEXT_LENGTH)
    status = models.CharField(choices=COMMON_TEMPLATE_RUN_STATUS, null=True, blank=True, max_length=MAX_TEXT_LENGTH)
    failure_reason = models.TextField(null=True, blank=True)
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    project = models.ForeignKey(Projects, on_delete=models.CASCADE)
    template = models.ForeignKey(CommonTemplate, on_delete=models.DO_NOTHING)
    created_by = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return f"<CommonTemplateRun({self.name}:{self.id})>"

    def mark_deleted(self):
        if not self.deleted_at:
            self.deleted_at = datetime.now()
            self.save(update_fields=['deleted_at', 'updated_at'])

    def mark_error(self, reason):
        self.status = ERROR
        self.failure_reason = reason
        self.save(update_fields=['status', 'failure_reason', 'updated_at'])


class WorkflowEgressPolicy(SafeDeleteMixinExtended, BaseMixin):
    run_id = models.CharField(null=True, max_length=MAX_TEXT_LENGTH)
    workflow_name = models.CharField(max_length=MAX_TEXT_LENGTH)
    namespace = models.CharField(max_length=MAX_TEXT_LENGTH)
    egress_policy_name = models.CharField(max_length=MAX_TEXT_LENGTH)
    egress_detail = models.ForeignKey(EgressGatewayDetail, on_delete=models.DO_NOTHING)
    policy_end_date = models.DateTimeField(default=None, null=True, blank=True)
    # all time related info is in utc

    class Meta:
        # Define unique-together constraint
        unique_together = ['workflow_name', 'namespace', 'created_at']

    def __str__(self):
        return f"<WorkflowEgressPolicy({self.workflow_name}:ip={self.egress_detail.public_ip})>"
