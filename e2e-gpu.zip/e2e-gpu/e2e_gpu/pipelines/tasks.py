import logging
from datetime import datetime, timedelta

from rest_framework import status

from e2e_gpu.celery import app
from pipelines.constants import SYNC_SCHEDULED_JOBS_RELATED_RUNS_TASK, CREATE_TEMPLATE_RUNS_TASK
from pipelines.api.v1.services.kubeflow_job_service import KubeflowJobService
from pipelines.api.v1.services.pipeline_service import PipeLineService
from pipelines.models import ScheduledJobs, Pipelines, PipelineVersions

logger = logging.getLogger(__name__)


@app.task(
    name=SYNC_SCHEDULED_JOBS_RELATED_RUNS_TASK,
    bind=True,
)
def sync_scheduled_jobs_related_runs_task(self, *args, **kwargs):
    project = kwargs.get("project")
    customer = kwargs.get("customer")
    customer_auth_header = kwargs.get("customer_auth_header")

    try:
        cutoff_time = datetime.utcnow()-timedelta(seconds=30)
        PipelineVersions.objects.filter(version_id__isnull=True, deleted_at__isnull=True, created_at__lte=cutoff_time).delete()
        Pipelines.objects.filter(pipeline_id__isnull=True, deleted_at__isnull=True, created_at__lte=cutoff_time).delete()
    except Exception as e:
        logger.info(f"SYNC_SCHEDULED_JOBS_RELATED_RUNS_TASK | COULD_NOT_REMOVE_DUMMY_PIPELINES | ERROR - {e}")

    scheduled_jobs = kwargs.get("scheduled_jobs", ScheduledJobs.objects.filter(project=project, deleted_at__isnull=True).order_by('-created_at'))    
    for job in scheduled_jobs:
        try:
            KubeflowJobService(customer=customer, project=project,
                               auth_header=customer_auth_header).get_all_runs_for_scheduled_job(job.job_id, "", "")
        except Exception as e:
            logger.error(f"KUBEFLOW_PIPELINE_JOB_TASK | CRITICAL_RED | SYNC_SCHEDULED_JOBS_RELATED_RUNS_TASK | Customer - {customer.email} | ERROR - {e}")


@app.task(
    name=CREATE_TEMPLATE_RUNS_TASK,
    bind=True,
)
def create_template_runs_task(self, *args, **kwargs):
    template_run = kwargs.get("template_run",)
    common_template_service_object = kwargs.get("common_template_service_object")
    
    response = common_template_service_object.create_pipeline_and_run_for_template(template_run)
    if response["code"] not in [status.HTTP_200_OK, status.HTTP_201_CREATED]:
        errors = response.get("errors")
        logger.error(f"CREATE_TEMPLATE_RUNS_TASK : ERROR --> {errors}")
        raise Exception(f"CREATE_TEMPLATE_RUNS_TASK : ERROR-->{errors}")
