from django.contrib import admin
from safedelete.admin import SafeDeleteAdmin

from projects.models import ProjectMembers, Projects


class ProjectsAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "deleted_at",
        "id",
        "name",
        "namespace",
        "team",
        "created_by",
        "description",
        "created_at",
        "updated_at",
    )
    raw_id_fields = ("created_by", "team")
    search_fields = ("id", "created_by__email", "name", "team__id",)
    list_filter = ("deleted_at", "deleted",)
    list_display_links = ("id", "name",)
    list_select_related = ("created_by", "team",)
    readonly_fields = ("namespace",)


class ProjectMembersAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "deleted_at",
        "id",
        "is_active",
        "role",
        "project",
        "team_member",
        "created_by",
        "created_at",
        "updated_at",
    )
    raw_id_fields = ("project", "team_member", "created_by")
    search_fields = ("id", "project__name", "role", "team_member__iam_user__added_user__email")
    list_filter = ("deleted", "deleted_at", "role", "is_active")
    list_display_links = ("id", "team_member")
    list_select_related = ("project", "team_member", "created_by")


admin.site.register(Projects, ProjectsAdmin)
admin.site.register(ProjectMembers, ProjectMembersAdmin)
