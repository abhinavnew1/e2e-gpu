from django.conf import settings

from e2e_core.constants import MAX_LENGTH_ERROR

# namespace groot urls
CREATE_NAMESPACE_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}"
DELETE_NAMESPACE_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}"
ADD_NAMESPACE_PERM_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/permissions"
DELETE_NAMESPACE_PERM_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/permissions"

NAME_REGEX = r'^[A-Za-z0-9_-]{1,}$'
NAME_INVALID = "Project name should contain letters, digits, underscore and hyphen only."
PROJECT_NAME_MAX_LENGTH = 50
PROJECT_NAME_MAX_LENGTH_ERROR = MAX_LENGTH_ERROR.format(field_name="Project Name", max_length=PROJECT_NAME_MAX_LENGTH)


DEFAULT_PROJECT_NAME = "default-project"

# resource list for usage on dashboard
USAGE_RESOURCE_LIST = ['Notebooks', 'Notebook Disk', 'Inference Service', 'Disk Dataset', 'VectorDB', 'VectorDB Disk']

# project usage constants
NOTEBOOK_RESOURCE = "notebook"
INFERENCE_RESOURCE = "inference"
NOTEBOOK_PVC_RESOURCE = "notebook-disk"
DISK_DATASET_RESOURCE = "disk-dataset"
MODEL_PLAYGROUND_USAGE = "model-playground"
PIPELINE_RUN_RESOURCE = "pipeline_run"
VECTOR_DB_RESOURCE = 'vectordb'
VECTOR_DB_PVC_RESOURCE = 'vectordb-pvc'

# audit log constants
PROJECT_CREATE_EVENT = "PROJECT_CREATE"
PROJECT_UPDATE_EVENT = "PROJECT_UPDATE"
PROJECT_DELETE_EVENT = "PROJECT_DELETE"
PROJECT_MEMBER_CREATE_EVENT = 'ADD_PROJECT_MEMBER'
PROJECT_MEMBER_UPDATE_EVENT = 'PROJECT_MEMBER_ACCESS_UPDATE'
PROJECT_MEMBER_DELETE_EVENT = 'REMOVE_PROJECT_MEMBER'

PROJECT_MEMBER_SELF_DELETE = "PROJECT_MEMBER_SELF_DELETE"
COLUMN_NAME = ["RESOURCE_NAME", "SERVICE", "EVENT", "TIMESTAMP", "CLIENT_IP", "DETAILS", "ACTIVITY_BY"]

# error/success msgs
NAMESPACE_ROLE_BINDING = 'Namespace role binding'
PROJECT_NAME_ALREADY_EXISTS = "Project with the same name already exists."
OWNER_DELETION_RESTRICTION = "Owner cannot be deleted!"
PROJECT_MEMBER_ALREADY_EXIST = "Requested user is already part of the part"
RESOURCE_USAGE_FETCH_ERROR = "Could not fetch resource usage!"
PROJECT_CREATE_ASSIGN_NAMESPACE_ACCESS_ERROR = 'Failed to assign OWNER, ADMIN, TEAM_LEAD access to namespace: {project_id}'
PROJECT_CREATE_ASSIGN_NAMESPACE_ACCESS_SUBJECT = 'Failed to assign OWNER, ADMIN, TEAM_LEAD access to namespace created_by: {email}'
PROJECT_MEMBERS_ASSIGN_NAMESPACE_ACCESS_ERROR = 'Failed to assign namespace access to project members: {members}'
PROJECT_MEMBERS_ASSIGN_NAMESPACE_ACCESS_SUBJECT = 'Failed to assign namespace access to project members created_by: {email}'
PROJECT_MEMBERS_REMOVE_NAMESPACE_ACCESS_ERROR = 'Failed to remove namespace access to project members: {members}'
PROJECT_MEMBERS_REMOVE_NAMESPACE_ACCESS_SUBJECT = 'Failed to remove namespace access to project members deleted_by: {email}'
PROJECT_RESOURCES_DELETION_FAILED_ERROR = "Failed to delete following resources while project deletion: {}"
PROJECT_RESOURCES_DELETION_FAILED_SUBJECT = "Failed to delete resources for customer :{email}"

# vector_db tasks
VECTOR_DB_DNS_SERVICE_RECORD_DELETION_TASK = 'vector_db_dns_service_record_deletion_task'
PROJECT_RESOURCES_DELETION_TASK = "project_resources_deletion_task"
VECTOR_DB_DNS_SERVICE_RECORD_DELETION_TASK_COUNTDOWN = 90
PROJECT_RESOURCES_DELETION_TASK_COUNTDOWN = 90
VECTOR_DB_DNS_SERVICE_RECORD_DELETION_TASK_MAX_RETRIES = 20
PROJECT_CREATION_ASSIGN_NAMESPACE_ACCESS_TASK = 'project_creation_assign_namespace_access_task'
PROJECT_MEMBER_CREATION_ASSIGN_NAMESPACE_ACCESS_TASK = 'project_member_creation_assign_namespace_access_task'
ASSIGN_ACCESS_COUNTDOWN = 20
ASSIGN_ACCESS_MAX_RETRIES = 4
REMOVE_ACCESS_MAX_RETRIES = 4
PROJECT_MEMBER_DELETION_REMOVE_NAMESPACE_ACCESS_TASK = 'project_member_deletion_remove_namespace_access_task'
REMOVE_ACCESS_COUNTDOWN = 20
