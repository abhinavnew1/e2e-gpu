from rest_framework import status

from eventlogs.api.v1.services.eventlog_service import EventLogService
from eventlogs.constants import (
    CREATE,
    DELETE,
    EVENTLOG_FAILED_STATUS,
    EVENTLOG_SUCCESS_STATUS,
    PROJECT_MEMBERS_CODE,
    PROJECT_SERVICE_CODE,
    UPDATE,
)
from projects.constants import (
    PROJECT_CREATE_EVENT,
    PROJECT_DELETE_EVENT,
    PROJECT_MEMBER_CREATE_EVENT,
    PROJECT_MEMBER_DELETE_EVENT,
    PROJECT_MEMBER_UPDATE_EVENT,
    PROJECT_UPDATE_EVENT,
)


def project_creation_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        response = func(*args, **kwargs)
        event_log = EventLogService(PROJECT_SERVICE_CODE)
        log_status = EVENTLOG_SUCCESS_STATUS if response.status_code == status.HTTP_201_CREATED else EVENTLOG_FAILED_STATUS
        event_log.create_log(
            request=request,
            event=PROJECT_CREATE_EVENT,
            resource_name=request.data["project_name"],
            resource_id=response.data["data"].get("project_id", ""),
            detailed_info={"response": response.data["data"], "team_id": kwargs.get("team_id")},
            status=log_status,
            resource_obj_id=response.data["data"].get("project_id"),
            event_type=CREATE,
        )
        return response

    return wrapper_func


def project_update_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        response = func(*args, **kwargs)
        event_log = EventLogService(PROJECT_SERVICE_CODE)
        log_status = EVENTLOG_SUCCESS_STATUS if response.status_code == status.HTTP_200_OK else EVENTLOG_FAILED_STATUS
        event_log.create_log(
            request=request,
            event=PROJECT_UPDATE_EVENT,
            resource_name=request.data["project_name"],
            resource_id=kwargs.get("project_id"),
            detailed_info={"update_data": request.data, "team_id": kwargs.get("team_id")},
            status=log_status,
            resource_obj_id=kwargs.get("project_id"),
            event_type=UPDATE,
        )
        return response

    return wrapper_func


def project_delete_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        response = func(*args, **kwargs)
        event_log = EventLogService(PROJECT_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=PROJECT_DELETE_EVENT,
            resource_name=kwargs.get("project").name,
            resource_id=kwargs.get("project_id"),
            resource_obj_id=kwargs.get("project_id"),
            detailed_info={"team_id": kwargs.get("team_id")},
            event_type=DELETE,
        )
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else event_log.log_event_failure()
        return response

    return wrapper_func


# PROJECT MEMBER AUDIT LOG


def project_member_create_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        response = func(*args, **kwargs)
        event_log = EventLogService(PROJECT_MEMBERS_CODE)
        log_status = EVENTLOG_SUCCESS_STATUS if response.status_code == status.HTTP_201_CREATED else EVENTLOG_FAILED_STATUS
        res_data = response.data["data"]
        member_id, team_member = res_data.get("id", ""), res_data.get("team_member", {})
        email = team_member.get("iam_user", {}).get("added_user", {}).get("email", "")
        event_log.create_log(
            request=request,
            event=PROJECT_MEMBER_CREATE_EVENT,
            resource_name=email,
            resource_id=member_id,
            resource_obj_id=member_id,
            status=log_status,
            event_type=CREATE,
            detailed_info=request.data,
        )
        return response

    return wrapper_func


def project_member_update_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        response = func(*args, **kwargs)
        event_log = EventLogService(PROJECT_MEMBERS_CODE)
        log_status = EVENTLOG_SUCCESS_STATUS if response.status_code == status.HTTP_200_OK else EVENTLOG_FAILED_STATUS
        target_member = kwargs.get("targeted_project_member")
        event_log.create_log(
            request=request,
            event=PROJECT_MEMBER_UPDATE_EVENT,
            resource_name=target_member.team_member.iam_user.added_user.email,
            resource_id=target_member.id,
            resource_obj_id=target_member.id,
            status=log_status,
            event_type=UPDATE,
            detailed_info=request.data,
        )
        return response

    return wrapper_func


def project_member_delete_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        response = func(*args, **kwargs)
        event_log = EventLogService(PROJECT_MEMBERS_CODE)
        log_status = EVENTLOG_SUCCESS_STATUS if response.status_code == status.HTTP_200_OK else EVENTLOG_FAILED_STATUS
        target_member = kwargs.get("targeted_project_member")
        event_log.create_log(
            request=request,
            event=PROJECT_MEMBER_DELETE_EVENT,
            resource_name=target_member.team_member.iam_user.added_user.email,
            resource_id=target_member.id,
            resource_obj_id=target_member.id,
            status=log_status,
            event_type=DELETE,
        )
        return response

    return wrapper_func
