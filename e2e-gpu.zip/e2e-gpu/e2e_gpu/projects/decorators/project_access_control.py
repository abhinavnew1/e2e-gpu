import logging

from rest_framework.response import Response

from e2e_core.api.v1.services.base import BaseService
from e2e_core.constants import NOT_FOUND_ERROR, PERMISSION_DENIED
from e2e_core.exceptions import ObjectNotFoundError, TirPermissionError
from projects.models import ProjectMembers
from rbac.constants import PROJECT_MEMBER_SERVICE, PROJECT_SERVICE, READ, ROLE_ACCESS_DENIED
from rbac.helpers import check_role_access, check_tir_role_based_permissions
from teams.models import TeamMembers

logger = logging.getLogger(__name__)


class ProjectAccessControl(object):

    def __init__(self, action):
        self.action = action
        self.request = None
        self.customer = None
        self.iam = None

    def __call__(self, original_function, *args, **kwargs):
        def inner_func(*args, **kwargs):
            self._initialize_params(*args)
            team_id = kwargs.get("team_id", None)
            project_id = kwargs.get("project_id", None)
            iam_role = self.iam.role
            try:
                team_member = self._get_team_member(team_id=team_id, iam_user=self.iam)
                if not team_member:
                    raise ObjectNotFoundError(NOT_FOUND_ERROR.format(service="Team member"))
                kwargs["team"] = team_member.team
                iam_role = team_member.role
                if project_id:
                    project_member = self._get_project_member(project_id=project_id, team_member=team_member)
                    if not project_member:
                        raise ObjectNotFoundError(NOT_FOUND_ERROR.format(service="Project member"))
                    kwargs["project"] = project_member.project
                    iam_role = project_member.role
                if not check_tir_role_based_permissions(PROJECT_SERVICE, iam_role, self.action):
                    raise TirPermissionError(ROLE_ACCESS_DENIED)
            except Exception as e:
                logger.error(f"PROJECT_ACCESS_CHECK_FAILED | CRITICAL_GREEN | CUSTOMER - {self.customer.email} | ERRORS - {str(e)}")
                response = BaseService.get_403_response(PERMISSION_DENIED)
                return Response(response, status=response.get("code"))
            return original_function(*args, **kwargs)

        return inner_func

    def _initialize_params(self, *args):
        self.request = args[1]
        self.customer = self.request.customer
        self.iam = self.request.iam

    def _get_team_member(self, **filters):
        return TeamMembers.get_active_members(**filters).select_related("team").first()

    def _get_project_member(self, **filters):
        return ProjectMembers.get_active_members(**filters).select_related("project").first()


class ProjectMemberAccessControl(object):

    def __init__(self, action):
        self.action = action
        self.request = None
        self.customer = None
        self.iam = None

    def __call__(self, original_function, *args, **kwargs):
        def inner_func(*args, **kwargs):
            self._initialize_params(*args)
            team_id = kwargs.get("team_id", None)
            project_id = kwargs.get("project_id", None)
            project_member_id = kwargs.get("member_id", None)
            try:
                performer_project_member = self._get_project_member(
                    "project",
                    project_id=project_id,
                    team_member__team_id=team_id,
                    team_member__iam_user=self.iam,
                )
                if not performer_project_member:
                    raise ObjectNotFoundError(NOT_FOUND_ERROR.format(service="Performer project member"))
                kwargs["project_member"] = performer_project_member
                if not check_tir_role_based_permissions(PROJECT_MEMBER_SERVICE, performer_project_member.role, self.action):
                    raise TirPermissionError(ROLE_ACCESS_DENIED)
                if project_member_id:
                    targeted_project_member = self._get_project_member(
                        "project",
                        "team_member__iam_user__added_user",
                        id=project_member_id,
                        project_id=project_id,
                    )
                    if not targeted_project_member:
                        raise ObjectNotFoundError(NOT_FOUND_ERROR.format(service="Target project member"))
                    if self.action != READ and not check_role_access(performer_project_member.role, targeted_project_member.role):
                        raise TirPermissionError(ROLE_ACCESS_DENIED)
                    kwargs["targeted_project_member"] = targeted_project_member
            except Exception as e:
                logger.error(f"PROJECT_MEMBER_ACCESS_CHECK_FAILED | CRITICAL_GREEN | CUSTOMER - {self.customer.email} | ERRORS - {str(e)}")
                response = BaseService.get_403_response(PERMISSION_DENIED)
                return Response(response, status=response.get("code"))
            return original_function(*args, **kwargs)

        return inner_func

    def _initialize_params(self, *args):
        self.request = args[1]
        self.customer = self.request.customer
        self.iam = self.request.iam

    def _get_project_member(self, *related_field, **filters):
        return ProjectMembers.get_active_members(**filters).select_related(*related_field).first()
