from e2e_core.datetime_helper import date_filter_validator


def validate_date_filter_params(func):
    def wrapper_func(*args, **kwargs):
        query_params = args[0].query_params
        status, err = date_filter_validator(**query_params)
        if not status:
            return args[0].get_baked_400_response(err)
        return func(*args, **kwargs)

    return wrapper_func
