import logging

from celery.execute import send_task

from e2e_core.helpers import support_ticket_generator
from projects.constants import (
    ASSIGN_ACCESS_COUNTDOWN,
    DEFAULT_PROJECT_NAME,
    PROJECT_CREATE_ASSIGN_NAMESPACE_ACCESS_ERROR,
    PROJECT_CREATE_ASSIGN_NAMESPACE_ACCESS_SUBJECT,
    PROJECT_CREATION_ASSIGN_NAMESPACE_ACCESS_TASK,
    PROJECT_RESOURCES_DELETION_TASK,
    PROJECT_RESOURCES_DELETION_TASK_COUNTDOWN,
    VECTOR_DB_DNS_SERVICE_RECORD_DELETION_TASK,
    VECTOR_DB_DNS_SERVICE_RECORD_DELETION_TASK_COUNTDOWN,
)
from vector_db.constants import QDRANT_SNAPSHOT_DELETION_TASK
from vector_db.models import VectorDB


logger = logging.getLogger(__name__)


def create_default_project(customer, iam, team):
    """Creates a project by default on creation of a team"""
    from projects.api.v1.services.projects_service import ProjectService

    create_payload = {"project_name": DEFAULT_PROJECT_NAME}
    ProjectService(customer, iam, team.id).create_project(create_payload)


def assign_namespace_access_to_owner_admin_team_lead(customer, project):
    try:
        send_task(
            PROJECT_CREATION_ASSIGN_NAMESPACE_ACCESS_TASK,
            kwargs={"created_by": customer, "project": project},
            countdown=ASSIGN_ACCESS_COUNTDOWN,
        )
    except Exception as e:
        logger.error(
            f"PROJECT_CREATE_SERVICE | CRITICAL_RED | ASSIGN_OWNER_ADMIN_TEAM_LEAD_NAMESPACE_ACCESS_TASK_CREATION_FAILED \
                        | PROJECT_ID:{project.id} | ERROR:{str(e)}"
        )
        support_ticket_generator(
            errors=PROJECT_CREATE_ASSIGN_NAMESPACE_ACCESS_ERROR.format(project_id=project.id),
            subject=PROJECT_CREATE_ASSIGN_NAMESPACE_ACCESS_SUBJECT.format(email=customer.email),
            customer=customer,
        )


def delete_project_resources(project, deletion_timestamp):
    """Deletes all resources associated with a project"""
    send_task(
        PROJECT_RESOURCES_DELETION_TASK,
        kwargs={"project": project, "deletion_timestamp": deletion_timestamp},
        countdown=PROJECT_RESOURCES_DELETION_TASK_COUNTDOWN,
    )
    send_task(
        VECTOR_DB_DNS_SERVICE_RECORD_DELETION_TASK,
        kwargs={"project": project, "deletion_timestamp": deletion_timestamp},
        countdown=VECTOR_DB_DNS_SERVICE_RECORD_DELETION_TASK_COUNTDOWN,
    )

    delete_qdrant_snapshots_from_project(project=project)


def delete_qdrant_snapshots_from_project(project):
    vectordbs = VectorDB.objects.filter(project=project)
    for vectordb in vectordbs:
        send_task(
            QDRANT_SNAPSHOT_DELETION_TASK,
            kwargs={
                "vectordb": vectordb,
                "snapshot": None,
            },
        )
