from datetime import datetime
from django.db import models
from django.db.models import Q, UniqueConstraint

from customer.models import Customer
from e2e_core.helpers import mark_delete_related_objects
from e2e_core.mixins import BaseMixin, SafeDeleteMixinExtended
from projects.constants import PROJECT_NAME_MAX_LENGTH
from rbac.constants import ADMIN, PROJECT_MEMBER_ROLE_CHOICES, ROLE_MAX_LENGTH
from teams.models import TeamMembers, Teams


class Projects(SafeDeleteMixinExtended, BaseMixin):

    # For projects deleted by customer, we don't soft-delete the record but only set deleted_at.
    # Therefore, a filter for deleted_at must be applied to all queries
    deleted_at = models.DateTimeField(null=True, blank=True, default=None)
    name = models.CharField(max_length=PROJECT_NAME_MAX_LENGTH)
    namespace = models.CharField(max_length=128, unique=True, default=None, null=True)
    description = models.TextField(default=None, null=True, blank=True)
    created_by = models.ForeignKey(Customer, on_delete=models.PROTECT, related_name="created_projects")
    team = models.ForeignKey(Teams, on_delete=models.PROTECT, related_name="projects")
    project_members = models.ManyToManyField(TeamMembers, blank=True)  # PBAC_TODO: This field will be remove after everything runs fine

    def __str__(self):
        return f"<Project({self.id}: {self.name})>"

    @classmethod
    def get_project_namespace(cls, project_id):
        project = cls.objects.filter(deleted_at__isnull=True, id=project_id).first()
        if not project:
            return None
        return project.namespace

    @classmethod
    def get_all_billable_projects_for_customer(cls, email: str):
        """
        Returns all the projects (across teams) that are billed under the name of the customer.
        This includes projects in the teams owned by the customer and also the teams owned by its contact persons.
        """
        return cls.objects.filter(Q(team__owner__email=email) | Q(team__owner__primary_email=email))

    @classmethod
    def get_not_deleted_projects(cls, **filters):
        return cls.objects.filter(deleted_at__isnull=True, **filters)

    def mark_deleted(self):
        if self.deleted_at is None:
            mark_delete_related_objects(self)
            self.deleted_at = datetime.now()
            self.save(update_fields=["deleted_at", "updated_at"])


class ProjectMembers(SafeDeleteMixinExtended, BaseMixin):
    from user_policies.models import UserPolicies

    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    is_active = models.BooleanField(default=True)
    role = models.CharField(choices=PROJECT_MEMBER_ROLE_CHOICES, default=ADMIN, max_length=ROLE_MAX_LENGTH)
    project = models.ForeignKey(Projects, null=True, default=None, on_delete=models.CASCADE, related_name="members")
    team_member = models.ForeignKey(TeamMembers, null=True, default=None, on_delete=models.CASCADE, related_name="project_members")
    created_by = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True, related_name="created_project_members")
    policies = models.ManyToManyField(UserPolicies, blank=True, related_name="policy_members")

    class Meta:
        constraints = [UniqueConstraint(fields=["project", "team_member", "deleted_at"], name="unique_project_member")]

    def __str__(self):
        return f"<ProjectMember({self.id}, project:{self.project.id}, team_member:{self.team_member.id})>"

    @classmethod
    def get_active_members(cls, **filters):
        return cls.objects.filter(deleted_at__isnull=True, is_active=True, **filters)

    @classmethod
    def get_not_deleted_members(cls, **filters):
        return cls.objects.filter(deleted_at__isnull=True, **filters)

    def mark_deleted(self):
        if self.deleted_at is None:
            mark_delete_related_objects(self)
            self.deleted_at = datetime.now()
            self.save(update_fields=["deleted_at", "updated_at"])
