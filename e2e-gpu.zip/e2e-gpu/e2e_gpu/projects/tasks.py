import logging

from django.conf import settings

from data_syncer.api.v1.services.airbyte_service import ConnectionAirbyteService, DestinationAirbyteService, SourceAirbyteService
from data_syncer.models import Connection, Destination, Source
from e2e_core.helpers import support_ticket_generator
from e2e_gpu.celery import app
from projects.api.v1.services.namespace_service import NamespaceService
from projects.models import ProjectMembers
from projects.constants import (
    PROJECT_CREATION_ASSIGN_NAMESPACE_ACCESS_TASK,
    PROJECT_MEMBERS_ASSIGN_NAMESPACE_ACCESS_ERROR,
    PROJECT_MEMBERS_ASSIGN_NAMESPACE_ACCESS_SUBJECT,
    PROJECT_RESOURCES_DELETION_FAILED_ERROR,
    PROJECT_RESOURCES_DELETION_FAILED_SUBJECT,
    PROJECT_RESOURCES_DELETION_TASK,
    VECTOR_DB_DNS_SERVICE_RECORD_DELETION_TASK,
    VECTOR_DB_DNS_SERVICE_RECORD_DELETION_TASK_MAX_RETRIES,
)
from vector_db.api.v1.services.dns_service import DnsService
from vector_db.api.v1.services.vectordb_groot_services import VectorDBGatewayGrootService
from vector_db.constants import VECTOR_DB_GATEWAY_PATCH_FAILED_ERROR, VECTOR_DB_GATEWAY_PATCH_FAILED_SUBJECT
from vector_db.models import VectorDB

logger = logging.getLogger(__name__)


@app.task(
    name=VECTOR_DB_DNS_SERVICE_RECORD_DELETION_TASK,
    max_retries=VECTOR_DB_DNS_SERVICE_RECORD_DELETION_TASK_MAX_RETRIES,
    bind=True
)
def vectordb_dns_service_record_deletion_task(self, *args, **kwargs):
    """deletes the DNS Records of VectorDB hosts and removes the hosts from vectordb-gateway on k8s cluster on deletion of the project"""
    project = kwargs.get("project")
    deletion_timestamp = kwargs.get("deletion_timestamp")
    vectordbs = VectorDB.objects.filter(deleted_at__gte=deletion_timestamp, project=project)
    dns_service = DnsService()
    host_urls = list(vectordbs.values_list("endpoint_url", flat=True))
    status, response = VectorDBGatewayGrootService(project.created_by).remove_host_in_vectordb_gateway(host_urls)
    if not status:
        support_ticket_generator(
            errors=VECTOR_DB_GATEWAY_PATCH_FAILED_ERROR.format(vectordb_hosts=host_urls, errors=response.text),
            subject=VECTOR_DB_GATEWAY_PATCH_FAILED_SUBJECT.format(email_id=project.created_by.email),
            customer=project.created_by,
        )
    failed_dns_records = []
    for host_url in host_urls:
        response = dns_service.delete_record(record_name=host_url, content=settings.ISTIO_INGRESSGATEWAY_IP)
        if not response["status"]:
            failed_dns_records.append(host_url)

    if len(failed_dns_records) == 0:
        return
    elif self.request.retries == self.max_retries:
        return f"Unable to delete following DNS records: {failed_dns_records}"
    else:
        self.retry()


@app.task(
    name=PROJECT_RESOURCES_DELETION_TASK,
    bind=True
)
def project_resources_deletion_task(self, *args, **kwargs):
    project = kwargs.get("project")
    deletion_timestamp = kwargs.get("deletion_timestamp")
    failed_deletions = {}
    # airbyte resources
    failed_deletions["airbyte_sources"] = []
    sources_to_delete = Source.objects.filter(project=project, deleted_at__gte=deletion_timestamp)
    for source_to_delete in sources_to_delete:
        is_success, _ = SourceAirbyteService().delete_airbyte_resource({"sourceId": source_to_delete.airbyte_id})
        if not is_success:
            failed_deletions["airbyte_sources"].append(source_to_delete.id)
    if not failed_deletions.get("airbyte_sources"):
        failed_deletions.pop("airbyte_sources", "")

    failed_deletions["airbyte_destinations"] = []
    destinations_to_delete = Destination.objects.filter(project=project, deleted_at__gte=deletion_timestamp)
    for destination_to_delete in destinations_to_delete:
        is_success, _ = DestinationAirbyteService().delete_airbyte_resource({"destinationId": destination_to_delete.airbyte_id})
        if not is_success:
            failed_deletions["airbyte_destinations"].append(destination_to_delete.id)
    if not failed_deletions.get("airbyte_destinations"):
        failed_deletions.pop("airbyte_destinations", "")

    failed_deletions["airbyte_connections"] = []
    connections_to_delete = Connection.objects.filter(project=project, deleted_at__gte=deletion_timestamp)
    for connection_to_delete in connections_to_delete:
        is_success, _ = ConnectionAirbyteService().delete_airbyte_resource({"connectionId": connection_to_delete.airbyte_id})
        if not is_success:
            failed_deletions["airbyte_connections"].append(connection_to_delete.id)
    if not failed_deletions.get("airbyte_connections"):
        failed_deletions.pop("airbyte_connections", "")

    if failed_deletions:
        support_ticket_generator(
            errors=PROJECT_RESOURCES_DELETION_FAILED_ERROR.format(failed_deletions),
            subject=PROJECT_RESOURCES_DELETION_FAILED_SUBJECT.format(email=project.created_by),
            customer=project.created_by
        )


@app.task(
    name=PROJECT_CREATION_ASSIGN_NAMESPACE_ACCESS_TASK,
    bind=True
)
def project_creation_assign_namespace_access_task(self, *args, **kwargs):
    failed_to_assign_access = []
    created_by = kwargs.get("created_by", None)
    project = kwargs.get("project", None)
    project_members = ProjectMembers.get_active_members(project=project).select_related("team_member__iam_user__added_user")
    namespace_service = NamespaceService(project, None)
    for project_member in project_members:
        added_user = project_member.team_member.iam_user.added_user
        namespace_service.customer = added_user
        is_success = namespace_service.add_permissions(added_user.email, project_member.role)
        if not is_success:
            failed_to_assign_access.append(project_member.id)
    if failed_to_assign_access:
        logger.error(f" PROJECT_CREATE_SERVICE | FAILED_TO_ASSIGN_NAMESPACE_ACCESS_TO_PROJECT_MEMBERS | CRITICAL_RED | \
                     PROJECT_MEMBERS: {failed_to_assign_access}")
        support_ticket_generator(
            errors=PROJECT_MEMBERS_ASSIGN_NAMESPACE_ACCESS_ERROR.format(members=failed_to_assign_access),
            subject=PROJECT_MEMBERS_ASSIGN_NAMESPACE_ACCESS_SUBJECT.format(email=created_by.email),
            customer=created_by
        )
