from django.contrib import admin
from safedelete.admin import SafeDeleteAdmin

from pvc.models import PVCStorage, PVCHistory

class PVCStorageAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "deleted_at",
        "id",
        "disk_size",
        "pvc_type",
        "dataset",
        "status",
        "status_log",
    )
    search_fields = ("id", "dataset__name", )
    list_filter = ("pvc_type", "status", "deleted_at", "deleted",)
    list_display_links = ("id", "dataset",)
    readonly_fields = ()


class PVCHistoryAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "customer",
        "id",
        "pvc",
        "disk_size",
        "created_at",
        "start_date",
        "end_date",
    )
    raw_id_fields = ("pvc", "customer")
    search_fields = ("id", "pvc__dataset__name", "customer__email")
    list_filter = ("created_at", "start_date", "end_date", "deleted",)
    list_display_links = ("id", "pvc",)
    readonly_fields = ("customer",
                       "id",
                       "pvc",
                       "disk_size",
                       "created_at",)


admin.site.register(PVCStorage, PVCStorageAdmin)
admin.site.register(PVCHistory, PVCHistoryAdmin)
