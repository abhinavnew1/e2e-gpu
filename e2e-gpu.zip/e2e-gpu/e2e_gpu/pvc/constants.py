from django.conf import settings

from e2e_core.constants import MAX_LENGTH_ERROR


DISK = "DISK"
DEFAULT_PVC = "default_pvc"  # default workspace of a notebook
CUSTOM_PVC = "custom_pvc"
PVC_TYPE_CHOICES = (
    (DEFAULT_PVC, DEFAULT_PVC),
    (CUSTOM_PVC, CUSTOM_PVC)
)

# pvc groot urls
DELETE_PVC_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/pvcs/{pvc_name}"
UPGRADE_PVC_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/pvcs/{pvc_name}"
CREATE_PVC_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/pvcs"
LIST_PVC_URL = settings.GROOT_BASE_URL + "api/namespaces/{namespace}/pvcs"


# pvc validations constants
DEFAULT_PVC_DISK_SIZE = 30
PVC_NAME_MAX_LENGTH = 20

# pvc/disk msg
PVC_NAME_MAX_LENGTH_ERROR = f"Max Length of disk_name is {PVC_NAME_MAX_LENGTH}"
NAME_INVALID = "Disk name should start and end with an alphanumeric character and can contain lowercase letters, digits and hyphen only."
PVC_NAME_ALREADY_EXISTS = "Disk name already exists"
UPGRADE_PVC_SUCCESS = "Disk Size upgraded successfully. It can take a few minutes for the changes to get reflected"
PVC_DELETION_NOT_POSSIBLE = "Can't delete PVC mounted to notebook, unmount first"
PVC_CREATION_FAILED = "Disk creation failed"
INVALID_REQUEST = "Invalid request : {}"
NOT_FOUND = "{} not found"
DISK_SIZE_REDUCE_NOT_ALLOWED = "disk_size can't be reduced"
MIN_DISK_SIZE = 10

# groot pvc create-update payloads
PVC_CREATE_GROOT_PAYLOAD = {"class": "csi-rbd-sc",
                             "mode": "ReadWriteOnce",
                             "name": "",
                             "size": ""
                             }

PVC_UPDATE_GROOT_PAYLOAD = {"name": "",
                            "size": ""
                            }

# pvc action/events
PVC_CREATE = "PVC_CREATE"
PVC_DELETE = "PVC_DELETE"
PVC_UPDATE = "PVC_UPDATE"
PVC_LIST = "PVC_GET_LIST"
PVC_GET = "PVC_GET"


# pvc status
WAITING = "waiting"
READY = "ready"
TERMINATING = "terminating"
DONE = "Done"
ERROR = "error"
WARNING = "warning"
PENDING = "Pending"
PVC_STATUS_CHOICES = (
    (WAITING, WAITING),
    (READY, READY),
    (TERMINATING, TERMINATING),
    (DONE, DONE),
    (ERROR, ERROR),
    (WARNING, WARNING),
    (PENDING, PENDING),
)

PVC_INCONSISTENCY_TICKET_MESSAGE = "PVC '{pvc_name}' (DATASET_ID:{pvc_id}) exists in our DB but does not exist on groot."
PVC_INCONSISTENCY_TICKET_SUBJECT = "PVC does not exist on groot | PVC_INCONSISTENCY"