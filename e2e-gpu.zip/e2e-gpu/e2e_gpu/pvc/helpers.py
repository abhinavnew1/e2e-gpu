import logging

from dataset.constants import DONE, OK, PENDING
from dataset.models import Dataset
from e2e_core.helpers import support_ticket_generator
from pvc.constants import (ERROR, PVC_INCONSISTENCY_TICKET_MESSAGE,
                           PVC_INCONSISTENCY_TICKET_SUBJECT, READY)

logger = logging.getLogger(__name__)


def generate_pvc_inconsistency_ticket(pvc):
    support_ticket_generator(
        errors=PVC_INCONSISTENCY_TICKET_MESSAGE.format(pvc_name=pvc.name, pvc_id=pvc.id),
        subject=PVC_INCONSISTENCY_TICKET_SUBJECT,
        customer=pvc.created_by,
    )


def update_pvc_status_in_dataset_model(pvc_obj, groot_pvc_obj):
    if groot_pvc_obj["status"]["phase"] == READY:
        pvc_obj.status = OK
    elif groot_pvc_obj["status"]["phase"] == DONE:
        pvc_obj.status = DONE
    else:
        pvc_obj.status = PENDING


def sync_and_update_pvc_on_db(pvc_db_list, groot_pvcs_list):
    pvc_mapping = {data["name"]: data for data in groot_pvcs_list}
    for pvc_obj in pvc_db_list:
        pvc = pvc_obj.pvc
        groot_pvc_obj = pvc_mapping.get(pvc_obj.name)
        if not groot_pvc_obj:
            if pvc_obj.status != ERROR:
                logger.error(f"PVC_INCONSISTENCY | CRITICAL_RED | PVC_DOES_NOT_EXIST_ON_GROOT | PVC_NAME:{pvc_obj.name} | DATASET_ID:{pvc_obj.id}")
                pvc_obj.status = ERROR
                pvc.status = ERROR
                generate_pvc_inconsistency_ticket(pvc_obj)
        elif groot_pvc_obj["status"] != pvc.status_log:
            pvc.status_log = groot_pvc_obj["status"]
            pvc.status = groot_pvc_obj["status"]["phase"]
            update_pvc_status_in_dataset_model(pvc_obj, groot_pvc_obj)
        
        pvc.save(update_fields=['status', 'status_log', 'updated_at',])
    Dataset.objects.bulk_update(pvc_db_list, ['status', 'updated_at', ])