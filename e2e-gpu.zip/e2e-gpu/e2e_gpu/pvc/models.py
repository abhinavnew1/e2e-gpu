import logging
from datetime import datetime

from django.db import models

from customer.models import Customer
from e2e_core.helpers import mark_delete_related_objects
from e2e_core.jsonfield import JSONField
from e2e_core.mixins import BaseMixin, SafeDeleteMixinExtended
from pvc.constants import (CUSTOM_PVC, DEFAULT_PVC_DISK_SIZE, PENDING, DONE,
                           PVC_STATUS_CHOICES, PVC_TYPE_CHOICES)

logger = logging.getLogger(__name__)


class PVCStorage(SafeDeleteMixinExtended, BaseMixin):
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    disk_size = models.IntegerField(default=DEFAULT_PVC_DISK_SIZE)
    pvc_type = models.CharField(choices=PVC_TYPE_CHOICES, max_length=64, default=CUSTOM_PVC)
    status = models.CharField(choices=PVC_STATUS_CHOICES, max_length=32, default=PENDING)
    status_log = JSONField(default=None, null=True, blank=True)

    def __str__(self):
        return f"<PVC({self.id}: size: {self.disk_size_str}: {self.pvc_type})>" 

    @property
    def disk_size_str(self):
        return f"{self.disk_size}GB"
    
    @property
    def billable_customer(self):
        return self.dataset.project.team.owner.get_primary_contact()

    def mark_deleted(self):
        if self.deleted_at is None:
            self.status = DONE
            self.deleted_at = datetime.now()
            self.save(update_fields=['deleted_at', 'status', 'updated_at', ])
            self.mark_pvc_history_entry_as_done(self.deleted_at)

    def create_entry_in_pvc_history(self, start_date):
        PVCHistory.objects.create(pvc=self, customer=self.billable_customer, disk_size=self.disk_size, start_date=start_date)

    def mark_pvc_history_entry_as_done(self, done_date=None):
        pvc_history_object = PVCHistory.objects.filter(pvc=self, customer=self.billable_customer, disk_size=self.disk_size, end_date__isnull=True).last()
        if pvc_history_object:
            pvc_history_object.end_date = datetime.now() if not done_date else done_date
            pvc_history_object.save(update_fields=["end_date", "updated_at"])
        else:
            logger.error(f"PVC_SERVICE | PVC_HISTORY_NOT_FOUND | CRITICAL_RED | pvc_id={self.id}")


class PVCHistory(SafeDeleteMixinExtended, BaseMixin):
    customer = models.ForeignKey(Customer, null=True, on_delete=models.SET_NULL)
    pvc = models.ForeignKey(PVCStorage, on_delete=models.CASCADE)
    disk_size = models.IntegerField()
    start_date = models.DateTimeField()
    end_date = models.DateTimeField(default=None, null=True, blank=True)

    def __str__(self):
        return f"PVCHistory:({self.id}: {self.customer}: {self.disk_size}GB)"

    def mark_deleted(self):
        if self.end_date is None:
            self.end_date = datetime.now()
            self.save(update_fields=['end_date', 'updated_at', ])
