from django.contrib import admin
from safedelete.admin import SafeDeleteAdmin

from rbac.models import IAM, TirRoleBasedPermissions


class IAMsAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "deleted_at",
        "owner",
        "added_user",
        "iam_type",
        "role",
        "created_at",
        "updated_at",
    )
    raw_id_fields = ("owner", "added_user")
    search_fields = ("id", "added_user__email", "owner__email", "role")
    list_filter = ("deleted", "deleted_at", "iam_type", "role")
    list_display_links = ("id", "added_user")
    list_select_related = ("added_user", "owner")


class TirRoleBasedPermissionsAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + ("id", "service", "role", "permissions")
    raw_id_fields = ("service",)
    search_fields = ("service__service_id", "role")
    list_filter = ("deleted", "service__service_id", "role")
    list_display_links = ("id", "service")
    list_select_related = ("service",)


admin.site.register(IAM, IAMsAdmin)
admin.site.register(TirRoleBasedPermissions, TirRoleBasedPermissionsAdmin)
