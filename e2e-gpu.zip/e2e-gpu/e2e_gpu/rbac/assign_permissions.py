from projects.models import ProjectMembers, Projects
from rbac.constants import ADMIN, IAM_USER, MEMBER, TEAM_LEAD, TEAM_MEMBER
from teams.models import TeamMembers, Teams
from user_policies.models import UserPolicies


class AssignPermissions:

    def __init__(self, customer, iam, team_member=None):
        self.customer = customer  # login_customer
        self.iam = iam  # active iam
        self.owner = iam.owner
        self.team_member = team_member  # active team member this is field is required for team based role team_lead and team_member

    def assign_iam_role_access(self, target_iam, target_teams=[]):
        if target_iam.role == ADMIN:
            self._assign_admin_access(target_iam)
        elif target_iam.role == IAM_USER:
            self.assign_iam_user_access(target_iam, target_teams)

    def _assign_admin_access(self, target_iam):
        teams = Teams.get_not_deleted_teams(owner=self.owner, is_private=False)  # active teams
        teams_projects = list(Projects.get_not_deleted_projects(team__owner=self.owner))  # active projects
        team_members_instance = []
        for team in teams:
            team_members_instance.append(TeamMembers(team=team, iam_user=target_iam, role=target_iam.role, created_by=self.customer))
        TeamMembers.objects.bulk_create(team_members_instance, batch_size=200)

        team_members = TeamMembers.get_active_members(iam_user=target_iam)
        project_member_instances = []
        for member in team_members:
            projects = [team_prj for team_prj in teams_projects if team_prj.team_id == member.team_id]
            for project in projects:
                project_member_instances.append(
                    ProjectMembers(project=project, team_member=member, role=target_iam.role, created_by=self.customer)
                )
        ProjectMembers.objects.bulk_create(project_member_instances, batch_size=200)

    def assign_iam_user_access(self, target_iam, target_teams):
        active_team_members = TeamMembers.get_active_members(iam_user=self.iam)  # perfomer active team_members
        active_team_members_map = {active_tm.team_id: active_tm for active_tm in active_team_members}
        for target_team in target_teams:
            team_id = target_team["team_id"]
            active_tm = active_team_members_map.get(team_id, None)
            if active_tm:
                target_team_member = TeamMembers.objects.create(
                    team_id=team_id, iam_user=target_iam, role=target_team["team_role"], created_by=self.customer
                )
                self.team_member = active_tm
                self.assign_team_role_access(target_team_member, target_team["projects"])

    def assign_team_role_access(self, target_team_member, target_projects=[]):
        if target_team_member.role == TEAM_LEAD:
            self._assign_team_lead_access(target_team_member)
        elif target_team_member.role == TEAM_MEMBER:
            self.assign_team_member_access(target_team_member, target_projects)

    def _assign_team_lead_access(self, target_team_member):
        active_projects = Projects.get_not_deleted_projects(members__team_member=self.team_member)  # active projects
        project_member_instances = []
        for active_prj in active_projects:
            project_member_instances.append(
                ProjectMembers(
                    project=active_prj,
                    team_member=target_team_member,
                    role=target_team_member.role,
                    created_by=self.customer,
                )
            )
        ProjectMembers.objects.bulk_create(project_member_instances, batch_size=200)

    def assign_team_member_access(self, targeted_team_member, target_projects):
        active_prj_members = ProjectMembers.get_active_members(team_member=self.team_member)  # perfomer active project members
        user_policies = list(UserPolicies.objects.filter(project__team_id=self.team_member.team_id))
        active_prj_members_map = {active_pm.project_id: active_pm for active_pm in active_prj_members}
        created_prj_members = []
        for target_project in target_projects:
            project_id = target_project["project_id"]
            active_prj_member = active_prj_members_map.get(project_id, None)
            if active_prj_member:
                target_role = target_project["project_role"]
                new_project_mem = ProjectMembers(
                    project_id=project_id, team_member=targeted_team_member, role=target_role, created_by=self.customer
                )
                if target_role == MEMBER:
                    new_project_mem.save()
                    policy_ids = target_project.get("policies", [])
                    policy_instances = [policy for policy in user_policies if policy.id in policy_ids]
                    new_project_mem.policies.set(policy_instances)
                else:
                    created_prj_members.append(new_project_mem)
        ProjectMembers.objects.bulk_create(created_prj_members, batch_size=200)


class UpdatePermissions:

    def __init__(self, customer, iam, team_member=None):
        self.customer = customer  # login_customer
        self.iam = iam  # active iam
        self.owner = iam.owner
        self.team_member = team_member  # active team member this is field is required for team based role team_lead and team_member

    def update_iam_role_access(self, target_iam, iam_role, target_teams):
        if iam_role == ADMIN:
            self._update_as_admin(target_iam, iam_role)
        elif iam_role == IAM_USER:
            self._update_as_iam_user(target_iam, target_teams)

    def _update_as_admin(self, target_iam, iam_role):
        teams = Teams.get_not_deleted_teams(is_private=False, owner=self.owner)  # active teams
        projects = list(Projects.get_not_deleted_projects(team__owner=self.owner))  # active projects
        existing_tms = TeamMembers.get_not_deleted_members(iam_user=target_iam)
        existing_pms = ProjectMembers.get_not_deleted_members(team_member__iam_user=target_iam)
        existing_tms_map = {tm.team_id: tm for tm in existing_tms}
        existing_pms_map = {f"{pm.project_id}-{pm.team_member_id}": pm for pm in existing_pms}
        created_team_member_ins = []
        created_project_member_ins = []

        for team in teams:
            exs_team_member = existing_tms_map.get(team.id, None)
            if exs_team_member:
                exs_team_member.is_active = True
                exs_team_member.role = iam_role
            else:
                created_team_member_ins.append(TeamMembers(team=team, iam_user=target_iam, role=iam_role, created_by=self.customer))
        TeamMembers.objects.bulk_create(created_team_member_ins, batch_size=200)
        TeamMembers.objects.bulk_update(existing_tms, ["is_active", "role"], batch_size=200)
        updated_team_members = TeamMembers.get_active_members(iam_user=target_iam)

        for udpated_team_member in updated_team_members:
            team_projects = [prj for prj in projects if prj.team_id == udpated_team_member.team_id]
            for project in team_projects:
                exs_project_member = existing_pms_map.get(f"{project.id}-{udpated_team_member.id}", None)
                if exs_project_member:
                    exs_project_member.role = iam_role
                    exs_project_member.is_active = True
                    exs_project_member.policies.clear()
                else:
                    created_project_member_ins.append(
                        ProjectMembers(
                            project=project,
                            team_member=udpated_team_member,
                            role=iam_role,
                            created_by=self.customer,
                        )
                    )
        ProjectMembers.objects.bulk_create(created_project_member_ins, batch_size=200)
        ProjectMembers.objects.bulk_update(existing_pms, ["is_active", "role"], batch_size=200)

    def _update_as_iam_user(self, target_iam, target_teams):
        active_team_members = TeamMembers.get_active_members(iam_user=self.iam)  # active team members
        existing_tms = TeamMembers.get_not_deleted_members(iam_user=target_iam)
        existing_pms = list(ProjectMembers.get_not_deleted_members(team_member__iam_user=target_iam))

        target_teams_map = {target_team["team_id"]: target_team for target_team in target_teams}
        active_tms_map = {active_tm.team_id: active_tm for active_tm in active_team_members}

        existing_tms_ids_set = set()
        updated_existing_pms = []
        for existing_team_mem in existing_tms:
            existing_tms_ids_set.add(existing_team_mem.team_id)
            active_tm = active_tms_map.get(existing_team_mem.team_id, None)
            if active_tm:
                target_team_obj = target_teams_map.get(existing_team_mem.team_id, None)
                if target_team_obj:
                    team_projects = target_team_obj["projects"]
                    team_role = target_team_obj["team_role"]
                    self.team_member = active_tm  # setting self.team_teammember for updating team_role
                    self.update_team_role_access(existing_team_mem, team_role, team_projects)
                    existing_team_mem.role = team_role
                    existing_team_mem.is_active = True
                else:
                    team_existing_project_members = [team_existing_pm for team_existing_pm in existing_pms if team_existing_pm.team_member_id == existing_team_mem.id]
                    for team_existing_proj_mem in team_existing_project_members:
                        team_existing_proj_mem.role = MEMBER
                        team_existing_proj_mem.is_active = False
                        team_existing_proj_mem.policies.clear()
                        updated_existing_pms.append(team_existing_proj_mem)
                    existing_team_mem.is_active = False
                    existing_team_mem.role = TEAM_MEMBER
        ProjectMembers.objects.bulk_update(updated_existing_pms, ["is_active", "role"], batch_size=200)
        TeamMembers.objects.bulk_update(existing_tms, ["is_active", "role"], batch_size=200)

        not_created_member_teams = []
        for target_team in target_teams:
            if target_team["team_id"] not in existing_tms_ids_set:
                not_created_member_teams.append(target_team)
        if not_created_member_teams:
            AssignPermissions(self.customer, self.iam).assign_iam_user_access(target_iam, not_created_member_teams)

    def update_team_role_access(self, target_team_member, team_role, target_projects):
        if team_role == TEAM_LEAD:
            self._update_as_team_lead(target_team_member, team_role)
        elif team_role == TEAM_MEMBER:
            self._update_as_team_member(target_team_member, target_projects)

    def _update_as_team_lead(self, target_team_member, team_role):
        projects = Projects.get_not_deleted_projects(members__team_member=self.team_member)
        existing_pms = ProjectMembers.get_not_deleted_members(team_member=target_team_member)
        existing_pms_map = {pm.project_id: pm for pm in existing_pms}
        created_project_member_ins = []

        for project in projects:
            exs_project_member = existing_pms_map.get(project.id, None)
            if exs_project_member:
                exs_project_member.is_active = True
                exs_project_member.role = team_role
                exs_project_member.policies.clear()
            else:
                created_project_member_ins.append(
                    ProjectMembers(project=project, team_member=target_team_member, role=team_role, created_by=self.customer)
                )
        ProjectMembers.objects.bulk_create(created_project_member_ins, batch_size=200)
        ProjectMembers.objects.bulk_update(existing_pms, ["is_active", "role"], batch_size=200)

    def _update_as_team_member(self, target_team_member, target_projects):
        active_prj_members = ProjectMembers.get_active_members(team_member=self.team_member)  # active project members
        existing_pms = ProjectMembers.get_not_deleted_members(team_member=target_team_member)
        user_policies = list(UserPolicies.objects.filter(project__team_id=self.team_member.team_id))

        target_projects_map = {target_project["project_id"]: target_project for target_project in target_projects}
        active_prj_members_map = {active_pm.project_id: active_pm for active_pm in active_prj_members}
        existing_pms_ids_set = set()
        for existing_prj_member in existing_pms:
            existing_pms_ids_set.add(existing_prj_member.project_id)
            active_prj_member = active_prj_members_map.get(existing_prj_member.project_id, None)
            if active_prj_member:
                target_project_obj = target_projects_map.get(existing_prj_member.project_id, None)
                if target_project_obj:
                    target_prj_role = target_project_obj["project_role"]
                    existing_prj_member.role = target_prj_role
                    existing_prj_member.is_active = True
                    if target_prj_role == MEMBER:
                        policy_ids = target_project_obj.get("policies", [])
                        policy_instances = [policy for policy in user_policies if policy.id in policy_ids]
                        existing_prj_member.policies.set(policy_instances)
                else:
                    existing_prj_member.role = MEMBER
                    existing_prj_member.is_active = False
                    existing_prj_member.policies.clear()
        ProjectMembers.objects.bulk_update(existing_pms, ["is_active", "role"], batch_size=200)

        not_created_member_prjs = []
        for target_project in target_projects:
            if target_project["project_id"] not in existing_pms_ids_set:
                not_created_member_prjs.append(target_project)
        if not_created_member_prjs:
            AssignPermissions(self.customer, self.iam, self.team_member).assign_team_member_access(
                target_team_member, not_created_member_prjs
            )
