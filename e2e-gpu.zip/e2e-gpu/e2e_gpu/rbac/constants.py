# IAM TYPE
OWNER_IAM = "OwnerIam"  # this type represent iam object for owner
PRIMARY_USER_IAM = "PrimaryUserIam"  # this type represent iam object for user which has account on my account
CONTACT_PERSON_IAM = "ContactPersonIam"  # this type represent iam object for user who is contact person on my account

IAM_CHOICES = (
    (OWNER_IAM, OWNER_IAM),
    (PRIMARY_USER_IAM, PRIMARY_USER_IAM),
    (CONTACT_PERSON_IAM, CONTACT_PERSON_IAM),
)

# ROLES
# if you are changing values of below constants make sure change it on frontend and groot server also.
OWNER = "Owner"
ADMIN = "Admin"
TEAM_LEAD = "TeamLead"
PROJECT_LEAD = "ProjectLead"
IAM_USER = "IAMUser"
TEAM_MEMBER = "TeamMember"
MEMBER = "Member"

OWNER_VALUE = 64
ADMIN_VALUE = 32
TEAM_LEAD_VALUE = 16
PROJECT_LEAD_VALUE = 8
IAM_USER_VALUE = 4
TEAM_MEMBER_VALUE = 2
MEMBER_VALUE = 1

INDIVIDUAL = "individual"
COMBINED = "combined"

# combined: represent aggregate value of team-lead, team-member, project-lead, member
# we need this because we do not allow iam_user to add team-member, member and team-member to added member
ROLES_VALUE = {
    OWNER: {INDIVIDUAL: OWNER_VALUE, COMBINED: OWNER_VALUE},
    ADMIN: {INDIVIDUAL: ADMIN_VALUE, COMBINED: ADMIN_VALUE},
    IAM_USER: {INDIVIDUAL: IAM_USER_VALUE, COMBINED: IAM_USER_VALUE},
    TEAM_LEAD: {INDIVIDUAL: TEAM_LEAD_VALUE, COMBINED: IAM_USER_VALUE + TEAM_LEAD_VALUE},
    TEAM_MEMBER: {INDIVIDUAL: TEAM_MEMBER_VALUE, COMBINED: IAM_USER_VALUE + TEAM_MEMBER_VALUE},
    PROJECT_LEAD: {INDIVIDUAL: PROJECT_LEAD_VALUE, COMBINED: IAM_USER_VALUE + TEAM_MEMBER_VALUE + PROJECT_LEAD_VALUE},
    MEMBER: {INDIVIDUAL: MEMBER_VALUE, COMBINED: IAM_USER_VALUE + TEAM_MEMBER_VALUE + MEMBER_VALUE},
}

ROLE_CHOICES = (
    (OWNER, OWNER),
    (ADMIN, ADMIN),
    (IAM_USER, IAM_USER),
    (TEAM_LEAD, TEAM_LEAD),
    (TEAM_MEMBER, TEAM_MEMBER),
    (PROJECT_LEAD, PROJECT_LEAD),
    (MEMBER, MEMBER),
)

IAM_ROLE_CHOICES = (
    (OWNER, OWNER),
    (ADMIN, ADMIN),
    (IAM_USER, IAM_USER),
)

TEAM_MEMBER_ROLE_CHOICES = (
    (OWNER, OWNER),
    (ADMIN, ADMIN),
    (TEAM_LEAD, TEAM_LEAD),
    (TEAM_MEMBER, TEAM_MEMBER),
)

PROJECT_MEMBER_ROLE_CHOICES = (
    (OWNER, OWNER),
    (ADMIN, ADMIN),
    (TEAM_LEAD, TEAM_LEAD),
    (PROJECT_LEAD, PROJECT_LEAD),
    (MEMBER, MEMBER),
)

# services
TEAM_SERVICE = "team_service"
PROJECT_SERVICE = "project_service"
IAM_USER_SERVICE = "iam_user_service"
TEAM_MEMBER_SERVICE = "team_member_service"
PROJECT_MEMBER_SERVICE = "project_member_service"
USER_POLICY_SERVICE = "user_policy_service"
INVITE_SERVICE = "invite_service"
NOTEBOOK = "notebook"
DATASET = "dataset"
PROJECT_BILLING = "project_billing_and_logs"
INFERENCE_SERVICE = "inference_service"
EOS_SERVICE = "eos"
MODEL_SERVICE = "model"
AUTH_TOKEN_SERVICE = "auth_token"
INTEGRATION_SERVICE = "integration_service"
PIPELINE = "pipeline"
FINE_TUNING = "finetuning"
CONTAINER_REGISTRY_SERVICE = "container_registry"
MODEL_PLAYGROUND = "model_playground"
DISTRIBUTED_JOB = "distributed_job"
VECTOR_DB = "vector_db"
DATA_SYNCER = "data_syncer"

#  ACCESS CONTROL CONSTANTS
CREATE = "create"
READ = "read"
UPDATE = "update"
DELETE = "delete"
PATCH = "patch"

NO_PERMISSION_VALUE = 0
READ_VALUE = 1
CREATE_VALUE = 2
UPDATE_VALUE = 4
DELETE_VALUE = 8

ACCESS_CONTROL_VALUE = {
    CREATE: CREATE_VALUE,
    READ: READ_VALUE,
    UPDATE: UPDATE_VALUE,
    DELETE: DELETE_VALUE,
}

ACCESS_CONTROL_CHOICES = (
    (CREATE_VALUE, CREATE),
    (READ_VALUE, READ),
    (UPDATE_VALUE, UPDATE),
    (DELETE_VALUE, DELETE),
    (CREATE_VALUE | READ_VALUE, f"{CREATE},{READ}"),
    (CREATE_VALUE | UPDATE_VALUE, f"{CREATE},{UPDATE}"),
    (CREATE_VALUE | DELETE_VALUE, f"{CREATE},{DELETE}"),
    (READ_VALUE | UPDATE_VALUE, f"{READ},{UPDATE}"),
    (READ_VALUE | DELETE_VALUE, f"{READ},{DELETE}"),
    (UPDATE_VALUE | DELETE_VALUE, f"{UPDATE},{DELETE}"),
    (CREATE_VALUE | READ_VALUE | UPDATE_VALUE, f"{CREATE},{READ},{UPDATE}"),
    (CREATE_VALUE | READ_VALUE | DELETE_VALUE, f"{CREATE},{READ},{DELETE}"),
    (CREATE_VALUE | UPDATE_VALUE | DELETE_VALUE, f"{CREATE},{UPDATE},{DELETE}"),
    (READ_VALUE | UPDATE_VALUE | DELETE_VALUE, f"{READ},{UPDATE},{DELETE}"),
    (CREATE_VALUE | READ_VALUE | UPDATE_VALUE | DELETE_VALUE, f"{CREATE},{READ},{UPDATE},{DELETE}"),
    (NO_PERMISSION_VALUE, "NO PERMISSIONS"),
)

CRUD_LIST = [CREATE, READ, UPDATE, DELETE]

# ROLES CONSTANT
IAM_TYPE_MAX_LENGTH = 50
ROLE_MAX_LENGTH = 50


# ERROR MESSAGES
SERVICE_ACCESS_DENIED = "You don't have permission to access this service. Please verify your policy, team or project."
PRIMARY_IAM_CREATE_SUPPORT_MESSAGE = "Unable to create primary user iam.\nerrors: {email_id}"
ACCESS_CONTROL_ERROR = "User does not have {access} permission"
ROLE_ACCESS_DENIED = "You do not have permission to perform this action with your current role"
IAM_USER_ASSIGN_NAMESPACE_ACCESS_TASK_FAILED = "Failed to assign namespace access to iam-user members, id: {iam_id} \n errors: {errors}"
IAM_USER_ASSIGN_NAMESPACE_ACCESS_TASK_SUBJECT = "Failed to assign namespace access to iam-user members created_by: {email}"
IAM_USER_REMOVE_NAMESPACE_ACCESS_TASK_FAILED = "Failed to remove namespace access to iam-user members, id: {iam_id} \n errors: {errors}"
IAM_USER_REMOVE_NAMESPACE_ACCESS_TASK_SUBJECT = "Failed to remove namespace access to iam-user members deleted_by: {email}"

# TASKS
IAM_USER_DELETE_MEMBERS_AND_NAMESPACE_ACCESS_TASK = "iam_user_delete_members_and_namespace_access_task"
IAM_USER_ASSIGN_NAMESPACE_ACCESS_TASK = "iam_user_assign_namespace_access_task"
IAM_USER_REMOVE_INACTIVE_MEMBERS_NAMESPACE_ACCESS_TASK = "iam_user_remove_inactive_members_namespace_access_task"

# AUDIT LOG
IAM_ACCESS_UPDATE_EVENT = "IAM_ACCESS_UPDATE"
IAM_DELETE_EVENT = "IAM_DELETE"

# Services which need iam consent
CONSENT_SERVICES_SET = set([MODEL_PLAYGROUND])
CONSENT_SERVICE_ERROR = "Invalid consent service"

# audit log  constant
IAM_CONSENT_EVENT_MAPPING = {
    MODEL_PLAYGROUND: "GENAI_API_CONSENT_UPDATE",
}
