import logging

from rest_framework.response import Response

from e2e_core.api.v1.services.base import BaseService
from e2e_core.constants import NOT_FOUND_ERROR, PERMISSION_DENIED
from e2e_core.exceptions import ObjectNotFoundError, TirPermissionError
from gpu_service.models import TirServicesDependency
from projects.models import ProjectMembers
from rbac.constants import ACCESS_CONTROL_VALUE, MEMBER, SERVICE_ACCESS_DENIED
from user_policies.models import UserPolicyServices

logger = logging.getLogger(__name__)


class RoleBasedAccessControl(object):

    def __init__(self, service_name, access):
        self.service_name = service_name
        self.access = access
        self.request = None
        self.customer = None
        self.iam = None
        self.project_member = None

    def __call__(self, original_function, *args, **kwargs):
        def inner_func(*args, **kwargs):
            self._initialize_params(*args)
            team_id = kwargs.get("team_id", None)
            project_id = kwargs.get("project_id", None)
            try:
                self.project_member = self._get_project_member(
                    "project",
                    "team_member__team",
                    project_id=project_id,
                    team_member__is_active=True,
                    team_member__team_id=team_id,
                    team_member__iam_user_id=self.iam.id,
                    team_member__deleted_at__isnull=True,
                )
                if not self.project_member:
                    raise ObjectNotFoundError(NOT_FOUND_ERROR.format(service="Project member"))
                team = self.project_member.team_member.team
                kwargs["team"] = team
                kwargs["project"] = self.project_member.project
                if not team_id:
                    kwargs["team_id"] = team.id
                if self.project_member.role == MEMBER:
                    self._check_permission()
            except Exception as e:
                logger.error(f"SERVICE_ACCESS_CHECK_FAILED | CRITICAL_GREEN | CUSTOMER -{self.customer.email} | ERRORS - {str(e)}")
                response = BaseService().get_403_response(SERVICE_ACCESS_DENIED)
                return Response(response, status=response.get("code"))

            return original_function(*args, **kwargs)

        return inner_func

    def _initialize_params(self, *args):
        self.request = args[1]
        self.customer = self.request.customer
        self.iam = self.request.iam

    def _get_project_member(self, *related_field, **filters):
        team_id = filters.get("team_member__team_id", None)
        if not team_id:
            filters.pop("team_member__team_id", None)
        return ProjectMembers.get_active_members(**filters).select_related(*related_field).first()

    def _check_permission(self):
        policies = self.project_member.policies.values_list("id", flat=True)
        if not self._get_service_permission(policies) and not self._get_dependent_service_permission(policies):
            raise TirPermissionError(PERMISSION_DENIED)
        return True

    def _get_service_permission(self, policies):
        policy_services = UserPolicyServices.objects.filter(policy_id__in=policies, service_id=self.service_name)
        service_permissions = policy_services.values_list("permissions", flat=True)
        for service_permsn in service_permissions:
            if service_permsn & ACCESS_CONTROL_VALUE[self.access]:
                return True
        return False

    def _get_dependent_service_permission(self, policies):
        as_dependencies = TirServicesDependency.objects.filter(dependency_id=self.service_name, is_active=True).values_list("service_id", flat=True)
        policy_services = UserPolicyServices.objects.filter(policy_id__in=policies, service_id__in=as_dependencies)
        service_permissions = policy_services.values_list("permissions", flat=True)
        for service_permsn in service_permissions:
            if service_permsn & ACCESS_CONTROL_VALUE[self.access]:
                return True
        return False
