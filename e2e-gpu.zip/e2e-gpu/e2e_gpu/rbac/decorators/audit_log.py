from rest_framework import status

from rbac.constants import IAM_ACCESS_UPDATE_EVENT, IAM_CONSENT_EVENT_MAPPING, IAM_DELETE_EVENT
from eventlogs.api.v1.services.eventlog_service import EventLogService
from eventlogs.constants import DELETE, EVENTLOG_FAILED_STATUS, EVENTLOG_SUCCESS_STATUS, IAM_CONSENT_CODE, IAM_SERVICE_CODE, UPDATE


def iam_delete_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        response = func(*args, **kwargs)
        event_log = EventLogService(IAM_SERVICE_CODE)
        log_status = EVENTLOG_SUCCESS_STATUS if response.status_code == status.HTTP_200_OK else EVENTLOG_FAILED_STATUS
        target_iam = kwargs.get("targeted_iam")
        event_log.create_log(
            request=request,
            event=IAM_DELETE_EVENT,
            resource_name=target_iam.added_user.email,
            resource_id=target_iam.id,
            resource_obj_id=target_iam.id,
            status=log_status,
            event_type=DELETE,
        )
        return response

    return wrapper_func


def iam_access_update_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        response = func(*args, **kwargs)
        event_log = EventLogService(IAM_SERVICE_CODE)
        log_status = EVENTLOG_SUCCESS_STATUS if response.status_code == status.HTTP_200_OK else EVENTLOG_FAILED_STATUS
        target_iam = kwargs.get("targeted_iam")
        event_log.create_log(
            request=request,
            event=IAM_ACCESS_UPDATE_EVENT,
            resource_name=target_iam.added_user.email,
            resource_id=target_iam.id,
            resource_obj_id=target_iam.id,
            detailed_info=request.data,
            status=log_status,
            event_type=UPDATE,
        )
        return response

    return wrapper_func


def iam_consent_update_audit_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        response = func(*args, **kwargs)
        event_log = EventLogService(IAM_CONSENT_CODE)
        log_status = EVENTLOG_SUCCESS_STATUS if response.status_code == status.HTTP_200_OK else EVENTLOG_FAILED_STATUS
        res_data = response.data["data"]
        consent_field = kwargs.get("consent_field", "")
        event_log.create_log(
            request=request,
            event=IAM_CONSENT_EVENT_MAPPING.get(consent_field, ""),
            resource_name=request.customer.email,
            resource_id=res_data.get("id", ""),
            resource_obj_id=res_data.get("id", None),
            event_type=UPDATE,
            status=log_status,
            detailed_info={"consent_field": consent_field},
        )
        return response

    return wrapper_func
