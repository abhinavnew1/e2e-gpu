import logging

from rest_framework.response import Response

from e2e_core.api.v1.services.base import BaseService
from e2e_core.constants import NOT_FOUND_ERROR, PERMISSION_DENIED
from e2e_core.exceptions import ObjectNotFoundError, TirPermissionError
from rbac.constants import IAM_USER_SERVICE, READ, ROLE_ACCESS_DENIED
from rbac.helpers import check_role_access, check_tir_role_based_permissions
from rbac.models import IAM

logger = logging.getLogger(__name__)


class IAMAccessControl(object):
    def __init__(self, action):
        self.action = action
        self.request = None
        self.iam: IAM = None

    def __call__(self, original_function, *args, **kwargs):
        def inner_func(*args, **kwargs):
            self._initialize_params(*args)
            iam_id = kwargs.get("iam_id", None)
            try:
                if not check_tir_role_based_permissions(IAM_USER_SERVICE, self.iam.role, self.action):
                    raise TirPermissionError(PERMISSION_DENIED)
                if iam_id:
                    targeted_iam = IAM.get_active_iams(id=iam_id, owner_id=self.iam.owner_id).first()
                    if not targeted_iam:
                        raise ObjectNotFoundError(NOT_FOUND_ERROR.format(service='Iam user'))
                    if self.action != READ and not check_role_access(self.iam.role, targeted_iam.role):
                        raise TirPermissionError(ROLE_ACCESS_DENIED)
                    kwargs["targeted_iam"] = targeted_iam
            except Exception as e:
                logger.error(f"IAM_ACCESS_CHECK_FAILED | CRITICAL_YELLOW | ERRORS - {str(e)}")
                response = BaseService.get_403_response(PERMISSION_DENIED)
                return Response(response, status=response.get("code"))
            return original_function(*args, **kwargs)

        return inner_func

    def _initialize_params(self, *args):
        self.request = args[1]
        self.iam = self.request.iam
