import base64
import jwt
import logging

from celery.execute import send_task

from e2e_core.helpers import support_ticket_generator
from e2e_gpu.settings import USER_INVITE_SECRET_KEY
from projects.constants import ASSIGN_ACCESS_COUNTDOWN, REMOVE_ACCESS_COUNTDOWN
from rbac.constants import (
    ACCESS_CONTROL_VALUE,
    COMBINED,
    IAM_USER_ASSIGN_NAMESPACE_ACCESS_TASK,
    IAM_USER_ASSIGN_NAMESPACE_ACCESS_TASK_FAILED,
    IAM_USER_ASSIGN_NAMESPACE_ACCESS_TASK_SUBJECT,
    IAM_USER_DELETE_MEMBERS_AND_NAMESPACE_ACCESS_TASK,
    IAM_USER_REMOVE_INACTIVE_MEMBERS_NAMESPACE_ACCESS_TASK,
    IAM_USER_REMOVE_NAMESPACE_ACCESS_TASK_FAILED,
    IAM_USER_REMOVE_NAMESPACE_ACCESS_TASK_SUBJECT,
    INDIVIDUAL,
    INVITE_SERVICE,
    NO_PERMISSION_VALUE,
    ROLES_VALUE,
)
from rbac.models import TirRoleBasedPermissions

logger = logging.getLogger(__name__)


def check_role_level(smaller_role, higher_role):
    return ROLES_VALUE[smaller_role][INDIVIDUAL] > ROLES_VALUE[higher_role][INDIVIDUAL]


def check_role_access(performer_role, targeted_role):
    individual = ROLES_VALUE[performer_role][INDIVIDUAL] > ROLES_VALUE[targeted_role][INDIVIDUAL]
    combined = ROLES_VALUE[performer_role][COMBINED] > ROLES_VALUE[targeted_role][COMBINED]
    return individual and combined


def check_tir_role_based_permissions(service, role, action):
    team_service = TirRoleBasedPermissions.objects.filter(service_id=service, role=role).first()
    if team_service:
        return team_service.permissions & ACCESS_CONTROL_VALUE[action]
    return NO_PERMISSION_VALUE


def get_role_based_permissions(role):
    role_permissions = TirRoleBasedPermissions.objects.filter(role=role).exclude(service_id=INVITE_SERVICE)
    return {role_perm.service_id: role_perm.permissions for role_perm in role_permissions}


def get_owner_added_user(token):
    token += "=" * ((4 - len(token) % 4) % 4)
    token_bytes = base64.urlsafe_b64decode(token.encode("utf-8"))
    payload = jwt.decode(token_bytes, USER_INVITE_SECRET_KEY, algorithms=["HS256"])
    return payload


def iam_user_assign_namespace_access(customer, targeted_iam):
    try:
        send_task(
            IAM_USER_ASSIGN_NAMESPACE_ACCESS_TASK,
            kwargs={"created_by": customer, "targeted_iam_id": targeted_iam.id},
            countdown=ASSIGN_ACCESS_COUNTDOWN,
        )
    except Exception as e:
        errors = str(e)
        logger.error(
            f"IAM_SERVICE | CRITICAL_RED | IAM_USER_ASSIGN_NAMESPACE_ACCESS_TASK_FAILED \
                    | IAM_ID:{targeted_iam.id} | ERROR:{errors}"
        )
        support_ticket_generator(
            errors=IAM_USER_ASSIGN_NAMESPACE_ACCESS_TASK_FAILED.format(iam_id=targeted_iam.id, errors=errors),
            subject=IAM_USER_ASSIGN_NAMESPACE_ACCESS_TASK_SUBJECT.format(email=customer.email),
            customer=customer,
        )


def iam_user_remove_inactive_members_namespace_access(customer, targeted_iam):
    try:
        send_task(
            IAM_USER_REMOVE_INACTIVE_MEMBERS_NAMESPACE_ACCESS_TASK,
            kwargs={"removed_by": customer, "targeted_iam_id": targeted_iam.id},
            countdown=ASSIGN_ACCESS_COUNTDOWN,
        )
    except Exception as e:
        errors = str(e)
        logger.error(
            f"IAM_SERVICE | CRITICAL_RED | IAM_USER_REMOVE_INACTIVE_MEMBERS_NAMESPACE_ACCESS_TASK_FAILED \
                    | IAM_ID:{targeted_iam.id} | ERROR:{errors}"
        )
        support_ticket_generator(
            errors=IAM_USER_REMOVE_NAMESPACE_ACCESS_TASK_FAILED.format(iam_id=targeted_iam.id, errors=errors),
            subject=IAM_USER_REMOVE_NAMESPACE_ACCESS_TASK_SUBJECT.format(email=customer.email),
            customer=customer,
        )


def iam_user_delete_members_and_namespace_access(customer, targeted_iam):
    try:
        send_task(
            IAM_USER_DELETE_MEMBERS_AND_NAMESPACE_ACCESS_TASK,
            kwargs={"deleted_by": customer, "targeted_iam_id": targeted_iam.id},
            countdown=REMOVE_ACCESS_COUNTDOWN,
        )
    except Exception as e:
        errors = str(e)
        logger.error(
            f"IAM_SERVICE | CRITICAL_RED | IAM_USER_DELETE_MEMBERS_AND_NAMESPACE_ACCESS_TASK_FAILED \
                | IAM_ID:{targeted_iam.id} | ERROR:{errors}"
        )
        support_ticket_generator(
            errors=IAM_USER_REMOVE_NAMESPACE_ACCESS_TASK_FAILED.format(iam_id=targeted_iam.id, errors=errors),
            subject=IAM_USER_REMOVE_NAMESPACE_ACCESS_TASK_SUBJECT.format(email=customer.email),
            customer=customer,
        )
