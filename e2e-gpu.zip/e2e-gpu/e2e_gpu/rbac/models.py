from datetime import datetime

from django.db import models
from django.db.models import UniqueConstraint

from customer.models import Customer
from e2e_core.mixins import BaseMixin, SafeDeleteMixinExtended
from e2e_core.helpers import mark_delete_related_objects
from gpu_service.models import TirServices
from rbac.constants import (
    ACCESS_CONTROL_CHOICES,
    IAM_CHOICES,
    IAM_ROLE_CHOICES,
    IAM_TYPE_MAX_LENGTH,
    NO_PERMISSION_VALUE,
    OWNER,
    OWNER_IAM,
    ROLE_CHOICES,
    ROLE_MAX_LENGTH,
)


class IAM(SafeDeleteMixinExtended, BaseMixin):
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    owner = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name="account_owner")
    added_user = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name="add_user")
    iam_type = models.CharField(max_length=IAM_TYPE_MAX_LENGTH, choices=IAM_CHOICES, default=OWNER_IAM)
    role = models.CharField(max_length=ROLE_MAX_LENGTH, choices=IAM_ROLE_CHOICES, default=OWNER)

    class Meta:
        constraints = [UniqueConstraint(fields=["owner", "added_user", "deleted_at"], name="unique_iam_user")]

    def __str__(self):
        return f"<IAM({self.id}, owner:({self.owner.email}, added_user:{self.added_user.email})>"

    @classmethod
    def get_active_iams(cls, **filters):
        return cls.objects.filter(deleted_at__isnull=True, **filters)

    def mark_deleted(self):
        if self.deleted_at is None:
            mark_delete_related_objects(self)
            self.deleted_at = datetime.now()
            self.save(update_fields=["deleted_at", "updated_at"])


class IAMConsent(SafeDeleteMixinExtended, BaseMixin):
    iam_user = models.OneToOneField(IAM, on_delete=models.CASCADE)
    model_playground = models.BooleanField(default=False)

    def __str__(self):
        return f"<IAMConsent({self.id}, iam_user:({self.iam_user.added_user.email})>"


class TirRoleBasedPermissions(SafeDeleteMixinExtended, BaseMixin):
    service = models.ForeignKey(TirServices, on_delete=models.CASCADE, to_field="service_id", related_name="tir_role_based_permissions")
    role = models.CharField(max_length=ROLE_MAX_LENGTH, choices=ROLE_CHOICES)
    permissions = models.PositiveSmallIntegerField(choices=ACCESS_CONTROL_CHOICES, default=NO_PERMISSION_VALUE)
