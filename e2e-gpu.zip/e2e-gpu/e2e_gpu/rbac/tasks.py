import logging

from e2e_gpu.celery import app
from e2e_core.helpers import support_ticket_generator

from projects.constants import (
    PROJECT_MEMBERS_ASSIGN_NAMESPACE_ACCESS_ERROR,
    PROJECT_MEMBERS_ASSIGN_NAMESPACE_ACCESS_SUBJECT,
    PROJECT_MEMBERS_REMOVE_NAMESPACE_ACCESS_ERROR,
    PROJECT_MEMBERS_REMOVE_NAMESPACE_ACCESS_SUBJECT,
)
from projects.api.v1.services.namespace_service import NamespaceService
from projects.models import ProjectMembers
from rbac.constants import (
    IAM_USER_ASSIGN_NAMESPACE_ACCESS_TASK,
    IAM_USER_DELETE_MEMBERS_AND_NAMESPACE_ACCESS_TASK,
    IAM_USER_REMOVE_INACTIVE_MEMBERS_NAMESPACE_ACCESS_TASK,
)
from rbac.models import IAM

logger = logging.getLogger(__name__)


@app.task(
    name=IAM_USER_ASSIGN_NAMESPACE_ACCESS_TASK,
    bind=True,
)
def iam_user_assign_namespace_access_task(self, *args, **kwargs):
    created_by = kwargs.get("created_by", None)
    targeted_iam_id = kwargs.get("targeted_iam_id", None)
    targeted_iam = IAM.objects.filter(id=targeted_iam_id).select_related("added_user").first()
    project_members = ProjectMembers.get_active_members(team_member__iam_user=targeted_iam).select_related("project")
    namespace_service = NamespaceService(None, targeted_iam.added_user)
    failed_member_assign_namespace_access = []
    for project_member in project_members:
        namespace_service.project = project_member.project
        is_success = namespace_service.add_permissions(targeted_iam.added_user.email, project_member.role)
        if not is_success:
            failed_member_assign_namespace_access.append(project_member.id)
    if failed_member_assign_namespace_access:
        logger.error(
            f"IAM_USER_ASSIGN_NAMESPACE_ACCESS_TASK | FAILED_TO_ASSIGN_NAMESPACE_ACCESS_FOR_PROJECT_MEMBERS | CRITICAL_RED |\
            | PROJECT_MEMBERS: {failed_member_assign_namespace_access}"
        )
        support_ticket_generator(
            errors=PROJECT_MEMBERS_ASSIGN_NAMESPACE_ACCESS_ERROR.format(members=failed_member_assign_namespace_access),
            subject=PROJECT_MEMBERS_ASSIGN_NAMESPACE_ACCESS_SUBJECT.format(email=created_by.email),
            customer=created_by,
        )


@app.task(
    name=IAM_USER_REMOVE_INACTIVE_MEMBERS_NAMESPACE_ACCESS_TASK,
    bind=True,
)
def iam_user_remove_inactive_members_namespace_access_task(self, **kwargs):
    removed_by = kwargs.get("removed_by", None)
    targeted_iam_id = kwargs.get("targeted_iam_id", None)
    targeted_iam = IAM.objects.filter(id=targeted_iam_id).select_related("added_user").first()
    project_members = ProjectMembers.objects.filter(team_member__iam_user=targeted_iam, is_active=False).select_related("project")
    namespace_service = NamespaceService(None, targeted_iam.added_user)
    failed_member_namespace_access_removal = []
    for project_member in project_members:
        namespace_service.project = project_member.project
        is_success = namespace_service.delete_permissions(targeted_iam.added_user.email, project_member.role)
        if not is_success:
            failed_member_namespace_access_removal.append(project_member.id)
    if failed_member_namespace_access_removal:
        logger.error(
            f"IAM_USER_REMOVE_INACTIVE_MEMBERS_NAMESPACE_ACCESS_TASK | FAILED_TO_REMOVE_NAMESPACE_ACCESS_FOR_PROJECT_MEMBERS | CRITICAL_RED |\
            | PROJECT_MEMBERS: {failed_member_namespace_access_removal}"
        )
        support_ticket_generator(
            errors=PROJECT_MEMBERS_REMOVE_NAMESPACE_ACCESS_ERROR.format(members=failed_member_namespace_access_removal),
            subject=PROJECT_MEMBERS_REMOVE_NAMESPACE_ACCESS_SUBJECT.format(email=removed_by.email),
            customer=removed_by,
        )


@app.task(
    name=IAM_USER_DELETE_MEMBERS_AND_NAMESPACE_ACCESS_TASK,
    bind=True,
)
def iam_user_delete_members_and_namespace_access_task(self, **kwargs):
    deleted_by = kwargs.get("deleted_by", None)
    targeted_iam_id = kwargs.get("targeted_iam_id", None)
    targeted_iam = IAM.objects.filter(id=targeted_iam_id).select_related("added_user").first()
    project_members = ProjectMembers.objects.filter(team_member__iam_user=targeted_iam).select_related("project")
    namespace_service = NamespaceService(None, targeted_iam.added_user)
    failed_member_namespace_access_removal = []
    for project_member in project_members:
        namespace_service.project = project_member.project
        is_success = namespace_service.delete_permissions(targeted_iam.added_user.email, project_member.role)
        if not is_success:
            failed_member_namespace_access_removal.append(project_member.id)
    targeted_iam.delete()  # this will delete all the related objects to IAM model
    if failed_member_namespace_access_removal:
        logger.error(
            f"IAM_USER_DELETE_MEMBERS_AND_NAMESPACE_ACCESS_TASK | FAILED_TO_REMOVE_NAMESPACE_ACCESS_FOR_PROJECT_MEMBERS | CRITICAL_RED |\
            | PROJECT_MEMBERS: {failed_member_namespace_access_removal}"
        )
        support_ticket_generator(
            errors=PROJECT_MEMBERS_REMOVE_NAMESPACE_ACCESS_ERROR.format(members=failed_member_namespace_access_removal),
            subject=PROJECT_MEMBERS_REMOVE_NAMESPACE_ACCESS_SUBJECT.format(email=deleted_by.email),
            customer=deleted_by,
        )
