from e2e_core.api.v1.services.base import BaseService
from e2e_core.exceptions import TirPermissionError
from projects.models import ProjectMembers
from invites.constants import (
    ASSIGN_ROLE_ERROR,
    PROJECTS_ACCESS_ERROR,
    TEAMS_ACCESS_ERROR,
    USER_POLICIES_ACCESS_ERROR,
)
from rbac.helpers import check_role_access, check_role_level
from rbac.constants import IAM_USER, MEMBER, TEAM_MEMBER
from rbac.models import IAM
from teams.models import TeamMembers
from user_policies.models import UserPolicies


"""
OWNER can add user with any role[ADMIN, IAM_USER, IAM_USER__TEAM_LEAD, IAM_USER__TEAM_MEMBER,
IAM_USER__TEAM_MEMBER__PROJECT_LEAD, IAM_USER__TEAM_MEMBER__MEMBER].

ADMIN can add user with role [IAM_USER, IAM_USER__TEAM_LEAD, IAM_USER__TEAM_MEMBER,
IAM_USER__TEAM_MEMBER__PROJECT_LEAD, IAM_USER__TEAM_MEMBER__MEMBER].

IAM_USER can not add any user.
IAM_USER_TEAM_LEAD can add user with role [IAM_USER, IAM_USER__TEAM_MEMBER, IAM_USER__TEAM_MEMBER__PROJECT_LEAD,
IAM_USER__TEAM_MEMBER__MEMBER].
IAM_USER__TEAM_MEMBER can not add any user in his team.
IAM_USER__TEAM_MEMBER__PROJECT_LEAD can add user in his project as [IAM_USER, IAM_USER__TEAM_MEMBER, IAM_USER__TEAM_MEMBER__MEMBER].
IAM_USER__TEAM_MEMBER__MEMBER can not add any user his team, project.
"""


class ValidateTeamsProjectsAccess(BaseService):
    def __init__(self, iam: IAM):
        self.iam = iam
        self.team_members = []
        self.project_members = []
        self.user_policies = []

    def validate_teams(self, targeted_iam_role, targeted_teams):
        performer_iam_role = self.iam.role
        if targeted_iam_role == IAM_USER:
            self.team_members = TeamMembers.get_active_members(iam_user=self.iam, team__is_private=False)
            self.project_members = ProjectMembers.get_active_members(team_member__iam_user=self.iam)
            self.user_policies = UserPolicies.objects.filter(project__team__owner_id=self.iam.owner_id)
            team_members_map = {}
            for team_member in self.team_members:
                team_members_map[team_member.team_id] = team_member
                if check_role_level(team_member.role, performer_iam_role):
                    performer_iam_role = team_member.role
            for targeted_team in targeted_teams:
                target_team_id = targeted_team["team_id"]
                performer_team_member = team_members_map.get(target_team_id, None)
                if not performer_team_member:
                    raise TirPermissionError(TEAMS_ACCESS_ERROR.format(team_id=target_team_id))
                targeted_team_role = targeted_team["team_role"]
                performer_team_role = self._determine_performer_team_role(performer_team_member, targeted_team, targeted_team_role)
                self._validate_level_access(performer_team_role, targeted_team_role)
                if check_role_level(performer_team_role, performer_iam_role):
                    performer_iam_role = performer_team_role

            if not targeted_teams and performer_iam_role == IAM_USER:
                performer_iam_role = self._check_project_members_roles(performer_iam_role)

        self._validate_level_access(performer_iam_role, targeted_iam_role)

    def _determine_performer_team_role(self, performer_team_member, targeted_team, targeted_team_role):
        if targeted_team_role == TEAM_MEMBER:
            return self._check_projects(performer_team_member, targeted_team["projects"])
        return performer_team_member.role

    def _check_projects(self, performer_team_member: TeamMembers, targeted_projects):
        team_project_members = self.project_members.filter(team_member=performer_team_member)
        project_members_map = {}
        performer_team_role = performer_team_member.role
        for prj_mem in team_project_members:
            project_members_map[prj_mem.project_id] = prj_mem
            if check_role_level(prj_mem.role, performer_team_role):
                performer_team_role = prj_mem.role

        for targeted_project in targeted_projects:
            target_project_id = targeted_project["project_id"]
            performer_project_member = project_members_map.get(target_project_id, None)
            if not performer_project_member:
                raise TirPermissionError(PROJECTS_ACCESS_ERROR.format(project_id=target_project_id))
            targeted_project_role = targeted_project["project_role"]
            if targeted_project_role == MEMBER:
                policies = targeted_project.get("policies", [])
                self._check_user_policies(target_project_id, policies)
            self._validate_level_access(performer_project_member.role, targeted_project_role)
        return performer_team_role

    def _check_project_members_roles(self, performer_iam_role):
        for prj_mem in self.project_members:
            if check_role_level(prj_mem.role, performer_iam_role):
                performer_iam_role = prj_mem.role
        return performer_iam_role

    def _check_user_policies(self, project_id, policy_id_list):
        count_mactching_policies = self.user_policies.filter(id__in=policy_id_list, project_id=project_id).count()
        if count_mactching_policies != len(policy_id_list):
            raise TirPermissionError(USER_POLICIES_ACCESS_ERROR)

    def _validate_level_access(self, performer_role, targeted_role):
        level_access = check_role_access(performer_role, targeted_role)
        if not level_access:
            raise TirPermissionError(ASSIGN_ROLE_ERROR.format(role=targeted_role))
