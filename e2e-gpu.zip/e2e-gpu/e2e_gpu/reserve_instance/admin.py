from django.contrib import admin
from safedelete.admin import SafeDeleteAdmin

from reserve_instance.models import ReserveInstance, ReserveInstanceTransaction


class ReserveInstanceAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "resource",
        "resource_state",
        "updation_policy",
        "sku_item_price",
        "next_sku_item_price",
    )
    search_fields = ("id", "resource", "resource_state", "updation_policy",)
    list_filter = ("updation_policy", "resource_state",)
    list_display_links = ("id", "resource",)
    list_select_related = ("sku_item_price", "sku_item_price__sku", "sku_item_price__currency",
                           "next_sku_item_price", "next_sku_item_price__sku", "next_sku_item_price__currency",)
    readonly_fields = ("id",
                       "resource",
                       "resource_state",
                       "updation_policy",
                       "sku_item_price",
                       "next_sku_item_price",)


class ReserveInstanceTransactionAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "reserve_instance",
        "current_sku_item_price",
        "status",
        "start_date",
        "end_date",
    )
    raw_id_fields = ("current_sku_item_price", "reserve_instance")
    search_fields = ("id", "reserve_instance")
    list_filter = ("status", "start_date", "end_date", )
    list_display_links = ("id", "reserve_instance",)
    list_select_related = ("reserve_instance", "current_sku_item_price", "current_sku_item_price__sku", "current_sku_item_price__currency",)
    readonly_fields = ("id",
                       "reserve_instance",
                       "current_sku_item_price",
                       "status",
                       "start_date",
                       "end_date",
                       )


admin.site.register(ReserveInstance, ReserveInstanceAdmin)
admin.site.register(ReserveInstanceTransaction, ReserveInstanceTransactionAdmin)
