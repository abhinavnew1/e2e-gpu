from django.apps import AppConfig


class ReserveInstanceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'reserve_instance'
