from django.conf import settings

from gpu_service.constants import HOURLY, COMMITTED, NOTEBOOK, INFERENCE_SERVICE

# my_account names mapping
MY_ACCOUNT_SKU_ITEM_CATEGORY = {NOTEBOOK: "Notebook",
                                INFERENCE_SERVICE: "Inference"}
MY_ACCOUNT_COMMITTED_SKU_STR = "committed_sku"
MY_ACCOUNT_SKU_NAMES = {NOTEBOOK: "_NOTEBOOK",
                        INFERENCE_SERVICE: "_INFERENCE"}
LINE_ITEM_ID_MAPPING = {NOTEBOOK: "notebook_{}",  # NOTEBOOK_LINE_ITEM_UNIQUE_ID
                        INFERENCE_SERVICE: "inference_{}"}  # INFERENCE_LINE_ITEM_UNIQUE_ID

# my_account urls
COMMITTED_INSTANCE_DEDUCTION_URL = settings.MYACCOUNT_LB_URL + "api/v1/debit-item-usage/?customer_email={}&token={}"

# notification days
FIRST_NOTIFICATION_DAYS = 7
SECOND_NOTIFICATION_DAYS = 2
LAST_NOTIFICATION_DAYS = 1

# status option
AUTO_RENEW_STATUS = 'auto_renew'
AUTO_TERMINATE_STATUS = 'auto_terminate'
CONVERT_TO_HOURLY_BILLING = 'convert_to_hourly_billing'
INSTANCE_SKU_TYPE_MAPPING = {CONVERT_TO_HOURLY_BILLING: HOURLY,
                             AUTO_RENEW_STATUS: COMMITTED,
                             AUTO_TERMINATE_STATUS: ""}
INSTANCE_UPDATION_LIST = [AUTO_RENEW_STATUS, AUTO_TERMINATE_STATUS, CONVERT_TO_HOURLY_BILLING]
INSTANCE_UPDATION_POLICY = [(x, x) for x in INSTANCE_UPDATION_LIST]

# reserve instance status
STATE_TERMINATED = 'terminated'
STATE_RUNNING = 'running'
RESOURCE_STATE_LIST = [STATE_TERMINATED, STATE_RUNNING]
RESOURCE_STATE_CHOICES = [(x, x) for x in RESOURCE_STATE_LIST]

# transaction status
ACTIVE = "ACTIVE"
DONE = "DONE"
TRANSCATION_STATUS_CHOICES = (
    (ACTIVE, ACTIVE),
    (DONE, DONE)
)

# MSG/ERROR
INVALID_UPDATION_POLICY = "Invalid Updation policy chosen for committed instance"
INVALID_SKU_AND_UPDATION_POLICY = "Invalid sku_item_price & policy combination selected"
SUCCESSFULLY_RENEWED = "Successfully Renewed Committed {service}, name={name}, id={id}"
SUCCESSFULLY_CONVERTED = "Successfully converted Committed to hourly {service}, name={name}, id={id}"
TERMINATE_DONE = "Committed {service} terminated, name={name}, id={id}"
STATE_UPDATION_FAILURE = "Updation failed for {service},  name={name}, id={id}"

# template
COMMITTED_INSTANCE_TERMINATION_MAIL_NOTIFICATION = "reserve_instance/auto_termination_prior_notification.html"
COMMITTED_INSTANCE_AUTO_RENEWAL_NOTIFICATION = "reserve_instance/auto_renewal_prior_notification.html"
COMMITTED_INSTANCE_HOURLY_BILLING_CONVERSION_NOTIFICATION = "reserve_instance/auto_convert_to_hourly_prior_notification.html"
COMMITTED_INSTANCE_TERMINATED_MAIL = "reserve_instance/auto_termination_success.html"
COMMITTED_INSTANCE_AUTO_RENEWED_MAIL = "reserve_instance/auto_renewal_success.html"
COMMITTED_INSTANCE_AUTO_RENEWED_FAILED_MAIL = "reserve_instance/auto_renewal_failed.html"
COMMITTED_INSTANCE_HOURLY_BILLING_CONVERSION_MAIL = "reserve_instance/auto_convert_to_hourly_success.html"

SUFFICIENT_CREDIT = "Customer has sufficient credits"
