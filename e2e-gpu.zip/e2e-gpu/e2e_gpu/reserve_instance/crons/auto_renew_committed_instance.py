from datetime import datetime
import logging

from crons.base_crons import BaseCrons
from reserve_instance.constants import ACTIVE
from reserve_instance.helpers import get_committed_service_for_instance, ReserveInstanceMails
from reserve_instance.models import ReserveInstance

logger = logging.getLogger(__name__)
COMMITTED_AUTO_RENEWAL = 'Auto Renewal For Committed instance'
COMMITTED_CONVERT_TO_HOURLY_BILLING = 'Hourly Billing Mode For Committed instance'


class AutoRenewCommittedInstanceCustomer(BaseCrons):
    help = 'Auto renew Committed Instance of customers'

    def run(self, *args, **options):
        self.auto_renew_committed_instance()
        self.convert_to_hourly_billing()

    def auto_renew_committed_instance(self):
        committed_instances = ReserveInstance.get_committed_instance_for_auto_renewal()
        for instance in committed_instances:
            active_transaction = instance.reserveinstancetransaction_set.filter(current_sku_item_price=instance.sku_item_price,
                                                                                end_date__lte=datetime.now(), status=ACTIVE).last()
            committed_service_name, committed_service_handler = get_committed_service_for_instance(instance)
            if not (committed_service_name and active_transaction):
                continue
            try:
                is_renewed_to_committed, resource, msg = committed_service_handler(instance, active_transaction).auto_renew()
                ReserveInstanceMails.send_auto_renewal_mail(committed_service_name, resource, is_renewed_to_committed)
                self._success.append(
                    "Committed Instance Renewal done for instance {}, msg={}".format(instance.id, msg))
            except Exception as e:
                self._error_handler(instance.resource.created_by, e)

        subject = COMMITTED_AUTO_RENEWAL
        self._send_report(self._errors, self._success, subject)

    def convert_to_hourly_billing(self):
        committed_instances = ReserveInstance.get_committed_instance_for_hourly_billing()
        for instance in committed_instances:
            active_transaction = instance.reserveinstancetransaction_set.filter(current_sku_item_price=instance.sku_item_price,
                                                                                end_date__lte=datetime.now(), status=ACTIVE).last()
            committed_service_name, committed_service_handler = get_committed_service_for_instance(instance)
            if not (committed_service_name and active_transaction):
                continue
            try:
                resource, msg = committed_service_handler(instance, active_transaction).convert_to_hourly()
                ReserveInstanceMails.send_hourly_billing_mode_convert_mail(committed_service_name, resource, msg)
                self._success.append("Hourly Billing done for instance {}, msg={}".format(instance.id, msg))
            except Exception as e:
                self._error_handler(instance.resource.created_by, e)

        subject = COMMITTED_CONVERT_TO_HOURLY_BILLING
        self._send_report(self._errors, self._success, subject)


run = AutoRenewCommittedInstanceCustomer().run
