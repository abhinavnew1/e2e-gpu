from django.conf import settings

from crons.base_crons import BaseCrons
from customer.helpers import get_prepaid_credit_balance_via_user_email
from reserve_instance import constants
from reserve_instance.helpers import ReserveInstanceNotification
from reserve_instance.models import ReserveInstance


class NotifyCommittedInstanceCustomer(BaseCrons):  # TODO : scheduling, checks, etc
    help = 'Notify Customer about termination or renewal, of committed instance'

    def run(self, *args, **options):
        self.notify_customer_about_renewal()
        self.notify_customer_about_termination()
        self.notify_customer_about_start_of_hourly_billing()

    def notify_customer_about_termination(self):
        committed_instances = ReserveInstance.get_committed_instance_for_termination()
        for instance in committed_instances:
            is_notification_needed, active_transaction = ReserveInstanceNotification.check_if_is_notification_needed(instance)
            if not is_notification_needed:
                continue
            try:
                ReserveInstanceNotification.send_notification(constants.COMMITTED_INSTANCE_TERMINATION_MAIL_NOTIFICATION, instance, instance.resource)
                self._success.append("Customer {}".format(instance.resource.created_by))
            except Exception as e:
                self._error_handler(instance.resource.created_by, e)

        subject = 'Committed instance Mail Notify For Renewal'
        self._send_report(self._errors, self._success, subject)

    def notify_customer_about_renewal(self):
        committed_instances = ReserveInstance.get_committed_instance_for_auto_renewal()
        for instance in committed_instances:
            is_notification_needed, active_transaction = ReserveInstanceNotification.check_if_is_notification_needed(instance)
            if not is_notification_needed:
                continue
            try:
                is_prepaid, prepaid_user_balance = get_prepaid_credit_balance_via_user_email(instance.resource.project.team.owner.get_primary_contact().email)
                resource = instance.resource
                resource.is_prepaid = is_prepaid
                ReserveInstanceNotification.send_notification(constants.COMMITTED_INSTANCE_AUTO_RENEWAL_NOTIFICATION, instance, resource)
                self._success.append("Customer {}".format(instance.resource.created_by))
            except Exception as e:
                self._error_handler(instance.resource.created_by, e)

        subject = 'Committed instance Mail Notify For Termination'
        self._send_report(self._errors, self._success, subject)

    def notify_customer_about_start_of_hourly_billing(self):
        committed_instances = ReserveInstance.get_committed_instance_for_hourly_billing()
        for instance in committed_instances:
            is_notification_needed, active_transaction = ReserveInstanceNotification.check_if_is_notification_needed(instance)
            if not is_notification_needed:
                continue
            try:
                ReserveInstanceNotification.send_notification(constants.COMMITTED_INSTANCE_HOURLY_BILLING_CONVERSION_NOTIFICATION, instance, instance.resource)
                self._success.append("Customer {}".format(instance.resource.created_by))
            except Exception as e:
                self._error_handler(instance.resource.created_by, e)

        subject = 'Committed instance Mail Notify For Hourly Billing Start'
        self._send_report(self._errors, self._success, subject)


run = NotifyCommittedInstanceCustomer().run
