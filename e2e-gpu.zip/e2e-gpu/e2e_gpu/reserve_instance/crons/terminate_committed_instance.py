from datetime import datetime
import logging

from crons.base_crons import BaseCrons
from reserve_instance import constants
from reserve_instance.helpers import get_committed_service_for_instance, ReserveInstanceMails
from reserve_instance.models import ReserveInstance

logger = logging.getLogger(__name__)
COMMITTED_INSTANCE_TERMINATE = 'Committed instance Terminate Mail'


class TerminateCommittedInstanceCustomer(BaseCrons):  # TODO : scheduling, checks, etc
    help = 'Auto Terminate Committed Instance of customers'

    def run(self, *args, **options):
        committed_instance = ReserveInstance.get_committed_instance_for_termination()
        for instance in committed_instance:
            active_transaction = instance.reserveinstancetransaction_set.filter(current_sku_item_price=instance.sku_item_price,
                                                                                  end_date__lte=datetime.now(), status=constants.ACTIVE).last()
            committed_service_name, committed_service_handler = get_committed_service_for_instance(instance)
            if not (committed_service_name and active_transaction):
                continue
            try:
                msg = committed_service_handler(instance, active_transaction).auto_terminate_now()
                ReserveInstanceMails.send_termination_mail(committed_service_name, instance.resource, msg)
                self._success.append(
                    "Committed Instance Termination done for instance {}, msg={}".format(instance.id, msg))
            except Exception as e:
                self._error_handler(instance.resource.created_by, e)

        subject = COMMITTED_INSTANCE_TERMINATE
        self._send_report(self._errors, self._success, subject)


run = TerminateCommittedInstanceCustomer().run
