import json
import logging
import requests

from datetime import datetime, timedelta

from dbtemplates.models import Template
from django.conf import settings
from django.template.loader import get_template
from rest_framework import status

from customer.helpers import get_prepaid_credit_balance_via_user_email
from e2e_core.api.v1.services.mandrill import Mandrill
from gpu_service.constants import HOURLY
from inferenceservice.models import Inference
from notebook.models import Notebook
from reserve_instance import constants
from reserve_instance.services.comitted_inference_service import CommittedInferenceService
from reserve_instance.services.comitted_notebook_service import CommittedNotebooksService

logger = logging.getLogger(__name__)
mandrill_manager = Mandrill(mandrill_api_token=settings.MANDRILL_API_TOKEN, bcc=[],
                            from_email=settings.NOTIFY_FROM, notify=settings.NOTIFY_FROM)


def get_committed_service_for_instance(instance):
    if isinstance(instance.resource, Notebook):
        return constants.NOTEBOOK, CommittedNotebooksService
    if isinstance(instance.resource, Inference):
        return constants.INFERENCE_SERVICE, CommittedInferenceService
    else:
        return None, None


def deduct_reserve_instance_price_on_my_account(customer, sku_item_price, history_id, name, quantity=1):
    try:
        line_item_id = constants.LINE_ITEM_ID_MAPPING.get(sku_item_price.sku.category)
        my_acc_sku_name = constants.MY_ACCOUNT_SKU_NAMES.get(sku_item_price.sku.category)
        if line_item_id is None or my_acc_sku_name is None:
            logger.error(f"RESERVE_INSTANCE_DEDUCTION_API | API_CALL_FAILED | CRITICAL_RED | ERROR | line_item_id_not_defined")
            return False

        email = customer.email.replace('+', '%2B')
        payload = {
            'name': name,
            'line_item_id': line_item_id.format(history_id),
            'category': constants.MY_ACCOUNT_SKU_ITEM_CATEGORY.get(sku_item_price.sku.category),
            'sku_name': sku_item_price.sku.name + my_acc_sku_name,
            'sku_type': HOURLY if sku_item_price.sku_type == HOURLY else constants.MY_ACCOUNT_COMMITTED_SKU_STR,
            'committed_days': sku_item_price.committed_days,
            'currency': sku_item_price.currency.name,
            'location': sku_item_price.location,
            'quantity': quantity
        }

        url = constants.COMMITTED_INSTANCE_DEDUCTION_URL.format(email, settings.GPU_BILLING_API_TOKEN)
        response = requests.request("POST", url, data=json.dumps(payload),)
        if response.status_code == status.HTTP_200_OK:
            return True
        logger.error(f"RESERVE_INSTANCE_DEDUCTION_API | FAILED_TRANSACTION_ON_MY_ACCOUNT | CRITICAL_RED | CUSTOMER: {customer.email} | SKU_ITEM_PRICE_ID: {sku_item_price.id} | response: {response.text}")
        return False
    except Exception as e:
        logger.error(f"RESERVE_INSTANCE_DEDUCTION_API | API_CALL_FAILED | CRITICAL_RED | ERROR | {e}")


def send_mail_for_template(customer_emails, template_name, context_template_variables, **kwargs):
    mail_body = get_template(template_name).render(context_template_variables)
    mail_subject = str(Template.objects.get(name=template_name).subject).format(**kwargs)
    mandrill_manager.send_email([], customer_emails, mail_body, mail_subject)


class ReserveInstanceNotification:

    @classmethod
    def check_if_is_notification_needed(cls, instance):
        active_transaction = instance.reserveinstancetransaction_set.filter(status=constants.ACTIVE).last()
        if not active_transaction:
            return False, None
        date_time_now = datetime.now()
        if (instance.sku_item_price.committed_days > constants.FIRST_NOTIFICATION_DAYS
                and (date_time_now + timedelta(constants.FIRST_NOTIFICATION_DAYS)).date() == active_transaction.end_date.date()):
            return True, active_transaction
        if ((date_time_now + timedelta(constants.LAST_NOTIFICATION_DAYS)).date() == active_transaction.end_date.date() or
                (date_time_now + timedelta(constants.SECOND_NOTIFICATION_DAYS)).date() == active_transaction.end_date.date()):
            return True, active_transaction
        return False, active_transaction

    @classmethod
    def send_notification(cls, template_name, reserve_instance, committed_instance):
        upcoming_pricing = reserve_instance.next_sku_item_price.unit_price if reserve_instance.next_sku_item_price else ""
        committed_sku_day = reserve_instance.next_sku_item_price.committed_days if reserve_instance.next_sku_item_price else ""

        service_name, service_handler = get_committed_service_for_instance(reserve_instance)
        creator_email = committed_instance.created_by.email
        primary_user = committed_instance.project.team.owner.get_primary_contact()
        primary_email = primary_user.email
        contact_email_list = [creator_email, primary_email] if creator_email != primary_email else [creator_email]

        template_variables = {"customer_name": committed_instance.created_by.full_name,
                              "service_name": service_name,
                              "is_prepaid": committed_instance.is_prepaid if hasattr(committed_instance, "is_prepaid") else "",
                              "committed_instance_name": committed_instance.name,
                              "committed_upto": reserve_instance.reserveinstancetransaction_set.filter(status=constants.ACTIVE).last().end_date,
                              "committed_sku_day": committed_sku_day,
                              "upcoming_sku_pricing": upcoming_pricing,
                              "currency": primary_user.currency.display_text}
        template_subject_variables = {
            "committed_instance_name":  committed_instance.name, "service_name": service_name
        }
        send_mail_for_template(
            contact_email_list, template_name, template_variables, **template_subject_variables)


class ReserveInstanceMails:

    @classmethod
    def send_task_completion_mail(cls, template_name, committed_service_name,  committed_instance, msg):
        creator_email = committed_instance.created_by.email
        primary_user = committed_instance.project.team.owner.get_primary_contact()
        primary_email = primary_user.email
        contact_email_list = [creator_email, primary_email] if creator_email != primary_email else [creator_email]

        template_variables = {"customer_name": committed_instance.created_by.full_name,
                              "service_name": committed_service_name,
                              "current_date": datetime.now(),
                              "committed_sku_day": committed_instance.sku_item_price.committed_days if not hasattr(committed_instance, "scheduled_sku_pricing") else committed_instance.scheduled_sku_pricing.committed_days,
                              "sku_pricing": committed_instance.sku_item_price.unit_price,
                              "committed_instance_name": committed_instance.name,
                              "committed_sku_pricing": committed_instance.scheduled_sku_pricing.unit_price if hasattr(committed_instance, "scheduled_sku_pricing") else "",
                              "is_prepaid": committed_instance.is_billable_customer_prepaid if hasattr(committed_instance, "is_billable_customer_prepaid") else "",
                              "currency": primary_user.currency.display_text,
                              "msg": msg}
        template_subject_variables = {
            "committed_instance_name":  committed_instance.name, "service_name": committed_service_name
        }
        send_mail_for_template(
            contact_email_list, template_name, template_variables, **template_subject_variables)

    @classmethod
    def send_auto_renewal_mail(cls, committed_service_name, committed_instance_object, is_renewed_to_committed):
        is_prepaid, available_customer_credits = get_prepaid_credit_balance_via_user_email(committed_instance_object.project.team.owner.get_primary_contact().email)
        committed_instance_object.is_prepaid = is_prepaid
        template_name = constants.COMMITTED_INSTANCE_AUTO_RENEWED_MAIL if is_renewed_to_committed else constants.COMMITTED_INSTANCE_AUTO_RENEWED_FAILED_MAIL
        cls.send_task_completion_mail(template_name, committed_service_name.lower(), committed_instance_object, is_renewed_to_committed)

    @classmethod
    def send_termination_mail(cls, committed_service_name, committed_instance_object, msg):
        cls.send_task_completion_mail(constants.COMMITTED_INSTANCE_TERMINATED_MAIL, committed_service_name.lower(), committed_instance_object, msg)

    @classmethod
    def send_hourly_billing_mode_convert_mail(cls, committed_service_name, committed_instance_object, msg):
        cls.send_task_completion_mail(constants.COMMITTED_INSTANCE_HOURLY_BILLING_CONVERSION_MAIL, committed_service_name.lower(), committed_instance_object, msg)
