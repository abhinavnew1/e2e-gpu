import logging
from datetime import datetime, timedelta

from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.db import models
from simple_history.models import HistoricalRecords

from e2e_core.mixins import BaseMixin, SafeDeleteMixinExtended
from gpu_service.constants import COMMITTED
from gpu_service.models import SkuItemPrice
from reserve_instance import constants

logger = logging.getLogger(__name__)


class ReserveInstance(SafeDeleteMixinExtended, BaseMixin):
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    resource_id = models.PositiveIntegerField()
    resource = GenericForeignKey('content_type', 'resource_id')
    resource_state = models.CharField(choices=constants.RESOURCE_STATE_CHOICES, default=constants.STATE_RUNNING,
                                      max_length=50)
    updation_policy = models.CharField(choices=constants.INSTANCE_UPDATION_POLICY, default=constants.CONVERT_TO_HOURLY_BILLING,
                                       max_length=50)
    sku_item_price = models.ForeignKey(SkuItemPrice, related_name="sku_item_price", on_delete=models.CASCADE)
    next_sku_item_price = models.ForeignKey(SkuItemPrice, related_name="next_sku_item_price", default=None, on_delete=models.CASCADE, null=True)
    history = HistoricalRecords()

    def mark_last_transaction_as_done(self):
        reserve_instance_last_transaction = self.reserveinstancetransaction_set.filter(status=constants.ACTIVE).last()
        if reserve_instance_last_transaction:
            reserve_instance_last_transaction.status = constants.DONE
            reserve_instance_last_transaction.save(update_fields=["status", "updated_at"])

    def terminate(self):
        if self.resource_state != constants.STATE_TERMINATED:
            self.resource_state = constants.STATE_TERMINATED
            self.save(update_fields=["resource_state", "updated_at"])
            self.mark_last_transaction_as_done()

    def create_new_transaction(self, start_date=None):
        self.mark_last_transaction_as_done()
        transaction_start_date = start_date if start_date else datetime.now()
        ReserveInstanceTransaction.objects.create(reserve_instance=self, current_sku_item_price=self.sku_item_price,
                                                  start_date=transaction_start_date, end_date=(transaction_start_date+timedelta(days=self.sku_item_price.committed_days)), status=constants.ACTIVE)

    @classmethod
    def get_committed_instance_for_auto_renewal(cls):
        committed_instances = ReserveInstance.objects.filter(resource_state=constants.STATE_RUNNING, sku_item_price__sku_type=COMMITTED,
                                                             updation_policy=constants.AUTO_RENEW_STATUS)
        return committed_instances

    @classmethod
    def get_committed_instance_for_termination(cls):
        committed_instances = ReserveInstance.objects.filter(resource_state=constants.STATE_RUNNING, sku_item_price__sku_type=COMMITTED,
                                                             updation_policy=constants.AUTO_TERMINATE_STATUS)
        return committed_instances

    @classmethod
    def get_committed_instance_for_hourly_billing(cls):
        committed_instances = ReserveInstance.objects.filter(resource_state=constants.STATE_RUNNING, sku_item_price__sku_type=COMMITTED,
                                                             updation_policy=constants.CONVERT_TO_HOURLY_BILLING)
        return committed_instances


class ReserveInstanceTransaction(SafeDeleteMixinExtended, BaseMixin):
    reserve_instance = models.ForeignKey(ReserveInstance, on_delete=models.CASCADE)
    current_sku_item_price = models.ForeignKey(SkuItemPrice, related_name="current_sku_item_price", on_delete=models.DO_NOTHING)
    start_date = models.DateTimeField()
    end_date = models.DateTimeField()
    status = models.CharField(max_length=20, choices=constants.TRANSCATION_STATUS_CHOICES)
