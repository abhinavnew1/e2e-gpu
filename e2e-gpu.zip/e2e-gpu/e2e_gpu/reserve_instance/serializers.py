from rest_framework import serializers

from gpu_service.api.v1.serializers import SkuItemDetailsSerializer
from reserve_instance.models import ReserveInstance, constants


class ReserveInstanceSerializer(serializers.ModelSerializer):
    next_sku_item_price = SkuItemDetailsSerializer(read_only=True)
    end_date = serializers.SerializerMethodField()

    class Meta:
        model = ReserveInstance
        fields = ('resource_state', 'updation_policy', 'next_sku_item_price', 'end_date')
        read_only_fields = fields

    def get_end_date(self, reserve_instance):
        recent_transaction = reserve_instance.reserveinstancetransaction_set.filter(status=constants.ACTIVE).last()
        if recent_transaction:
            return recent_transaction.end_date
        return None
