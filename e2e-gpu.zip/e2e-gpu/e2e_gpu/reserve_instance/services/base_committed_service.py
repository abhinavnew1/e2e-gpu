import logging
from abc import ABC, abstractmethod

from e2e_core.api.v1.services.base import BaseService

logger = logging.getLogger(__name__)


class CommittedBaseService(ABC, BaseService):

    @abstractmethod
    def auto_renew(self,):
        """
        :return: Return list of host in list format
        """
        raise NotImplementedError()

    @abstractmethod
    def get_hourly_sku(self):
        """
        :return:Return awx template_id for running playbook
        """
        raise NotImplementedError()

    @abstractmethod
    def convert_to_hourly(self):
        """
        :return:Return dict of variable which required  to run playbook
        """
        raise NotImplementedError()

    @abstractmethod
    def auto_terminate_now(self):
        """
        :return:Return awx template_id for running playbook
        """
        raise NotImplementedError()
