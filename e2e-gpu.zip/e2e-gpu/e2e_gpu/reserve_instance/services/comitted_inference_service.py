import logging

from gpu_service.helpers import is_credit_sufficient_for_inventory_launch
from gpu_service.models import HOURLY, SkuItemPrice
from inferenceservice.api.v1.services.inference_service import InferenceService
from reserve_instance.constants import (INFERENCE_SERVICE,
                                        STATE_UPDATION_FAILURE,
                                        SUCCESSFULLY_CONVERTED,
                                        SUCCESSFULLY_RENEWED,
                                        SUFFICIENT_CREDIT, TERMINATE_DONE)
from reserve_instance.services.base_committed_service import \
    CommittedBaseService
from rest_framework import exceptions, status

logger = logging.getLogger(__name__)


class CommittedInferenceService(CommittedBaseService):
    def __init__(self, instance, upcoming_transaction):
        self.instance = instance
        self.upcoming_transaction = upcoming_transaction
        self.inference = instance.resource

    def minimum_balance_check_for_committed_inference(self):
        is_credit_sufficient, err_msg = is_credit_sufficient_for_inventory_launch(
                                            billable_customer=self.inference.created_by.get_primary_contact(),
                                            sku_item_price=self.instance.sku_item_price,
                                        )
        if not is_credit_sufficient:
            return self.get_baked_412_response(err_msg)
        else:
            return self.get_200_response(SUFFICIENT_CREDIT)

    def auto_renew(self) -> str:
        credit_check = self.minimum_balance_check_for_committed_inference()
        if credit_check["code"] == status.HTTP_200_OK:
            start_date = self.upcoming_transaction.end_date
            self.instance.sku_item_price = self.instance.next_sku_item_price
            self.instance.save(update_fields=["sku_item_price", "updated_at"])
            self.instance.create_new_transaction(start_date)
            self.inference.sku_item_price = self.instance.sku_item_price
            self.inference.save(update_fields=["sku_item_price", "updated_at"])
            self.inference.create_inference_history(start_date)
            return SUCCESSFULLY_RENEWED.format(service=INFERENCE_SERVICE, name=self.inference.name, id=self.inference.id)
        elif credit_check["code"] == status.HTTP_412_PRECONDITION_FAILED:
            self.convert_to_hourly()
            errors = credit_check["errors"]
            return f"Converted {INFERENCE_SERVICE},  name={self.inference.name} id={self.inference.id} to hourly, reason {errors}"
        else:
            logger.error(f"CREDIT_FETCH_ERROR | info={credit_check} | email={self.inference.created_by.email}")
            raise exceptions.ValidationError()

    def get_hourly_sku(self, sku_item_price) -> SkuItemPrice:
        return SkuItemPrice.objects.filter(sku=sku_item_price.sku, currency=sku_item_price.currency,
                                           location=sku_item_price.location, is_active=True, sku_type=HOURLY).last()

    def convert_to_hourly(self) -> str:
        hourly_sku_item_price = self.get_hourly_sku(
            self.instance.sku_item_price)
        self.inference.sku_item_price = hourly_sku_item_price
        self.inference.committed_replicas = 0
        self.inference.save(update_fields=['sku_item_price', 'committed_replicas', 'updated_at',])
        self.inference.update_end_date_in_inference_history(end_date=self.upcoming_transaction.end_date)
        self.inference.create_inference_history(start_date=self.upcoming_transaction.end_date)
        self.instance.sku_item_price = hourly_sku_item_price
        self.instance.mark_last_transaction_as_done()
        self.instance.save(update_fields=['sku_item_price', 'updated_at',])
        return SUCCESSFULLY_CONVERTED.format(service=INFERENCE_SERVICE, name=self.inference.name, id=self.inference.id)

    def auto_terminate_now(self) -> str:
        termination_response = InferenceService(self.inference.created_by, None, self.inference.project).delete_inference(self.inference)
        if termination_response["code"] == status.HTTP_200_OK:
            return TERMINATE_DONE.format(service=INFERENCE_SERVICE, name=self.inference.name, id=self.inference.id)
        else:
            logger.error(f"COMMITTED_INFERENCE_TERMINATION_FAILED | ID={self.inference.id} | email={self.inference.created_by.email} | {termination_response}")
            raise STATE_UPDATION_FAILURE.format(service=INFERENCE_SERVICE, name=self.inference.name, id=self.inference.id)
