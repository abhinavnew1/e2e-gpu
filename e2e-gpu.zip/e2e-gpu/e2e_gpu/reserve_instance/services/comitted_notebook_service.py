import logging

from rest_framework import status

from customer.helpers import get_prepaid_credit_balance_via_user_email
from gpu_service.models import HOURLY, SkuItemPrice
from notebook.api.v1.services.notebook_service import NotebookService
from notebook.constants import CREDIT_FETCH_ERROR, INSUFFICIENT_CREDIT_BALANCE, SUFFICIENT_CREDIT
from notebook.helpers import is_credit_sufficient_to_launch_notebook
from reserve_instance.constants import (NOTEBOOK,
                                        STATE_UPDATION_FAILURE,
                                        SUCCESSFULLY_CONVERTED,
                                        SUCCESSFULLY_RENEWED, TERMINATE_DONE)
from reserve_instance.services.base_committed_service import CommittedBaseService

logger = logging.getLogger(__name__)


class CommittedNotebooksService(CommittedBaseService):
    def __init__(self, instance, active_transaction):
        self.instance = instance
        self.active_transaction = active_transaction
        self.notebook = instance.resource
        self.credit_check = self.minimum_balance_check_for_committed_notebook()

    def minimum_balance_check_for_committed_notebook(self):
        is_prepaid, available_customer_credits = get_prepaid_credit_balance_via_user_email(
            self.notebook.project.team.owner.get_primary_contact().email)
        if is_prepaid is None:
            return self.get_400_response(CREDIT_FETCH_ERROR)
        else:
            is_credit_sufficient, additional_required_credits = is_credit_sufficient_to_launch_notebook(self.notebook.created_by,
                                                                                                        self.instance.sku_item_price,
                                                                                                        is_prepaid,
                                                                                                        available_customer_credits)
            self.notebook.is_billable_customer_prepaid = is_prepaid
            if not is_credit_sufficient:
                return self.get_412_response(INSUFFICIENT_CREDIT_BALANCE.format(credits=additional_required_credits))
            else:
                return self.get_200_response(SUFFICIENT_CREDIT)

    def auto_renew(self):
        if self.credit_check["code"] == status.HTTP_200_OK:
            start_date = self.active_transaction.end_date
            self.instance.sku_item_price = self.instance.next_sku_item_price
            self.instance.save(update_fields=["sku_item_price", "updated_at"])
            self.instance.create_new_transaction(start_date)
            self.notebook.sku_item_price = self.instance.sku_item_price
            self.notebook.save(update_fields=["sku_item_price", "updated_at"])
            self.notebook.create_notebook_history(start_date)
            return True, self.notebook, SUCCESSFULLY_RENEWED.format(service=NOTEBOOK, name=self.notebook.name, id=self.notebook.id)
        elif self.credit_check["code"] == status.HTTP_412_PRECONDITION_FAILED:
            self.convert_to_hourly()
            errors = self.credit_check["errors"]
            return False, self.notebook, f"Converted {NOTEBOOK} to hourly, name={self.notebook.name} id={self.notebook.id}, reason {errors}"
        else:
            logger.error(f"CREDIT_FETCH_ERROR | info={self.credit_check} | email={self.notebook.created_by.email}")
            raise Exception(CREDIT_FETCH_ERROR)

    def get_hourly_sku(self, sku_item_price) -> SkuItemPrice:
        return SkuItemPrice.objects.filter(sku=sku_item_price.sku, currency=sku_item_price.currency,
                                           location=sku_item_price.location, is_active=True, sku_type=HOURLY).last()

    def convert_to_hourly(self):
        scheduled_sku_pricing = self.instance.next_sku_item_price if hasattr(self.instance, "next_sku_item_price") else ""
        hourly_sku_item_price = self.get_hourly_sku(
            self.instance.sku_item_price)
        self.notebook.sku_item_price = hourly_sku_item_price
        self.notebook.save(update_fields=['sku_item_price', 'updated_at',])
        self.notebook.create_notebook_history(start_date=self.active_transaction.end_date)
        self.instance.sku_item_price = hourly_sku_item_price
        self.instance.mark_last_transaction_as_done()
        self.instance.save(update_fields=['sku_item_price', 'updated_at',])
        self.notebook.scheduled_sku_pricing = scheduled_sku_pricing
        return self.notebook, SUCCESSFULLY_CONVERTED.format(service=NOTEBOOK, name=self.notebook.name, id=self.notebook.id)

    def auto_terminate_now(self) -> str:
        termination_response = NotebookService(self.notebook.created_by,
                                               self.notebook.project.id).delete_notebook(self.notebook.id, notebook=self.notebook)
        if termination_response["code"] == status.HTTP_200_OK:
            return TERMINATE_DONE.format(service=NOTEBOOK, name=self.notebook.name, id=self.notebook.id)
        else:
            logger.error(f"COMMITTED_NOTEBOOK_TERMINATION_FAILED | ID={self.notebook.id} | email={self.notebook.created_by.email} | {termination_response}")
            raise STATE_UPDATION_FAILURE.format(service=NOTEBOOK, name=self.notebook.name, id=self.notebook.id)
