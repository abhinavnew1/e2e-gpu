from django.db.models import Prefetch

from dataset.models import Dataset
from projects.models import Projects
from eos.models import Bucket
from inferenceservice.models import Model
from pipelines.models import Pipelines

# Fetch all Bucket objects
buckets = Bucket.objects.filter(deleted_at__isnull=True)

# Prefetch related objects for Dataset, Model, Pipelines
buckets = buckets.prefetch_related(
    Prefetch("dataset_set", queryset=Dataset.objects.all()),
    Prefetch("model_set", queryset=Model.objects.all()),
    Prefetch("pipelines_set", queryset=Pipelines.objects.all()),
)


def list_project_id():
    bucket_name_prj_id_map = {}
    for bucket in buckets:
        project_id_set = set()
        project_id_set.update(bucket.dataset_set.all().values_list("project_id", flat=True).distinct())
        project_id_set.update(bucket.model_set.all().values_list("project_id", flat=True).distinct())
        project_id_set.update(bucket.pipelines_set.all().values_list("project_id", flat=True).distinct())
        if bucket.bucket_name in bucket_name_prj_id_map:
            bucket_name_prj_id_map[bucket.bucket_name].update(project_id_set)
        else:
            bucket_name_prj_id_map[bucket.bucket_name] = project_id_set

    for name, project_id_set in bucket_name_prj_id_map.items():
        prj_id_len = len(project_id_set)
        if prj_id_len > 1:
            projects = Projects.objects.filter(id__in=list(project_id_set)).select_related("team__owner")
            print(f"project_id:{project_id_set} bucket:{name}")
            for prj in projects:
                owner_email = prj.team.owner.email
                e2e_user = "e2enetworks.com"
                if e2e_user not in owner_email:
                    print(prj.team.owner.email)
