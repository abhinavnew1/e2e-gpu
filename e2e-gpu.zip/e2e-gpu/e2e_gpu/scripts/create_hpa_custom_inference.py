from inferenceservice.models import Inference
from inferenceservice.constants import STOPPED
from inferenceservice.api.v1.services.inference_groot_service import InferenceGrootService

ALL_CUSTOM_FRAMEWORKS = ['llma', 'stable_diffusion', 'mpt', 'codellama', 'custom']

def run():
    inferences = Inference.objects.filter(deleted_at__isnull=True, framework__in=ALL_CUSTOM_FRAMEWORKS).exclude(status=STOPPED)
    for inf in inferences:
        groot_service = InferenceGrootService(inf.project.namespace, inf.created_by)
        _, flag = groot_service.get_hpa_details(inf.id)
        if flag:
            continue
        data = {
            "min_replicas": inf.replica,
            "max_replicas": inf.replica,
            "cpu_utilization": 80
        }
        flag, response = groot_service.create_custom_hpa(inf.id, data)


run()
