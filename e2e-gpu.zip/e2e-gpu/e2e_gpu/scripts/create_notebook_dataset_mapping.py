"""Script to create a mapping of datasets that are mounted to notebooks"""

from datetime import datetime
from pprint import pprint

from django.db.models import Prefetch

from dataset.constants import DONE as DATASET_DONE
from dataset.models import Dataset
from notebook.api.v1.services.notebook_groot_service import NotebookGrootService
from notebook.constants import DONE as NOTEBOOK_DONE
from notebook.models import Notebook
from projects.models import Projects


def run():
    failed_updates = {}
    projects_with_datasets = get_projects_having_datasets()

    for project in projects_with_datasets:
        try:
            notebook_volumes = get_notebook_volumes(project)
        except Exception as e:
            failed_updates[project.id] = e
            continue

        for notebook in project.notebooks:
            dataset_ids_to_mount = []
            nb_mounted_dataset_ids = list(notebook.get_mounted_datasets().values_list("id", flat=True))
            nb_volumes = notebook_volumes.get(notebook.slug_name, [])
            for dataset in project.datasets:
                if dataset.name in nb_volumes and dataset.id not in nb_mounted_dataset_ids:
                    dataset_ids_to_mount.append(dataset.id)
            notebook.mounted_datasets.add(*dataset_ids_to_mount, through_defaults={"mount_start_date": datetime.now()})

    print("\n\n================== FAILED_UPDATES ====================\n\n")
    pprint(failed_updates)


def get_projects_having_datasets():
    project_ids = Dataset.objects.filter(deleted_at__isnull=True).exclude(status=DATASET_DONE).values_list("project_id", flat=True)

    notebook_qs = Notebook.objects.filter(deleted_at__isnull=True).exclude(status=NOTEBOOK_DONE)
    dataset_qs = Dataset.objects.filter(deleted_at__isnull=True).exclude(status=DATASET_DONE)
    return Projects.objects.filter(
        deleted_at__isnull=True, id__in=project_ids
    ).prefetch_related(
        Prefetch("notebook_set", notebook_qs, to_attr="notebooks"),
        Prefetch("dataset_set", dataset_qs, to_attr="datasets"),
    )


def get_notebook_volumes(project):
    nb_volumes = {}
    nb_list = NotebookGrootService(project.namespace, project.created_by).list_notebooks_from_groot()[1]["notebooks"]
    for nb_data in nb_list:
        nb_volumes[nb_data["name"]] = nb_data.get("volumes", [])
    return nb_volumes


run()
