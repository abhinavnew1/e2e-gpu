from inferenceservice.models import AutoScalePolicy, Inference


def run():
    inferences = Inference.objects.filter()
    for inference in inferences:
        if not inference.auto_scale_policy:
            ap = AutoScalePolicy()
            ap.max_replicas = inference.replica
            ap.min_replicas = inference.replica
            ap.stability_period = "60"
            ap.rules = {
                "metric": "cpu",
                "condition_type": "limit",
                "value": "80",
                "watch_period": "15"
            }
            ap.save()
            inference.auto_scale_policy = ap

        inference.desired_replica = inference.replica
        inference.save() 


run()
