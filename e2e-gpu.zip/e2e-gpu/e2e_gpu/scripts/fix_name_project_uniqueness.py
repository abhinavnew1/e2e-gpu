from django.db import transaction

from dataset.models import Dataset
from finetuning.models import FineTuning
from inferenceservice.models import Model
from integration.models import Integration

model_repo_with_repeat_names = Model.objects.raw('SELECT MIN(id) as id, name, project_id, count(*) AS occurance FROM inferenceservice_model GROUP BY name, project_id having occurance >1 ORDER BY occurance DESC')
dataset_with_repeat_names = Dataset.objects.raw('SELECT *, count(*) AS occurance FROM dataset_dataset GROUP BY name, project_id having occurance >1 ORDER BY occurance DESC')
finetuning_with_repeat_names = FineTuning.objects.raw('SELECT *, count(*) AS occurance FROM finetuning_finetuning GROUP BY name, project_id having occurance >1 ORDER BY occurance DESC')
integration_with_repeat_names = Integration.objects.raw('SELECT *, count(*) AS occurance FROM integration_integration GROUP BY name, project_id having occurance >1 ORDER BY occurance DESC')


def fix_for_uniqueness(model_objects):
    for model_object in model_objects:
        if model_object == model_objects[0]:
            continue
        model_object.name = f"{model_object.name}_{model_object.id}"


def run():

    print("model_repo_with_repeat_names", len(model_repo_with_repeat_names), model_repo_with_repeat_names)
    for model_repo in model_repo_with_repeat_names:
        model_list = Model.objects.all_with_deleted().filter(name=model_repo.name, project=model_repo.project).order_by('-id')
        fix_for_uniqueness(model_list)
        with transaction.atomic():
            Model.objects.all_with_deleted().bulk_update(model_list, ["name"], batch_size=1000)
            print(f"fixed model_repos -> {model_list}")
    print("fixed model_repos name uniqueness")

    print("dataset_with_repeat_names", len(dataset_with_repeat_names), dataset_with_repeat_names)
    for repeat_dataset in dataset_with_repeat_names:
        datasets_list = Dataset.objects.all_with_deleted().filter(name=repeat_dataset.name,
                                                                  project=repeat_dataset.project).order_by('-id')
        fix_for_uniqueness(datasets_list)
        with transaction.atomic():
            Dataset.objects.all_with_deleted().bulk_update(datasets_list, ["name"], batch_size=1000)
            print(f"fixed datasets -> {datasets_list}")
    print("fixed datasets uniqueness")

    print("finetuning_with_repeat_names", len(finetuning_with_repeat_names), finetuning_with_repeat_names)
    for repeat_finetuning in finetuning_with_repeat_names:
        finetunings_list = FineTuning.objects.all_with_deleted().filter(name=repeat_finetuning.name,
                                                                        project=repeat_finetuning.project).order_by('-id')
        fix_for_uniqueness(finetunings_list)
        with transaction.atomic():
            FineTuning.objects.all_with_deleted().bulk_update(finetunings_list, ["name"], batch_size=1000)
            print(f"fixed finetunings -> {finetunings_list}")
    print("fixed finetunings uniqueness")

    print("integration_with_repeat_names", len(finetuning_with_repeat_names), integration_with_repeat_names)
    for repeat_integration in integration_with_repeat_names:
        integrations_list = Integration.objects.all_with_deleted().filter(name=repeat_integration.name,
                                                                          project=repeat_integration.project).order_by('-id')
        fix_for_uniqueness(integrations_list)
        with transaction.atomic():
            Integration.objects.all_with_deleted().bulk_update(integrations_list, ["name"], batch_size=1000)
            print(f"fixed integrations -> {integrations_list}")
    print("fixed integrations uniqueness")
