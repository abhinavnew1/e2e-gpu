from django.db import transaction
from django.db.models import Prefetch

from customer.models import Customer, CustomerConsent
from eventlogs.constants import INVITES_CODE, TEAM_MEMBERS_CODE, PROJECT_MEMBERS_CODE
from eventlogs.models import InviteEventLog, MemberManagementEventLog, ProjectMemberEventLog, TeamMemberEventLog
from invites.constants import ACCEPTED
from invites.models import Invites
from projects.models import ProjectMembers, Projects
from rbac.constants import (
    ADMIN,
    CONTACT_PERSON_IAM,
    IAM_USER,
    MEMBER,
    OWNER,
    OWNER_IAM,
    PRIMARY_USER_IAM,
    TEAM_LEAD,
    TEAM_MEMBER,
)
from rbac.models import IAM, IAMConsent
from teams.models import TeamMembers, Teams


# RUN: FIRST
def create_iam_using_customer_script():
    customer_list = Customer.objects.all()
    iam_instance = []
    primary_email_not_exist = []
    contact_person_primary_customer_not_exist = []
    for customer in customer_list:
        if customer.is_primary_contact:
            iam_instance.append(IAM(owner=customer, added_user=customer, iam_type=OWNER_IAM, role=OWNER))
        else:
            if customer.primary_email:
                secondary_contact_owner = Customer.objects.filter(
                    email=customer.primary_email, primary_email=customer.primary_email, is_primary_contact=True
                ).first()
                if secondary_contact_owner:
                    iam_instance.append(IAM(owner=secondary_contact_owner, added_user=customer, iam_type=CONTACT_PERSON_IAM, role=IAM_USER))
                else:
                    contact_person_primary_customer_not_exist.append(customer.id)

            else:
                primary_email_not_exist.append(customer.id)

    with transaction.atomic():
        IAM.objects.bulk_create(iam_instance, batch_size=100)
    print(f"PRIMARY_EMAIL_NOT_EXIST- ${primary_email_not_exist}---length:{len(primary_email_not_exist)}")
    print(f"CONTACT_PERSON_PRIMARY_CUSTOMER_NOT_EXIST- ${contact_person_primary_customer_not_exist}")


# RUN: SECOND
def map_team_member_iam_user():
    team_members = TeamMembers.objects.all_with_deleted().select_related("team", "customer")
    iam_not_found_team_members = []
    team_customer_mismatch_members = []
    with transaction.atomic():
        for team_member in team_members:
            owner_id = team_member.team.owner_id
            added_user_id = team_member.customer_id
            iam = IAM.objects.filter(added_user_id=added_user_id, owner_id=owner_id).first()
            if iam:
                if team_member.role == OWNER and owner_id == added_user_id:
                    if team_member.deleted_at:
                        team_member.is_active = False
                    team_member.iam_user = iam
                    team_member.created_by = team_member.team.owner
                    team_member.save()
                elif team_member.role != OWNER and owner_id != added_user_id:
                    if team_member.role == ADMIN:
                        team_member.role = TEAM_LEAD
                    else:
                        team_member.role = TEAM_MEMBER

                    if team_member.deleted_at:
                        team_member.is_active = False
                    iam.role = IAM_USER
                    iam.save()
                    team_member.iam_user = iam
                    team_member.created_by = team_member.team.owner
                    team_member.save()
                else:
                    # print("ERROR_OCCURED: OWNER TEAM-MEMBER HAS WRONG CUSTOMER ENTRY OR EITHER TEAM ENTRY")
                    team_customer_mismatch_members.append(team_member.id)
            else:
                # print("ERROR_OCCURED: unable to find IAM")
                iam_not_found_team_members.append(team_member.id)
        print(f"IAM_NOT_FOUND: {iam_not_found_team_members}---length:{len(iam_not_found_team_members)}")
        print(f"MISMATCH_TEAM_CUSTOMER: {team_customer_mismatch_members}")


# RUN: THIRD
def create_iam_for_not_found_team_member_iam():
    team_members = TeamMembers.objects.all_with_deleted().select_related("team", "customer")
    primary_email_not_found = []
    different_added_user_owner = []
    primary_customer_not_exist = []
    with transaction.atomic():
        for team_member in team_members:
            owner = team_member.team.owner
            added_user_customer = team_member.customer
            iam = IAM.objects.filter(added_user_id=added_user_customer.id, owner_id=owner.id).first()
            if not iam:
                if owner.is_primary_contact:
                    if added_user_customer.is_primary_contact and added_user_customer.id != owner.id:
                        if team_member.role != OWNER:
                            iam, _is_created = IAM.objects.get_or_create(
                                owner=owner, added_user=added_user_customer, role=IAM_USER, iam_type=PRIMARY_USER_IAM
                            )
                            if team_member.role == ADMIN:
                                team_member.role = TEAM_LEAD
                            else:
                                team_member.role = TEAM_MEMBER

                            if team_member.deleted_at:
                                team_member.is_active = False

                            team_member.iam_user = iam
                            team_member.created_by = owner
                            team_member.save()
                        else:
                            different_added_user_owner.append(team_member.id)
                            # print("ERROR_OCCURED: OWNER has different added user and owner")
                elif not owner.is_primary_contact and not added_user_customer.is_primary_contact:
                    if team_member.role == OWNER and owner.id == added_user_customer.id:
                        # below cases are private workspace cases for contact person
                        if added_user_customer.primary_email:
                            primary_customer = Customer.objects.filter(
                                email=added_user_customer.primary_email,
                                primary_email=added_user_customer.primary_email,
                                is_primary_contact=True,
                            ).first()
                            if primary_customer:
                                contact_person_iam, _is_created = IAM.objects.get_or_create(
                                    added_user=added_user_customer, owner=primary_customer, iam_type=CONTACT_PERSON_IAM, role=IAM_USER
                                )
                                # change team-> owner from contact_person to (primary_user of contact person )
                                # create two team_member one is for contact_person and one is for primary_user (owner)
                                # also make team is_private false

                                if team_member.deleted_at:
                                    team_member.is_active = False

                                team_member.iam_user = contact_person_iam
                                team_member.created_by = primary_customer
                                team_member.role = TEAM_LEAD
                                team_member.save()
                            else:
                                primary_customer_not_exist.append(team_member.id)
                        else:
                            # print("ERROR_OCCURED: added user primary-email not exist")
                            primary_email_not_found.append(team_member.id)
    print(f"PRIMARY_EMAIL_NOT_FOUND:{primary_email_not_found}")
    print(f"DIFFERENT_ADDED_USER_OWNER:{different_added_user_owner}")
    print(f"PRIMARY_CUSTOMER_NOT_EXIST:{primary_customer_not_exist}")


# RUN: FOURTH
def map_team_member_project_members():
    projects = Projects.objects.all_with_deleted().prefetch_related("project_members")
    project_member_instance = []
    no_iam_for_team_member = []
    no_iam_for_team_member_id = []
    for project in projects:
        for member in project.project_members.all():
            if member.iam_user:
                role = MEMBER
                created_by = member.iam_user.owner
                if member.role == OWNER:
                    role = OWNER
                elif member.role == ADMIN:
                    role = ADMIN
                elif member.role == TEAM_LEAD:
                    role = TEAM_LEAD
                project_member_instance.append(ProjectMembers(project=project, team_member=member, role=role, created_by=created_by))
            else:
                no_iam_for_team_member.append({"team_member_id": member.id, "project_id": project.id})
                no_iam_for_team_member_id.append(member.id)
    with transaction.atomic():
        ProjectMembers.objects.bulk_create(project_member_instance, batch_size=100)
    print(f"No_IAM_USER_FOR_TEAM_MEMBER: {no_iam_for_team_member}")
    print(f"No_IAM_USER_FOR_TEAM_MEMBER_IDS: {no_iam_for_team_member_id}")


# RUN: FIFTH
def map_team_owner_to_created_by():
    teams = Teams.objects.all_with_deleted()
    customer_not_exist = []
    contact_person_team = []
    with transaction.atomic():
        for team in teams:
            customer = Customer.objects.filter(id=team.owner.id).first()
            if customer:
                if customer.is_primary_contact:
                    team.created_by = customer
                    team.save()
                else:
                    contact_person_team.append(team.id)
            else:
                customer_not_exist.append(team.id)

    print(f"customer_not_exist: {customer_not_exist}\n")
    print(f"CONTACT_PERSON_TEAM: {contact_person_team}\n")


# RUN: SIXTH
def contact_person_private_workspace_remove():
    teams = (
        Teams.objects.all_with_deleted()
        .filter(owner__is_primary_contact=False)
        .prefetch_related(Prefetch("projects", queryset=Projects.objects.all_with_deleted()))
    )
    primary_contact_not_exist = []
    with transaction.atomic():
        for team in teams:
            contact_person_owner = team.owner
            if contact_person_owner.primary_email:
                primary_customer = Customer.objects.filter(
                    email=contact_person_owner.primary_email, primary_email=contact_person_owner.primary_email, is_primary_contact=True
                ).first()
                if primary_customer:
                    primary_customer_iam, _is_created = IAM.objects.get_or_create(
                        added_user=primary_customer, owner=primary_customer, role=OWNER, iam_type=OWNER_IAM
                    )
                    owner_team_member = TeamMembers.objects.create(
                        team=team, role=OWNER, iam_user=primary_customer_iam, created_by=primary_customer
                    )
                    for project in team.projects.all_with_deleted():
                        ProjectMembers.objects.create(
                            project=project, role=OWNER, team_member=owner_team_member, created_by=primary_customer
                        )
                        project.created_by = primary_customer
                        project.save()
                    team.name = f"{contact_person_owner.first_name}-team"
                    team.owner = primary_customer
                    team.created_by = primary_customer
                    team.is_private = False
                    team.save()
                else:
                    primary_contact_not_exist.append(team.id)
    print(f"PRIMARY_CONTACT_NOT_EXIST: {primary_contact_not_exist}")


# RUN: SEVENTH
def team_member_email_map_with_invite():
    team_members = TeamMembers.objects.all_with_deleted().select_related("invite")
    iam_user_not_found_team_member = []
    iam_user_not_found_invite_id = []
    with transaction.atomic():
        for team_member in team_members:
            invite = team_member.invite
            if invite:
                if team_member.iam_user:
                    invite.email = team_member.iam_user.added_user.email
                    invite.save()
                else:
                    iam_user_not_found_team_member.append(team_member.id)
                    iam_user_not_found_invite_id.append(invite.id)
    print(f"IAM_NOT_FOUND_MEMBER_ID: {iam_user_not_found_team_member}")
    print(f"EMAIL_MAP_IAM_NOT_FOUND_INVITE_ID: {iam_user_not_found_invite_id}")


# RUN: EIGTH
def map_invited_by_id_from_deprecated_invited_by():
    invites = Invites.objects.all_with_deleted().select_related("invited_by_deprecated")
    iam_not_found_for_customer = []
    with transaction.atomic():
        for invite in invites:
            customer = invite.invited_by_deprecated
            primary_contact = invite.invited_by_deprecated
            if customer and (not customer.is_primary_contact) and customer.primary_email:
                owner = Customer.objects.filter(email=customer.primary_email).first()
                if owner:
                    primary_contact = owner
            invited_by_iam = IAM.objects.filter(added_user=customer, owner=primary_contact).first()
            if invited_by_iam:
                invite.invited_by = invited_by_iam
                invite.save()
            else:
                iam_not_found_for_customer.append(invite.id)
    print(f"IAM_NOT_FOUND_INVITE: {iam_not_found_for_customer}")


# RUN: NINTH
def map_customer_consent_to_iam_consent():
    customer_consents = CustomerConsent.objects.all().select_related("customer")
    iam_consent_objects = []
    iam_user_not_found = []
    for consent in customer_consents:
        customer = consent.customer
        owner = customer
        if (not owner.is_primary_contact) and owner.primary_email:
            primary_customer = Customer.objects.filter(email=owner.primary_email, is_primary_contact=True).first()
            if primary_customer:
                owner = primary_customer
        iam_user = IAM.objects.filter(owner=owner, added_user=customer).first()
        if iam_user:
            iam_consent_objects.append(IAMConsent(iam_user=iam_user, model_playground=consent.model_playground))
        else:
            iam_user_not_found.append(consent.id)
    with transaction.atomic():
        IAMConsent.objects.bulk_create(iam_consent_objects, batch_size=100)
    print(f"IAM_USER_NOT_FOUND_FOR_CONSENT: {iam_user_not_found}")


invite_event_mapping = {
    "INVITE_TEAM_MEMBER": "INVITE_USER",
    "ACCEPT_INVITE": "ACCEPT_INVITE",
    "REJECT_INVITE": "REJECT_INVITE",
}

team_member_event_mapping = {
    "TEAM_MEMBER_UPDATE": "TEAM_MEMBER_ACCESS_UPDATE",
    "TEAM_MEMBER_DELETE": "REMOVE_TEAM_MEMBER",
}

prj_member_event_mapping = {
    "ADD_PROJECT_MEMBER": "ADD_PROJECT_MEMBER",
    "PROJECT_MEMBER_DELETE": "REMOVE_PROJECT_MEMBER",
}

self_delete_event_mapping = {
    "TEAM_MEMBER_SELF_DELETE": "REMOVE_TEAM_MEMBER",
    "PROJECT_MEMBER_SELF_DELETE": "REMOVE_PROJECT_MEMBER",
}


# RUN: TENTH
def map_users_eventlog():
    old_member_logs = MemberManagementEventLog.objects.all().select_related("resource_obj")
    invite_event_objs = []
    team_member_event_objs = []
    prj_member_event_objs = []
    other_event_logs = []
    project_id_not_found_log = []
    for member_log in old_member_logs:
        invite_event = invite_event_mapping.get(member_log.event, None)
        team_member_event = team_member_event_mapping.get(member_log.event, None)
        prj_member_event = prj_member_event_mapping.get(member_log.event, None)

        if invite_event and member_log.resource_obj:
            invite_event_objs.append(
                InviteEventLog(
                    created_at=member_log.created_at,
                    updated_at=member_log.updated_at,
                    service=INVITES_CODE,
                    resource_name=member_log.resource_name,
                    resource_id=member_log.resource_obj.invite_id,
                    customer_id=member_log.customer_id,
                    event=invite_event,
                    client_ip=member_log.client_ip,
                    detailed_info=member_log.detailed_info,
                    status=member_log.status,
                    event_type=member_log.event_type,
                    resource_obj_id=member_log.resource_obj.invite_id,
                )
            )
        elif team_member_event:
            team_member_event_objs.append(
                TeamMemberEventLog(
                    created_at=member_log.created_at,
                    updated_at=member_log.updated_at,
                    service=TEAM_MEMBERS_CODE,
                    resource_name=member_log.resource_name,
                    resource_id=member_log.resource_id,
                    customer_id=member_log.customer_id,
                    event=team_member_event,
                    client_ip=member_log.client_ip,
                    detailed_info=member_log.detailed_info,
                    status=member_log.status,
                    event_type=member_log.event_type,
                    resource_obj_id=member_log.resource_obj_id,
                )
            )
        elif prj_member_event:
            detailed_info = member_log.detailed_info
            is_object = isinstance(detailed_info, dict)
            project_id = detailed_info.get("project_id", None) if is_object else project_id_not_found_log.append(member_log.id)
            project_member = None
            if project_id:
                project_member = ProjectMembers.objects.filter(project_id=project_id, team_member_id=member_log.resource_id).first()
            if project_member:
                prj_member_event_objs.append(
                    ProjectMemberEventLog(
                        created_at=member_log.created_at,
                        updated_at=member_log.updated_at,
                        service=PROJECT_MEMBERS_CODE,
                        resource_name=member_log.resource_name,
                        resource_id=project_member.id,
                        customer_id=member_log.customer_id,
                        event=prj_member_event,
                        client_ip=member_log.client_ip,
                        detailed_info=member_log.detailed_info,
                        status=member_log.status,
                        event_type=member_log.event_type,
                        resource_obj_id=project_member.id,
                    )
                )
            else:
                project_id_not_found_log.append(member_log.id)
        else:
            other_event_logs.append(member_log.id)
    with transaction.atomic():
        InviteEventLog.objects.bulk_create(invite_event_objs, batch_size=100)
        TeamMemberEventLog.objects.bulk_create(team_member_event_objs, batch_size=100)
        ProjectMemberEventLog.objects.bulk_create(prj_member_event_objs, batch_size=100)
    print(f"OTHER_EVENT_LOG: {other_event_logs}--length:{len(other_event_logs)}")
    print(f"PROJECT_MEMBER_NOT_FOUND_EVENT_LOG: {project_id_not_found_log}--length:{len(project_id_not_found_log)}")


def mark_deleted_project_member():
    project_members = ProjectMembers.objects.all().select_related("project")
    for prj_member in project_members:
        if prj_member.project.deleted_at:
            prj_member.delete()


def delete_invite():
    not_found_email = []
    invites = Invites.objects.all()
    for invite in invites:
        if not invite.email:
            not_found_email.append(invite.id)
            invite.delete()
    print(f"NOT_FOUND_EMAIL_INVITE-{not_found_email}")


def sync_invite():
    deleted_invite = []
    with transaction.atomic():
        delete_invite()
        invite_objs = Invites.objects.all().select_related("invited_by__owner", "invited_by__added_user")
        invite_map = {}
        for invite in invite_objs:
            owner = invite.invited_by.owner
            map_key = f"{invite.email}-{owner.id}"
            if map_key in invite_map:
                invite_map[map_key].append(invite)
            else:
                invite_map[map_key] = [invite]

        for _email, invites in invite_map.items():
            user_invite = invites[0]
            iam = IAM.objects.filter(added_user__email=user_invite.email, owner=user_invite.invited_by.owner).first()
            if len(invites) == 1:
                if user_invite.status == ACCEPTED and iam:
                    user_invite.iam_user = iam
                    user_invite.save(update_fields=['iam_user'])
            elif len(invites) > 1:
                for invite in invites:
                    if invite.status == ACCEPTED and iam:
                        user_invite = invite
                for invite in invites:
                    if invite.id != user_invite.id:
                        deleted_invite.append(invite.id)
                        invite.delete()
                    else:
                        user_invite.iam_user = iam
                        user_invite.save(update_fields=['iam_user'])
    print(f'DELETED_INVITE-{deleted_invite}')


def change_invite_status():
    invite_ids = []
    invite_objs = Invites.objects.all()
    with transaction.atomic():
        for invite in invite_objs:
            iam = IAM.objects.filter(added_user__email=invite.email, owner=invite.invited_by.owner).first()
            if iam and invite.status != ACCEPTED:
                invite.status = ACCEPTED
                invite.iam_user = iam
                invite.save(update_fields=['status', 'iam_user'])
                invite_ids.append(invite.id)
    print(f'INVITE_ID-{invite_ids}')


def run():
    create_iam_using_customer_script()
    map_team_member_iam_user()
    create_iam_for_not_found_team_member_iam()
    map_team_member_project_members()
    map_team_owner_to_created_by()
    contact_person_private_workspace_remove()
    team_member_email_map_with_invite()
    map_invited_by_id_from_deprecated_invited_by()
    map_customer_consent_to_iam_consent()
    map_users_eventlog()
    mark_deleted_project_member()
    sync_invite()
