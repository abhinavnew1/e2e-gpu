""" Concept of teams introduced. This script does the following:
1. Creates a private workspace for customers, if not already created & migrates all the current customer projects to the private workspace of customer.
2. Project Members now stored in a many-to-many field in Projects model instead of a ProjectMembers model. Therefore, adds the project creator to the project member field
3. A new field 'created_by' to be used instead of 'owner' in Projects model. Changes done for migrating data
"""

from rbac.constants import OWNER
from rest_framework import status

from customer.models import Customer
from projects.models import Projects
from teams.api.v1.services.teams_service import TeamService
from teams.models import TeamMembers, Teams


def run():
    all_customers = Customer.objects.filter(is_active=True, is_superuser=False)

    customer_ids_with_private_workspace = TeamMembers.objects.filter(
        deleted_at__isnull=True, is_active=True, role=OWNER, team__is_private=True, team__deleted_at__isnull=True
    ).values_list("customer_id", flat=True)

    error = []
    for customer in all_customers:
        if customer.id in customer_ids_with_private_workspace:
            team = Teams.objects.filter(deletd_at__isnull=True, owner=customer, is_private=True).first()
            if not team:
                error.append(customer.id)
            team_id = team.id
        else:
            response = TeamService(customer).create_private_team()
            if response.get("code") != status.HTTP_201_CREATED:
                error.append(customer.id)
            team_id = response["data"].get("team_id")
        transfer_projects_to_private_team(team_id, customer.id)

    print(f"\n\n Script NOT successful for below customers:\n{error}")


def transfer_projects_to_private_team(team_id, customer_id):
    team_member = TeamMembers.objects.filter(deleted_at__isnull=True, is_active=True, team_id=team_id, customer_id=customer_id, role=OWNER).first()
    projects = Projects.objects.filter(owner_id=customer_id)
    for project in projects:
        project.team_id = team_id
        project.created_by = project.owner
        project.save(update_fields=['team_id', 'created_by', 'updated_at',])
        project.project_members.add(team_member)
