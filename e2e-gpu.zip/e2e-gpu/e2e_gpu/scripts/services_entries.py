from django.db import transaction

from gpu_service.models import TirServices, TirServicesDependency
from rbac.constants import (
    ADMIN, AUTH_TOKEN_SERVICE,
    CONTAINER_REGISTRY_SERVICE,
    CREATE_VALUE, DATASET,
    DELETE_VALUE, DISTRIBUTED_JOB,
    EOS_SERVICE, FINE_TUNING,
    IAM_USER, IAM_USER_SERVICE,
    INFERENCE_SERVICE, INTEGRATION_SERVICE, INVITE_SERVICE,
    MEMBER, MODEL_PLAYGROUND,
    MODEL_SERVICE, NO_PERMISSION_VALUE,
    NOTEBOOK, OWNER, PIPELINE,
    PROJECT_LEAD, PROJECT_MEMBER_SERVICE,
    PROJECT_SERVICE, READ_VALUE,
    TEAM_LEAD, TEAM_MEMBER,
    TEAM_MEMBER_SERVICE, TEAM_SERVICE,
    UPDATE_VALUE, USER_POLICY_SERVICE,
    VECTOR_DB
)
from rbac.models import TirRoleBasedPermissions

services = [
    {"service_id": TEAM_SERVICE, "alias_name": "Team", "description": "team", "is_internal_service": True},
    {"service_id": PROJECT_SERVICE, "alias_name": "Project", "description": "project", "is_internal_service": True},
    {"service_id": IAM_USER_SERVICE, "alias_name": "IAM User", "description": "iam user", "is_internal_service": True},
    {"service_id": TEAM_MEMBER_SERVICE, "alias_name": "Team Member", "description": "team member", "is_internal_service": True},
    {"service_id": PROJECT_MEMBER_SERVICE, "alias_name": "Project Member", "description": "project member", "is_internal_service": True},
    {"service_id": USER_POLICY_SERVICE, "alias_name": "User Policy", "description": "user policy", "is_internal_service": True},
    {"service_id": INVITE_SERVICE, "alias_name": "Invites", "description": "user invites", "is_internal_service": True},
    {"service_id": NOTEBOOK, "alias_name": "Node", "description": "notebook", "is_internal_service": False},
    {"service_id": DATASET, "alias_name": "Dataset", "description": "dataset", "is_internal_service": False},
    {"service_id": INFERENCE_SERVICE, "alias_name": "Inference", "description": "inference", "is_internal_service": False},
    {"service_id": PIPELINE, "alias_name": "Pipeline", "description": "pipeline", "is_internal_service": False},
    {"service_id": FINE_TUNING, "alias_name": "Fine Tuning", "description": "fine tuning", "is_internal_service": False},
    {"service_id": MODEL_PLAYGROUND, "alias_name": "GenAI API", "description": "model playground", "is_internal_service": False},
    {
        "service_id": CONTAINER_REGISTRY_SERVICE,
        "alias_name": "E2E Container Registry",
        "description": "container registry",
        "is_internal_service": False,
    },
    {"service_id": INTEGRATION_SERVICE, "alias_name": "External Integration", "description": "integration", "is_internal_service": False},
    {"service_id": AUTH_TOKEN_SERVICE, "alias_name": "API Token", "description": "auth token", "is_internal_service": False},
    {"service_id": VECTOR_DB, "alias_name": "Vector Database", "description": "vector db", "is_internal_service": False},
    {"service_id": DISTRIBUTED_JOB, "alias_name": "Multi-Node Training", "description": "distributed job", "is_internal_service": False},
    {"service_id": EOS_SERVICE, "alias_name": "EOS service", "description": "eos service", "is_internal_service": True},
    {"service_id": MODEL_SERVICE, "alias_name": "Model Repository", "description": "model service", "is_internal_service": True},
]


# RUN: NINE
def add_tir_services():
    service_instance = []
    count = 0
    for service in services:
        service_instance.append(
            TirServices(
                service_id=service["service_id"],
                alias_name=service["alias_name"],
                description=service["description"],
                is_internal_service=service["is_internal_service"],
                order=count,
            )
        )
        count = count + 1
    with transaction.atomic():
        services_object = TirServices.objects.bulk_create(service_instance)
        print(f"service-count:{len(services_object)}")


dependencies = [
    {"service_id": NOTEBOOK, "dependency_id": DATASET, "permissions": 1},
    {"service_id": NOTEBOOK, "dependency_id": CONTAINER_REGISTRY_SERVICE, "permissions": 1},
    {"service_id": INFERENCE_SERVICE, "dependency_id": AUTH_TOKEN_SERVICE, "permissions": 1},
    {"service_id": INFERENCE_SERVICE, "dependency_id": DATASET, "permissions": 1},
    {"service_id": INFERENCE_SERVICE, "dependency_id": INTEGRATION_SERVICE, "permissions": 1},
    {"service_id": INFERENCE_SERVICE, "dependency_id": CONTAINER_REGISTRY_SERVICE, "permissions": 1},
    {"service_id": INFERENCE_SERVICE, "dependency_id": MODEL_SERVICE, "permissions": 15},
    {"service_id": FINE_TUNING, "dependency_id": INTEGRATION_SERVICE, "permissions": 1},
    {"service_id": FINE_TUNING, "dependency_id": DATASET, "permissions": 1},
    {"service_id": FINE_TUNING, "dependency_id": INFERENCE_SERVICE, "permissions": 1},
    {"service_id": FINE_TUNING, "dependency_id": MODEL_SERVICE, "permissions": 15},
]


# RUN: TEN
def add_dependent_service():
    dependency_instances = []
    for dependency in dependencies:
        dependency_instances.append(
            TirServicesDependency(
                service_id=dependency["service_id"],
                dependency_id=dependency["dependency_id"],
                required_permissions=dependency["permissions"],
            )
        )
    with transaction.atomic():
        dependency_objects = TirServicesDependency.objects.bulk_create(dependency_instances)
        print(f"dependency-count:{len(dependency_objects)}")


TEAM_SERVICE_PERMISSION = {
    OWNER: CREATE_VALUE | READ_VALUE | UPDATE_VALUE | DELETE_VALUE,
    ADMIN: CREATE_VALUE | READ_VALUE | UPDATE_VALUE | DELETE_VALUE,
    TEAM_LEAD: READ_VALUE | UPDATE_VALUE,
    PROJECT_LEAD: READ_VALUE,
    IAM_USER: READ_VALUE,
    TEAM_MEMBER: READ_VALUE,
    MEMBER: READ_VALUE,
}

PROJECT_SERVICE_PERMISSION = {
    OWNER: CREATE_VALUE | READ_VALUE | UPDATE_VALUE | DELETE_VALUE,
    ADMIN: CREATE_VALUE | READ_VALUE | UPDATE_VALUE | DELETE_VALUE,
    TEAM_LEAD: CREATE_VALUE | READ_VALUE | UPDATE_VALUE | DELETE_VALUE,
    PROJECT_LEAD: READ_VALUE | UPDATE_VALUE,
    IAM_USER: READ_VALUE,
    TEAM_MEMBER: READ_VALUE,
    MEMBER: READ_VALUE,
}

USER_POLICIES_PERMISSION = {
    OWNER: CREATE_VALUE | READ_VALUE | UPDATE_VALUE | DELETE_VALUE,
    ADMIN: CREATE_VALUE | READ_VALUE | UPDATE_VALUE | DELETE_VALUE,
    TEAM_LEAD: CREATE_VALUE | READ_VALUE | UPDATE_VALUE | DELETE_VALUE,
    PROJECT_LEAD: CREATE_VALUE | READ_VALUE | UPDATE_VALUE | DELETE_VALUE,
    IAM_USER: NO_PERMISSION_VALUE,
    TEAM_MEMBER: NO_PERMISSION_VALUE,
    MEMBER: NO_PERMISSION_VALUE,
}

IAM_SERVICE_PERMISSION = {
    OWNER: CREATE_VALUE | READ_VALUE | UPDATE_VALUE | DELETE_VALUE,
    ADMIN: CREATE_VALUE | READ_VALUE | UPDATE_VALUE | DELETE_VALUE,
    IAM_USER: READ_VALUE | CREATE_VALUE,
}

TEAM_MEMBER_SERVICE_PERMISSION = {
    OWNER: CREATE_VALUE | READ_VALUE | UPDATE_VALUE | DELETE_VALUE,
    ADMIN: CREATE_VALUE | READ_VALUE | UPDATE_VALUE | DELETE_VALUE,
    TEAM_LEAD: CREATE_VALUE | READ_VALUE | UPDATE_VALUE | DELETE_VALUE,
    IAM_USER: READ_VALUE | CREATE_VALUE,
    TEAM_MEMBER: READ_VALUE | CREATE_VALUE,
}

PROJECT_MEMBER_SERVICE_PERMISSION = {
    OWNER: CREATE_VALUE | READ_VALUE | UPDATE_VALUE | DELETE_VALUE,
    ADMIN: CREATE_VALUE | READ_VALUE | UPDATE_VALUE | DELETE_VALUE,
    TEAM_LEAD: CREATE_VALUE | READ_VALUE | UPDATE_VALUE | DELETE_VALUE,
    PROJECT_LEAD: CREATE_VALUE | READ_VALUE | UPDATE_VALUE | DELETE_VALUE,
    IAM_USER: READ_VALUE,
    TEAM_MEMBER: READ_VALUE,
    MEMBER: READ_VALUE,
}

INVITE_SERVICE_PERMISSION = {
    OWNER: CREATE_VALUE | READ_VALUE | UPDATE_VALUE | DELETE_VALUE,
    ADMIN: CREATE_VALUE | READ_VALUE | UPDATE_VALUE | DELETE_VALUE,
    TEAM_LEAD: CREATE_VALUE | READ_VALUE | UPDATE_VALUE | DELETE_VALUE,
    PROJECT_LEAD: CREATE_VALUE | READ_VALUE | UPDATE_VALUE | DELETE_VALUE,
    IAM_USER: READ_VALUE,
    TEAM_MEMBER: READ_VALUE,
    MEMBER: READ_VALUE,
}


# RUN: ELEVENTH
def entries_for_tir_services():
    tir_servcies_permission_objs = []
    for role, permission in TEAM_SERVICE_PERMISSION.items():
        tir_servcies_permission_objs.append(TirRoleBasedPermissions(service_id=TEAM_SERVICE, role=role, permissions=permission))

    for role, permission in PROJECT_SERVICE_PERMISSION.items():
        tir_servcies_permission_objs.append(TirRoleBasedPermissions(service_id=PROJECT_SERVICE, role=role, permissions=permission))

    for role, permission in USER_POLICIES_PERMISSION.items():
        tir_servcies_permission_objs.append(TirRoleBasedPermissions(service_id=USER_POLICY_SERVICE, role=role, permissions=permission))

    for role, permission in IAM_SERVICE_PERMISSION.items():
        tir_servcies_permission_objs.append(TirRoleBasedPermissions(service_id=IAM_USER_SERVICE, role=role, permissions=permission))

    for role, permission in TEAM_MEMBER_SERVICE_PERMISSION.items():
        tir_servcies_permission_objs.append(TirRoleBasedPermissions(service_id=TEAM_MEMBER_SERVICE, role=role, permissions=permission))

    for role, permission in PROJECT_MEMBER_SERVICE_PERMISSION.items():
        tir_servcies_permission_objs.append(TirRoleBasedPermissions(service_id=PROJECT_MEMBER_SERVICE, role=role, permissions=permission))

    for role, permission in INVITE_SERVICE_PERMISSION.items():
        tir_servcies_permission_objs.append(TirRoleBasedPermissions(service_id=INVITE_SERVICE, role=role, permissions=permission))

    with transaction.atomic():
        tir_service_objects = TirRoleBasedPermissions.objects.bulk_create(tir_servcies_permission_objs)
        print(f"no-of-permission: {len(tir_service_objects)}")


def run():
    add_tir_services()
    add_dependent_service()
    entries_for_tir_services()
