from django.contrib import admin

from ssh_keys.models import SSHKey

# Register your models here.


# class SSHKeyAdmin:
#     search_fields = ('customer__email',)
#     raw_id_fields = ('customer',)

#     def customer_email(self, obj):
#         return str(obj.customer.email)

admin.site.register(SSHKey)
