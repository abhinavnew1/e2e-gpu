from django.conf import settings
MYACCOUNT_PROJECT_URL =  settings.MYACCOUNT_LB_URL + "api/v1/pbac/projects-header/?apikey={apikey}"
MYACCOUNT_SSH_KEY =  settings.MYACCOUNT_LB_URL + "api/v1/ssh_keys/?apikey={apikey}&project_id={project_id}"
SYNCED = "Your SSH Key(s) have been synced successfully"
SSH_ADDED = "Your SSH Key has been added"
SSH_DELETION_ERROR = "SSH Key is attached to one or more resources. Please detach the key from all resources before deleting it."
