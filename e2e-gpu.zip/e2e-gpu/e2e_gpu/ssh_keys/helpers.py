def is_ssh_being_used_in_notebook(ssh_key):
    if ssh_key.notebook_set.filter(deleted_at__isnull=True).exists():
        return True
    return False
