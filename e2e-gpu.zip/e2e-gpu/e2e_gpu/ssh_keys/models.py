from django.db import models

from customer.models import Customer

# Create your models here.


class SSHKey(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    label = models.CharField(max_length=50)
    ssh_key = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.label
