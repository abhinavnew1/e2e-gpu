from django.contrib import admin
from safedelete.admin import SafeDeleteAdmin

from teams.models import TeamMembers, Teams


# Register your models here.
class TeamsAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "deleted_at",
        "id",
        "name",
        "is_private",
        "owner",
        "created_by",
        "description",
        "created_at",
        "updated_at",
    )
    raw_id_fields = ("owner", "created_by")
    search_fields = ("id", "owner__email", "name")
    list_filter = ("deleted_at", "deleted", "is_private")
    list_display_links = ("id", "name")
    list_select_related = ("owner", "created_by")


class TeamMembersAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "deleted_at",
        "id",
        "is_active",
        "iam_user",
        "team",
        "role",
        "created_by",
        "created_at",
        "updated_at",
    )
    raw_id_fields = ("team", "iam_user", "created_by")
    search_fields = ("id", "team__name", "role", "iam_user__added_user__email")
    list_filter = ("deleted", "is_active")
    list_display_links = ("id", "iam_user")
    list_select_related = ("team", "iam_user", "created_by")


admin.site.register(Teams, TeamsAdmin)
admin.site.register(TeamMembers, TeamMembersAdmin)
