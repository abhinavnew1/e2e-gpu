from e2e_core.constants import MAX_LENGTH_ERROR

TEAM_NAME_MAX_LENGTH = 32
TEAM_NAME_MAX_LENGTH_ERROR = MAX_LENGTH_ERROR.format(field_name="Team Name", max_length=TEAM_NAME_MAX_LENGTH)
NAME_REGEX = r"^[A-Za-z0-9_-]{1,}$"
NAME_INVALID = "Team name should contain letters, digits, underscore and hyphen only."
TEAM_NAME_NOT_AVAILABLE = "Team name not available. Please try some other name."

# audit log constants
TEAM_CREATE_EVENT = "TEAM_CREATE"
TEAM_DELETE_EVENT = "TEAM_DELETE"
TEAM_UPDATE_EVENT = "TEAM_UPDATE"
TEAM_MEMBER_CREATE_EVENT = 'ADD_TEAM_MEMBER'
TEAM_MEMBER_UPDATE_EVENT = "TEAM_MEMBER_ACCESS_UPDATE"
TEAM_MEMBER_DELETE_EVENT = "REMOVE_TEAM_MEMBER"

# TEAM SERVICE MESSAGE
PRIVATE_WORKSPACE_NAME = "Private Workspace"
PRIVATE_WORKSPACE_DESCRIPTION = "This is your personal workspace"
TEAM_DELETION_SUCCESSFUL = "Team deleted successfully"
PRIVATE_WORKSPACE_CANNOT_BE_MODIFIED = "You cannot update or delete your Private Workspace"
FAILED_TEAM_PROJECT_DELETION_MESSAGE = "Unable to delete project id: {project_id} while team: {team_id} deletion. \
    \n errors: {errors}"
FAILED_TEAM_PROJECT_DELETION_SUBJECT = "Unable to delete project for customer: {email_id}"

# ERROR MESSAGES
MEMBER_ALREADY_EXIST = "Requested user is already part of the team"
TEAM_MEMBER_ASSIGN_NAMESPACE_ACCESS_TASK_FAILED = "Failed to assign namespace access to team-member id: {member_id} \n error:{errors}"
TEAM_MEMBER_ASSIGN_NAMESPACE_ACCESS_TASK_SUBJECT = "Failed to assign namespace access to team-member created by: {email}"
TEAM_MEMBER_REMOVE_NAMESPACE_ACCESS_TASK_FAILED = "Failed to remove namespace access to team-member id: {member_id} \n error:{errors}"
TEAM_MEMBER_REMOVE_NAMESPACE_ACCESS_TASK_SUBJECT = "Failed to remove namespace access to team-member deleted by: {email}"

# TASKS
TEAM_PROJECTS_DELETION_TASK = "team_projects_deletion_task"
COUNTDOWN_FOR_TEAM_PROJECTS_DELETION = 5
TEAM_MEMBER_ASSIGN_NAMESPACE_ACCESS_TASK = "team_member_assign_namespace_access_task"
TEAM_MEMBER_REMOVE_NAMESPACE_ACCESS_TASK = "team_member_remove_namespace_access_task"
