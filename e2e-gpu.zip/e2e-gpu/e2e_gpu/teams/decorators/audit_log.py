from rest_framework import status

from eventlogs.api.v1.services.eventlog_service import EventLogService
from eventlogs.constants import (
    CREATE,
    DELETE,
    EVENTLOG_FAILED_STATUS,
    EVENTLOG_SUCCESS_STATUS,
    TEAM_MANAGEMENT_SERVICE_CODE,
    TEAM_MEMBERS_CODE,
    UPDATE,
)
from teams.constants import (
    TEAM_CREATE_EVENT,
    TEAM_DELETE_EVENT,
    TEAM_MEMBER_CREATE_EVENT,
    TEAM_MEMBER_DELETE_EVENT,
    TEAM_MEMBER_UPDATE_EVENT,
    TEAM_UPDATE_EVENT,
)


def team_create_log(func):
    def wrapper_func(*args, **kwargs):
        event_log = EventLogService(TEAM_MANAGEMENT_SERVICE_CODE)
        request = args[1]
        response = func(*args, **kwargs)
        log_status = EVENTLOG_SUCCESS_STATUS if response.status_code == status.HTTP_201_CREATED else EVENTLOG_FAILED_STATUS
        event_log.create_log(
            request=request,
            event=TEAM_CREATE_EVENT,
            resource_name=request.data.get("team_name", ""),
            resource_id=response.data["data"].get("team_id", ""),
            detailed_info=response.data["data"],
            status=log_status,
            resource_obj_id=response.data["data"].get("team_id"),
            event_type=CREATE,
        )
        return response

    return wrapper_func


def team_delete_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(TEAM_MANAGEMENT_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=TEAM_DELETE_EVENT,
            resource_name=kwargs.get("team").name,
            resource_id=kwargs.get("team_id"),
            resource_obj_id=kwargs.get("team_id"),
            event_type=DELETE,
        )
        response = func(*args, **kwargs)
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else event_log.log_event_failure()
        return response

    return wrapper_func


def team_update_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(TEAM_MANAGEMENT_SERVICE_CODE)
        response = func(*args, **kwargs)
        log_status = EVENTLOG_SUCCESS_STATUS if response.status_code == status.HTTP_200_OK else EVENTLOG_FAILED_STATUS
        event_log.create_log(
            request=request,
            event=TEAM_UPDATE_EVENT,
            resource_name=request.data["team_name"],
            resource_id=kwargs.get("team_id"),
            detailed_info={"update_data": request.data},
            status=log_status,
            resource_obj_id=kwargs.get("team_id"),
            event_type=UPDATE,
        )
        return response

    return wrapper_func


# TEAM-MEMBERS AUDIT LOG

def team_member_create_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        response = func(*args, **kwargs)
        event_log = EventLogService(TEAM_MEMBERS_CODE)
        log_status = EVENTLOG_SUCCESS_STATUS if response.status_code == status.HTTP_201_CREATED else EVENTLOG_FAILED_STATUS
        res_data = response.data["data"]
        member_id, iam_user = res_data.get("id", ""), res_data.get("iam_user", {})
        email = iam_user.get("added_user", {}).get("email", "")
        event_log.create_log(
            request=request,
            event=TEAM_MEMBER_CREATE_EVENT,
            resource_name=email,
            resource_id=member_id,
            resource_obj_id=member_id,
            status=log_status,
            event_type=CREATE,
            detailed_info=request.data,
        )
        return response

    return wrapper_func


def team_member_update_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        response = func(*args, **kwargs)
        event_log = EventLogService(TEAM_MEMBERS_CODE)
        log_status = EVENTLOG_SUCCESS_STATUS if response.status_code == status.HTTP_200_OK else EVENTLOG_FAILED_STATUS
        target_member = kwargs.get("targeted_team_member")
        event_log.create_log(
            request=request,
            event=TEAM_MEMBER_UPDATE_EVENT,
            resource_name=target_member.iam_user.added_user.email,
            resource_id=target_member.id,
            resource_obj_id=target_member.id,
            status=log_status,
            event_type=UPDATE,
            detailed_info=request.data,
        )
        return response

    return wrapper_func


def team_member_delete_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        response = func(*args, **kwargs)
        event_log = EventLogService(TEAM_MEMBERS_CODE)
        log_status = EVENTLOG_SUCCESS_STATUS if response.status_code == status.HTTP_200_OK else EVENTLOG_FAILED_STATUS
        target_member = kwargs.get("targeted_team_member")
        event_log.create_log(
            request=request,
            event=TEAM_MEMBER_DELETE_EVENT,
            resource_name=target_member.iam_user.added_user.email,
            resource_id=target_member.id,
            resource_obj_id=target_member.id,
            status=log_status,
            event_type=DELETE,
        )
        return response

    return wrapper_func
