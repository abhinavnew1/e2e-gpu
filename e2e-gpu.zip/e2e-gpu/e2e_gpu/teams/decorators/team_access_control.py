import logging

from rest_framework.response import Response

from e2e_core.api.v1.services.base import BaseService
from e2e_core.constants import NOT_FOUND_ERROR, PERMISSION_DENIED
from e2e_core.exceptions import ObjectNotFoundError, TirPermissionError
from rbac.constants import READ, ROLE_ACCESS_DENIED, TEAM_MEMBER_SERVICE, TEAM_SERVICE
from rbac.helpers import check_role_access, check_tir_role_based_permissions
from teams.models import TeamMembers


logger = logging.getLogger(__name__)


class TeamAccessControl(object):

    def __init__(self, action):
        self.action = action
        self.request = None
        self.customer = None
        self.iam = None

    def __call__(self, original_function, *args, **kwargs):
        def inner_func(*args, **kwargs):
            self._initialize_params(*args)
            team_id = kwargs.get("team_id", None)
            iam_role = self.iam.role
            try:
                if team_id:
                    team_member = TeamMembers.get_active_members(team_id=team_id, iam_user=self.iam).select_related("team").first()
                    if not team_member:
                        raise ObjectNotFoundError(NOT_FOUND_ERROR.format(service='Team member'))
                    kwargs["team"] = team_member.team
                    iam_role = team_member.role
                if not check_tir_role_based_permissions(TEAM_SERVICE, iam_role, self.action):
                    raise TirPermissionError(ROLE_ACCESS_DENIED)
            except Exception as e:
                logger.error(f"TEAM_ACCESS_CHECK_FAILED | CRITICAL_GREEN | CUSTOMER - {self.customer.email} | ERRORS - {str(e)}")
                response = BaseService.get_403_response(PERMISSION_DENIED)
                return Response(response, status=response.get("code"))
            return original_function(*args, **kwargs)

        return inner_func

    def _initialize_params(self, *args):
        self.request = args[1]
        self.customer = self.request.customer
        self.iam = self.request.iam


class TeamMemberAccessControl(object):
    def __init__(self, action):
        self.action = action
        self.request = None
        self.customer = None
        self.iam = None

    def __call__(self, original_function, *args, **kwargs):
        def inner_func(*args, **kwargs):
            self._initialize_params(*args)
            team_id = kwargs.get("team_id", None)
            team_member_id = kwargs.get("member_id", None)
            performer_role = self.iam.role
            try:
                performer_team_member = TeamMembers.get_active_members(team_id=team_id, iam_user=self.iam).first()
                if not performer_team_member:
                    raise ObjectNotFoundError(NOT_FOUND_ERROR.format(service='Performer team member'))
                kwargs["team_member"] = performer_team_member
                performer_role = performer_team_member.role
                if not check_tir_role_based_permissions(TEAM_MEMBER_SERVICE, performer_role, self.action):
                    raise TirPermissionError(ROLE_ACCESS_DENIED)
                if team_member_id:
                    targeted_team_member = TeamMembers.get_active_members(id=team_member_id, team_id=team_id).select_related('iam_user__added_user').first()
                    if not targeted_team_member:
                        raise ObjectNotFoundError(NOT_FOUND_ERROR.format(service='Target team member'))
                    if self.action != READ and not check_role_access(performer_role, targeted_team_member.role):
                        raise TirPermissionError(ROLE_ACCESS_DENIED)
                    kwargs["targeted_team_member"] = targeted_team_member
            except Exception as e:
                logger.error(f"TEAM_MEMBER_ACCESS_CHECK_FAILED | CRITICAL_GREEN | CUSTOMER - {self.customer.email} | ERRORS - {str(e)}")
                response = BaseService.get_403_response(PERMISSION_DENIED)
                return Response(response, status=response.get("code"))
            return original_function(*args, **kwargs)

        return inner_func

    def _initialize_params(self, *args):
        self.request = args[1]
        self.customer = self.request.customer
        self.iam = self.request.iam
