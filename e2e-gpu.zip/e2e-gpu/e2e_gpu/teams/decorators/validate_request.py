from rest_framework.response import Response

from e2e_core.api.v1.services.base import BaseService
from teams.constants import PRIVATE_WORKSPACE_CANNOT_BE_MODIFIED


def validate_team_type(func):
    def wrapper_func(*args, **kwargs):
        team = kwargs.get("team")
        if team.is_private:
            response = BaseService.get_400_response(PRIVATE_WORKSPACE_CANNOT_BE_MODIFIED)
            return Response(response, status=response.get("code"))
        return func(*args, **kwargs)

    return wrapper_func
