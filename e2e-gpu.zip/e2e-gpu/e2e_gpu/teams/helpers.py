import logging

from celery.execute import send_task
from django.db.models import Q

from e2e_core.helpers import support_ticket_generator
from projects.constants import ASSIGN_ACCESS_COUNTDOWN, REMOVE_ACCESS_COUNTDOWN
from rbac.constants import ADMIN, OWNER
from teams.constants import (
    TEAM_MEMBER_ASSIGN_NAMESPACE_ACCESS_TASK,
    TEAM_MEMBER_ASSIGN_NAMESPACE_ACCESS_TASK_FAILED,
    TEAM_MEMBER_ASSIGN_NAMESPACE_ACCESS_TASK_SUBJECT,
    TEAM_MEMBER_REMOVE_NAMESPACE_ACCESS_TASK,
    TEAM_MEMBER_REMOVE_NAMESPACE_ACCESS_TASK_FAILED,
    TEAM_MEMBER_REMOVE_NAMESPACE_ACCESS_TASK_SUBJECT,
)
from teams.models import TeamMembers


logger = logging.getLogger(__name__)


def get_team_owner_admins(team_id, emails_to_exclude=[]):
    return TeamMembers.objects.filter(Q(role=OWNER) | Q(role=ADMIN), deleted_at__isnull=True, is_active=True, team_id=team_id).exclude(
        iam_user__added_user__email=emails_to_exclude
    )


def get_team_owner_admin_email_list(team_id, emails_to_exclude=[]) -> list:
    return list(get_team_owner_admins(team_id, emails_to_exclude).values_list("iam_user__added_user__email", flat=True))


def team_member_assign_namespace_access(customer, team_member):
    try:
        send_task(
            TEAM_MEMBER_ASSIGN_NAMESPACE_ACCESS_TASK,
            kwargs={"created_by": customer, "team_member_id": team_member.id},
            countdown=ASSIGN_ACCESS_COUNTDOWN,
        )
    except Exception as e:
        errors = str(e)
        logger.error(
            f"TEAM_MEMBER_SERVICE | CRITICAL_RED | TEAM_MEMBER_ASSIGN_NAMESPACE_ACCESS_TASK_FAILED \
                | TEAM_MEMBER_ID:{team_member.id} | ERROR:{errors}"
        )
        support_ticket_generator(
            errors=TEAM_MEMBER_ASSIGN_NAMESPACE_ACCESS_TASK_FAILED.format(member_id=team_member.id, errors=errors),
            subject=TEAM_MEMBER_ASSIGN_NAMESPACE_ACCESS_TASK_SUBJECT.format(email=customer.email),
            customer=customer,
        )


def team_member_remove_members_namespace_access(customer, team_member):
    try:
        send_task(
            TEAM_MEMBER_REMOVE_NAMESPACE_ACCESS_TASK,
            kwargs={"deleted_by": customer, "team_member_id": team_member.id},
            countdown=REMOVE_ACCESS_COUNTDOWN,
        )
    except Exception as e:
        errors = str(e)
        logger.error(
            f"TEAM_MEMBER_SERVICE | CRITICAL_RED | TEAM_MEMBER_REMOVE_MEMBERS_NAMESPACE_ACCESS_TASK_FAILED \
                | TEAM_MEMBER_ID:{team_member.id} | ERROR:{errors}"
        )
        support_ticket_generator(
            errors=TEAM_MEMBER_REMOVE_NAMESPACE_ACCESS_TASK_FAILED.format(member_id=team_member.id, errors=errors),
            subject=TEAM_MEMBER_REMOVE_NAMESPACE_ACCESS_TASK_SUBJECT.format(email=customer.email),
            customer=customer,
        )
