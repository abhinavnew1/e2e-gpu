from datetime import datetime

from django.db import models
from django.db.models import UniqueConstraint

from customer.models import Customer
from e2e_core.helpers import mark_delete_related_objects
from e2e_core.mixins import BaseMixin, SafeDeleteMixinExtended
from invites.models import Invites
from rbac.constants import ROLE_MAX_LENGTH, TEAM_MEMBER, TEAM_MEMBER_ROLE_CHOICES
from rbac.models import IAM
from teams.constants import TEAM_NAME_MAX_LENGTH


class Teams(SafeDeleteMixinExtended, BaseMixin):
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    name = models.CharField(max_length=TEAM_NAME_MAX_LENGTH)
    owner = models.ForeignKey(Customer, on_delete=models.PROTECT, related_name="teams")
    created_by = models.ForeignKey(Customer, null=True, default=None, on_delete=models.PROTECT, related_name="created_teams")
    description = models.TextField(default=None, null=True, blank=True)
    is_private = models.BooleanField(default=False)

    def __str__(self):
        return f"<Team({self.id}: {self.name}: {self.owner.email}: {self.is_private})>"

    @classmethod
    def get_not_deleted_teams(cls, **filters):
        return cls.objects.filter(deleted_at__isnull=True, **filters)

    def mark_deleted(self):
        if self.deleted_at is None:
            mark_delete_related_objects(self)
            self.deleted_at = datetime.now()
            self.save(update_fields=["deleted_at", "updated_at"])


class TeamMembers(SafeDeleteMixinExtended, BaseMixin):
    """
    In case of team or iam delete team_member will also be deleted
    """

    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    is_active = models.BooleanField(default=True)
    role = models.CharField(choices=TEAM_MEMBER_ROLE_CHOICES, default=TEAM_MEMBER, max_length=ROLE_MAX_LENGTH)
    team = models.ForeignKey(Teams, on_delete=models.CASCADE, related_name="members")
    iam_user = models.ForeignKey(IAM, null=True, default=None, on_delete=models.CASCADE, related_name="team_members")
    created_by = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True, related_name="created_team_members")
    # PBAC_TODO: REMOVE NULL =TRUE
    # below field will be reomoved after everything runs fine
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, null=True)  # this two field will be remove
    invite = models.OneToOneField(Invites, null=True, blank=True, on_delete=models.SET_NULL)  # PBAC_TODO: this two field will be remove
    active_start_date = models.DateTimeField(default=None, null=True, blank=True)
    active_end_date = models.DateTimeField(default=None, null=True, blank=True)

    class Meta:
        constraints = [UniqueConstraint(fields=["team", "iam_user", "deleted_at"], name="unique_team_member")]

    def __str__(self):
        return f"<TeamMember({self.id}: team:{self.team.name})>"

    @classmethod
    def get_active_members(cls, **filters):
        return cls.objects.filter(deleted_at__isnull=True, is_active=True, **filters)

    @classmethod
    def get_not_deleted_members(cls, **filters):
        return cls.objects.filter(deleted_at__isnull=True, **filters)

    def mark_deleted(self):
        if self.deleted_at is None:
            mark_delete_related_objects(self)
            self.deleted_at = datetime.now()
            self.save(update_fields=["deleted_at", "updated_at"])
