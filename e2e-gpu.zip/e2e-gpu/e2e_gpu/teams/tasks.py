import logging

from rest_framework import status

from e2e_core.helpers import support_ticket_generator
from e2e_gpu.celery import app
from projects.constants import (
    ASSIGN_ACCESS_MAX_RETRIES,
    PROJECT_MEMBERS_ASSIGN_NAMESPACE_ACCESS_ERROR,
    PROJECT_MEMBERS_ASSIGN_NAMESPACE_ACCESS_SUBJECT,
    PROJECT_MEMBERS_REMOVE_NAMESPACE_ACCESS_ERROR,
    PROJECT_MEMBERS_REMOVE_NAMESPACE_ACCESS_SUBJECT,
    REMOVE_ACCESS_MAX_RETRIES,
)
from projects.api.v1.services.namespace_service import NamespaceService
from projects.api.v1.services.projects_service import ProjectService
from projects.models import ProjectMembers, Projects
from teams.constants import (
    FAILED_TEAM_PROJECT_DELETION_MESSAGE,
    FAILED_TEAM_PROJECT_DELETION_SUBJECT,
    TEAM_MEMBER_ASSIGN_NAMESPACE_ACCESS_TASK,
    TEAM_MEMBER_REMOVE_NAMESPACE_ACCESS_TASK,
    TEAM_PROJECTS_DELETION_TASK,
)
from teams.models import TeamMembers

logger = logging.getLogger(__name__)


@app.task(name=TEAM_PROJECTS_DELETION_TASK, bind=True)
def team_projects_deletion_task(self, *args, **kwargs):
    customer = kwargs.get("customer")
    iam = kwargs.get("iam")
    team_id = kwargs.get("team_id")
    projects = Projects.objects.filter(deleted_at__isnull=True, team_id=team_id)
    for project in projects:
        response = ProjectService(customer, iam, team_id, project).delete_project()
        if response.get("code") != status.HTTP_200_OK:
            logger.error(
                f"TEAM_PROJECTS_DELETION_TASK | CRITICAL_RED | FAILED_TO_DELETE_PROJECT | PROJECT_ID:{project.id} | ERRORS:{response['errors']}"
            )
            support_ticket_generator(
                errors=FAILED_TEAM_PROJECT_DELETION_MESSAGE.format(project_id=project.id, team_id=team_id, errors=response.get("errors")),
                subject=FAILED_TEAM_PROJECT_DELETION_SUBJECT.format(email_id=customer.email),
                customer=customer,
            )


@app.task(
    name=TEAM_MEMBER_ASSIGN_NAMESPACE_ACCESS_TASK,
    max_retries=ASSIGN_ACCESS_MAX_RETRIES,
    bind=True,
)
def team_member_assign_namespace_task(self, **kwargs):
    created_by = kwargs.get("created_by", None)
    team_member_id = kwargs.get("team_member_id", None)
    team_member = TeamMembers.objects.filter(id=team_member_id).select_related("iam_user__added_user").first()
    project_members = ProjectMembers.get_active_members(team_member=team_member).select_related("project")
    added_user = team_member.iam_user.added_user
    namespace_service = NamespaceService(None, added_user)
    failed_member_assign_namespace_access = []
    for project_member in project_members:
        namespace_service.project = project_member.project
        is_success = namespace_service.add_permissions(added_user.email, project_member.role)
        if not is_success:
            failed_member_assign_namespace_access.append(project_member.project.id)
    if failed_member_assign_namespace_access:
        logger.error(
            f"TEAM_MEMBER_ASSIGN_NAMESPACE_ACCESS_TASK | FAILED_TO_ASSIGN_NAMESPACE_ACCESS_FOR_PROJECT_MEMBERS | CRITICAL_RED |\
               TEAM_MEMBER_ID: {team_member.id}| PROJECT_MEMBERS:{failed_member_assign_namespace_access}"
        )
        support_ticket_generator(
            errors=PROJECT_MEMBERS_ASSIGN_NAMESPACE_ACCESS_ERROR.format(members=failed_member_assign_namespace_access),
            subject=PROJECT_MEMBERS_ASSIGN_NAMESPACE_ACCESS_SUBJECT.format(email=created_by.email),
            customer=created_by,
        )


@app.task(
    name=TEAM_MEMBER_REMOVE_NAMESPACE_ACCESS_TASK,
    max_retries=REMOVE_ACCESS_MAX_RETRIES,
    bind=True,
)
def team_member_remove_namespace_access_task(self, **kwargs):
    deleted_by = kwargs.get("deleted_by", None)
    team_member_id = kwargs.get("team_member_id", None)
    team_member = TeamMembers.objects.filter(id=team_member_id).select_related("iam_user__added_user").first()
    project_members = ProjectMembers.objects.filter(team_member=team_member, is_active=False).select_related("project")
    added_user = team_member.iam_user.added_user
    namespace_service = NamespaceService(None, added_user)
    failed_member_namespace_access_removal = []
    for project_member in project_members:
        namespace_service.project = project_member.project
        is_success = namespace_service.delete_permissions(added_user.email, project_member.role)
        if not is_success:
            failed_member_namespace_access_removal.append(project_member.project.id)
    if failed_member_namespace_access_removal:
        logger.error(
            f"TEAM_MEMBER_REMOVE_NAMESPACE_ACCESS_TASK | FAILED_TO_REMOVE_NAMESPACE_ACCESS_FOR_PROJECT_MEMBERS | CRITICAL_RED |\
               TEAM_MEMBER_ID: {team_member.id}| PROJECT_MEMBERS:{failed_member_namespace_access_removal}"
        )
        support_ticket_generator(
            errors=PROJECT_MEMBERS_REMOVE_NAMESPACE_ACCESS_ERROR.format(members=failed_member_namespace_access_removal),
            subject=PROJECT_MEMBERS_REMOVE_NAMESPACE_ACCESS_SUBJECT.format(email=deleted_by.email),
            customer=deleted_by,
        )
