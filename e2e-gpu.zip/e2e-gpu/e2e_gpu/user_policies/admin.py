from django.contrib import admin
from safedelete.admin import SafeDeleteAdmin

from user_policies.models import UserPolicies


class UserPoliciesAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "name",
        "description",
        "created_by",
        "project",
        "created_at",
        "updated_at",
    )
    raw_id_fields = ("created_by", "project")
    search_fields = ("id", "name")
    list_filter = ("deleted",)
    list_display_links = ("id", "name")
    list_select_related = ("created_by", "project")


admin.site.register(UserPolicies, UserPoliciesAdmin)
