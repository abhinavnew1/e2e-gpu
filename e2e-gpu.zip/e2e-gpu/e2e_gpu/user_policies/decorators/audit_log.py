from rest_framework import status

from eventlogs.api.v1.services.eventlog_service import EventLogService
from eventlogs.constants import CREATE, DELETE, EVENTLOG_FAILED_STATUS, EVENTLOG_SUCCESS_STATUS, UPDATE, USER_POLICIES_CODE
from user_policies.constants import POLICY_CREATE_EVENT, POLICY_DELETE_EVENT, POLICY_UPDATE_EVENT


def policy_create_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(USER_POLICIES_CODE)
        response = func(*args, **kwargs)
        log_status = EVENTLOG_SUCCESS_STATUS if response.status_code == status.HTTP_201_CREATED else EVENTLOG_FAILED_STATUS
        res_data = response.data["data"]
        resource_id = res_data.get("id", "")
        event_log.create_log(
            request=request,
            event=POLICY_CREATE_EVENT,
            resource_name=request.data.get("name", ""),
            resource_id=resource_id,
            resource_obj_id=resource_id,
            status=log_status,
            detailed_info={"services": request.data.get('services', [])},
            event_type=CREATE,
        )
        return response

    return wrapper_func


def policy_delete_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(USER_POLICIES_CODE)
        response = func(*args, **kwargs)
        log_status = EVENTLOG_SUCCESS_STATUS if response.status_code == status.HTTP_200_OK else EVENTLOG_FAILED_STATUS
        policy_id = kwargs.get("policy_id")
        event_log.create_log(
            request=request,
            event=POLICY_DELETE_EVENT,
            resource_name=kwargs.get("policy").name,
            resource_id=policy_id,
            resource_obj_id=policy_id,
            status=log_status,
            event_type=DELETE,
        )
        return response

    return wrapper_func


def policy_update_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(USER_POLICIES_CODE)
        response = func(*args, **kwargs)
        log_status = EVENTLOG_SUCCESS_STATUS if response.status_code == status.HTTP_200_OK else EVENTLOG_FAILED_STATUS
        policy_id = kwargs.get("policy_id")
        event_log.create_log(
            request=request,
            event=POLICY_UPDATE_EVENT,
            resource_name=kwargs.get("policy").name,
            resource_id=policy_id,
            resource_obj_id=policy_id,
            status=log_status,
            detailed_info={"services": request.data.get('services', [])},
            event_type=UPDATE,
        )
        return response

    return wrapper_func
