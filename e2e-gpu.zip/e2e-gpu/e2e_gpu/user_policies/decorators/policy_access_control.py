import logging

from rest_framework.response import Response

from e2e_core.api.v1.services.base import BaseService
from e2e_core.constants import NOT_FOUND_ERROR, PERMISSION_DENIED
from e2e_core.exceptions import ObjectNotFoundError, TirPermissionError
from projects.models import ProjectMembers
from rbac.constants import ROLE_ACCESS_DENIED, USER_POLICY_SERVICE
from rbac.helpers import check_tir_role_based_permissions
from user_policies.models import UserPolicies

logger = logging.getLogger(__name__)


class UserPolicyAccessControl(object):

    def __init__(self, action):
        self.action = action
        self.request = None
        self.customer = None
        self.iam = None

    def __call__(self, original_function, *args, **kwargs):
        def inner_func(*args, **kwargs):
            self._initialize_params(*args)
            team_id = kwargs.get("team_id", None)
            project_id = kwargs.get("project_id", None)
            policy_id = kwargs.get("policy_id", None)
            try:
                project_member = (
                    ProjectMembers.objects.filter(
                        project_id=project_id,
                        team_member__iam_user=self.iam,
                        team_member__team_id=team_id,
                        deleted_at__isnull=True,
                    )
                    .select_related("project")
                    .first()
                )
                if not project_member:
                    raise ObjectNotFoundError(NOT_FOUND_ERROR.format(service="Project member"))
                kwargs["project"] = project_member.project
                if policy_id:
                    policy = UserPolicies.objects.filter(id=policy_id).first()
                    if not policy:
                        raise ObjectNotFoundError(NOT_FOUND_ERROR.format(service="Policy"))
                    kwargs["policy"] = policy
                if not check_tir_role_based_permissions(USER_POLICY_SERVICE, project_member.role, self.action):
                    raise TirPermissionError(ROLE_ACCESS_DENIED)
            except Exception as e:
                logger.error(f"POLICY_ACCESS_CHECK_FAILED | CRITICAL_GREEN | CUSTOMER - {self.customer.email} | ERRORS - {str(e)}")
                response = BaseService().get_403_response(PERMISSION_DENIED)
                return Response(response, status=response.get("code"))
            return original_function(*args, **kwargs)

        return inner_func

    def _initialize_params(self, *args):
        self.request = args[1]
        self.customer = self.request.customer
        self.iam = self.request.iam
