from django.db import models

from e2e_core.mixins import BaseMixin, SafeDeleteMixinExtended
from customer.models import Customer
from gpu_service.models import TirServices
from projects.models import Projects
from rbac.constants import ACCESS_CONTROL_CHOICES, NO_PERMISSION_VALUE
from user_policies.constants import POLICY_DESCRIPTION_MAX_LENGTH, POLICY_NAME_MAX_LENGTH


class UserPolicies(SafeDeleteMixinExtended, BaseMixin):

    name = models.CharField(max_length=POLICY_NAME_MAX_LENGTH)
    description = models.TextField(null=False, blank=False, max_length=POLICY_DESCRIPTION_MAX_LENGTH)
    created_by = models.ForeignKey(Customer, on_delete=models.PROTECT, related_name="created_policies")
    project = models.ForeignKey(Projects, on_delete=models.CASCADE, related_name="policies")

    def __str__(self):
        return f"<UserPolicies({self.id}: {self.name}: {self.description})>"

    class Meta:
        ordering = ["-updated_at"]


class UserPolicyServices(SafeDeleteMixinExtended, BaseMixin):
    policy = models.ForeignKey(UserPolicies, on_delete=models.CASCADE, related_name="policy_services")
    service = models.ForeignKey(TirServices, on_delete=models.CASCADE, to_field="service_id", related_name="policies")
    permissions = models.PositiveSmallIntegerField(choices=ACCESS_CONTROL_CHOICES, default=NO_PERMISSION_VALUE)

    def __str__(self):
        return f"<UserPolicyServices({self.id}: {self.policy.name}: {self.service_id}: {self.permissions})>"
