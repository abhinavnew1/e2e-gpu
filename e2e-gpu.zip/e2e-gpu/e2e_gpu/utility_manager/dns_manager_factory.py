import logging

from .powerdns_manager import PowerDNSManager

from utility_manager.singleton_metaclass import SingletonType

logger = logging.getLogger(__name__)

class DNSManagerUndefined(Exception):
    pass


class DNSManagerFactory(metaclass=SingletonType):
    def __init__(self):
        logger.debug("DNS Manager initialised")

    @staticmethod
    def get_dns_manager(dns_name, *args, **kwargs):
        # TODO: Developer should create the object for the new dns manager here
        if dns_name == "PowerDNS":
            dns_manager = PowerDNSManager(*args, **kwargs)
        else:
            raise DNSManagerUndefined("No defintion for this dns Manager")

        return dns_manager
