import json
import logging
import requests
import socket
from dns import (
    resolver,
    reversename,
)
from netaddr import (
    valid_ipv4,
    valid_ipv6,
)

from utility_manager.singleton_metaclass import SingletonType

logger = logging.getLogger(__name__)


class PowerDNSManager(metaclass=SingletonType):
    METHODS = {
        "zones": "servers/localhost/zones",
        "search": "servers/localhost/search-data"
    }

    def __init__(self, base_url, api_key, dns_nameserver, domain_ttl=86400, record_ttl=3600, ptr_ttl=86400):
        self.base_url = base_url
        self.api_key = api_key
        self.domain_ttl = domain_ttl
        self.record_ttl = record_ttl
        self.ptr_ttl = ptr_ttl
        self.dns_nameserver = dns_nameserver
        logger.debug("PowerDNSManager initialised")

    def _get_clean_error_message(self, error_message, domain_name=None, record_name=None):
        error_message = eval(error_message)["error"]
        if "while parsing IP address" in error_message.lower().strip() or \
                        "unable to parse IP address".lower().strip() in error_message.lower().strip() or \
                        "Invalid IPv6 address" in error_message.lower().strip():
            return "Invalid IP address. Please enter a valid IP address."
        if "Parsing record content" in error_message.lower().strip() or \
                        "in wrong position in DNS".lower().strip() in error_message.lower().strip():
            return "Content value error. Please enter valid input"
        if "All data was not consumed" in error_message.lower().strip():
            return "The record type and content did not match. Please enter valid input"
        if "Not in expected format" in error_message.lower().strip():
            return "Content not in expected format. Please try again with valid content format."
        if "is not canonical" in error_message.lower().strip():
            return "DNS Name is not canonical. Please try again with canonical DNS name"
        if "could not find domain" in error_message.lower().strip():
            return "Could not find domain"
        if "name is out of zone" in error_message.lower().strip():
            return "Hostname ending in period is considered as FQDN. {} does not belong to zone {}".format(
                    record_name, domain_name)
        if "unable to parse dns name" in error_message.lower().strip():
            return "{} is not a valid FQDN and doesnot belong to zone {}".format(record_name,
                                                                                 domain_name)
        if "Parsing record content (try 'pdnsutil check-zone'): expected digits at position" in error_message.lower().strip():
            return "Please enter valid priority."
        return error_message

    def list_zones(self):
        response = {
            "status": False,
            "message": None,
            "data": None
        }

        url = self.base_url + self.METHODS["zones"]
        logger.debug(f"url: {url}")

        headers = {
            'x-api-key': self.api_key
        }

        try:
            http_response = requests.request("GET", url, headers=headers)
            logger.debug(f"http_response: {http_response}")

            result = json.loads(http_response.text)

            response["status"] = True
            response["message"] = "success"
            response["data"] = result
        except Exception as e:
            logger.error(f"DNS_ERROR - zone listing failed {e} - ALERT")
            response["message"] = e

        logger.debug(f"response: f{response}")
        return response

    def create_zone(self, name, nameservers, kind="Native", masters=[]):
        """
        Creates a new zone in the DNS
        For info - https://doc.powerdns.com/md/authoritative/modes-of-operation/
                 - https://doc.powerdns.com/md/httpapi/api_spec/

        Args:
            name: the domain name
            nameservers: string list of name servers
            kind: By default it is Native.
            kind Authoritative: <kind>: Native, Master or Slave
            Native replication basically means that PowerDNS will not send out DNS update notifications,
             nor will react to them. PowerDNS assumes that the backend is taking care of replication unaided.
            masters: By default it is empty

        Returns:

        """
        logger.debug(f"name: {name}")
        logger.debug("nameservers: {nameservers}")
        logger.debug("kind: {kind}")
        logger.debug("masters: {masters}")

        response = {
            "status": False,
            "message": None,
            "data": None
        }

        url = self.base_url + self.METHODS["zones"]

        headers = {
            'x-api-key': self.api_key,
            'content-type': "application/json",
        }

        data = {
            "name": name,
            "kind": kind,
            "masters": masters,
            "nameservers": nameservers,
        }

        try:
            http_response = requests.request("POST", url, headers=headers, data=json.dumps(data))
            logger.debug(f"http_response: {http_response}")

            result = json.loads(http_response.text)

            if "error" in result:
                response["status"] = False
                response["message"] = result["error"]
                response["data"] = result

                logger.debug(f"response: {response}")
                return response

            response["status"] = True
            response["message"] = "success"
            response["data"] = result
        except Exception as e:
            logger.error(f"DNS_ERROR - create zone failed {e} - ALERT")
            response["message"] = e

        logger.debug(f"response: {response}")
        return response

    def show_zone(self, zone_name):
        """
        Show the zone information for the given zone name.
        More info - https://doc.powerdns.com/md/httpapi/api_spec/
        Args:
            zone_name:

        Returns:

        """
        logger.debug(f"zone_name: {zone_name}")

        response = {
            "status": False,
            "message": None,
            "data": None
        }

        url = self.base_url + self.METHODS["zones"] + "/" + zone_name
        logger.debug(f"url: {url}")

        headers = {
            'x-api-key': self.api_key,
        }

        try:
            http_response = requests.request("GET", url, headers=headers)
            logger.debug(f"http_response: {http_response}")

            result = json.loads(http_response.text)

            response["status"] = True
            response["message"] = "success"
            response["data"] = result
        except Exception as e:
            logger.error(f"DNS_ERROR - show zone failed {e} - ALERT")
            response["message"] = e

        logger.debug("response: {response}")
        return response

    def add_record_with_diff_host(self, zone_name, record_name, content, record_type,
                                  disabled=False, record_ttl=None):
        """
        Add a new record to the zone.
        Would replace any existing record_name.zone_name
        Args:
            zone_name: the name of the zone for which we need to add record
            record_name: Full name of the RRset to modify
            content: the record content. Must confirm to the DNS content rules for the specified type
            record_type: Type of the RRset to modify
            disabled: if this record will be hidden from DNS. (true: hidden, false: visible (the default)).
            record_ttl: the ttl for the record. None would take the manager's default

        Returns:

        """
        logger.debug(f"zone_name: {zone_name}")
        logger.debug(f"record_name: {record_name}")
        logger.debug(f"content: {content}" + str())
        logger.debug(f"record_type: {record_type}")
        logger.debug(f"disabled: {disabled}")
        logger.debug(f"record_ttl: {record_ttl}")

        response = {
            "status": False,
            "message": None,
            "data": None
        }

        url = self.base_url + self.METHODS["zones"] + "/" + zone_name
        logger.debug(f"url: {url}")

        headers = {
            'x-api-key': self.api_key,
            'content-record_type': "application/json",
        }

        record_ttl = self.record_ttl if not record_ttl else record_ttl

        data = {
            "rrsets": [
                {
                    "name": record_name,  # "test.example2.org.",
                    "type": record_type,
                    "ttl": record_ttl,
                    "changetype": "REPLACE",
                    "records": [
                        {
                            "content": content,
                            "disabled": disabled
                        }
                    ]
                }
            ]
        }

        try:
            http_response = requests.request("PATCH", url, headers=headers, data=json.dumps(data))
            logger.debug(f"http_response: {http_response}")

            if http_response.status_code == 204:
                response["status"] = True
                response["message"] = "success"
            else:
                response["status"] = False
                response["message"] = self._get_clean_error_message(http_response.text,
                                                                    domain_name=zone_name,
                                                                    record_name=record_name)
        except Exception as e:
            logger.error(f"DNS_ERROR - Add zone record failed {e} - ALERT")
            response["message"] = e

        logger.debug(f"response: {response}")
        return response

    def add_record_with_same_host(self, zone_name, content, record_type, record_ttl=None,
                                  record_name=None):
        """
        Adds a A, AAAA, NS, MX, TXT type record.

        For records which have same hostname, fetches the previous records for hostname and appends
        new record to it.
        Args:
            zone_name: name of the zone
            record_name: FQDN. If None, zone_name is considered as record_name
            content: IPv4 / IPv6 / FQDN /priority FQDN /text
            record_type: type of record
            record_ttl: ttl of record. If None, manager's default TTL will be taken
        Returns:
            response object

        """
        response = {
            "status": False,
            "message": None,
            "data": None
        }

        zone_response = self.show_zone(zone_name=zone_name)

        if not zone_response["status"]:
            logger.debug("Zone response not correct")
            response["message"] = zone_response["message"]

            logger.debug(f"response: {response}")
            return response

        if not record_name:
            record_name = zone_name

        previous_records = filter(lambda x: x["type"] == record_type and x["name"] == record_name,
                                  zone_response["data"]["rrsets"])
        previous_records = list(previous_records)

        record = {"content": content, "disabled": False}

        if previous_records:
            if record in previous_records[0]["records"]:
                response["message"] = "Record already exists."
                return response

            records = previous_records[0]

            # update record_ttl if specified
            if record_ttl:
                records["ttl"] = record_ttl
        else:
            # default ttl in case no previous record is present and no record_ttl specified
            if not record_ttl:
                record_ttl = self.domain_ttl if record_type == "NS" else self.record_ttl

            records = {
                "name": record_name,
                "type": record_type,
                "ttl": record_ttl,
                "records": []
            }

        records["records"].append(record)

        url = self.base_url + self.METHODS["zones"] + "/" + zone_name
        logger.debug(f"url: {url}")

        headers = {
            'x-api-key': self.api_key,
            'content-record_type': "application/json",
        }

        data = {
            "rrsets": [
                {
                    "name": records["name"],  # "test.example2.org.",
                    "type": records["type"],
                    "ttl": records["ttl"],
                    "changetype": "REPLACE",
                    "records": records["records"]
                }
            ]
        }

        try:
            http_response = requests.request("PATCH", url, headers=headers, data=json.dumps(data))
            logger.debug(f"http_response: {http_response}")

            if http_response.status_code == 204:
                response["status"] = True
                response["message"] = "success"
            else:
                response["status"] = False
                response["message"] = self._get_clean_error_message(http_response.text,
                                                                    domain_name=zone_name,
                                                                    record_name=record_name)
        except Exception as e:
            logger.error(f"DNS_ERROR - Add zone record failed {e}")
            response["message"] = e

        logger.debug(f"response: {response}")
        return response

    def delete_zone(self, name):
        """
        Delete the sepcified zone
        Args:
            name: name of the zone to be deleted

        Returns:

        """
        logger.debug(f"name: {name}")

        response = {
            "status": False,
            "message": None,
            "data": None
        }

        url = self.base_url + self.METHODS["zones"] + "/" + name
        logger.debug(f"url: {url}")

        headers = {
            'x-api-key': self.api_key,
        }

        try:
            http_response = requests.request("DELETE", url, headers=headers)
            logger.debug(f"http_response: {http_response}")

            if http_response.status_code == 204:
                response["status"] = True
                response["message"] = "success"
            else:
                response["status"] = False
                response["message"] = self._get_clean_error_message(http_response.text,
                                                                    domain_name=name)
        except Exception as e:
            logger.error(f"DNS_ERROR - Delete zone failed {e} - ALERT")
            response["message"] = e

        logger.debug(f"response: {response}")
        return response

    def delete_record_with_diff_host(self, zone_name, record_name, record_type):
        """
        Removes the records from the zone with name: record_name and type: record_type
        Args:
            zone_name: name of the zone from which we need to remove the record
            record_name: name of the record to be removed
            record_type: type of the record to be deleted

        Returns:

        """
        logger.debug(f"zone_name: {zone_name}")
        logger.debug(f"record_name: {record_name}")
        logger.debug(f"record_type: {record_type}")
        response = {
            "status": False,
            "message": None,
            "data": None
        }

        url = self.base_url + self.METHODS["zones"] + "/" + zone_name
        logger.debug(f"url: {url}")

        headers = {
            'x-api-key': self.api_key,
            'content-record_type': "application/json",
        }

        data = {
            "rrsets": [
                {
                    "name": record_name,  # "test.example2.org.",
                    "type": record_type,
                    "changetype": "DELETE"
                }
            ]
        }

        try:
            http_response = requests.request("PATCH", url, headers=headers, data=json.dumps(data))
            logger.debug(f"http_response: {http_response}")

            if http_response.status_code == 204:
                response["status"] = True
                response["message"] = "success"
            else:
                response["status"] = False
                response["message"] = self._get_clean_error_message(http_response.text,
                                                                    domain_name=zone_name,
                                                                    record_name=record_name)
        except Exception as e:
            logger.error(f"DNS_ERROR - Delete record failed {e} - ALERT")
            response["message"] = e

        logger.debug(f"response: {response}")
        return response

    def delete_record_with_same_host(self, zone_name, record_name, content, record_type):
        """
        Removes a A, AAAA, NS, MX, TXT type record.
        Internally fetches all the previous records and removes a record to it and updates it
        Args:
            zone_name: name of the zone
            record_name: name of the record
            content: IPv4 / IPv6 / FQDN / priority FQDN / text
            record_type: type of record
        Returns:
            response object

        """
        response = {
            "status": False,
            "message": None,
            "data": None
        }

        zone_response = self.show_zone(zone_name=zone_name)

        if not zone_response["status"]:
            logger.debug("Zone response not correct")
            response["message"] = zone_response["message"]

            logger.debug(f"response: {response}")
            return response

        previous_records = filter(lambda x: x["type"] == record_type and x["name"] == record_name,
                                  zone_response["data"]["rrsets"])

        previous_records = list(previous_records)

        if not previous_records:
            logger.error("{} records not found".format(record_type))
            response["message"] = "{} record not found".format(record_type)

            logger.debug(f"response: {response}")
            return response

        # record found
        records = previous_records[0]

        # issue #583 update MX TTL
        record_ttl = records["ttl"]

        record_to_remove = {
            "content": content,
            "disabled": False
        }

        if record_to_remove in records["records"]:
            records["records"].remove(record_to_remove)
        else:
            response["message"] = "{} {} {} record does not exists.".format(record_name,
                                                                            record_type, content)
            return response

        url = self.base_url + self.METHODS["zones"] + "/" + zone_name
        logger.debug(f"url: {url}")

        headers = {
            'x-api-key': self.api_key,
            'content-record_type': "application/json",
        }

        data = {
            "rrsets": [
                {
                    "name": records["name"],  # "test.example2.org.",
                    "type": records["type"],
                    "ttl": record_ttl,  # 86400,
                    "changetype": "REPLACE",
                    "records": records["records"]
                }
            ]
        }

        try:
            http_response = requests.request("PATCH", url, headers=headers, data=json.dumps(data))
            logger.debug(f"http_response: {http_response}")

            if http_response.status_code == 204:
                response["status"] = True
                response["message"] = "success"
            else:
                response["status"] = False
                response["message"] = self._get_clean_error_message(http_response.text,
                                                                    domain_name=zone_name,
                                                                    record_name=record_name)
        except Exception as e:
            logger.error(f"DNS_ERROR - Delete record failed {e} - ALERT")
            response["message"] = e

        logger.debug(f"response: {response}")
        return response

    def search(self, query, query_type=None, record_type=None):
        """
        Returns a list of records matching query
        query: search term
        query_type: list of return records can be zone / record / comment
        record_type: type of record to be searched for
        """
        logger.debug("query: " + str(query))
        logger.debug("query_type: " + str(query_type))
        logger.debug("record_type: " + str(record_type))

        response = {
            "status": False,
            "message": None,
            "data": None
        }

        url = self.base_url + self.METHODS["search"]
        logger.debug(f"url: {url}")

        headers = {
            'x-api-key': self.api_key,
            'content-type': "application/json",
        }

        data = {

            "q": query
        }

        try:
            http_response = requests.request("GET", url, headers=headers, params=data)
            logger.debug(f"http_response: {http_response}")

            result = json.loads(http_response.text)
            logger.debug("result: " + str(result))

            if "error" in result:
                response["status"] = False
                response["message"] = result["error"]
                response["data"] = result

                logger.debug(f"response: {response}")
                return response

            if record_type:
                result = list(
                    filter(lambda x: (x["object_type"] == "record" and x["type"] == record_type),
                           result))
            if query_type:
                result = list(filter(lambda x: (x["object_type"] == query_type), result))

            response["status"] = True
            response["message"] = "success"
            response["data"] = result
        except Exception as e:
            logger.error(f"DNS_ERROR - search record failed {e} - ALERT")
            response["message"] = e

        logger.debug(f"response: {response}")
        return response

    def update(self, zone_name, record_name, record_type, old_content, new_content, new_ttl,
               disabled=False):
        """
        Updates the record with record_name, record_type.

        old_content is replaced with new_content and ttl with new_ttl.

        Changing hostname in a update call is not allowed right now.
        In order to support hostname change two rrsets of changetype:REPLACE with updated records 
        for each hostname have to to be sent.
        Args:
            zone_name: the name of the zone for which we need to update record
            record_name: Full name of the RRset to modify
            old_content: the record content to be deleted.
            new_content: the record content to be added.
            new_ttl: the ttl for the record. None would take the manager's default or will not change
            disabled: if this record will be hidden from DNS. (true: hidden, false: visible (the default)).
        Returns:

        """
        logger.debug(f"zone_name: {zone_name}")
        logger.debug(f"record_name: {record_name}")
        logger.debug(f"record_type: {record_type}")
        logger.debug(f"old_content: {old_content}")
        logger.debug(f"new_content: {new_content}")
        logger.debug(f"new_ttl: {new_ttl}")
        logger.debug(f"disabled: {disabled}")

        response = {
            "status": False,
            "message": None,
            "data": None
        }

        zone_response = self.show_zone(zone_name=zone_name)

        if not zone_response["status"]:
            logger.debug("Zone response not correct")
            response["message"] = zone_response["message"]

            logger.debug(f"response: {response}")
            return response

        # check when record_name is None
        if not record_name:
            record_name = zone_name

        previous_records = filter(lambda x: x["type"] == record_type and x["name"] == record_name,
                                  zone_response["data"]["rrsets"])
        previous_records = list(previous_records)

        if not previous_records:
            response["message"] = "No record exists for {} of {} type.".format(record_name,
                                                                               record_type)
            logger.error("No record exists for {} of {} type. zone_response".format(record_name,
                                                                                    record_type,
                                                                                    zone_response))
            return response

        record_to_del = {"content": old_content, "disabled": False}
        record_to_add = {"content": new_content, "disabled": False}

        updated_records = previous_records[0]

        updated_records["records"].remove(record_to_del)

        if record_to_add in updated_records["records"]:
            response["message"] = "Record already exists."
            return response

        updated_records["records"].append(record_to_add)

        if new_ttl:
            updated_records["ttl"] = new_ttl

        url = self.base_url + self.METHODS["zones"] + "/" + zone_name
        logger.debug(f"url: {url}")

        headers = {
            'x-api-key': self.api_key,
            'content-record_type': "application/json",
        }

        data = {
            "rrsets": [
                {
                    "name": updated_records["name"],
                    "type": updated_records["type"],
                    "ttl": updated_records["ttl"],
                    "changetype": "REPLACE",
                    "records": updated_records["records"],
                }
            ]
        }

        try:
            http_response = requests.request("PATCH", url, headers=headers, data=json.dumps(data))
            logger.debug(f"http_response: {http_response}")

            if http_response.status_code == 204:
                response["status"] = True
                response["message"] = "success"
            else:
                response["status"] = False
                response["message"] = self._get_clean_error_message(http_response.text)
        except Exception as e:
            logger.error(f"DNS_ERROR - update record failed {e} - ALERT")
            response["message"] = e

        logger.debug(f"response: {response}")
        return response

    def resolve_dns(self, query, record_type="A"):
        """
        Resolve domain name or an IP address using our nameservers

        query (String): Domain Name or IP Address to be resolved
        record_type: Type of record
        Returns (String):
            IP Address if record_type is A, AAAA or CNAME
            target if record_type is PTR
        """
        result = ""

        logger.debug(f"query: {query}")
        logger.debug(f"record_type: {record_type}")

        nameservers = []

        for nameserver in self.dns_nameserver:
            nameservers.append(socket.gethostbyname(nameserver))

        # resolver.default_resolver = resolver.Resolver(configure=False)
        e2e_resolver = resolver.Resolver(configure = False)
        e2e_resolver.nameservers = nameservers
        # resolver.default_resolver.nameservers = nameservers

        try:
            if record_type.lower().strip() == "cname":
                try:
                    answer = e2e_resolver.query(query, "A")
                except Exception as e:
                    answer = e2e_resolver.query(query, "AAAA")
            else:
                answer = e2e_resolver.query(query, record_type)

            logger.debug(f"answer: {answer}")

            for rdata in answer:
                result = str(rdata)

            logger.debug(f"answer: {result}")

        except Exception as e:
            logger.error(e)
            raise e

        return result

    def ns_global_resolve(self, domain):
        ns = []
        try:
            nameservers = resolver.query(domain,'NS')
        except Exception as e:
            logger.error(f"DNS_ERROR - Error resolving nameserver. domain name not found {e}")
            return ns

        for nameserver in nameservers:
            ns.append(nameserver.to_text())

        return ns

    def set_ptr_default(self, ip_address):
        """
        Sets the given IP's reverse dns record to default.
        :return:
        """
        response = {
            "status": False,
            "message": "Custom Reverse DNS record cannot be set to default",
            "data": None
        }

        logger.debug(f"PTR record to be set to default for ip_address: {ip_address}")

        record_name = str(reversename.from_address(ip_address))

        if valid_ipv4(ip_address):
            # IPv4 .1 is first IP in series
            host = ip_address.split(".")[-1]
            network_first_ip = "{}.1".format(ip_address[: ip_address.rfind(".")])
            reverse_zone_name = ".".join(record_name.split(".")[1:])
        elif valid_ipv6(ip_address):
            # IPv6 ::10 is first IP in series
            host = ip_address.split("::")[-1]
            network_first_ip = "{}::10".format(ip_address.split("::")[0])
            reverse_ip_octet = ".".join(list(ip_address.split("::")[1])[::-1])
            reverse_zone_name = record_name.replace(reverse_ip_octet + ".", "", 1)
        else:
            response["message"] = "Invalid IP Address"
            return response

        logger.debug("host: {}".format(host))
        logger.debug("network_first_ip: {}".format(network_first_ip))

        first_ip_reverse_address = str(reversename.from_address(network_first_ip))
        try:
            default_ptr_target = self.resolve_dns(first_ip_reverse_address, "PTR")
        except Exception as e:
            logger.error(f"DNS_ERROR - default PTR record not found for {first_ip_reverse_address}, Error: {e} - ALERT")
            return response

        new_ptr_target = default_ptr_target[:default_ptr_target.rfind("-") + 1] + host + default_ptr_target[default_ptr_target.find("."):]

        logger.debug("first_ip_reverse_address: {}".format(first_ip_reverse_address))
        logger.debug("default_ptr_target: {}".format(default_ptr_target))
        logger.debug("new_ptr_target: {}".format(new_ptr_target))

        # custom PTR is replaced by default ptr
        delete_record_result = self.add_record_with_diff_host(zone_name = reverse_zone_name,
                                                                          content = new_ptr_target,
                                                                          record_type = "PTR",
                                                                          record_name = record_name)

        if not delete_record_result["status"]:
            response["message"] = delete_record_result["message"]
            logger.debug("response: {}").format(response)
            return response

        response["status"] = True
        response["message"] = "Custom Reverse DNS Record set to default successfully"

        logger.debug("response: {}".format(response))
        return response
