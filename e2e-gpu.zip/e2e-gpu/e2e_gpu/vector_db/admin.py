from django.contrib import admin
from safedelete.admin import SafeDeleteAdmin

from vector_db.models import (Qdrant, VectorDB, VectorDBHistory,
                              VectorDBPVCHistory, VectorDBSnapshots)


class VectorDBAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "deleted_at",
        "id",
        "name",
        "vectordb_type",
        "status",
        "project",
        "sku_item_price",
        "created_by",
        "created_at",
        "updated_at",
    )
    raw_id_fields = ("created_by", "sku_item_price", "project")
    search_fields = ("id", "created_by__email", "project__id", "name")
    list_filter = ("deleted_at", 'deleted', "vectordb_type", "status", "sku_item_price__sku__series", ("sku_item_price__sku", admin.RelatedOnlyFieldListFilter))
    list_display_links = ("id", "name")
    list_select_related = ("created_by", "sku_item_price", "project", "sku_item_price__sku", "sku_item_price__currency")
    read_only_fields = ()


class QdrantAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "vector_db",
        "disk_size",
        "replicas"
    )
    list_filter = ['deleted']
    list_select_related = ['vector_db']
    list_display_links = ['id', 'vector_db']
    raw_id_fields = ['vector_db']
    read_only_fields = []


class VectorDBHistoryAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "vector_db",
        "customer",
        "start_date",
        "end_date",
        "sku_item_price",
        "replicas",
    )
    raw_id_fields = ("vector_db", "customer", "sku_item_price")
    list_filter = ("deleted", "sku_item_price__sku_type", "sku_item_price__committed_days", "sku_item_price__sku__is_free", ("sku_item_price__sku", admin.RelatedOnlyFieldListFilter),)
    list_select_related = ['vector_db', 'customer', 'sku_item_price', 'sku_item_price__sku', 'sku_item_price__currency',]
    list_display_links = ['id', 'vector_db']
    search_fields = ('id', 'vector_db__name', 'customer__email', 'start_date', 'end_date')


class VectorDBPVCHistoryAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "vector_db",
        "disk_size",
        "replicas",
        "customer",
        "start_date",
        "end_date",
    )
    raw_id_fields = ("vector_db", "customer")
    search_fields = ('id', 'vector_db__name', 'customer__email', 'disk_size')
    list_filter = ("deleted",)
    list_display_links = ['id', 'vector_db']
    list_select_related = ['vector_db', 'customer']


class VectorDBSnapshotsAdmin(SafeDeleteAdmin):
    list_display = SafeDeleteAdmin.list_display + (
        "id",
        "snapshot_time",
        "vector_db",
        "status",
        "secret_key",
        "restoring_status",
        "deleted_at",
        "upload_count",
        "download_count"
    )

    raw_id_fields = ("vector_db", )
    search_fields = ('id', 'vector_db__name', 'snapshot_time')
    list_filter = ("deleted_at", )
    list_display_links = ['id', 'snapshot_time']
    list_select_related = ['vector_db']


admin.site.register(VectorDB, VectorDBAdmin)
admin.site.register(Qdrant, QdrantAdmin)
admin.site.register(VectorDBHistory, VectorDBHistoryAdmin)
admin.site.register(VectorDBPVCHistory, VectorDBPVCHistoryAdmin)
admin.site.register(VectorDBSnapshots, VectorDBSnapshotsAdmin)
