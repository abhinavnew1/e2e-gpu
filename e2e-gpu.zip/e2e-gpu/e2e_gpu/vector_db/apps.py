from django.apps import AppConfig


class VectorDbConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'vector_db'
