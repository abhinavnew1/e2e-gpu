from django.conf import settings

from e2e_core.constants import MAX_LENGTH_ERROR

QDRANT_CREATE_COLLECTIONS_URL = "https://{hostname}:6333/collections/{collection_name}"
CREATE_QDRANT_URL = settings.GROOT_BASE_URL + "/api/namespaces/{namespace}/qdrant"
LIST_PVC_URL = settings.GROOT_BASE_URL + "/api/namespaces/{namespace}/pvcs"
GET_PVC_URL = settings.GROOT_BASE_URL + "/api/namespaces/{namespace}/pvcs/{pvc_name}"
UPDATE_QDRANT_PVC_URL = settings.GROOT_BASE_URL + "/api/namespaces/{namespace}/pvcs/{pvc_name}"
LIST_QDRANT_URL = settings.GROOT_BASE_URL + "/api/namespaces/{namespace}/qdrant"
LIST_QDRANT_PODS_URL = settings.GROOT_BASE_URL + "/api/namespaces/{namespace}/qdrant/{qdrant_slug_name}/pods"
GET_QDRANT_DETAILS_URL = settings.GROOT_BASE_URL + "/api/namespaces/{namespace}/qdrant/{qdrant_slug_name}"
DELETE_QDRANT_URL = settings.GROOT_BASE_URL + "/api/namespaces/{namespace}/qdrant/{qdrant_slug_name}"
UPDATE_QDRANT_URL = settings.GROOT_BASE_URL + "/api/namespaces/{namespace}/qdrant/{qdrant_slug_name}"
VECTOR_DB_GATEWAY_URL = settings.GROOT_BASE_URL + "/api/namespaces/{namespace}/gateways/{gateway_name}"

QDRANT_COLLECTION_CREATION_TASK = 'qdrant_collection_creation_task'
QDRANT_CREATE_COLLECTION_TASK_COUNTDOWN = 15
QDRANT_COLLECTION_CREATION_TASK_RETRY_DELAY = 30
QDRANT_COLLECTION_CREATION_TASK_MAX_RETRIES = 30
QDRANT_REPLICAS_PVC_UPGRADATION_TASK = 'qdrant_replicas_pvc_upgradation_task'
QDRANT_REPLICAS_PVC_UPGRADATION_TASK_COUNTDOWN = 30
QDRANT_REPLICAS_PVC_UPGRADATION_TASK_DELAY = 60
QDRANT_REPLICAS_PVC_UPGRADATION_TASK_MAX_RETRIES = 20

QDRANT_SNAPSHOT_FILE_SEARCH_TASK = "qdrant_snapshot_files_search_task"
QDRANT_SNAPSHOT_RETRY_BACKOFF = 60
QDRANT_SNAPSHOT_RETRY_BACKOFF_MAX = 900
QDRANT_SNAPSHOT_RETRY_DELAY = 40
QDRANT_SNAPSHOT_MAX_RETRIES = 11
QDRANT_SNAPSHOT_TASK_COUNTDOWN = 200

QDRANT_UPDATE_SNAPSHOT_STATUS_TASK = "qdrant_update_snapshot_status_task"

QDRANT_SNAPSHOT_RESTORATION_TASK = "qdrant_snapshot_restoration_task"

QDRANT_SNAPSHOT_DELETION_TASK = "qdrant_snapshot_deletion_task"
QDRANT_SNAPSHOT_DELETION_RETRY_DELAY = 10
QDRANT_SNAPSHOT_DELETION_MAX_RETRIES = 3

QDRANT_PVC_UPGRADE_EVENT = 'QDRANT_PVC_UPGRADE'
VECTOR_DB_CREATE_EVENT = 'VECTOR_DB_CREATE'
VECTOR_DB_UPDATE_EVENT = 'VECTOR_DB_UPDATE'
VECTOR_DB_DELETE_EVENT = 'VECTOR_DB_DELETE'
VECTOR_DB_SNAPSHOT_CREATE_EVENT = 'VECTOR_DB_SNAPSHOT_CREATE'
VECTOR_DB_SNAPSHOT_DELETE_EVENT = 'VECTOR_DB_SNAPSHOT_DELETE'
VECTOR_DB_SNAPSHOT_RESTORE_EVENT = 'VECTOR_DB_SNAPSHOT_RESTORE'

REDUCTION_NOT_ALLOWED = "{service} can't be reduced"

UPGRADE_PVC_SUCCESS = "Disk Size upgraded successfully. It can take a few minutes for the changes to get reflected"
SNAPSHOT_CREATION_SUCCESS = "Snapshot Creation Scheduled."
SNAPSHOT_RESTORATION_SUCCESS = "Snapshot Restoration Scheduled."
SNAPSHOT_DELETION_SUCCESS = "Snapshot Deleted Successfully"

BACKEND_ERROR = "Error occured at backend! Please try after sometime."
COLLECTION_CREATION_FAILED_ERROR = "Collections Creation failed."
FETCHING_ERROR = 'Error while fetching {service} details'
INVALID_REQUEST = 'Invalid Reuquest'
SKU_INVENTORY_UNAVAILABLE = "Inventory temporarily unavailable. Please try again after some time."
SNAPSHOT_CREATION_FAILED = "Snapshot Creation Failed."
SNAPSHOT_NOT_FOUND = "Invalid request! Snapshot Not Found"
SNAPSHOT_RESTORATION_FAILED = "Snapshot Restoration Failed."
SNAPSHOT_CANNOT_BE_RESTORED_ERROR = "Invalid request! Snapshot Not Created"
SNAPSHOT_DELETION_FAILED = "Invalid request! Snapshot Deletion Failed"
SNAPSHOT_CREATION_IN_PROGRESS = "Invalid request! Snapshot creation in progress."
VECTOR_DB_NOT_READY = 'Vector database NOT in RUNNING state. Please Try again later.'
VECTOR_DB_MONITORING_DATA_GET_ERROR = "Prometheus server connection error"
VECTOR_DB_INVALID_REQUEST = 'Invalid request! VectorDB Not Found'
VECTOR_DB_NO_COLLECTION_IN_CLUSTER_ERROR = 'No Collection is present in cluster'
VECTOR_DB_HISTORY_AMBIGUITY_ERROR = 'VectorDB History Table has {count} entries for vector_db: {vectordb_id}'
VECTOR_DB_HISTORY_AMBIGUITY_SUBJECT = 'VectorDB History inconsistency for customer: {email_id}'
VECTOR_DB_GATEWAY_PATCH_FAILED_ERROR = 'Failed to add url in VectorDB gateway for vectordb_hosts: {vectordb_hosts} | Error: {errors}'
VECTOR_DB_GATEWAY_PATCH_FAILED_SUBJECT = 'VectorDB gateway url additon failed for customer: {email_id}'
QDRANT_PVC_UPGRADATION_FAILED_MESSAGE = 'Qdrant pvc upgradation failed for vector_db: {vectordb_id}. \n errors: Failed to upgrade following pvcs : {pvcs}'
QDRANT_PVC_UPGRADATION_FAILED_SUBJECT = 'Qdrant pvc upgradation failed for customer: {email_id}'
QDRANT_REPLICAS_PVC_UPGRADATION_FAILED_MESSAGE = 'Qdrant replicas pvc upgradation failed for vector_db: {vectordb_id}. \n errors: {errors}'
QDRANT_REPLICAS_PVC_UPGRADATION_FAILED_MAX_RETRIES_REACHED_MESSAGE = 'Qdrant replicas pvc upgradation failed for vector_db: {vectordb_id} | error: MAX_RETRIES_REACHED'
QDRANT_REPLICAS_PVC_UPGRADATION_FAILED_SUBJECT = 'Qdrant replicas pvc upgradation failed for customer: {email_id}'
QDRANT_REPLICAS_PVC_UPGRADATION_MAX_RETRIES_REACHED_FAILED_SUBJECT = 'Qdrant replicas pvc upgradation failed: max retries reached for customer: {email_id}'
QDRANT_COLLECTION_CREATION_MAX_RETRIES_REACHED_SUBJECT = 'Qdrant default collection creation failed for customer: {email_id}'
QDRANT_COLLECTION_CREATION_FAILED_MAX_RETRIES_REACHED_MESSAGE = 'Qdrant default collection creation failed for vector_db: {vectordb_id}: error: MAX_RETRIES_REACHED | Either VectorDB is not Running or failed response from collection creation api.'
QDRANT_DELETION_FAILED_MESSAGE = 'Qdrant deletion failed for Vector Databse: {vectordb_id} for customer: {email_id}'
QDRANT_DELETION_FAILED_SUBJECT = 'Qdrant deletion failed for Vector Databse: {vectordb_id}'
QDRANT_RESTORATION_FAILED_MESSAGE = 'Qdrant restoration failed for Vector Databse: {vectordb_id} for snapshot {snapshot_id}'
QDRANT_RESTORATION_FAILED_SUBJECT = 'Qdrant restoration failed for Vector Databse: {vectordb_id}'
QDRANT_SNAPSHOT_DELETION_FAILED_MESSAGE = 'Qdrant snapshot: {snapshot_id} deletion failed for Vector Databse: {vectordb_id}.'
QDRANT_SNAPSHOT_DELETION_FAILED_SUBJECT = 'Qdrant snapshot deletion failed for Vector Databse: {vectordb_id}'

QDRANT_NAME = 'qdrant-{}'
QDRANT_PVC_PREFIX = 'qdrant-storage-qdrant-{}'
QDRANT_PVC_NAME = 'qdrant-storage-qdrant-{}-{}'
VECTOR_DB_DNS_PREFIX = '{id}v{uuid_str}'
QDRANT_DASHBOARD_URL = 'https://{}:6333/dashboard'
VECTORDB_GATEWAY_NAME = 'vectordb-gateway'
VECTORDB_GATEWAY_NAMESPACE = 'kubeflow'
VECTOR_DB_CREATION_TEMPLATE_NAME = 'vector_db/vectordb_creation_success.html'
VECTOR_DB_REPLICA_UPDATION_TEMPLATE_NAME = 'vector_db/vector_db_replica_updation.html'
VECTOR_DB_SNAPSHOT_RESTORATION_TEMPLATE_NAME = 'vector_db/vector_db_snapshot_restoration.html'
VECTOR_DB_SNAPSHOT_RESTORATION_FAIL_TEMPLATE_NAME = 'vector_db/vector_db_snapshot_restoration_fail.html'

VECTOR_DB_DEFAULT_DISK_SIZE = 30
MINIMUM_QDRANT_DISK_SIZE = 10
MAXIMUM_QDRANT_DISK_SIZE = 1000
MINIMUM_QDRANT_DISK_SIZE_ERROR = f'Disk size not allowed less than {MINIMUM_QDRANT_DISK_SIZE}.'
MAXIMUM_QDRANT_DISK_SIZE_ERROR = f'Disk size not allowed greater than {MAXIMUM_QDRANT_DISK_SIZE}'

VECTOR_DB_NAME_REGEX = r'[a-z0-9]([-a-z0-9]*[a-z0-9])?'
VECTOR_DB_NAME_MAX_LENGTH = 50
VECTOR_DB_NAME_INVALID = "VectorDB name should contain letters, digits and hyphen only."
VECTOR_DB_NAME_ALREADY_EXISTS = "VectorDB with the same name already exists in the Project."
VECTOR_DB_NAME_MAX_LENGTH_ERROR = MAX_LENGTH_ERROR.format(field_name="VectorDB Name", max_length=VECTOR_DB_NAME_MAX_LENGTH)

CONTAINER_MEMORY_USAGE_KEY = "container_memory_usage_bytes"
CONTAINER_CPU_USAGE_KEY = "container_cpu_usage_seconds_total"
COLLECTION_VECTOR_TOTAL = "collections_vector_total"

QDRANT_SIDECAR_UPLOAD_URL = "https://{endpoint_url}:6333/node-{node}-snapshot/snapshot/upload"
QDRANT_SIDECAR_DOWNLOAD_URL = "https://{endpoint_url}:6333/node-{node}-snapshot/snapshot/download"
QDRANT_SIDECAR_DELETE_URL = "https://{endpoint_url}:6333/node-{node}-snapshot/snapshot/delete"
QDRANT_SIDECAR_RESTORE_URL = "https://{endpoint_url}:6333/node-{node}-snapshot/snapshot/restore"

QDRANT_DELETE_SNAPSHOT_URL = "https://{endpoint_url}:6333/node-{node}/collections/{collection}/snapshots/{snapshot_name}"
QDRANT_RECOVER_SNAPSHOT_URL = "https://{endpoint_url}:6333/node-{node}/collections/{collection}/snapshots/recover?wait=false"
QDRANT_RESTORE_FILE_PATH = "file:///qdrant/storage/restore/{snapshot_time}/{snapshot_name}"
QDRANT_GET_SNAPSHOT_URL = "https://{endpoint_url}:6333/node-{node}/collections/{collection}/snapshots"
QDRANT_LIST_COLLECTION_URL = "https://{endpoint_url}:6333/node-{node}/collections"
QDRANT_CREATE_SNAPSHOT_URL = "https://{endpoint_url}:6333/node-{node}/collections/{collection}/snapshots?wait=false"

QDRANT_APIS_CONTENT_TYPE = 'application/json'
SNAPSHOT_DATE_TIME_FORMAT = '%Y-%m-%dT%H:%M:%S'

# pvc status
BOUND = 'Bound'
READY = 'ready'
# vector_db status
RUNNING = 'Running'
CREATING = 'Creating'
DONE = 'Done'
ERROR = 'Error'
RESTORING = 'Restoring'
RESTORE_FAILED = 'Restore Failed'

# vector_db snapshot status
CREATED = 'Created'
FAILED = 'Failed'

# operations for upload and download snapshot hook call
UPLOAD = 'Upload'
DOWNLOAD = 'Download'
RESTORE = 'Restore'

VECTOR_DB_STATUS_CHOICES = (
    (RUNNING, RUNNING),
    (CREATING, CREATING),
    (DONE, DONE),
    (ERROR, ERROR),
    (RESTORING, RESTORING),
    (RESTORE_FAILED, RESTORE_FAILED),
)
VECTOR_DB_SNAPSHOT_CHOICES = (
    (CREATING, CREATING),
    (CREATED, CREATED),
    (FAILED, FAILED),
)

QDRANT = 'Qdrant'
VECTOR_DB_TYPE_CHOICES = (
    (QDRANT, QDRANT),
)

DISTANCE_CHOICES = (
    ('Dot', 'Dot'),
    ('Cosine', 'Cosine'),
    ('Euclid', 'Euclid'),
    ('Manhattan', 'Manhattan'),
)

SHARDING_METHOD_CHOICES = (
    ('auto', 'auto'),
)
QDRANT_API_KEYS_VAULT_PATH = "secret/vector_db/api_keys-{vectordb_obj_id}"

INTERVAL_TO_TIME_FORMAT_MAPPING = {
                                        '5m': [300, '%I:%M:%S%p', 15],
                                        '1h': [3600, '%I:%M%p', 180],
                                        '1d': [86400, '%I:%M:%p', 3600],
                                        '7d': [604800, '%m/%d/%Y, %I%p', 28800],
                                        '1mn': [2592000, '%m/%d/%Y', 86400]
                                }

SNAPSHOT_AUTH_SECRET_LENGTH = 32
