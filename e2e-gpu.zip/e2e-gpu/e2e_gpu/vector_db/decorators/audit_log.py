from rest_framework import status

from eventlogs.api.v1.services.eventlog_service import EventLogService
from eventlogs.constants import (CREATE, DELETE, EVENTLOG_SUCCESS_STATUS,
                                 UPDATE, VECTOR_DB_SERVICE_CODE,
                                 VECTOR_DB_SNAPSHOT_SERVICE_CODE)
from vector_db.constants import (SNAPSHOT_DATE_TIME_FORMAT,
                                 QDRANT_PVC_UPGRADE_EVENT,
                                 VECTOR_DB_CREATE_EVENT,
                                 VECTOR_DB_DELETE_EVENT,
                                 VECTOR_DB_UPDATE_EVENT,
                                 VECTOR_DB_SNAPSHOT_CREATE_EVENT,
                                 VECTOR_DB_SNAPSHOT_DELETE_EVENT,
                                 VECTOR_DB_SNAPSHOT_RESTORE_EVENT)


def vectordb_create_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(VECTOR_DB_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=VECTOR_DB_CREATE_EVENT,
            resource_name=request.data.get("name"),
            resource_id="",
            resource_obj_id=None,
            detailed_info={
                "request": request.data,
                "project_id": kwargs.get('project_id')
            },
            event_type=CREATE
        )
        response = func(*args, **kwargs)
        if response.status_code == status.HTTP_201_CREATED:
            event_log.update_log(
                status=EVENTLOG_SUCCESS_STATUS,
                resource_id=response.data['data']['id'],
                detailed_info={
                    "response": response.data['data'],
                    "project_id": kwargs.get('project_id')
                },
                resource_obj_id=response.data['data']['id']
            )
        else:
            event_log.log_event_failure()
        return response
    return wrapper_func


def vectordb_delete_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(VECTOR_DB_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=VECTOR_DB_DELETE_EVENT,
            resource_name=kwargs.get("vectordb").name,
            resource_id=kwargs.get("vectordb_id"),
            resource_obj_id=kwargs.get("vectordb_id"),
            detailed_info={
                "project_id": kwargs.get('project_id')
            },
            event_type=DELETE
        )
        response = func(*args, **kwargs)
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else event_log.log_event_failure()
        return response
    return wrapper_func


def vectordb_update_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(VECTOR_DB_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=VECTOR_DB_UPDATE_EVENT,
            resource_name=kwargs.get('vectordb').name,
            resource_id=kwargs.get('vectordb_id'),
            resource_obj_id=kwargs.get('vectordb_id'),
            detailed_info={
                "project_id": kwargs.get('project_id')
            },
            event_type=UPDATE
        )
        response = func(*args, **kwargs)
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else event_log.log_event_failure()
        return response
    return wrapper_func


def qdrant_pvc_update_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(VECTOR_DB_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=QDRANT_PVC_UPGRADE_EVENT,
            resource_name=kwargs.get('vectordb').name,
            resource_id=kwargs.get('vectordb_id'),
            resource_obj_id=kwargs.get('vectordb_id'),
            detailed_info={
                "new_disk_size": request.data.get('disk_size')
            },
            event_type=UPDATE
        )
        response = func(*args, **kwargs)
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else event_log.log_event_failure()
        return response
    return wrapper_func


def vectordb_snapshot_create_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(VECTOR_DB_SNAPSHOT_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=VECTOR_DB_SNAPSHOT_CREATE_EVENT,
            resource_name="",
            resource_id="",
            resource_obj_id=None,
            detailed_info={
                "request": request.data,
                "project_id": kwargs.get('project_id'),
                "vectordb_name": kwargs.get('vectordb').name
            },
            event_type=CREATE
        )
        response = func(*args, **kwargs)
        if response.status_code == status.HTTP_201_CREATED:
            event_log.update_log(
                status=EVENTLOG_SUCCESS_STATUS,
                resource_name=response.data.get("data").get("snapshot_time"),
                resource_id=response.data.get("data").get("snapshot_id"),
                detailed_info={
                    "project_id": kwargs.get('project_id'),
                    "vectordb_name": kwargs.get('vectordb').name
                },
                resource_obj_id=response.data.get("snapshot_id"),
            )
        else:
            event_log.log_event_failure()
        return response
    return wrapper_func


def vectordb_snapshot_delete_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(VECTOR_DB_SNAPSHOT_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=VECTOR_DB_SNAPSHOT_DELETE_EVENT,
            resource_name=kwargs.get("snapshot").snapshot_time.strftime(SNAPSHOT_DATE_TIME_FORMAT),
            resource_id=kwargs.get("snapshot_id"),
            resource_obj_id=kwargs.get("snapshot_id"),
            detailed_info={
                "project_id": kwargs.get('project_id'),
                "vectordb_name": kwargs.get('vectordb').name
            },
            event_type=DELETE
        )
        response = func(*args, **kwargs)
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else event_log.log_event_failure()
        return response
    return wrapper_func


def vectordb_snapshot_restore_log(func):
    def wrapper_func(*args, **kwargs):
        request = args[1]
        event_log = EventLogService(VECTOR_DB_SERVICE_CODE)
        event_log.create_log(
            request=request,
            event=VECTOR_DB_SNAPSHOT_RESTORE_EVENT,
            resource_name=kwargs.get('vectordb').name,
            resource_id=kwargs.get('vectordb_id'),
            resource_obj_id=kwargs.get('vectordb_id'),
            detailed_info={
                "snapshot_id": request.data.get('snapshot_id')
            },
            event_type=UPDATE
        )
        response = func(*args, **kwargs)
        event_log.log_event_success() if response.status_code == status.HTTP_200_OK else event_log.log_event_failure()
        return response
    return wrapper_func
