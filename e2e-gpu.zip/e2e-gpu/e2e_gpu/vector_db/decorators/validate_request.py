from rest_framework.response import Response

from e2e_core.api.v1.services.base import BaseService
from e2e_core.constants import PARAMS_MISSING_OR_INVALID
from vector_db.constants import RUNNING, SNAPSHOT_NOT_FOUND, VECTOR_DB_INVALID_REQUEST, VECTOR_DB_NOT_READY
from vector_db.helpers import is_pvc_disk_size_valid
from vector_db.models import VectorDB, VectorDBSnapshots


def validate_vectordb_request(func):
    def wrapper_func(*args, **kwargs):
        vectordb_id = kwargs.get("vectordb_id")
        project_id = kwargs.get("project_id")
        vectordb = VectorDB.objects.filter(
                deleted_at__isnull=True,
                id=vectordb_id,
                project_id=project_id
            ).select_related(
                "project", "sku_item_price"
            ).first()
        if not vectordb:
            response = BaseService.get_404_response(VECTOR_DB_INVALID_REQUEST)
            return Response(response, status=response.get('code'))
        kwargs["vectordb"] = vectordb
        return func(*args, **kwargs)
    return wrapper_func


def validate_snapshot_request(func):
    def wrapper_func(*args, **kwargs):
        snapshot_id = kwargs.get("snapshot_id")
        vectordb = kwargs.get("vectordb")
        snapshot = VectorDBSnapshots.objects.filter(
                deleted_at__isnull=True,
                id=snapshot_id,
                vector_db=vectordb
            ).first()
        if not snapshot:
            response = BaseService.get_404_response(SNAPSHOT_NOT_FOUND)
            return Response(response, status=response.get('code'))
        kwargs["snapshot"] = snapshot
        return func(*args, **kwargs)
    return wrapper_func


def validate_upgrade_pvc_request(func):
    def wrapper_func(*args, **kwargs):
        vectordb = kwargs.get('vectordb')
        if vectordb.status != RUNNING:
            return args[0].get_baked_412_response(VECTOR_DB_NOT_READY)
        new_disk_size = args[1]
        if not new_disk_size or not isinstance(new_disk_size, int):
            return args[0].get_baked_400_response(PARAMS_MISSING_OR_INVALID.format(param="Disk size"))
        existing_disk_size = vectordb.qdrant.disk_size
        is_valid, error_str = is_pvc_disk_size_valid(existing_disk_size, new_disk_size)
        if not is_valid:
            return args[0].get_baked_400_response(error_str)
        return func(*args, **kwargs)
    return wrapper_func
