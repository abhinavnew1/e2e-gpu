import hashlib
import json
import logging
import re
import secrets
import string
from datetime import datetime, timedelta

import requests
from dbtemplates.models import Template
from django.conf import settings
from django.db import transaction
from django.template.loader import get_template
from minio import Minio

from e2e_core.datetime_helper import change_timezone, round_to_previous_second, tz_aware
from e2e_core.api.v1.services.mandrill import Mandrill
from e2e_core.helpers import support_ticket_generator
from gpu_service.helpers import is_credit_sufficient_for_inventory_launch, check_inventory_availability_status
from gpu_service.models import SkuItemPrice
from teams.helpers import get_team_owner_admin_email_list
from vector_db.constants import (CREATING, ERROR, MAXIMUM_QDRANT_DISK_SIZE, MAXIMUM_QDRANT_DISK_SIZE_ERROR, MINIMUM_QDRANT_DISK_SIZE, 
                                 MINIMUM_QDRANT_DISK_SIZE_ERROR, QDRANT_APIS_CONTENT_TYPE, QDRANT_DELETE_SNAPSHOT_URL, QDRANT_GET_SNAPSHOT_URL, 
                                 QDRANT_PVC_PREFIX, QDRANT_SIDECAR_DELETE_URL, QDRANT_SIDECAR_DOWNLOAD_URL, QDRANT_SIDECAR_RESTORE_URL, 
                                 QDRANT_SIDECAR_UPLOAD_URL, REDUCTION_NOT_ALLOWED, RESTORE_FAILED, RESTORING, RUNNING, SKU_INVENTORY_UNAVAILABLE, 
                                 SNAPSHOT_AUTH_SECRET_LENGTH, SNAPSHOT_DATE_TIME_FORMAT, VECTOR_DB_CREATION_TEMPLATE_NAME, VECTOR_DB_HISTORY_AMBIGUITY_ERROR, 
                                 VECTOR_DB_HISTORY_AMBIGUITY_SUBJECT, VECTOR_DB_NAME_ALREADY_EXISTS,VECTOR_DB_NAME_INVALID, VECTOR_DB_NAME_REGEX, 
                                 VECTOR_DB_REPLICA_UPDATION_TEMPLATE_NAME, VECTOR_DB_SNAPSHOT_RESTORATION_FAIL_TEMPLATE_NAME, 
                                 VECTOR_DB_SNAPSHOT_RESTORATION_TEMPLATE_NAME)
from vector_db.models import VectorDB

logger = logging.getLogger(__name__)
mandrill_manager = Mandrill(mandrill_api_token=settings.MANDRILL_API_TOKEN, bcc="",
                            from_email=settings.NOTIFY_FROM, notify=settings.NOTIFY_FROM)


def validate_vectordb_name(name, project_id, vectordb_id=None):
    if not re.fullmatch(VECTOR_DB_NAME_REGEX, name):
        return False, VECTOR_DB_NAME_INVALID
    if VectorDB.objects.filter(deleted_at__isnull=True, project_id=project_id, name=name).exclude(id=vectordb_id).exists():
        return False, VECTOR_DB_NAME_ALREADY_EXISTS
    return True, ""


def update_vectordbs_data(vectordbs, groot_vectordbs_list, *args, **kwargs):
    vdb_mapping = {vdb['slug_name']: vdb for vdb in groot_vectordbs_list}
    fields_to_update = ['status']
    for vectordb in vectordbs:
        vdb_data = vdb_mapping.get(vectordb.slug_name)
        if not vdb_data:
            logger.error(f"VECTORDB_INCONSISTENCY | CRITICAL_RED | VECTORDB_DOES_NOT_EXIST_ON_GROOT | VECTORDB_ID:{vectordb.id}")
            if vectordb.status != ERROR:
                vectordb.status = ERROR
            continue
        # Restoring and Restore_failed status are updated from hook call and cannot be updated from Groot get and list calls.
        if vectordb.status == RESTORING or vectordb.status == RESTORE_FAILED:
            vdb_data['status'] = vectordb.status
        if vectordb.status != CREATING or vectordb.status == CREATING and vdb_data['status'] == RUNNING:
            vectordb.status = vdb_data['status']
            fields_to_update.append('updated_at')
    with transaction.atomic():
        VectorDB.objects.bulk_update(vectordbs, fields_to_update)


def update_vectordb_details(vectordb, groot_data, *args, **kwargs):
    fields_to_update = []
    # Restoring and Restore_failed status are updated from hook call and cannot be updated from Groot get and list calls.
    if vectordb.status == RESTORING or vectordb.status == RESTORE_FAILED:
        groot_data['status'] = vectordb.status
    if vectordb.status != CREATING or vectordb.status == CREATING and groot_data['status'] == RUNNING:
        vectordb.status = groot_data['status']
        fields_to_update = ['status', 'updated_at']
    vectordb.save(update_fields=fields_to_update)
    return vectordb


def is_pvc_disk_size_valid(existing_disk_size, new_disk_size):
    if new_disk_size > MAXIMUM_QDRANT_DISK_SIZE:
        return False, MAXIMUM_QDRANT_DISK_SIZE_ERROR
    elif new_disk_size < MINIMUM_QDRANT_DISK_SIZE:
        return False, MINIMUM_QDRANT_DISK_SIZE_ERROR
    elif new_disk_size < existing_disk_size:
        return False, REDUCTION_NOT_ALLOWED.format(sevice='Disk Size')
    return True, ""


def verify_qdrant_pvcs_from_groot(pvc_list, vectordb):
    qdrant_pvc_prefix = QDRANT_PVC_PREFIX.format(vectordb.id)
    res = [pvc['name'] for pvc in pvc_list if pvc['name'].startswith(qdrant_pvc_prefix)]
    if len(res) != vectordb.qdrant.replicas:
        return False, res
    return True, res


def verify_vectordb_history(vectordb, count):
    if count > 1 or count == 0:
        logger.error(f"VECTOR_DB_HISTORY | CRITICAL_RED | ACTIVE_VECTOR_DB_HISTORY_ENTRIES: {count}")
        billable_customer = vectordb.project.team.owner.get_primary_contact()
        support_ticket_generator(
            errors=VECTOR_DB_HISTORY_AMBIGUITY_ERROR.format(count=count, vectordb_id=vectordb.id),
            subject=VECTOR_DB_HISTORY_AMBIGUITY_SUBJECT.format(email_id=billable_customer.email),
            customer=billable_customer
        )


def send_vectordb_creation_email(vectordb):
    cc_email_list = get_team_owner_admin_email_list(vectordb.project.team_id, emails_to_exclude=[vectordb.created_by.email])
    team_name = vectordb.project.team.name
    vectordb_creation_success_template_object = Template.objects.filter(name=VECTOR_DB_CREATION_TEMPLATE_NAME).first()
    if not vectordb_creation_success_template_object:
        logger.error("VECTOR_DB | SEND_VECTOR_DB_CREATION_EMAIL | VECTOR_DB_CREATION_SUCCESS_TEMPLATE_NOT_FOUND")
        return
    subject = vectordb_creation_success_template_object.subject
    body = get_template(VECTOR_DB_CREATION_TEMPLATE_NAME).render(
        {
            "vectordb_name": vectordb.name,
            "vectordb_type": vectordb.vectordb_type,
            "team_name": team_name,
            "project_name": vectordb.project.name,
            "plan_name": vectordb.sku_item_price.sku.name,
            "cloud_support_email_address": settings.CLOUD_PLATFORM_EMAIL
        }
    )
    try:
        mandrill_manager.send_email([], [vectordb.created_by.email], body, subject, cc_email_list=cc_email_list)
    except Exception as e:
        logger.error(f"VECTOR_DB | CRITICAL_RED | SEND_VECTOR_DB_CREATION_EMAIL | Customer - {vectordb.created_by.email} | ERROR_IN_SENDING_EMAIL - {e}")


def send_vectordb_restoration_success_email(vectordb, snapshot):
    cc_email_list = get_team_owner_admin_email_list(vectordb.project.team_id, emails_to_exclude=[vectordb.created_by.email])
    vectordb_snapshot_restoration_template_object = Template.objects.filter(name=VECTOR_DB_SNAPSHOT_RESTORATION_TEMPLATE_NAME).first()
    if not vectordb_snapshot_restoration_template_object:
        logger.error("VECTOR_DB | SEND_VECTOR_DB_SNAPSHOT_RESTORATION_EMAIL | VECTOR_DB_SNAPSHOT_RESTORATION_TEMPLATE_NOT_FOUND")
        return
    subject = vectordb_snapshot_restoration_template_object.subject
    body = get_template(VECTOR_DB_SNAPSHOT_RESTORATION_TEMPLATE_NAME).render(
        {
            "vectordb_name": vectordb.name,
            "vectordb_type": vectordb.vectordb_type, 
            "snapshot_time": change_timezone(datetime_obj=snapshot.snapshot_time, timezone=settings.IST_TIMEZONE_STR), # Snapshot Time is shown in IST format in frontend, so for better user experience we send the same format in the mail.
            "team_name": vectordb.project.team.name,
            "project_name": vectordb.project.name,
            "cloud_support_email_address": settings.CLOUD_PLATFORM_EMAIL
        }
    )
    try:
        mandrill_manager.send_email([], [vectordb.created_by.email], body, subject, cc_email_list=cc_email_list)
    except Exception as e:
        logger.error(f"VECTOR_DB | CRITICAL_RED | SEND_VECTOR_DB_SNAPSHOT_RESTORATION_EMAIL | CUSTOMER - {vectordb.created_by.email} | ERROR_IN_SENDING_EMAIL - {e}")


def send_vectordb_restoration_fail_email(vectordb, snapshot):
    cc_email_list = get_team_owner_admin_email_list(vectordb.project.team_id, emails_to_exclude=[vectordb.created_by.email])
    vectordb_snapshot_restoration_template_object = Template.objects.filter(name=VECTOR_DB_SNAPSHOT_RESTORATION_FAIL_TEMPLATE_NAME).first()
    if not vectordb_snapshot_restoration_template_object:
        logger.error("VECTOR_DB | SEND_VECTOR_DB_SNAPSHOT_RESTORATION_EMAIL | VECTOR_DB_SNAPSHOT_RESTORATION_TEMPLATE_NOT_FOUND")
        return
    subject = vectordb_snapshot_restoration_template_object.subject
    body = get_template(VECTOR_DB_SNAPSHOT_RESTORATION_FAIL_TEMPLATE_NAME).render(
        {
            "vectordb_name": vectordb.name,
            "vectordb_type": vectordb.vectordb_type,
            "snapshot_time": change_timezone(datetime_obj=snapshot.snapshot_time, timezone=settings.IST_TIMEZONE_STR), # Snapshot Time is shown in IST format in frontend, so for better user experience we send the same format in the mail.
            "project_name": vectordb.project.name,
            "cloud_support_email_address": settings.CLOUD_PLATFORM_EMAIL
        }
    )
    try:
        mandrill_manager.send_email([], [vectordb.created_by.email], body, subject, cc_email_list=cc_email_list)
    except Exception as e:
        logger.error(f"VECTOR_DB | CRITICAL_RED | SEND_VECTOR_DB_SNAPSHOT_RESTORATION_EMAIL | CUSTOMER - {vectordb.created_by.email} | ERROR_IN_SENDING_EMAIL - {e}")


def send_vectordb_replica_updation_email(vectordb, previous_replicas):
    cc_email_list = get_team_owner_admin_email_list(vectordb.project.team_id, emails_to_exclude=[vectordb.created_by.email])
    team_name = vectordb.project.team.name
    vectordb_replica_updation_template_object = Template.objects.filter(name=VECTOR_DB_REPLICA_UPDATION_TEMPLATE_NAME).first()
    if not vectordb_replica_updation_template_object:
        logger.error("VECTOR_DB | SEND_VECTORDB_REPLICA_UPDATION_EMAIL | VECTOR_DB_REPLICA_UPDATION_TEMPLATE_NOT_FOUND")
        return
    subject = vectordb_replica_updation_template_object.subject
    body = get_template(VECTOR_DB_REPLICA_UPDATION_TEMPLATE_NAME).render(
        {
            "vectordb_name": vectordb.name,
            "vectordb_type": vectordb.vectordb_type,
            "team_name": team_name,
            "project_name": vectordb.project.name,
            "plan_name": vectordb.sku_item_price.sku.name,
            "previous_replicas": previous_replicas,
            "new_replicas": vectordb.qdrant.replicas,
            "cloud_support_email_address": settings.CLOUD_PLATFORM_EMAIL
        }
    )
    try:
        mandrill_manager.send_email([], [vectordb.created_by.email], body, subject, cc_email_list=cc_email_list)
    except Exception as e:
        logger.error(f"VECTOR_DB | CRITICAL_RED | SEND_VECTOR_DB_REPLICA_UPDATION_EMAIL | Customer - {vectordb.created_by.email} | ERROR_IN_SENDING_EMAIL - {e}")


def check_inventory_and_minimum_credits(project, vectordb_payload):
    sku_item_price_id = vectordb_payload.get("sku_item_price_id")
    replicas = vectordb_payload.get("replicas")
    sku_item_price = SkuItemPrice.objects.filter(id=sku_item_price_id, is_active=True, sku__is_active=True).first()
    billable_customer = project.team.owner.get_primary_contact()

    is_valid = check_inventory_availability_status(sku_item_price.sku, replicas)
    if not is_valid:
        return False, SKU_INVENTORY_UNAVAILABLE
    is_valid, response_str = is_credit_sufficient_for_inventory_launch(billable_customer, sku_item_price, replicas)
    if not is_valid:
        return False, response_str
    return True, ""


def generate_secret_key_for_snapshot():
    choices = string.digits + string.ascii_uppercase + string.ascii_lowercase
    random_string = "".join(secrets.choice(choices) for _ in range(SNAPSHOT_AUTH_SECRET_LENGTH))
    return random_string


def get_snapshot_file_name(collection, node, vectordb, snapshot_time):
    url = QDRANT_GET_SNAPSHOT_URL.format(endpoint_url=vectordb.endpoint_url, node=node, collection=collection)
    headers = {
        'Authorization': f'Bearer {vectordb.qdrant.api_key}'
    }
    response = requests.request("GET", url, headers=headers)
    snapshot_info = response.json().get('result')
    min_time = timedelta(9999)
    for snaps in snapshot_info:
        time_diff = tz_aware(datetime.strptime(snaps.get("creation_time"), SNAPSHOT_DATE_TIME_FORMAT)) - round_to_previous_second(snapshot_time)
        if time_diff >= timedelta(0) and time_diff <= min_time:
            min_time = time_diff
            snapshot_file_name = snaps.get("name")
    return snapshot_file_name


def delete_folder_from_pv(snapshot_restoration_list, vectordb, snapshot):
    for snaps in snapshot_restoration_list:
        url = QDRANT_SIDECAR_DELETE_URL.format(endpoint_url=vectordb.endpoint_url, node=snaps.get("node"))
        payload = json.dumps({
            "snapshot_time": snapshot.snapshot_time
        })
        headers = {
            'Content-Type': QDRANT_APIS_CONTENT_TYPE
        }
        requests.request("DELETE", url, headers=headers, data=payload)

def generate_authentication_tag(snapshot):
    generated_tag = hashlib.sha256(f"{snapshot.id}~{snapshot.secret_key}~{snapshot.snapshot_time.strftime(SNAPSHOT_DATE_TIME_FORMAT)}".encode()).hexdigest()
    original_tag = f"{snapshot.secret_key}~{generated_tag}"
    return original_tag

def delete_qdrant_snapshot_api_call(vectordb, snap):
    url = QDRANT_DELETE_SNAPSHOT_URL.format(endpoint_url=vectordb.endpoint_url, node=snap.get("node"), collection=snap.get("collection_name"), snapshot_name=snap.get("snapshot_file_name"))
    headers = {
        'Authorization': f'Bearer {vectordb.qdrant.api_key}'
    }
    requests.request("DELETE", url, headers=headers)

def upload_file_from_sidecar_to_eos_api_call(vectordb, snapshot_file_list, snapshot, node):
    tag = generate_authentication_tag(snapshot=snapshot)
    url = QDRANT_SIDECAR_UPLOAD_URL.format(endpoint_url=vectordb.endpoint_url, node=node)
    headers = {
        'Content-Type': QDRANT_APIS_CONTENT_TYPE
    }
    payload = json.dumps({
        "snapshot_file_list": snapshot_file_list,
        "vectordb": vectordb.id,
        "vectordb_name": vectordb.name,
        "snapshot_time": snapshot.snapshot_time.strftime(SNAPSHOT_DATE_TIME_FORMAT),
        "snapshot_id": snapshot.id,
        "self_node": node,
        "tag": tag,
    })
    response = requests.request("POST", url, headers=headers, data=payload)
    return response

def restore_snapshot_file_from_sidecar_api_call(vectordb, snapshot, snapshot_restoration_list):
    url = QDRANT_SIDECAR_RESTORE_URL.format(endpoint_url=vectordb.endpoint_url, node=0)
    headers = {
        'Content-Type': QDRANT_APIS_CONTENT_TYPE,
        'tag': generate_authentication_tag(snapshot=snapshot)
    }
    payload = json.dumps({
        "snapshot_restoration_list": snapshot_restoration_list,
        "vectordb_url": vectordb.endpoint_url,
        "snapshot_time": snapshot.snapshot_time.strftime(SNAPSHOT_DATE_TIME_FORMAT),
        "api_key": vectordb.qdrant.api_key,
        "snapshot_id": snapshot.id,
        "replicas": vectordb.qdrant.replicas,
        "vectordb_id": vectordb.id
    })
    requests.request("PUT", url, headers=headers, data=payload)

def delete_single_snapshot(prefix, vectordb):
    minio_client = Minio(settings.QDRANT_MINIO_ENDPOINT, settings.QDRANT_MINIO_ACCESS_KEY, settings.QDRANT_MINIO_SECRET_KEY)
    objects = minio_client.list_objects(settings.QDRANT_MINIO_BUCKET_NAME, prefix=prefix)
    for obj in objects:
        for node in range(vectordb.qdrant.replicas):
            prefix = f"{obj.object_name}{node}/"
            snapshot_files = minio_client.list_objects(settings.QDRANT_MINIO_BUCKET_NAME, prefix=prefix)
            for file in snapshot_files:
                minio_client.remove_object(settings.QDRANT_MINIO_BUCKET_NAME, file.object_name)


def delete_all_snapshots(prefix, vectordb):
    minio_client = Minio(settings.QDRANT_MINIO_ENDPOINT, settings.QDRANT_MINIO_ACCESS_KEY, settings.QDRANT_MINIO_SECRET_KEY)
    objects = minio_client.list_objects(settings.QDRANT_MINIO_BUCKET_NAME, prefix=prefix)
    for obj in objects:
        delete_single_snapshot(prefix=obj.object_name, vectordb=vectordb)


def download_file_from_bucket_to_pv(node, vectordb, snapshot, tag):
    prefix = f"{vectordb.id}-{vectordb.name}/{datetime.strftime(snapshot.snapshot_time, SNAPSHOT_DATE_TIME_FORMAT)}/"
    url = QDRANT_SIDECAR_DOWNLOAD_URL.format(endpoint_url=vectordb.endpoint_url, node=node)
    headers = {
        'Content-Type': QDRANT_APIS_CONTENT_TYPE
    }
    payload = json.dumps({
        "vectordb": vectordb.id,
        "snapshot_time": snapshot.snapshot_time.strftime(SNAPSHOT_DATE_TIME_FORMAT),
        "snapshot_id": snapshot.id,
        "prefix": prefix,
        "tag": tag,
        "self_node": node
    })
    requests.request("GET", url, headers=headers, data=payload)
