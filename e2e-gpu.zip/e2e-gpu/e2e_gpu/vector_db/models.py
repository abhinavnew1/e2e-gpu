from datetime import datetime

from django.db import models

from customer.models import Customer
from e2e_core.api.v1.services.vault import VaultService
from e2e_core.helpers import mark_delete_related_objects
from e2e_core.mixins import BaseMixin, SafeDeleteMixinExtended
from gpu_service.models import SkuItemPrice
from projects.models import Projects
from vector_db.constants import (CREATING, DONE, QDRANT,
                                 QDRANT_API_KEYS_VAULT_PATH,
                                 QDRANT_DASHBOARD_URL, QDRANT_NAME,
                                 VECTOR_DB_NAME_MAX_LENGTH,
                                 VECTOR_DB_STATUS_CHOICES,
                                 VECTOR_DB_SNAPSHOT_CHOICES,
                                 VECTOR_DB_TYPE_CHOICES,)


class VectorDB(BaseMixin, SafeDeleteMixinExtended):
    created_by = models.ForeignKey(Customer, on_delete=models.PROTECT, related_name="vectordb_created_by")
    name = models.CharField(max_length=VECTOR_DB_NAME_MAX_LENGTH)
    project = models.ForeignKey(Projects, on_delete=models.CASCADE)
    sku_item_price = models.ForeignKey(SkuItemPrice, on_delete=models.SET_NULL, null=True)
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    status = models.CharField(choices=VECTOR_DB_STATUS_CHOICES, max_length=32, default=CREATING)
    endpoint_url = models.CharField(null=True, blank=True, max_length=255)
    ip_enabled = models.BooleanField(default=False)
    vectordb_type = models.CharField(choices=VECTOR_DB_TYPE_CHOICES, max_length=50, default=QDRANT)

    def __str__(self):
        return f"<VectorDB({self.id}: {self.name}: {self.vectordb_type}: {self.status})>"

    @property
    def slug_name(self):
        return QDRANT_NAME.format(self.id) if self.vectordb_type == QDRANT else ""

    @property
    def dashboard_url(self):
        return QDRANT_DASHBOARD_URL.format(self.endpoint_url) if self.vectordb_type == QDRANT and self.endpoint_url else ""
    
    def update_status(self, status):
        self.status = status
        self.save(update_fields=['status', 'updated_at'])

    def mark_deleted(self):
        if self.deleted_at is None:
            mark_delete_related_objects(self)
            self.deleted_at = datetime.now()
            self.status = DONE
            self.save(update_fields=['deleted_at', 'status', 'updated_at'])
            self.update_end_date_in_vectordb_history(end_date=self.deleted_at)
            self.update_end_date_in_vectordb_pvc_history(end_date=self.deleted_at)

    def get_active_vectordb_history(self):
        from vector_db.helpers import verify_vectordb_history
        vectordb_history = VectorDBHistory.objects.filter(vector_db=self, end_date__isnull=True)
        verify_vectordb_history(self, vectordb_history.count())
        return vectordb_history.last()

    def create_vectordb_history(self, start_date=None):
        start_date = start_date if start_date else datetime.now()
        billable_customer = self.project.team.owner.get_primary_contact()
        return VectorDBHistory.objects.create(
            customer=billable_customer,
            vector_db=self,
            sku_item_price=self.sku_item_price,
            replicas=self.qdrant.replicas,
            start_date=start_date,
        )

    def update_end_date_in_vectordb_history(self, end_date=None):
        end_date = end_date if end_date else datetime.now()
        vectordb_history = self.get_active_vectordb_history()
        if vectordb_history:
            vectordb_history.end_date = end_date
            vectordb_history.save(update_fields=['end_date', 'updated_at'])

    def create_vectordb_pvc_history(self, start_date=None):
        start_date = start_date if start_date else datetime.now()
        billable_customer = self.project.team.owner.get_primary_contact()
        return VectorDBPVCHistory.objects.create(
            customer=billable_customer,
            vector_db=self,
            disk_size=self.qdrant.disk_size,
            replicas=self.qdrant.replicas,
            start_date=start_date
        )

    def update_end_date_in_vectordb_pvc_history(self, end_date=None):
        end_date = end_date if end_date else datetime.now()
        billable_customer = self.project.team.owner.get_primary_contact()
        pvc_history = VectorDBPVCHistory.objects.filter(
            vector_db=self,
            customer=billable_customer,
            disk_size=self.qdrant.disk_size,
            replicas=self.qdrant.replicas,
            end_date__isnull=True
        ).last()
        pvc_history.end_date = end_date
        pvc_history.save(update_fields=['end_date', 'updated_at'])


class VectorDBHistory(BaseMixin, SafeDeleteMixinExtended):
    customer = models.ForeignKey(Customer, on_delete=models.PROTECT)
    vector_db = models.ForeignKey(VectorDB, on_delete=models.PROTECT)
    sku_item_price = models.ForeignKey(SkuItemPrice, null=True, on_delete=models.SET_NULL)
    replicas = models.IntegerField()
    start_date = models.DateTimeField()
    end_date = models.DateTimeField(default=None, null=True, blank=True)

    def __str__(self):
        return f"VectorDBHistory:({self.id}: {self.vector_db.name}: {self.vector_db.vectordb_type}: {self.customer.email})"

    @property
    def sku(self):
        return self.sku_item_price.sku


class VectorDBPVCHistory(BaseMixin, SafeDeleteMixinExtended):
    customer = models.ForeignKey(Customer, on_delete=models.PROTECT)
    vector_db = models.ForeignKey(VectorDB, on_delete=models.PROTECT)
    disk_size = models.IntegerField()
    replicas = models.IntegerField()
    start_date = models.DateTimeField()
    end_date = models.DateTimeField(default=None, null=True, blank=True)

    def __str__(self):
        return f"VectorDBPVCHistory:({self.id}: {self.vector_db.name}: {self.vector_db.vectordb_type}: {self.disk_size}GB)"


class Qdrant(BaseMixin, SafeDeleteMixinExtended):
    vector_db = models.OneToOneField(VectorDB, on_delete=models.CASCADE, related_name='qdrant')
    disk_size = models.IntegerField()
    replicas = models.IntegerField()

    @property
    def api_key(self):
        api_key = VaultService().get_secret(QDRANT_API_KEYS_VAULT_PATH.format(vectordb_obj_id=self.id))
        if api_key['errors']:
            raise api_key['errors']
        return api_key['data']['value']['api_key']

    @property
    def read_only_api_key(self):
        read_only_api_key = VaultService().get_secret(QDRANT_API_KEYS_VAULT_PATH.format(vectordb_obj_id=self.id))
        if read_only_api_key['errors']:
            raise read_only_api_key['errors']
        return read_only_api_key['data']['value']['read_only_api_key']

    def store_api_keys_in_vault(self, api_key, read_only_api_key):
        vault_service = VaultService()
        api_keys = {
            'api_key': api_key,
            'read_only_api_key': read_only_api_key
        }
        vault_service.create_secret(QDRANT_API_KEYS_VAULT_PATH.format(vectordb_obj_id=self.id), api_keys)


class VectorDBSnapshots(BaseMixin, SafeDeleteMixinExtended):
    vector_db = models.ForeignKey(VectorDB, on_delete=models.CASCADE)
    snapshot_time = models.DateTimeField()
    status = models.CharField(choices=VECTOR_DB_SNAPSHOT_CHOICES, max_length=32, default=CREATING)
    secret_key = models.CharField(max_length=32)
    restoring_status = models.BooleanField(default=False, help_text="To determine whether snapshot is being restored so that it can't be deleted")
    deleted_at = models.DateTimeField(default=None, null=True, blank=True)
    upload_count = models.IntegerField(default=0, help_text="To maintain status of success upload operation from pv to minio on each pod of qdrant")
    download_count = models.IntegerField(default=0, help_text="To maintain status of success download operation from minio to pv on each pod of qdrant")

    def mark_deleted(self):
        if self.deleted_at is None:
            self.deleted_at = datetime.now()
            self.save(update_fields=['deleted_at', 'updated_at'])

    def update_snapshot_status(self, status):
        self.status = status
        self.save(update_fields=['status', 'updated_at'])

    def update_restore_status(self, status):
        self.restoring_status = status
        self.save(update_fields=['restoring_status', 'updated_at'])

    def update_upload_count(self, count):
        self.upload_count = count
        self.save(update_fields=['upload_count', 'updated_at'])

    def update_download_count(self, count):
        self.download_count = count
        self.save(update_fields=['download_count', 'updated_at'])

    def __str__(self):
        return f"<VectorDBSnapshots:({self.id}: {self.snapshot_time}: {self.status})>"
