import copy
import logging
from datetime import datetime

from django.conf import settings
from celery.execute import send_task
from minio import Minio
from rest_framework import status

from e2e_core.helpers import support_ticket_generator
from e2e_gpu.celery import app
from vector_db.api.v1.services.qdrant_services import QdrantCollectionService
from vector_db.api.v1.services.vectordb_groot_services import \
    QdrantGrootService
from vector_db.api.v1.services.vectordb_services import VectorDBService
from vector_db.constants import (BOUND, CREATED, FAILED, QDRANT_COLLECTION_CREATION_FAILED_MAX_RETRIES_REACHED_MESSAGE, 
                                 QDRANT_COLLECTION_CREATION_MAX_RETRIES_REACHED_SUBJECT, QDRANT_COLLECTION_CREATION_TASK, 
                                 QDRANT_COLLECTION_CREATION_TASK_MAX_RETRIES, QDRANT_COLLECTION_CREATION_TASK_RETRY_DELAY, 
                                 QDRANT_REPLICAS_PVC_UPGRADATION_FAILED_MAX_RETRIES_REACHED_MESSAGE, QDRANT_REPLICAS_PVC_UPGRADATION_FAILED_MESSAGE, 
                                 QDRANT_REPLICAS_PVC_UPGRADATION_FAILED_SUBJECT, QDRANT_REPLICAS_PVC_UPGRADATION_MAX_RETRIES_REACHED_FAILED_SUBJECT, 
                                 QDRANT_REPLICAS_PVC_UPGRADATION_TASK, QDRANT_REPLICAS_PVC_UPGRADATION_TASK_DELAY, QDRANT_REPLICAS_PVC_UPGRADATION_TASK_MAX_RETRIES, 
                                 QDRANT_RESTORATION_FAILED_MESSAGE, QDRANT_RESTORATION_FAILED_SUBJECT, QDRANT_SNAPSHOT_TASK_COUNTDOWN, 
                                 QDRANT_SNAPSHOT_DELETION_FAILED_MESSAGE, QDRANT_SNAPSHOT_DELETION_FAILED_SUBJECT,
                                 QDRANT_SNAPSHOT_DELETION_MAX_RETRIES, QDRANT_SNAPSHOT_DELETION_RETRY_DELAY, QDRANT_SNAPSHOT_DELETION_TASK, 
                                 QDRANT_SNAPSHOT_FILE_SEARCH_TASK, QDRANT_SNAPSHOT_MAX_RETRIES, 
                                 QDRANT_SNAPSHOT_RESTORATION_TASK, QDRANT_SNAPSHOT_RETRY_BACKOFF,
                                 QDRANT_SNAPSHOT_RETRY_BACKOFF_MAX, QDRANT_UPDATE_SNAPSHOT_STATUS_TASK,
                                 READY, RESTORE_FAILED, RUNNING, SNAPSHOT_DATE_TIME_FORMAT)
from vector_db.helpers import delete_folder_from_pv, delete_single_snapshot, delete_all_snapshots, delete_qdrant_snapshot_api_call, download_file_from_bucket_to_pv, \
                                get_snapshot_file_name, restore_snapshot_file_from_sidecar_api_call, upload_file_from_sidecar_to_eos_api_call
from vector_db.models import VectorDB, VectorDBSnapshots

logger = logging.getLogger(__name__)


@app.task(
    name=QDRANT_REPLICAS_PVC_UPGRADATION_TASK,
    default_retry_delay=QDRANT_REPLICAS_PVC_UPGRADATION_TASK_DELAY,
    max_retries=QDRANT_REPLICAS_PVC_UPGRADATION_TASK_MAX_RETRIES,
    bind=True
)
def qdrant_replicas_pvc_upgradation_task(self, *args, **kwargs):
    vectordb = kwargs.get('vectordb')
    if not VectorDB.objects.filter(id=vectordb.id, deleted_at__isnull=True).exists():
        return
    pvc_name = kwargs.get('pvc_name')
    qdrant_groot_service = QdrantGrootService(
        project=vectordb.project,
        customer=vectordb.created_by
    )
    status, response = qdrant_groot_service.get_pvc_from_groot(pvc_name)
    if not status:
        logger.error(f"QDRANT_REPLICAS_PVC_UPGRADATION_TASK | CRITICAL_RED | UNABLE_TO_FETCH_PVC_FROM_GROOT | VECTORDB_ID: {vectordb.id} | ERRORS: {response['errors']}")
        return
    if response['pvc']['status']['phase'] in (BOUND, READY):
        status, response = qdrant_groot_service.upgrade_qdrant_pvc_on_groot(pvc_name, vectordb.qdrant.disk_size)
        if not status:
            logger.error(f"QDRANT_REPLICAS_PVC_UPDRADATION_TASK | CRITICAL_RED | PVC_UPDATION_FALIED | VECTORDB_ID: {vectordb.id} | ERRORS: {response['errors']}")
            support_ticket_generator(
                errors=QDRANT_REPLICAS_PVC_UPGRADATION_FAILED_MESSAGE.format(vectordb_id=vectordb.id, errors=response.errors),
                subject=QDRANT_REPLICAS_PVC_UPGRADATION_FAILED_SUBJECT.format(email_id=vectordb.created_by.email),
                customer=vectordb.created_by,
            )
        return
    if self.request.retries == self.max_retries:
        logger.error(f'QDRANT_REPLICAS_PVC_UPGRADATION_TASK | CRITICAL_RED | PVC_STATUS_NOT_BOUND | VECTORDB_ID: {vectordb.id}')
        support_ticket_generator(
            errors=QDRANT_REPLICAS_PVC_UPGRADATION_FAILED_MAX_RETRIES_REACHED_MESSAGE.format(vectordb_id=vectordb.id),
            subject=QDRANT_REPLICAS_PVC_UPGRADATION_MAX_RETRIES_REACHED_FAILED_SUBJECT.format(email_id=vectordb.created_by.email),
            customer=vectordb.created_by,
        )
        return
    self.retry()


@app.task(
    name=QDRANT_COLLECTION_CREATION_TASK,
    default_retry_delay=QDRANT_COLLECTION_CREATION_TASK_RETRY_DELAY,
    max_retries=QDRANT_COLLECTION_CREATION_TASK_MAX_RETRIES,
    bind=True
)
def qdrant_collection_creation_task(self, *args, **kwargs):
    payload_data = kwargs.get("payload_data")
    vectordb = kwargs.get("vectordb")
    if not VectorDB.objects.filter(id=vectordb.id, deleted_at__isnull=True).exists():
        return
    VectorDBService(
        customer=vectordb.created_by,
        project_id=vectordb.project_id,
        project=vectordb.project
    ).get_vectordb_details_from_groot(vectordb)

    if vectordb.status == RUNNING:
        response = QdrantCollectionService(vectordb).send_create_collection_request(payload_data)
        if response.get('code') == status.HTTP_201_CREATED:
            return

    if self.request.retries == self.max_retries:
        logger.error(f"QDRANT_COLLECTION_CREATION_TASK | CRITICAL_RED | MAX_RETRIES_REACHED | VECTORDB_ID: {vectordb.id}")
        support_ticket_generator(
            errors=QDRANT_COLLECTION_CREATION_FAILED_MAX_RETRIES_REACHED_MESSAGE.format(vectordb_id=vectordb.id),
            subject=QDRANT_COLLECTION_CREATION_MAX_RETRIES_REACHED_SUBJECT.format(email_id=vectordb.created_by.email),
            customer=vectordb.created_by,
        )
        return
    self.retry()


@app.task(
    name=QDRANT_SNAPSHOT_FILE_SEARCH_TASK,
    retry_backoff=QDRANT_SNAPSHOT_RETRY_BACKOFF,
    retry_backoff_max=QDRANT_SNAPSHOT_RETRY_BACKOFF_MAX,
    max_retries=QDRANT_SNAPSHOT_MAX_RETRIES,
    retry_jitter=False,
    bind=True
)
def qdrant_snapshot_files_search_task(self, *args, **kwargs):
    """
    Finds the snapshot files in the Persistent Volume of Qdrant whose APIs were successfull. After successful finding it either pushes another 
    task to upload to eos or deletes the snapshot from PV depending on whether the APIs were successfull or not. 

    KWARGS
    ------
    snapshot: Object of VectorDBSnapshot
    vectordb: Object of VectorDB
    snapshot_files_info: List of dict: Information about snapshot files whose api has been successfully called
    snapshot_file_list: List of dict: Information about snapshot files who have been found.
    """
    snapshot = kwargs.get('snapshot')
    vectordb = kwargs.get('vectordb')
    snapshot_files_info = kwargs.get('snapshot_files_info', []) # Information about snapshot files whose api has been successfully called
    qdrant_snapshot_creation_api_status = kwargs.get('status')
    snapshot_file_list = kwargs.get('snapshot_file_list', []) # Information about snapshot files who have been found.

    temp_snapshot_files_info = copy.deepcopy(snapshot_files_info)
    search_fail_flag = False

    if self.request.retries == self.max_retries:
        logger.error("QDRANT_SNAPSHOT_FILE_FINDING_FAILED | CRITICAL_RED | FILE_NOT_FOUND_ON_QDRANT_PV")
        for snap in snapshot_file_list:
            delete_qdrant_snapshot_api_call(vectordb=vectordb, snap=snap)
        snapshot.update_snapshot_status(FAILED)
        return

    try:
        # Search files whose apis have been successful and search for them.
        # Insert the values of the files found in snapshot_file_list for the insertion task.
        # Remove it from the snapshot_files_info so that the search doesn.t happen again if task retries.
        for info in snapshot_files_info:
            snapshot_file_name = get_snapshot_file_name(collection=info.get("collection_name"), node=info.get("node"), vectordb=vectordb, snapshot_time=snapshot.snapshot_time)
            if snapshot_file_name != "":
                snapshot_file_list.append({
                    "snapshot_file_name": snapshot_file_name,
                    "collection_name": info.get("collection_name"),
                    "node": info.get("node")
                })
                temp_snapshot_files_info.remove(info)
            else:
                search_fail_flag = True
    except Exception as e:
        logger.info(f"QDRANT_SNAPSHOT_FILE_FINDING_FAILED | CRITICAL_RED | ERROR: {e}")
        self.retry(kwargs={
            "snapshot_files_info": temp_snapshot_files_info,
            "snapshot_file_list": snapshot_file_list,
            "snapshot": snapshot,
            "vectordb": vectordb,
            "status": qdrant_snapshot_creation_api_status
        })

    # Retry with updated snapshot_files_info 
    if search_fail_flag:
        logger.info("QDRANT_SNAPSHOT_FILE_FINDING_FAILED | CRITICAL_RED")
        self.retry(kwargs={
            "snapshot_files_info": temp_snapshot_files_info,
            "snapshot_file_list": snapshot_file_list,
            "snapshot": snapshot,
            "vectordb": vectordb,
            "status": qdrant_snapshot_creation_api_status
        })

    # If the apis were successful and the search was also successful move the files to bucket
    if qdrant_snapshot_creation_api_status:
        for node in range(vectordb.qdrant.replicas):
            upload_file_from_sidecar_to_eos_api_call(vectordb=vectordb, snapshot_file_list=snapshot_file_list, snapshot=snapshot, node=node)
        send_task(
            QDRANT_UPDATE_SNAPSHOT_STATUS_TASK,
            kwargs={
                "snapshot_file_list": snapshot_file_list,
                "vectordb": vectordb,
                "snapshot": snapshot,
            },
            countdown=QDRANT_SNAPSHOT_TASK_COUNTDOWN
        )

    # Else delete the files whose apis have been sent.
    else:
        for snap in snapshot_file_list:
            delete_qdrant_snapshot_api_call(vectordb=vectordb, snap=snap)


@app.task(
    name=QDRANT_UPDATE_SNAPSHOT_STATUS_TASK,
    retry_backoff=QDRANT_SNAPSHOT_RETRY_BACKOFF,
    retry_backoff_max=QDRANT_SNAPSHOT_RETRY_BACKOFF_MAX,
    max_retries=QDRANT_SNAPSHOT_MAX_RETRIES,
    retry_jitter=False,
    bind=True
)
def qdrant_update_snapshot_status_task(self, *args, **kwargs):
    """
    Checks the snapshot upload count and repeats until it is equal to the number of replicas.
    Updates the status of snapshot and deletes all the files from pv.
    If it reaches max retries, the snapshot

    KWARGS
    ------
    snapshot: Object of VectorDBSnapshot
    vectordb: Object of VectorDB
    snapshot_file_list: List of dict: Information about snapshot files who have been found.
    """
    snapshot_file_list = kwargs.get('snapshot_file_list', [])
    snapshot = kwargs.get('snapshot')
    vectordb = kwargs.get('vectordb')
    if vectordb.deleted_at is not None:
        return

    if self.request.retries == self.max_retries:
        prefix = f"{vectordb.id}-{vectordb.name}/{datetime.strftime(snapshot.snapshot_time, SNAPSHOT_DATE_TIME_FORMAT)}/"
        try:
            for snaps in snapshot_file_list:
                delete_qdrant_snapshot_api_call(vectordb=vectordb, snap=snaps)
            delete_single_snapshot(prefix=prefix, vectordb=vectordb)
        except Exception as e:
            logger.error(f"DELETION_OF_SNAPSHOTS_ON_MINIO_OR_PV_FAILED | CRITICAL_RED | ERROR: {e}")
        finally:
            snapshot.update_snapshot_status(FAILED)

    try:
        snapshot = VectorDBSnapshots.objects.filter(id=snapshot.id).last()
        if snapshot.upload_count == vectordb.qdrant.replicas:
            snapshot.update_snapshot_status(CREATED)
            for snaps in snapshot_file_list:
                delete_qdrant_snapshot_api_call(vectordb=vectordb, snap=snaps)
        else:
            raise RuntimeError("Snapshot Not Uploaded")
    except Exception as e:
        logger.info(f"QDRANT_SNAPSHOT_INSERTION_INCOMPLETE | CRITICAL_RED | ERROR: {e}")
        self.retry(kwargs={
            "snapshot_file_list": snapshot_file_list,
            "snapshot": snapshot,
            "vectordb": vectordb
        })

    logger.info(f"SNAPSHOT_CREATION_SUCCESS | VECTOR_DB: {vectordb} | SNAPSHOT: {snapshot.id}")


@app.task(
    name=QDRANT_SNAPSHOT_RESTORATION_TASK,
    retry_backoff=QDRANT_SNAPSHOT_RETRY_BACKOFF,
    retry_backoff_max = QDRANT_SNAPSHOT_RETRY_BACKOFF_MAX,
    max_retries=QDRANT_SNAPSHOT_MAX_RETRIES,
    retry_jitter=False,
    bind=True
)
def qdrant_snapshot_restoration_task(self, *args, **kwargs):
    """
    Restores all the file by calling the sidecar url which asynchronously restores all the snapshot files.
    Checks if the files have been downloaded by comaprig the download_count to the number of replicas in qdrant.

    KWARGS
    ------
    snapshot: Object of VectorDBSnapshot
    vectordb: Object of VectorDB
    snapshot_restoration_list: List of dict: Information about snapshot files which have to be restored
    """
    snapshot = kwargs.get('snapshot')
    vectordb = kwargs.get('vectordb')
    if vectordb.deleted_at is not None:
        return
    snapshot_restoration_list = kwargs.get("snapshot_restoration_list")

    prefix = f"{vectordb.id}-{vectordb.name}/{datetime.strftime(snapshot.snapshot_time, SNAPSHOT_DATE_TIME_FORMAT)}/"

    if self.request.retries == self.max_retries:
        delete_folder_from_pv(snapshot_restoration_list=snapshot_restoration_list, vectordb=vectordb, snapshot=snapshot)
        support_ticket_generator(
            errors=QDRANT_RESTORATION_FAILED_MESSAGE.format(vectordb_id=vectordb.id, snapshot_id=snapshot.id),
            subject=QDRANT_RESTORATION_FAILED_SUBJECT.format(vectordb_id=vectordb.id),
            customer=vectordb.created_by,
        )
        snapshot.update_restore_status(False)
        vectordb.update_status(RESTORE_FAILED)
        return

    try:
        snapshot = VectorDBSnapshots.objects.filter(id = snapshot.id).last()
        if snapshot.download_count == vectordb.qdrant.replicas:
            minio_client = Minio(settings.QDRANT_MINIO_ENDPOINT, settings.QDRANT_MINIO_ACCESS_KEY, settings.QDRANT_MINIO_SECRET_KEY)
            objects = minio_client.list_objects(settings.QDRANT_MINIO_BUCKET_NAME, prefix=prefix, recursive=True)
            for obj in objects:
                if not obj.is_dir:
                    collection = obj.object_name.split("/")[-3]
                    snapshot_file = obj.object_name.split("/")[-1]
                    node = obj.object_name.split("/")[-2]
                    snapshot_restoration_list.append({
                        "collection_name": collection,
                        "node": node, 
                        "snapshot_file_name": snapshot_file,
                    })
            restore_snapshot_file_from_sidecar_api_call(vectordb=vectordb, 
                                                    snapshot=snapshot, 
                                                    snapshot_restoration_list=snapshot_restoration_list)
        else:
            raise RuntimeError("Snapshot Not Downloaded")
    except Exception as e:
        logger.info(f"SNAPSHOT_RESTORATION_FAILED | CRITICAL_RED | ERROR: {e}")
        self.retry(kwargs={
            "snapshot_restoration_list": snapshot_restoration_list,
            "snapshot": snapshot,
            "vectordb": vectordb
        })
    logger.info(f"SNAPSHOT_RESTORATION_SUCCESS | RESTORATION DONE | VECTOR_DB: {vectordb}")


@app.task(
    name=QDRANT_SNAPSHOT_DELETION_TASK,
    default_retry_delay=QDRANT_SNAPSHOT_DELETION_RETRY_DELAY,
    max_retries=QDRANT_SNAPSHOT_DELETION_MAX_RETRIES,
    bind=True
)
def qdrant_snapshot_deletion_task(self, *args, **kwargs):
    """
    Deletes the snapshot files from EOS Bucket in two cases:
    1. Deletion of a single snapshot.
    2. Deletion of snapshot with the vectordb or project deletion.

    KWARGS
    ------

    snapshot: Object of the snapshot stored in DB --> If none all the snapshots of the vectordb will be deleted.
    vectordb: Object of the vectordb whose snapshot is to deleted.
    """
    snapshot = kwargs.get("snapshot")
    vectordb = kwargs.get('vectordb')

    if self.request.retries == self.max_retries:
        logger.error("SNAPSHOT_DELETION_FAILED | CRITICAL_RED | ERROR: MAX_RETIRES_REACHED")
        support_ticket_generator(
            errors=QDRANT_SNAPSHOT_DELETION_FAILED_MESSAGE.format(vectordb_id=vectordb.id, snapshot_id=snapshot.id),
            subject=QDRANT_SNAPSHOT_DELETION_FAILED_SUBJECT.format(vectordb_id=vectordb.id),
            customer=vectordb.created_by,
        )

    prefix = f"{vectordb.id}-{vectordb.name}/{datetime.strftime(snapshot.snapshot_time, SNAPSHOT_DATE_TIME_FORMAT)}/" if snapshot else f"{vectordb.id}-{vectordb.name}/"

    try:
        if snapshot:
            delete_single_snapshot(prefix=prefix, vectordb=vectordb)
        else:
            delete_all_snapshots(prefix=prefix, vectordb=vectordb)
    except Exception as e:
        logger.info(f"SNAPSHOT_DELETION_FAILED | CRITICAL_RED | ERROR: {e}")
        self.retry()
