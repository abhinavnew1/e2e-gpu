__version__ = "2.0"

default_app_config = 'dbtemplates.apps.DBTemplatesConfig'
