"""Fabfile to perform commands on the Infrastructure nodes"""


__author__ = 'Jagmeet Singh Jagmeet.singh@e2enetworks.com'
__version__ = '0.1'


import json
from fabric.api import *
from fabric.decorators import task, roles
from service_model import (pull_new_code_base,
						   gpu_deploy,
						   remove_temp_code_base,
						   restart_server,
						   add_branch_name,
						   celery_deploy,
						   add_branch_name_celery_jobs)

env.forward_agent = True
env.user = "awakening"
env.GIT_USER = ""
env.timeout = 1
env.warn_only = True

HIPCHAT_TOKEN = "k60XBGOBksC6sAjCWmnntE6gGkMiaMw6BEgIDICu"
ROOM_ID = "2355861"
ENV_LIST = ["thor", "loki"]


def set_roles():
	with open('hosts.json') as hosts_file:
		hosts_info = json.load(hosts_file)

		environment = hosts_info.get(env.ENV)
		if not env.get("SERVER"):
			env.gateway = str(environment['hosts']['deployment'][0])
		return environment['hosts']


def load_context():

	if not env.get("ENV"):
		raise Exception("Please specify --set ENV=<val>")

	if not env.get("BRANCH"):
		print("Please specify --set BRANCH=<val> or we are deploying master")
		env.BRANCH = "main"

	if env.get("SERVER"):
		env.GIT_USER = "jenkins"
		env.forward_agent = False

	env.roledefs.update(set_roles())


@task
@roles('gpu')
def deploy_gpu():
	print("Deploy GPU Backend")
	remove_temp_code_base()
	pull_new_code_base(env.BRANCH)
	gpu_deploy(env.BRANCH, env.ENV)

	if env.ENV in ENV_LIST:
		add_branch_name(env.BRANCH, env.ENV)

	restart_server()
	remove_temp_code_base()


@task
@roles('celery_job')
def deploy_celery_job():
	print("Deploy GPU Celery")
	remove_temp_code_base()
	pull_new_code_base(env.BRANCH)
	celery_deploy(env.BRANCH, env.ENV)
	if env.ENV in ENV_LIST:
		add_branch_name_celery_jobs(env.BRANCH, env.ENV)
	remove_temp_code_base()


@task
def deploy():
	execute(deploy_gpu)
	execute(deploy_celery_job)

load_context()
