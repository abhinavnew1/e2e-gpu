ENVTYPE=$2
mv ${HOME}/worker_e2e-gpu/e2e-gpu ${HOME}/worker_e2e-gpu/e2e_gpu_last_deployed
mv  ${HOME}/temp_code_base/e2e-gpu ${HOME}/worker_e2e-gpu/
cd ${HOME}/worker_e2e-gpu/e2e-gpu
sed -i "s/production/${ENVTYPE}/g" ${HOME}/worker_e2e-gpu/e2e-gpu/e2e_gpu/e2e_gpu/celery.py
${HOME}/celery_env/bin/pip install -r e2e_gpu/ini/requirements.txt
sudo systemctl restart supervisord

