BRANCH=$1
ENVTYPE=$2

source ${HOME}/python_3.12_venv/bin/activate
#python ${HOME}/temp_code_base/awakening/ops/deployment/script/compressor.py
rm -rf ${HOME}/public_html/e2e_gpu
rm -rf ${HOME}/public_html/ops
cd ${HOME}/temp_code_base/e2e-gpu
sed -i "s/production/${ENVTYPE}/g" ${HOME}/temp_code_base/e2e-gpu/e2e_gpu/e2e_gpu/celery.py
cp -R e2e_gpu ops libs ${HOME}/public_html/
git log -n 1 --pretty=format:"%H" > ${HOME}/public_html/e2e_gpu/git_commit
cd ${HOME}/
cd ${HOME}/public_html/e2e_gpu
${HOME}/python_3.12_venv/bin/pip install -r ini/requirements.txt
python manage.py migrate --settings=e2e_gpu.config.${ENVTYPE}
python manage.py collectstatic --no-input --settings=e2e_gpu.config.${ENVTYPE}
