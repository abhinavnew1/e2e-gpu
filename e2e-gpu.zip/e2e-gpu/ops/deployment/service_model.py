from fabric.api import *

GIT_CHECKOUT_BRANCH_VARIABLE = "git checkout %s"


def remove_temp_code_base():
	run('rm -rf ${HOME}/temp_code_base')


def pull_new_code_base(branch):
	# Create temp folder to pull new code base
	run('mkdir temp_code_base')
	with cd('temp_code_base'):
		run('git clone git@awakeninggit.e2enetworks.net:cloud/e2e-gpu.git')
		with cd('e2e-gpu'):
			run(GIT_CHECKOUT_BRANCH_VARIABLE % branch)

def gpu_deploy(branch, environment):
	run('sh /home/awakening/temp_code_base/e2e-gpu/ops/deployment/script/deploy_gpu.sh %s %s' % (branch,

																										  environment))

def celery_deploy(branch, environment):
    run('sh /home/awakening/temp_code_base/e2e-gpu/ops/deployment/script/deploy_celery_jobs.sh %s %s' % (branch,
                                                                                                    environment))

def restart_server():
	run('python_3.12_venv/bin/uwsgi --reload uwsgi/project-master.pid')
	run('sudo systemctl restart gunicorn')


def add_branch_name(branch, environment):
	file_path = "public_html/e2e_gpu/e2e_gpu/config/%s.py" % environment
	run('echo "" >> %s' % (file_path))
	run('echo  GIT_BRANCH=\'\"\'%s\'\"\' >> %s' % (branch, file_path))

def add_branch_name_celery_jobs(branch, environment):
    file_path = "worker_e2e-gpu/e2e-gpu/e2e_gpu/e2e_gpu/config/%s.py" % environment
    run('echo "" >> %s' % (file_path))
    run('echo  GIT_BRANCH=\'\"\'%s\'\"\' >> %s' % (branch, file_path))